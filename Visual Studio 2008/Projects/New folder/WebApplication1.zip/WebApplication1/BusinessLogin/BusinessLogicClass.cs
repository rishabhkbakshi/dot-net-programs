﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DataAccess;
using BusinessOdject;
using System.Data;
using BusinessLogic;

namespace BusinessLogic
{
    public class BusinessLogicClass
    {
        public static DataTable LoginLogic(BusinessObjectClass LoginL)
        {
            DataAccessClass LoginData = new DataAccessClass();
            DataTable dt = LoginData.LoginToApply(LoginL);
            return LoginData.LoginToApply(LoginL);
        }

        public static DataTable SelectLeaveGrid(BusinessObjectClass LeaveLogicGrid)
        {
            DataAccessClass LeaveDataGrid = new DataAccessClass();
            return LeaveDataGrid.LeaveRequestGrid(LeaveLogicGrid);
        }

        public static string InsertLogic(BusinessObjectClass InsertObject)
        {
            DataAccessClass InsertLeave = new DataAccessClass();
            return InsertLeave.LeaveInsert(InsertObject);
        }

        public static DataTable SelectManagerGrid(BusinessObjectClass ManagerTableObject)
        {
            DataAccessClass UpdateLeaveManager = new DataAccessClass();
            return UpdateLeaveManager.BindManagerGrid(ManagerTableObject);
        }

        public static string UpdateByManagerLogic(BusinessObjectClass ManagerObject)
        {
            DataAccessClass InsertLeave = new DataAccessClass();
            return InsertLeave.LeaveUpdateManager(ManagerObject);
        }

        public static DataTable SelectHRGrid(BusinessObjectClass HRTableObject)
        {
            DataAccessClass UpdateLeaveHR = new DataAccessClass();
            return UpdateLeaveHR.BindHRGrid(HRTableObject);
        }

        public static string UpdateHRLogic(BusinessObjectClass HRObject)
        {
            DataAccessClass InsertLeave = new DataAccessClass();
            return InsertLeave.LeaveUpdateHR(HRObject);
        }

        public static string CancelRequest(BusinessObjectClass CancelObject)
        {
            DataAccessClass CancelLeave = new DataAccessClass();
            return CancelLeave.DeleteRequest(CancelObject);
        }
    }
}
