﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using BusinessOdject;

namespace DataAccess
{
    public class DataAccessClass
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public DataTable LoginToApply(BusinessObjectClass Login)
        {
            SqlCommand cmd = new SqlCommand("usp_UserLogin", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Designation", Login.Designation);
            cmd.Parameters.AddWithValue("@Username", Login.UserName);
            cmd.Parameters.AddWithValue("@Password", Login.Password);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;
        }

        public DataTable LeaveRequestGrid(BusinessObjectClass LeaveObject)
        {
            SqlCommand cmd = new SqlCommand("LeaveRequestSelect", con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;
        }

        public string LeaveInsert(BusinessObjectClass InsertLeaveRequest)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("LeaveRequestInsert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@LeaveFrom", InsertLeaveRequest.FromDate);
            cmd.Parameters.AddWithValue("@LeaveTo", InsertLeaveRequest.ToDate);
            cmd.Parameters.AddWithValue("@LeaveType", InsertLeaveRequest.LeaveType);
            cmd.Parameters.AddWithValue("@Reason", InsertLeaveRequest.LeaveReason);
            cmd.Parameters.AddWithValue("@Status", "Pending with Manager");
            DataTable dt = new DataTable();
            cmd.ExecuteNonQuery();
            con.Close();
            string str = "";
            return str;
        }

        public string DeleteRequest(BusinessObjectClass UpdateByHR)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("DeleteLeaveRequest", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", UpdateByHR.RequestId);
            cmd.ExecuteNonQuery();
            con.Close();
            string str = "";
            return str;
        }

        public DataTable BindManagerGrid(BusinessObjectClass ManagerPendingRequest)
        {
            SqlCommand cmd = new SqlCommand("usp_PendingWithManager", con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;
        }

        public string LeaveUpdateManager(BusinessObjectClass UpdateByManager)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("ApproveRequestSelect", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", UpdateByManager.RequestId);
            cmd.ExecuteNonQuery();
            con.Close();
            string str = "";
            return str;
        }

        public DataTable BindHRGrid(BusinessObjectClass HRPendingRequest)
        {
            SqlCommand cmd = new SqlCommand("usp_PendingWithHR", con);
            cmd.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            return dt;
        }

        
        public string LeaveUpdateHR(BusinessObjectClass UpdateByHR)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("ApproveHRRequestSelect", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Id", UpdateByHR.RequestId);
            cmd.ExecuteNonQuery();
            con.Close();
            string str = "";
            return str;
        }
    }
}
