﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using BusinessOdject;
using System.Data;

namespace WebApplication1
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            LoginToApplyLeave();
        }
        private void LoginToApplyLeave()
        {
            BusinessObjectClass Login = new BusinessObjectClass();
            Login.Designation = drpdownDesignation.SelectedItem.Text;
            Login.UserName = txtUsername.Text;
            Login.Password = txtPassword.Text;
            DataTable dt = BusinessLogicClass.LoginLogic(Login);
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    Session["Login"] = dt;
                    Session["Login"] = Convert.ToString(dt.Rows[0]["Username"]);
                    if (drpdownDesignation.SelectedValue == "0")
                    {
                        Response.Redirect("ApplyToLeave.aspx");
                    }
                    else if (drpdownDesignation.SelectedValue == "1")
                    {
                        Response.Redirect("Approve By Manager.aspx");
                    }
                    else
                    {
                        Response.Redirect("Approved By HR.aspx");
                    }
                }
                else
                {
                    lblResponse.Text = "Login Failed";
                }
            }
        }
    }
}
