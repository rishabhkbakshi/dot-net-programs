﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using BusinessOdject;
using System.Data;

namespace WebApplication1
{
    public partial class ApplyToLeave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Login"] != null)
            {
                lblResponseType.Text = "Welcome" + " " + Session["Login"].ToString();
                BindGrid();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnApply_Click(object sender, EventArgs e)
        {
            LeaveInsertion();
        }

        private void BindGrid()
        {
            BusinessObjectClass LeaveGridObject = new BusinessObjectClass();
            DataTable dt = BusinessLogicClass.SelectLeaveGrid(LeaveGridObject);
            LeaveGrid.DataSource = dt;
            LeaveGrid.DataBind();
        }

        private void LeaveInsertion()
        {
            BusinessObjectClass InsertLeaveObject = new BusinessObjectClass();
            InsertLeaveObject.FromDate = txtFromDate.Text;
            InsertLeaveObject.ToDate = txtToDate.Text;
            InsertLeaveObject.LeaveType = txtLeaveType.Text;
            InsertLeaveObject.LeaveReason = txtLeaveReason.Text;
            string str1 = BusinessLogicClass.InsertLogic(InsertLeaveObject);
            BindGrid();
        }

        protected void LeaveGrid_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            BusinessObjectClass CancelLeaveObject = new BusinessObjectClass();
            CancelLeaveObject.RequestId = Convert.ToInt32(LeaveGrid.DataKeys[e.RowIndex].Value);
            string str = BusinessLogicClass.CancelRequest(CancelLeaveObject);
            lblCancelRequest.Text = "Request Id-> " + "<u>" + "<b>" + 
                                    "<font size=4>" + CancelLeaveObject.RequestId + 
                                    "</font>" + "</b>" + "</u>" + "  is Completely Cancel";
            BindGrid();
        }

        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("Login.aspx");
        }
    }
}
