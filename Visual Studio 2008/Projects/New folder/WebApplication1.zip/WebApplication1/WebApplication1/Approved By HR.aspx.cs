﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using BusinessOdject;
using System.Data;

namespace WebApplication1
{
    public partial class Approved_By_HR : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Login"] != null)
            {
                lblResponseType.Text = "Welcome" + " " + Session["Login"].ToString();
                BindHRGrid();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnHRApprove_Click(object sender, EventArgs e)
        {
            Button ApproveManager = sender as Button;
            GridViewRow gvrow = (GridViewRow)ApproveManager.NamingContainer;
            BusinessObjectClass HRApproveObject = new BusinessObjectClass();
            HRApproveObject.RequestId = Convert.ToInt32(LeaveHRGrid.DataKeys[gvrow.RowIndex].Value);
            string str1 = BusinessLogicClass.UpdateHRLogic(HRApproveObject);
            lblHRRequestId.Text = "Request Id->  " + "<u>" + "<b>" +
                                  "<font size=4>" + HRApproveObject.RequestId +
                                  "</font>" + "</b>" + "</u>" + " is Completed";
            BindHRGrid();
        }

        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("Login.aspx");
        }

        private void BindHRGrid()
        {
            BusinessObjectClass HRGridObject = new BusinessObjectClass();
            DataTable dt = BusinessLogicClass.SelectHRGrid(HRGridObject);
            LeaveHRGrid.DataSource = dt;
            LeaveHRGrid.DataBind();
        }
    }
}
