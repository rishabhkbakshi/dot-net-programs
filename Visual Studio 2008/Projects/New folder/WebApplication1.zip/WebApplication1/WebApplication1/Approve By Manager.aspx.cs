﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessLogic;
using BusinessOdject;
using System.Data;

namespace WebApplication1
{
    public partial class Approve_By_Manager : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Login"] != null)
            {
                lblResponseType.Text = "Welcome" + " " + Session["Login"].ToString();
                BindManagerGrid();
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnManagerApprove_Click(object sender, EventArgs e)
        {
            Button ApproveManager = sender as Button;
            GridViewRow gvrow = (GridViewRow)ApproveManager.NamingContainer;
            BusinessObjectClass ManagerApproveObject = new BusinessObjectClass();
            ManagerApproveObject.RequestId = Convert.ToInt32(LeaveManagerGrid.DataKeys[gvrow.RowIndex].Value);
            string str1 = BusinessLogicClass.UpdateByManagerLogic(ManagerApproveObject);
            lblManagerRequestId.Text = "Request Id->  " + "<u>" + "<b>" + 
                                       "<font size=4>" + ManagerApproveObject.RequestId + 
                                       "</font>" + "</b>" + "</u>" + " is Pending with HR";
            BindManagerGrid();
        }

        protected void lnkbtnLogOut_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.Clear();
            Response.Redirect("Login.aspx");
        }

        private void BindManagerGrid()
        {
            BusinessObjectClass ManagerGridObject = new BusinessObjectClass();
            DataTable dt = BusinessLogicClass.SelectManagerGrid(ManagerGridObject);
            LeaveManagerGrid.DataSource = dt;
            LeaveManagerGrid.DataBind();
        }
    }
}
