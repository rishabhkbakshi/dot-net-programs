﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public  class clsVehicleTypesBD
    {
        private System.Int64 _VehicleTypesId = 0;
        private System.Int64 _ClassOfVehicle = 0;
        private System.Int64 _TypeOfBody = 0;
        private System.String _CC = string.Empty;
        private System.Decimal _ApprovedRate = 0;
        private System.DateTime _FromDate;
        private System.DateTime _ToDate;       
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;

        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// ToDate properties
        /// </summary>
        public System.DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }
        /// <summary>
        /// FromDate properties
        /// </summary>
        public System.DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }
        /// <summary>
        /// ApprovedRate properties
        /// </summary>
        public System.Decimal ApprovedRate
        {
            get { return _ApprovedRate; }
            set { _ApprovedRate = value; }
        }
        /// <summary>
        /// CC properties
        /// </summary>
        public System.String CC
        {
            get { return _CC; }
            set { _CC = value; }
        }
        /// <summary>
        /// TypeOfBody properties
        /// </summary>
        public System.Int64 TypeOfBody
        {
            get { return _TypeOfBody; }
            set { _TypeOfBody = value; }
        }
        /// <summary>
        /// ClassOfVehicle properties
        /// </summary>
        public System.Int64 ClassOfVehicle
        {
            get { return _ClassOfVehicle; }
            set { _ClassOfVehicle = value; }
        }
        /// <summary>
        /// VehicleTypesId properties
        /// </summary>
        public System.Int64 VehicleTypesId
        {
            get { return _VehicleTypesId; }
            set { _VehicleTypesId = value; }
        }
    }//Class Close
}//NameSpace Close
