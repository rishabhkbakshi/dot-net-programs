﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsGradeMasterBD
    {
        private System.Int64 _GradeId = 0;
        private System.String _GradeName = string.Empty;
        private System.String _Descriptions = string.Empty;
        private System.String _Alias = string.Empty;       
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.Int64 _ParentId = 0;
        private System.String _Level = string.Empty;

       


       

        private System.String _cFlag = string.Empty;
        public clsGradeMasterBD()
        {
        }

        clsGradeMasterBD(System.String CFlag,System.Int64 GradeId, System.String GradeName, System.String Descriptions, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _cFlag = CFlag;
            _GradeId = GradeId;
            _GradeName = GradeName;
            _Descriptions = Descriptions;
            _Alias=Alias;
            _DOC=DOC;
            _DOU=DOU;
            _Status=Status;
            _TransactionId = TransactionId;
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// GradeName properties
        /// </summary>
        public System.String GradeName
        {
            get { return _GradeName; }
            set { _GradeName = value; }
        }
        /// <summary>
        /// Grade Descriptions properties
        /// </summary>
        public System.String Descriptions
        {
            get { return _Descriptions; }
            set { _Descriptions = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// ParentId properties
        /// </summary>
        public System.Int64 ParentId
        {
            get { return _ParentId; }
            set { _ParentId = value; }
        }
        /// <summary>
        /// Level properties
        /// </summary>
        public System.String Level
        {
            get { return _Level; }
            set { _Level = value; }
        }
    }//Class Close
}//NameSpace Close

