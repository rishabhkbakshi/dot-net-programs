﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsOrganizationStructureTypeBD
    {
        private System.Int64 _OrganisationStructureTypeId = 0;
        private System.String _Name = string.Empty;
        private System.String _Level = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        public clsOrganizationStructureTypeBD()
        { }

        clsOrganizationStructureTypeBD(System.String CFlag, System.Int64 OrganisationStructureTypeId, System.String Name, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId, System.String Level)
        {
            _cFlag = CFlag;
            _OrganisationStructureTypeId = OrganisationStructureTypeId;
            _Name = Name;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
            _Level = Level;
        }
        /// <summary>
        /// OrganisationStructureTypeId properties
        /// </summary>
        public System.Int64 OrganisationStructureTypeId
        {
            get { return _OrganisationStructureTypeId; }
            set { _OrganisationStructureTypeId = value; }
        }
        /// <summary>
        /// Name properties
        /// </summary>
        public System.String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// Level properties
        /// </summary>
        public System.String Level
        {
            get { return _Level; }
            set { _Level = value; }
        }   
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close

