﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
   public class clsVendorMasterBD
    {
        #region "--Private Variable--"
        private System.Int64 _VendorId = 0;       
        private System.String _VendorName = string.Empty;        
        private System.Int64 _VendorType = 0;        
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Private Variable--"
        /// <summary>
        /// VendorId properties
        /// </summary>
        public System.Int64 VendorId
        {
            get { return _VendorId; }
            set { _VendorId = value; }
        }
        /// <summary>
        /// VendorName properties
        /// </summary>
        public System.String VendorName
        {
            get { return _VendorName; }
            set { _VendorName = value; }
        }
        /// <summary>
        /// VendorType properties
        /// </summary>
        public System.Int64 VendorType
        {
            get { return _VendorType; }
            set { _VendorType = value; }
        }

        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion

    }
}
