﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsPolicyGradeMappingBD
    {
        private System.Int64 _PolicyGradeMappingId = 0;
        private System.Int64 _ReferencePolicyId = 0;
        private System.Int64 _GradeId = 0;     
        private System.String _ReferencePolicyType = string.Empty;       
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.String _cFlag = string.Empty;

        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

        public System.Int64 PolicyGradeMappingId
        {
            get { return _PolicyGradeMappingId; }
            set { _PolicyGradeMappingId = value; }
        }
        public System.Int64 ReferencePolicyId
        {
            get { return _ReferencePolicyId; }
            set { _ReferencePolicyId = value; }
        }
        public System.String ReferencePolicyType
        {
            get { return _ReferencePolicyType; }
            set { _ReferencePolicyType = value; }
        }
        public System.Int64 GradeId
        {
             get { return _GradeId; }
             set { _GradeId = value; }
        }
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
    }
}
