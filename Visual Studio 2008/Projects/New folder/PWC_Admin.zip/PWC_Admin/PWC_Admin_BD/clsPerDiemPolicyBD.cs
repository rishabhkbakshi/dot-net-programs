﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsPerDiemPolicyBD
    {
        private System.Int64 _PerDiemPolicyId = 0;
        private System.Int64 _TravelType = 0;
        private System.Int64 _GradeId = 0;
        private System.String _Specific = string.Empty;
        private System.Decimal _Amount = 0;
        private System.Int64 _Currency = 0;
        private System.Boolean _IsEquivalent = false;
        private System.DateTime _EffectiveFrom;
        private System.DateTime _EffectiveTo;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        private System.String _ForValue = string.Empty;
        private System.String _ForUnit = string.Empty;
        private System.String _Allowance = string.Empty;
        private System.Int64 _CountryId = 0;

        /// <summary>
        /// PerDiemPolicyId properties
        /// </summary>
        public System.Int64 PerDiemPolicyId
        {
            get { return _PerDiemPolicyId; }
            set { _PerDiemPolicyId = value; }
        }
        /// <summary>
        /// TravelType properties
        /// </summary>
        public System.Int64 TravelType
        {
            get { return _TravelType; }
            set { _TravelType = value; }
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// NoOfNights properties
        /// </summary>
        //public System.Int32 NoOfNights
        //{
        //    get { return _NoOfNights; }
        //    set { _NoOfNights = value; }
        //}
        /// <summary>
        /// Specific properties
        /// </summary>
        public System.String Specific
        {
            get { return _Specific; }
            set { _Specific = value; }
        }
        /// <summary>
        /// Amount properties
        /// </summary>
        public System.Decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
        /// <summary>
        /// Currency properties
        /// </summary>
        public System.Int64 Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }
        /// <summary>
        /// IsEquivalent properties
        /// </summary>
        public System.Boolean IsEquivalent
        {
            get { return _IsEquivalent; }
            set { _IsEquivalent = value; }
        }
        /// <summary>
        /// EffectiveFrom properties
        /// </summary>
        public System.DateTime EffectiveFrom
        {
            get { return _EffectiveFrom; }
            set { _EffectiveFrom = value; }
        }
        /// <summary>
        /// EffectiveTo properties
        /// </summary>
        public System.DateTime EffectiveTo
        {
            get { return _EffectiveTo; }
            set { _EffectiveTo = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

        public System.String ForValue
        {
            get { return _ForValue; }
            set { _ForValue = value; }
        }
        public System.String ForUnit
        {
            get { return _ForUnit; }
            set { _ForUnit = value; }
        }
        public System.String Allowance
        {
            get { return _Allowance; }
            set { _Allowance = value; }
        }
        /// <summary>
        /// CountryId properties
        /// </summary>
        public System.Int64 CountryId
        {
            get { return _CountryId; }
            set { _CountryId = value; }
        }

    }//Class Close
}//NameSpace Close

