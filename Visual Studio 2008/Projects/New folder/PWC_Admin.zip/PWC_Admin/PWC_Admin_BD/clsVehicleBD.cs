﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsVehicleBD
    {
        #region "PRIVATE VARIABLE"

        String _Flag;
        Int64 _VehicleId;
        String _Make;
        String _Model;
        Int64 _VehicleType;
        String _RegistrationNumber;
        String _AllocatedTo;
        String _Alias;
        DateTime _DOC;
        DateTime _DOU;
        String _Status;
        Int64 _TransactionId;

        #endregion "PRIVATE VARIABLE"

        #region "PUBLIC PROPERTIES"

        public String Flag
        {
            get { return _Flag; }
            set { _Flag = value; }
        }

        /// <summary>
        /// Properties:VehicleId
        /// </summary>
        public Int64 VehicleId
        {
            get { return _VehicleId; }
            set { _VehicleId = value; }
        }

        /// <summary>
        /// Properties:Make
        /// </summary>
        public String Make
        {
            get { return _Make; }
            set { _Make = value; }
        }

        /// <summary>
        /// Properties:Model
        /// </summary>
        public String Model
        {
            get { return _Model; }
            set { _Model = value; }
        }

        /// <summary>
        /// Properties:VehicleType
        /// </summary>
        public Int64 VehicleType
        {
            get { return _VehicleType; }
            set { _VehicleType = value; }
        }

        /// <summary>
        /// Properties:RegistrationNumber
        /// </summary>
        public String RegistrationNumber
        {
            get { return _RegistrationNumber; }
            set { _RegistrationNumber = value; }
        }

        /// <summary>
        /// Properties:AllocatedTo
        /// </summary>
        public String AllocatedTo
        {
            get { return _AllocatedTo; }
            set { _AllocatedTo = value; }
        }

        /// <summary>
        /// Properties:Alias
        /// </summary>
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }

        /// <summary>
        /// Properties:DOC
        /// </summary>
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Properties:DOU
        /// </summary>
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Properties:Status
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        /// <summary>
        /// Properties:TransactionId
        /// </summary>
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }

        #endregion "PUBLIC PROPERTIES"

    }
}
