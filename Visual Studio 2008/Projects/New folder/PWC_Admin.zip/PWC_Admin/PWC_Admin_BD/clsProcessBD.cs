﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Admin.BD
{
    public class clsProcessBD
    {
        #region "PRIVATE INSTANCE VARIABLES"

        private System.String _Flag;
        private System.Int64 _ProcessId;
        private System.String _ProcessName;
        private System.Int64 _ParentId;
        private System.Boolean _NeedDocumentMgt;
        private System.Boolean _NeedApprovers;
        private System.Boolean _NeedEnforceSLA;
        private System.String _DefaultURL;
        private System.String _OnErrorURL;
        private System.Int16 _SequenceNo;
        private System.String _Alias;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status;
        private System.String _ImageUrl;

        #endregion

        #region "PUBLIC PROPERTIES"
        
        /// <summary>
        /// Property : Flag
        /// </summary>
        public System.String Flag
        {
            get { return _Flag; }
            set { _Flag = value; }
        }
        /// <summary>
        /// Property : ProcessId
        /// </summary>
        public System.Int64 ProcessId
        {
            get { return _ProcessId; }
            set { _ProcessId = value; }
        }

        /// <summary>
        /// Property : ProcessName
        /// </summary>
        public System.String ProcessName
        {
            get { return _ProcessName; }
            set { _ProcessName = value; }
        }

        
        /// <summary>
        /// Property : ParentId
        /// </summary>
        public System.Int64 ParentId
        {
            get { return _ParentId; }
            set { _ParentId = value; }
        }

        /// <summary>
        /// Property : NeedDocumentMgt
        /// </summary>
        public System.Boolean NeedDocumentMgt
        {
            get { return _NeedDocumentMgt; }
            set { _NeedDocumentMgt = value; }
        }

        /// <summary>
        /// Property : NeedApprovers
        /// </summary>
        public System.Boolean NeedApprovers
        {
            get { return _NeedApprovers; }
            set { _NeedApprovers = value; }
        }

        /// <summary>
        /// Property : NeedEnforceSLA
        /// </summary>
        public System.Boolean NeedEnforceSLA
        {
            get { return _NeedEnforceSLA; }
            set { _NeedEnforceSLA = value; }
        }

        /// <summary>
        /// Property : DefaultURL
        /// </summary>
        public System.String DefaultURL
        {
            get { return _DefaultURL; }
            set { _DefaultURL = value; }
        }

        /// <summary>
        /// Property : OnErrorURL
        /// </summary>
        public System.String OnErrorURL
        {
            get { return _OnErrorURL; }
            set { _OnErrorURL = value; }
        }

        /// <summary>
        /// Property : SequenceNo
        /// </summary>
        public System.Int16 SequenceNo
        {
            get { return _SequenceNo; }
            set { _SequenceNo = value; }
        }

        /// <summary>
        /// Property : Alias
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }

        /// <summary>
        /// Property : DOC
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Property : DOU
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Status
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// ImageUrl
        /// </summary>
        public System.String ImageUrl
        {
            get { return _ImageUrl; }
            set { _ImageUrl = value; }
        }
        #endregion
    }
}
