﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsVehicleTypeBD
    {
        private System.Int64 _VehicleTypeId = 0;
        private System.String _VehicleName = string.Empty;
        private System.Boolean _IsAc = false;
        private System.Boolean _Is4Wheeler = false;
        private System.Decimal _Rate = 0;
        private System.Int64 _Unit = 0;
        private System.Int64 _Currency = 0;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;


        public clsVehicleTypeBD()
        { }


        public clsVehicleTypeBD(System.String CFlag,System.Int64 VehicleTypeId,System.String VehicleName, System.Boolean IsAc, System.Boolean Is4Wheeler,System.Decimal _Rate,System.Int64 Unit,System.Int64 Currency ,System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _cFlag = CFlag;
            _VehicleTypeId = VehicleTypeId;
            _VehicleName = VehicleName;
            _IsAc = IsAc;
            _Is4Wheeler = Is4Wheeler;
            _Rate = Rate;
            _Unit = Unit;
            _Currency = Currency;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
        }

        /// <summary>
        /// VehicleTypeId properties
        /// </summary>
        public System.Int64 VehicleTypeId
        {
            get { return _VehicleTypeId; }
            set { _VehicleTypeId = value; }
        }
        /// <summary>
        /// VehicleName properties
        /// </summary>
        public System.String VehicleName
        {
            get { return _VehicleName; }
            set { _VehicleName = value; }
        }
        /// <summary>
        /// IsAc properties
        /// </summary>
        public System.Boolean IsAc
        {
            get { return _IsAc; }
            set { _IsAc = value; }
        }
        /// <summary>
        /// Is4Wheeler properties
        /// </summary>
        public System.Boolean Is4Wheeler
        {
            get { return _Is4Wheeler; }
            set { _Is4Wheeler = value; }
        }
        /// <summary>
        /// Rate properties
        /// </summary>
        public System.Decimal Rate
        {
            get { return _Rate; }
            set { _Rate = value; }
        }
        /// <summary>
        /// Unit properties
        /// </summary>
        public System.Int64 Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        /// <summary>
        /// Currency properties
        /// </summary>
        public System.Int64 Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close

