﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsApprovalMasterBD
    {
        #region "PRIVATE INSTANCE VARIABLES"

        String _Flag;

        Int64 _ApprovalMasterId;
        Int64 _ProcessId;
        String _ProcessName;
        DateTime _FromDate;
        DateTime _ToDate;
        Boolean _IsEscalated;
        Int16 _EscalationAlertDuration;
        Int64 _Unit;
        String _UnitName;
        Int64 _Currency;
        String _CurrencyName;
        String _Alias;
        DateTime _DOC;
        DateTime _DOU;
        String _Status;
        Int64 _TransactionId;

        #endregion

        #region "PUBLIC PROPERTIES"


        public String Flag
        {
            get { return _Flag; }
            set { _Flag = value; }
        }

        /// <summary>
        /// Properties:ApprovalMasterId
        /// </summary>
        public Int64 ApprovalMasterId
        {
            get { return _ApprovalMasterId; }
            set { _ApprovalMasterId = value; }
        }

        /// <summary>
        /// Properties:ProcessId
        /// </summary>
        public Int64 ProcessId
        {
            get { return _ProcessId; }
            set { _ProcessId = value; }
        }
        public String ProcessName
        {
            get { return _ProcessName; }
            set { _ProcessName = value; }
        }
        /// <summary>
        /// Properties:FromDate
        /// </summary>
        public DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }

        /// <summary>
        /// Properties:ToDate
        /// </summary>
        public DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }

        /// <summary>
        /// Properties:IsEscalated
        /// </summary>
        public Boolean IsEscalated
        {
            get { return _IsEscalated; }
            set { _IsEscalated = value; }
        }

        /// <summary>
        /// Properties:EscalationAlertDuration
        /// </summary>
        public Int16 EscalationAlertDuration
        {
            get { return _EscalationAlertDuration; }
            set { _EscalationAlertDuration = value; }
        }

        /// <summary>
        /// Properties:Unit
        /// </summary>
        public Int64 Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        public String UnitName
        {
            get { return _UnitName; }
            set { _UnitName = value; }
        }
        /// <summary>
        /// Properties:Currency
        /// </summary>
        public Int64 Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }
        public String CurrencyName
        {
            get { return _CurrencyName; }
            set { _CurrencyName = value; }
        }
        /// <summary>
        /// Properties:Alias
        /// </summary>
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }

        /// <summary>
        /// Properties:DOC
        /// </summary>
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Properties:DOU
        /// </summary>
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Properties:Status
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        /// <summary>
        /// Properties:TransactionId
        /// </summary>
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }

        #endregion
    }
}
