﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsVendorServiceChargesBD
    {
        #region "private variables"
            private System.String _cFlag = "N";
            private System.Int64 _VendorServiceChargeId = 0;
            private System.Int64 _VendorId = 0;
            private System.Int64 _TypeOfTravelId = 0;
            private System.Int64 _TravelModeId = 0;
            private System.DateTime _EffectiveFromDate;
            private System.DateTime _EffectiveToDate;
            private System.String _Status = string.Empty;
            private System.Decimal _Amount = 0;
            private System.Int64 _CurrencyId = 0;
            private System.DateTime _DOC;
            private System.DateTime _DOU;
            private System.Int64 _TransactionId = 0;
            private System.Int64 _ServiceTypeID = 0;
        #endregion
        #region "--Public Properties--"
            public System.String CFlag
            {
                get { return _cFlag; }
                set { _cFlag = value; }
            }
            public System.Int64 VendorServiceChargeId
            {
                get { return _VendorServiceChargeId; }
                set { _VendorServiceChargeId = value; }
            }
            public System.Int64 VendorId
            {
                get { return _VendorId; }
                set { _VendorId = value; }
            }
            public System.Int64 TypeOfTravelId
            {
                get { return _TypeOfTravelId; }
                set { _TypeOfTravelId = value; }
            }
            public System.Int64 TravelModeId
            {
                get { return _TravelModeId; }
                set { _TravelModeId = value; }
            }
            public System.DateTime EffectiveFromDate
            {
                get { return _EffectiveFromDate; }
                set { _EffectiveFromDate = value; }
            }
            public System.DateTime EffectiveToDate
            {
                get { return _EffectiveToDate; }
                set { _EffectiveToDate = value; }
            }
            public System.String Status
            {
                get { return _Status; }
                set { _Status = value; }
            }
            public System.Decimal Amount
            {
                get { return _Amount; }
                set { _Amount = value; }
            }
            public System.Int64 CurrencyId
            {
                get { return _CurrencyId; }
                set { _CurrencyId = value; }
            }
            public System.DateTime DOC
            {
                get { return _DOC; }
                set { _DOC = value; }
            }
            public System.DateTime DOU
            {
                get { return _DOU; }
                set { _DOU = value; }
            }
            public System.Int64 TransactionId
            {
                get { return _TransactionId; }
                set { _TransactionId = value; }
            }
            public System.Int64 ServiceTypeID
            {
                get { return _ServiceTypeID; }
                set { _ServiceTypeID = value; }
            }
        #endregion
    }
}
