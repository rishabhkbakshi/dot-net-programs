﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAccomodationPolicyBD
    {
        #region "--Private Variable--"
        private System.Int64 _AccomodationPolicyId = 0;
        private System.Int64 _GradeId = 0;
        private System.Int64 _TravelType = 0;
        private System.Int64 _AccomodationRateId = 0;
        private System.String _Gender = string.Empty;
        private System.String _PriorityOfAllocation = string.Empty;
        private System.DateTime _EffectiveFROMDate;
        private System.DateTime _EffectiveToDate;
        private System.Boolean _IsEnforcePriority;
        private System.Boolean _IsBehalfOfBooking;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// AccomodationPolicyId properties
        /// </summary>
        public System.Int64 AccomodationPolicyId
        {
            get { return _AccomodationPolicyId; }
            set { _AccomodationPolicyId = value; }
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// TravelType properties
        /// </summary>
        public System.Int64 TravelType
        {
            get { return _TravelType; }
            set { _TravelType = value; }
        }
        /// <summary>
        /// Gender properties
        /// </summary>
        public System.String Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        /// <summary>
        /// AccomodationRateId properties
        /// </summary>
        public System.Int64 AccomodationRateId
        {
            get { return _AccomodationRateId; }
            set { _AccomodationRateId = value; }
        }
        /// <summary>
        /// PriorityOfAllocation properties
        /// </summary>
        public System.String PriorityOfAllocation
        {
            get { return _PriorityOfAllocation; }
            set { _PriorityOfAllocation = value; }
        }
        /// <summary>
        /// EffectiveFROMDate properties
        /// </summary>

        public System.DateTime EffectiveFROMDate
        {
            get { return _EffectiveFROMDate; }
            set { _EffectiveFROMDate = value; }
        }
        /// <summary>
        /// EffectiveToDate properties
        /// </summary>
        public System.DateTime EffectiveToDate
        {
            get { return _EffectiveToDate; }
            set { _EffectiveToDate = value; }
        }
        /// <summary>
        /// IsEnforcePriority properties
        /// </summary>
        public System.Boolean IsEnforcePriority
        {
            get { return _IsEnforcePriority; }
            set { _IsEnforcePriority = value; }
        }
        /// <summary>
        /// IsBehalfOfBooking properties
        /// </summary>
        public System.Boolean IsBehalfOfBooking
        {
            get { return _IsBehalfOfBooking; }
            set { _IsBehalfOfBooking = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion
    }
}
