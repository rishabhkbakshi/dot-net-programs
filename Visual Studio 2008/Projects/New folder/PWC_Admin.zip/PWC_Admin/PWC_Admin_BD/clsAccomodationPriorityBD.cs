﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAccomodationPriorityBD
    {
        #region "--Private Variable--"
        private System.Int64 _AccomodationPriorityId = 0;
        private System.Int64 _AccomodationPolicyId = 0;        
        private System.Int64 _AccomodationType = 0;        
        private System.String _AccomodationName = string.Empty;
        private System.Int32 _Priority = 0;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// AccomodationPriorityId properties
        /// </summary>
        public System.Int64 AccomodationPriorityId
        {
            get { return _AccomodationPriorityId; }
            set { _AccomodationPriorityId = value; }
        }
        /// <summary>
        /// AccomodationPolicyId properties
        /// </summary>
        public System.Int64 AccomodationPolicyId
        {
            get { return _AccomodationPolicyId; }
            set { _AccomodationPolicyId = value; }
        }        
        /// <summary>
        /// AccomodationType properties
        /// </summary>
        public System.Int64 AccomodationType
        {
            get { return _AccomodationType; }
            set { _AccomodationType = value; }
        }
        /// <summary>
        /// AccomodationName properties
        /// </summary>
        public System.String AccomodationName
        {
            get { return _AccomodationName; }
            set { _AccomodationName = value; }
        }
        /// <summary>
        /// Priority properties
        /// </summary>
        public System.Int32 Priority
        {
            get { return _Priority; }
            set { _Priority = value; }
        }               
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion
    }
}
