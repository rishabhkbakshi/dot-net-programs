﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsExpenseGLCodeMappingBD
    {
        public long ExpGL_Id { get; set; }
        public string Flag { get; set; }
        public int ExpenseCategory { get; set; }
        public string GLCode { get; set; }
        public string TravelType { get; set; }
        public float Debit { get; set; }
        public float Credit { get; set; }
        public string Status { get; set; }
        public DateTime DOC { get; set; }
        public DateTime DOU { get; set; }
        public long TransactionId { get; set; }
    }
}
