﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAccomodationRateBD
    {

        #region "--Private Variable--"
        private System.Int64 _AccomodationRateId = 0;
        private System.Int64 _CityGradeId = 0;
        private System.Decimal _Rate = 0;
        private System.Int64 _Unit = 0;
        private System.Int64 _Currency = 0;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// AccomodationRateId properties
        /// </summary>
        public System.Int64 AccomodationRateId
        {
            get { return _AccomodationRateId; }
            set { _AccomodationRateId = value; }
        }
        /// <summary>
        /// CityGradeId properties
        /// </summary>
        public System.Int64 CityGradeId
        {
            get { return _CityGradeId; }
            set { _CityGradeId = value; }
        }
        /// <summary>
        /// Rate properties
        /// </summary>
        public System.Decimal Rate
        {
            get { return _Rate; }
            set { _Rate = value; }
        }
        /// <summary>
        /// Unit properties
        /// </summary>
        public System.Int64 Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        /// <summary>
        /// Currency properties
        /// </summary>
        public System.Int64 Currency
        {
            get { return _Currency; }
            set { _Currency = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion
    }
}
