﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsStateMasterBD
    {
        private System.Int64 _StateId = 0;
        private System.String _StateName = string.Empty;
        private System.Int64 _CountryId = 0;
        private System.String _Alias = string.Empty;       
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        


        /// <summary>
        /// StateId properties
        /// </summary>
        public System.Int64 StateId
        {
            get { return _StateId; }
            set { _StateId = value; }
        }
        /// <summary>
        /// StateName properties
        /// </summary>
        public System.String StateName
        {
            get { return _StateName; }
            set { _StateName = value; }
        }
        /// <summary>
        /// CountryId properties
        /// </summary>
        public System.Int64 CountryId
        {
            get { return _CountryId; }
            set { _CountryId = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close


