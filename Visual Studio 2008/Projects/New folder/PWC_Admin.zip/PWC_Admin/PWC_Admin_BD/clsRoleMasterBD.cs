﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsRoleMasterBD
    {
        private System.Int64 _RoleId = 0;
        private System.String _Name = string.Empty;
        private System.Int64 _OrganisationStructureId = 0;        
        private System.String _Alias = string.Empty;       
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        public clsRoleMasterBD()
        { }

        clsRoleMasterBD(System.String CFlag, System.Int64 RoleId, System.String Name, System.Int64 OrganisationStructureId, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _cFlag = CFlag;
            _RoleId = RoleId;
            _Name = Name;
            _OrganisationStructureId = OrganisationStructureId;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
        }

        /// <summary>
        /// RoleId
        /// </summary>
        public System.Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }
        /// <summary>
        /// Name properties
        /// </summary>
        public System.String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// OrganisationStructureId properties
        /// </summary>
        public System.Int64 OrganisationStructureId
        {
            get { return _OrganisationStructureId; }
            set { _OrganisationStructureId = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close
