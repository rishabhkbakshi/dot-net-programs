﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    [Serializable]
    public class clsApprovalEscalationDetailsBD
    {
        #region "PRIVATE INSTANCE VARIABLES"

        String _Flag;
        Int64 _ApprovalEscalationDetailId;
        Int64 _ApprovalDetailId;
        Int64 _RoleId;
        String _RoleName;
        Int16 _Sequence;
        String _Alias;
        DateTime _DOC;
        DateTime _DOU;
        String _Status;
        Int64 _TransactionId;

        #endregion

        #region "PUBLIC PROPERTIES"

        public String Flag
        {
            get { return _Flag; }
            set { _Flag = value; }
        }

        /// <summary>
        /// Properties:ApprovalEscalationDetailId
        /// </summary>
        public Int64 ApprovalEscalationDetailId
        {
            get { return _ApprovalEscalationDetailId; }
            set { _ApprovalEscalationDetailId = value; }
        }

        /// <summary>
        /// Properties:ApprovalDetailId
        /// </summary>
        public Int64 ApprovalDetailId
        {
            get { return _ApprovalDetailId; }
            set { _ApprovalDetailId = value; }
        }

        /// <summary>
        /// Properties:RoleId
        /// </summary>
        public Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }

        /// <summary>
        /// Properties:RoleName
        /// </summary>
        public String RoleName
        {
            get { return _RoleName; }
            set { _RoleName = value; }
        }

        /// <summary>
        /// Properties:Sequence
        /// </summary>
        public Int16 Sequence
        {
            get { return _Sequence; }
            set { _Sequence = value; }
        }

        /// <summary>
        /// Properties:Alias
        /// </summary>
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }

        /// <summary>
        /// Properties:DOC
        /// </summary>
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Properties:DOU
        /// </summary>
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Properties:Status
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        /// <summary>
        /// Properties:TransactionId
        /// </summary>
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }

        #endregion
    }
}
