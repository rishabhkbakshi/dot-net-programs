﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Admin.BD
{
    public class clsTravelPolicyBD
    {
        #region "--Private Variable--"
        private System.Int64 _TravelPolicyId = 0;       
        private System.Int64 _GradeId = 0;        
        private System.Int64 _TravelType = 0;        
        private System.String _Gender = string.Empty;        
        private System.Decimal _DurationOfTravel = 0;        
        private System.Int64 _Unit = 0;        
        private System.Int64 _DefaultModeOfTravel = 0;        
        private System.Int64 _DefaultClASsOfTravel = 0;       
        private System.Int64 _AlternateModeOfTravel = 0;        
        private System.Int64 _AlternateClASsOfTravel = 0;        
        private System.DateTime _EffectiveFROMDate;       
        private System.DateTime _EffectiveToDate;        
        private System.Boolean _IsBehalfOfBooking;        
        private System.String _Alias = string.Empty;        
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// TravelPolicyId properties
        /// </summary>
        public System.Int64 TravelPolicyId
        {
            get { return _TravelPolicyId; }
            set { _TravelPolicyId = value; }
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// TravelMode properties
        /// </summary>
        public System.Int64 TravelType
        {
            get { return _TravelType; }
            set { _TravelType = value; }
        }
        /// <summary>
        /// Gender properties
        /// </summary>
        public System.String Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        /// <summary>
        /// DurationOfTravel properties
        /// </summary>
        public System.Decimal DurationOfTravel
        {
            get { return _DurationOfTravel; }
            set { _DurationOfTravel = value; }
        }
        /// <summary>
        /// Unit properties
        /// </summary>
        public System.Int64 Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        /// <summary>
        /// DefaultModeOfTravel properties
        /// </summary>
        public System.Int64 DefaultModeOfTravel
        {
            get { return _DefaultModeOfTravel; }
            set { _DefaultModeOfTravel = value; }
        }
        /// <summary>
        /// DefaultClASsOfTravel properties
        /// </summary>
        public System.Int64 DefaultClASsOfTravel
        {
            get { return _DefaultClASsOfTravel; }
            set { _DefaultClASsOfTravel = value; }
        }
        /// <summary>
        /// AlternateModeOfTravel properties
        /// </summary>
        public System.Int64 AlternateModeOfTravel
        {
            get { return _AlternateModeOfTravel; }
            set { _AlternateModeOfTravel = value; }
        }
        /// <summary>
        /// AlternateClASsOfTravel properties
        /// </summary>
        public System.Int64 AlternateClASsOfTravel
        {
            get { return _AlternateClASsOfTravel; }
            set { _AlternateClASsOfTravel = value; }
        }
        /// <summary>
        /// EffectiveFROMDate properties
        /// </summary>

        public System.DateTime EffectiveFROMDate
        {
            get { return _EffectiveFROMDate; }
            set { _EffectiveFROMDate = value; }
        }
        /// <summary>
        /// EffectiveToDate properties
        /// </summary>
        public System.DateTime EffectiveToDate
        {
            get { return _EffectiveToDate; }
            set { _EffectiveToDate = value; }
        }
        /// <summary>
        /// IsBehalfOfBooking properties
        /// </summary>
        public System.Boolean IsBehalfOfBooking
        {
            get { return _IsBehalfOfBooking; }
            set { _IsBehalfOfBooking = value; }
        }        
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion

    }
}
