﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsOrganizationStructureBD
    {
        private System.Int64 _OrganisationStructureId = 0;
        private System.String _Name = string.Empty;
        private System.Int64 _OrganisationStructureTypeId = 0;
        private System.String _CostCenter = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        private System.Int64 _ParentId = 0;
        private System.String _OrganisationStructureTypeName = string.Empty;

        public clsOrganizationStructureBD() { }

        clsOrganizationStructureBD(System.String CFlag, System.Int64 OrganisationStructureId, System.String Name, System.Int64 OrganisationStructureTypeId, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId, System.Int64 ParentId)
        {
            _cFlag = CFlag;
            _OrganisationStructureId = OrganisationStructureId;
            _Name = Name;
            _OrganisationStructureTypeId = OrganisationStructureTypeId;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
            _CostCenter = CostCenter;
            _ParentId = ParentId;
        }


        /// <summary>
        /// OrganisationStructureId properties
        /// </summary>
        public System.Int64 OrganisationStructureId
        {
            get { return _OrganisationStructureId; }
            set { _OrganisationStructureId = value; }
        }
        /// <summary>
        /// Name properties
        /// </summary>
        public System.String Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        /// <summary>
        /// OrganisationStructureTypeId properties
        /// </summary>
        public System.Int64 OrganisationStructureTypeId
        {
            get { return _OrganisationStructureTypeId; }
            set { _OrganisationStructureTypeId = value; }
        }
        /// <summary>
        /// CostCenter properties
        /// </summary>
        public System.String CostCenter
        {
            get { return _CostCenter; }
            set { _CostCenter = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// ParentId properties
        /// </summary>
        public System.Int64 ParentId
        {
            get { return _ParentId; }
            set { _ParentId = value; }
        }

        public System.String OrganisationStructureTypeName
        {
            get { return _OrganisationStructureTypeName; }
            set { _OrganisationStructureTypeName = value; }
        }


    }//Class Close
}//NameSpace Close
