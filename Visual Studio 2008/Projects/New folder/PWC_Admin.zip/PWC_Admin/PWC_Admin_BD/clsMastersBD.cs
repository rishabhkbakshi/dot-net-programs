﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsMastersBD
    {
        private System.Int64 _MasterId = 0;
        private System.Int64 _KeywordId = 0;
        private System.String _Value = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _Key1 = string.Empty;
        private System.String _Key2 = string.Empty;
        private System.String _Key3 = string.Empty;
        private System.String _Key4 = string.Empty;
        private System.String _Key5 = string.Empty;

       

        private System.Char _cFlag = 'N';
        
        /// <summary>
        /// MasterId
        /// </summary>
        public System.Int64 MasterId
        {
            get { return _MasterId; }
            set { _MasterId = value; }
        }
        /// <summary>
        /// KeywordId properties
        /// </summary>
        public System.Int64 KeywordId
        {
            get { return _KeywordId; }
            set { _KeywordId = value; }
        }
        /// <summary>
        /// Value properties
        /// </summary>
        public System.String Value
        {
            get { return _Value; }
            set { _Value = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.Char CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        public System.String Key5
        {
            get { return _Key5; }
            set { _Key5 = value; }
        }
        public System.String Key4
        {
            get { return _Key4; }
            set { _Key4 = value; }
        }
        public System.String Key3
        {
            get { return _Key3; }
            set { _Key3 = value; }
        }

        public System.String Key2
        {
            get { return _Key2; }
            set { _Key2 = value; }
        }
        public System.String Key1
        {
            get { return _Key1; }
            set { _Key1 = value; }
        }
    }//Class Close
}//NameSpace Close
