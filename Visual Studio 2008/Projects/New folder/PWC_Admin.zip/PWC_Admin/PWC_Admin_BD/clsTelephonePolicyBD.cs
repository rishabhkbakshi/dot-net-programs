﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsTelephonePolicyBD
    {
        #region "Private Instance Variable"

        Int64 _TPId;
        Int64 _GradeId;
        Decimal _Amount;
        Int64 _CurrencyId;
        String _Type;
        String _Alias;
        DateTime _DOC;
        DateTime _DOU;
        String _Status;
        Int64 _TransactionId;

        #endregion

        #region "Public Properties"
        public Int64 TPId
        {
            get { return _TPId; }
            set { _TPId = value; }
        }
        public Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        public Decimal Amount
        {
            get { return _Amount; }
            set { _Amount = value; }
        }
        public Int64 CurrencyId
        {
            get { return _CurrencyId; }
            set { _CurrencyId = value; }
        }
        public String Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }


        #endregion
    }
}
