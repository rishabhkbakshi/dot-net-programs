﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Admin.BD;

namespace Admin.BD
{
   public class clsCostCenterDepartmentHeadMappingBD
   {
     
       private string _Flag;

       public string Flag
       {
           get { return _Flag; }
           set { _Flag = value; }
       }
       private Int64 _CDHID;

       public Int64 CDHID
       {
           get { return _CDHID; }
           set { _CDHID = value; }
       }
       private Int64 _OSID;

       public Int64 OSID
       {
           get { return _OSID; }
           set { _OSID = value; }
       }
       private string _CostCenter;

       public string CostCenter
       {
           get { return _CostCenter; }
           set { _CostCenter = value; }
       }
       private Int64 _EmpId;

       public Int64 EmpId
       {
           get { return _EmpId; }
           set { _EmpId = value; }
       }
       private string _Email;

       public string Email
       {
           get { return _Email; }
           set { _Email = value; }
       }
       private DateTime _DOC;

       public DateTime DOC
       {
           get { return _DOC; }
           set { _DOC = value; }
       }
       private DateTime _DOU;

       public DateTime DOU
       {
           get { return _DOU; }
           set { _DOU = value; }
       }
       private string _Status;

       public string Status
       {
           get { return _Status; }
           set { _Status = value; }
       }
       private Int64 _GradeId;
   

public Int64 GradeId
{
  get { return _GradeId; }
  set { _GradeId = value; }
}}
    
}
