﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public struct AuthenticationBD
    {
        public Int64 EmployeeId { get; set; }
        public String EmployeeCode { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
        public String Email { get; set; }
        public String PersonalPhoneNo { get; set; }
        public String PersonalVehicleNo { get; set; }
        public String CompanyPhoneNo { get; set; }
        public String CompanyVehicleNo { get; set; }
        public Boolean IsSelfApproved { get; set; }
        public Int64 RoleId { get; set; }
        public Int64 DepartmentId { get; set; }
        public Int64 SessionId { get; set; }
    }
}
