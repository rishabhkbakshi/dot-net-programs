﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    [Serializable()]
    public class clsVendorContactDetailsBD
    {
        #region "--Private Variable--"
        private System.Int64 _VENDorContactDetailId = 0;
        private System.Int64 _VendorId = 0;
        private System.Int64 _CityId = 0;
        private System.String _Email = string.Empty;
        private System.String _PhoneNo1 = string.Empty;
        private System.String _PhoneNo2 = string.Empty;
        private System.String _VAddress = string.Empty;
        private System.Int64 _StateId = 0;
        private System.Int64 _CountryId = 0;
        private System.String _ZipCode = string.Empty;       
        private System.String _WebSite = string.Empty;       
        private System.String _Fax = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        private System.String _CountryName = string.Empty;
        private System.String _StateName = string.Empty;
        private System.String _CityName = string.Empty;

        #endregion
        #region "--Private Variable--"

        /// <summary>
        /// VendorAddressId properties
        /// </summary>
        public System.Int64 VENDorContactDetailId
        {
            get { return _VENDorContactDetailId; }
            set { _VENDorContactDetailId = value; }
        }
        /// <summary>
        /// VendorId properties
        /// </summary>
        public System.Int64 VendorId
        {
            get { return _VendorId; }
            set { _VendorId = value; }
        }       
        /// <summary>
        /// VAddress properties
        /// </summary>
        public System.String VAddress
        {
            get { return _VAddress; }
            set { _VAddress = value; }
        }
        /// <summary>
        /// CityId properties
        /// </summary>
        public System.Int64 CityId
        {
            get { return _CityId; }
            set { _CityId = value; }
        }
        /// <summary>
        /// StateId properties
        /// </summary>
        public System.Int64 StateId
        {
            get { return _StateId; }
            set { _StateId = value; }
        }
        /// <summary>
        /// CountryId properties
        /// </summary>
        public System.Int64 CountryId
        {
            get { return _CountryId; }
            set { _CountryId = value; }
        }
        /// <summary>
        /// ZipCode properties
        /// </summary>
        public System.String ZipCode
        {
            get { return _ZipCode; }
            set { _ZipCode = value; }
        }
        /// <summary>
        /// WebSite properties
        /// </summary>
        public System.String WebSite
        {
            get { return _WebSite; }
            set { _WebSite = value; }
        }
        /// <summary>
        /// Email properties
        /// </summary>
        public System.String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        /// <summary>
        /// PhoneNo1 properties
        /// </summary>
        public System.String PhoneNo1
        {
            get { return _PhoneNo1; }
            set { _PhoneNo1 = value; }
        }
        /// <summary>
        /// PhoneNo2 properties
        /// </summary>
        public System.String PhoneNo2
        {
            get { return _PhoneNo2; }
            set { _PhoneNo2 = value; }
        }
        /// <summary>
        /// Fax properties
        /// </summary>
        public System.String Fax
        {
            get { return _Fax; }
            set { _Fax = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// CountryName properties
        /// </summary>
        public System.String CountryName
        {
            get { return _CountryName; }
            set { _CountryName = value; }
        }
        /// <summary>
        /// StateName properties
        /// </summary>
        public System.String StateName
        {
            get { return _StateName; }
            set { _StateName = value; }
        }
        /// <summary>
        /// CityName properties
        /// </summary>
        public System.String CityName
        {
            get { return _CityName; }
            set { _CityName = value; }
        }
        #endregion
    }
}
