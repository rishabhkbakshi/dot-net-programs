﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAccomodationsBD
    {
        #region "--Private Variable--"
        private Int64 _AccomodationID;
        private Int64 _MasterID;
        private Int64 _CityID;
        private String _AccomodationName;
        private String _AccomodationAddress;
        private String _ContactNumber;
        private String _ContactPerson;
        private String _ContactPersonMobileNumber;
        private Int32 _NumberOfRoom;
        private String _Email;
        private String _Alias;
        private DateTime _DOC;
        private DateTime _DOU;
        private String _Status;
        private Int64 _TransactionID;
        private String _cFlag = string.Empty;
        private System.Decimal _ApprovedRoomRate = 0;
        private String _Description;


        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// Properties:AccomodationID
        /// </summary>
        public Int64 AccomodationID
        {
            get { return _AccomodationID; }
            set { _AccomodationID = value; }
        }

        /// <summary>
        /// Properties:MasterID
        /// </summary>
        public Int64 MasterID
        {
            get { return _MasterID; }
            set { _MasterID = value; }
        }

        /// <summary>
        /// Properties:CityID
        /// </summary>
        public Int64 CityID
        {
            get { return _CityID; }
            set { _CityID = value; }
        }

        /// <summary>
        /// Properties:AccomodationName
        /// </summary>
        public String AccomodationName
        {
            get { return _AccomodationName; }
            set { _AccomodationName = value; }
        }

        /// <summary>
        /// Properties:AccomodationAddress
        /// </summary>
        public String AccomodationAddress
        {
            get { return _AccomodationAddress; }
            set { _AccomodationAddress = value; }
        }

        /// <summary>
        /// Properties:ContactNumber
        /// </summary>
        public String ContactNumber
        {
            get { return _ContactNumber; }
            set { _ContactNumber = value; }
        }

        /// <summary>
        /// Properties:ContactPerson
        /// </summary>
        public String ContactPerson
        {
            get { return _ContactPerson; }
            set { _ContactPerson = value; }
        }

        /// <summary>
        /// Properties:ContactPersonMobileNumber
        /// </summary>
        public String ContactPersonMobileNumber
        {
            get { return _ContactPersonMobileNumber; }
            set { _ContactPersonMobileNumber = value; }
        }

        /// <summary>
        /// Properties:NumberOfRoom
        /// </summary>
        public Int32 NumberOfRoom
        {
            get { return _NumberOfRoom; }
            set { _NumberOfRoom = value; }
        }

        /// <summary>
        /// Properties:Email
        /// </summary>
        public String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }

        /// <summary>
        /// Properties:Alias
        /// </summary>
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }

        /// <summary>
        /// Properties:DOC
        /// </summary>
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Properties:DOU
        /// </summary>
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Properties:Status
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        /// <summary>
        /// Properties:TransactionID
        /// </summary>
        public Int64 TransactionID
        {
            get { return _TransactionID; }
            set { _TransactionID = value; }
        }
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        public String Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        public System.Decimal ApprovedRoomRate
        {
            get { return _ApprovedRoomRate; }
            set { _ApprovedRoomRate = value; }
        }
        #endregion
    }
}
