﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsCostCenterBD
    {
        private System.Int64 _CostCenterId = 0;
        private System.String _CostCenter = string.Empty;
        private System.Int64 _OrganisationStructureId = 0;
        private System.String _Description = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;


        /// <summary>
        /// CostCenterId properties
        /// </summary>
        public System.Int64 CostCenterId
        {
            get { return _CostCenterId; }
            set { _CostCenterId = value; }
        }
        /// <summary>
        /// CostCenter properties
        /// </summary>
        public System.String CostCenter
        {
            get { return _CostCenter; }
            set { _CostCenter = value; }
        }
        /// <summary>
        /// OrganisationStructureId properties
        /// </summary>
        public System.Int64 OrganisationStructureId
        {
            get { return _OrganisationStructureId; }
            set { _OrganisationStructureId = value; }
        }
        /// <summary>
        /// Description properties
        /// </summary>
        public System.String Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

    }//Class Close
}//NameSpace Close
