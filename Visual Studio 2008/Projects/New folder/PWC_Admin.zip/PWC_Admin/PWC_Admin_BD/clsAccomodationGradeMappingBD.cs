﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAccomodationGradeMappingBD
    {
        private System.Int64 _AGMId = 0;
        private System.Int64 _AccomodationId = 0;
        private System.Int64 _GradeId = 0;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;

        public clsAccomodationGradeMappingBD()
        { }


        /// <summary>
        /// AGMId properties
        /// </summary>
        public System.Int64 AGMId
        {
            get { return _AGMId; }
            set { _AGMId = value; }
        }
        /// <summary>
        /// AccomodationId properties
        /// </summary>
        public System.Int64 AccomodationId
        {
            get { return _AccomodationId; }
            set { _AccomodationId = value; }
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

    }//Class Close
}//NameSpace Close