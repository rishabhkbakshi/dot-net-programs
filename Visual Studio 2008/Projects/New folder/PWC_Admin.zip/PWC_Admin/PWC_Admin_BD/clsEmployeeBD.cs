﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsEmployeeBD
    {
        private System.Int64 _EmployeeId = 0;
        private System.String _EmployeeCode = string.Empty;
        private System.String _FirstName = string.Empty;
        private System.String _LastName = string.Empty;
        private System.String _Gender = string.Empty;
        private System.Int64 _ReportingManager = 0;
        private System.Int64 _DelegatationTo = 0;
        private System.String _Email = string.Empty;
        private System.String _PersonalPhoneNo = string.Empty;
        private System.String _PersonalVehicleNo = string.Empty;
        private System.String _CompanyPhoneNo = string.Empty;
        private System.String _CompanyVehicleNo = string.Empty;
        private System.Boolean _IsSelfApproved = false;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;
        private System.Int64 _DepartmentId = 0;
        private System.Int64 _RoleId = 0;
        private System.Int32 _GradeId = 0;
        private System.Int64 _LocationId = 0;

       


        public clsEmployeeBD()
        { }

        clsEmployeeBD(System.String CFlag, System.Int64 EmployeeId, System.String EmployeeCode, System.String FirstName, System.String LastName, System.String Gender, System.Int64 ReportingManager, System.Int64 DelegatationTo, System.String Email, System.String PersonalPhoneNo, System.String PersonalVehicleNo, System.String CompanyPhoneNo, System.String CompanyVehicleNo, System.Boolean IsSelfApproved, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId, System.Int64 DepartmentId, System.Int64 RoleId, System.Int32 GradeId, System.Int64 LocationId)
        {
            _cFlag = CFlag;
            _EmployeeId = EmployeeId;
            _EmployeeCode = EmployeeCode;
            _FirstName = FirstName;
            _LastName = LastName;
            _Gender = Gender;
            _ReportingManager = ReportingManager;
            _DelegatationTo = DelegatationTo;
            _Email = Email;
            _PersonalPhoneNo = PersonalPhoneNo;
            _PersonalVehicleNo = PersonalVehicleNo;
            _CompanyPhoneNo = CompanyPhoneNo;
            _CompanyVehicleNo = CompanyVehicleNo;
            _IsSelfApproved = IsSelfApproved;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
            _DepartmentId = DepartmentId;
            _RoleId = RoleId;
            _GradeId = GradeId;
            _LocationId =LocationId;

        }
        /// <summary>
        /// EmployeeId properties
        /// </summary>
        public System.Int64 EmployeeId
        {
            get { return _EmployeeId; }
            set { _EmployeeId = value; }
        }
        /// <summary>
        /// EmployeeCode properties
        /// </summary>
        public System.String EmployeeCode
        {
            get { return _EmployeeCode; }
            set { _EmployeeCode = value; }
        }
        /// <summary>
        /// FirstName properties
        /// </summary>
        public System.String FirstName
        {
            get { return _FirstName; }
            set { _FirstName = value; }
        }
        /// <summary>
        /// LastName properties
        /// </summary>
        public System.String LastName
        {
            get { return _LastName; }
            set { _LastName = value; }
        }
        /// <summary>
        /// Gender properties
        /// </summary>
        public System.String Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }
        /// <summary>
        /// ReportingManager properties
        /// </summary>
        public System.Int64 ReportingManager
        {
            get { return _ReportingManager; }
            set { _ReportingManager = value; }
        }
        /// <summary>
        /// DelegatationTo properties
        /// </summary>
        public System.Int64 DelegatationTo
        {
            get { return _DelegatationTo; }
            set { _DelegatationTo = value; }
        }
        /// <summary>
        /// Email properties
        /// </summary>
        public System.String Email
        {
            get { return _Email; }
            set { _Email = value; }
        }
        /// <summary>
        /// PersonalPhoneNo properties
        /// </summary>
        public System.String PersonalPhoneNo
        {
            get { return _PersonalPhoneNo; }
            set { _PersonalPhoneNo = value; }
        }
        /// <summary>
        /// PersonalVehicleNo properties
        /// </summary>
        public System.String PersonalVehicleNo
        {
            get { return _PersonalVehicleNo; }
            set { _PersonalVehicleNo = value; }
        }
        /// <summary>
        /// CompanyPhoneNo properties
        /// </summary>
        public System.String CompanyPhoneNo
        {
            get { return _CompanyPhoneNo; }
            set { _CompanyPhoneNo = value; }
        }
        /// <summary>
        /// CompanyVehicleNo properties
        /// </summary>
        public System.String CompanyVehicleNo
        {
            get { return _CompanyVehicleNo; }
            set { _CompanyVehicleNo = value; }
        }
        /// <summary>
        /// IsSelfApproved properties
        /// </summary>
        public System.Boolean IsSelfApproved
        {
            get { return _IsSelfApproved; }
            set { _IsSelfApproved = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// DepartmentId properties
        /// </summary>
        public System.Int64 DepartmentId
        {
            get { return _DepartmentId; }
            set { _DepartmentId = value; }
        }
        /// <summary>
        /// RoleId properties
        /// </summary>
        public System.Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }
        public System.Int32 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        public System.Int64 LocationId
        {
            get { return _LocationId; }
            set { _LocationId = value; }
        }


    }//Class Close
}//NameSpace Close

