﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    /// <summary>
    /// summary description for  clsKeywordMasterBD
    /// </summary>
    public class clsKeywordMasterBD
    {
        private System.Int64 _KeywordId=0;
        private System.String _Keyword = string.Empty;      
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.Char _cFlag = 'N';
        public clsKeywordMasterBD()
        { }
        
        clsKeywordMasterBD(System.Int64 KeywordId, System.String Keyword, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _KeywordId = KeywordId;
            _Keyword=Keyword;
            _Alias=Alias;
            _DOC=DOC;
            _DOU=DOU;
            _Status=Status;
            _TransactionId = TransactionId;
        }

        /// <summary>
        /// KeywordId properies
        /// </summary>
        public System.Int64 KeywordId
        {
          get 
          { 
              return _KeywordId; 
          }
          set 
          {
              _KeywordId = value; 
          }
        }
        /// <summary>
        /// Keyword properies
        /// </summary>
        public System.String Keyword
        {
            get { return _Keyword; }
            set { _Keyword = value; }
        }
        /// <summary>
        /// Alias properies
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.Char CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close

