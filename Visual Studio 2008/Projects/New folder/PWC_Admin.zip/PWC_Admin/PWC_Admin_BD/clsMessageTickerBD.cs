﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsMessageTickerBD
    {
        public string Flag { get; set; }
        public long MTID { get; set; }
        public string Message { get; set; }
        public long RoleID { get; set; }
        public string Color { get; set; }
        public string Status { get; set; }
        public DateTime DOC { get; set; }
        public DateTime DOU { get; set; }
    }
}
