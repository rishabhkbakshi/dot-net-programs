﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsPetrolPoliciesBD
    {
        #region "Private Instance Variable"

        Int64 _PPId;
        Int64 _GradeId;
        Decimal _Limit;
        String _Unit;
        Decimal _Period;
        String _PUnit;
        String _Alias;
        String _Status;
        DateTime _DOC;
        DateTime _DOU;
        Int64 _TransactionId;

        #endregion

        #region "Public Properties"

        public Int64 PPId
        {
            get { return _PPId; }
            set { _PPId = value; }
        }
        public Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        public Decimal Limit
        {
            get { return _Limit; }
            set { _Limit = value; }
        }
        public String Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        public Decimal Period
        {
            get { return _Period; }
            set { _Period = value; }
        }
        public String PUnit
        {
            get { return _PUnit; }
            set { _PUnit = value; }
        }
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }

        #endregion
    }
}
