﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsLocationDistanceMappingBD
    {
        #region "START: PUBLIC PROPERTIES"
        public long LocationDistanceMappingMaster_ID { get; set; }
        public long LocationDistanceMapping_ID { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public int ForYear { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public string FromLocation { get; set; }
        public string ToLocation { get; set; }
        public string Distance { get; set; }
        public string PickUpDropLocation { get; set; }
        public string Rate { get; set; }
        public string FullVehicle { get; set; }
        public string WaitingCharges { get; set; }
        public long TransactionID { get; set; }
        public DateTime DOC { get; set; }
        public DateTime DOU { get; set; }
        public string Status { get; set; }

        #endregion "END: PUBLIC PROPERTIES"
    }
}
