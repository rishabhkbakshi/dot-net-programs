﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsGradeRoleMappingBD
    {
        private System.Int64 _GradeRoleMappingId = 0;
        private System.Int64 _GradeId = 0;
        private System.Int64 _RoleId = 0;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;

        public clsGradeRoleMappingBD()
        { }


        public clsGradeRoleMappingBD(System.String CFlag, System.Int64 GradeRoleMappingId, System.Int64 GradeId, System.Int64 RoleId, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _cFlag = CFlag;
            _GradeRoleMappingId = GradeRoleMappingId;
            _GradeId = GradeId;
            _RoleId = RoleId;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
        }
        /// <summary>
        /// GradeRoleMappingId propeties
        /// </summary>
        public System.Int64 GradeRoleMappingId
        {
            get { return _GradeRoleMappingId; }
            set { _GradeRoleMappingId = value; }
        }
        /// <summary>
        /// GradeId propeties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// RoleId properties
        /// </summary>
        public System.Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

    }//Class Close
}//NameSpace Close