﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsConveyancePolicyBD
    {
        #region "--Private Variable--"
        private System.Int64 _ConveyancePolicyId = 0;
        private System.Int64 _GradeId = 0;
        private System.Int64 _VehicleTypeId = 0;       
        private System.String _Gender = string.Empty;        
        private System.DateTime _EffectiveFROMDate;
        private System.DateTime _EffectiveToDate;
        private System.Boolean _IsEnforcePriority;
        private System.Boolean _IsBehalfOfBooking;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        private System.Int32 _AfterOutTime = 0;
        private System.String _DefaultMode = string.Empty;
        private System.String _AlternateMode = string.Empty;
        private System.Int64 _DefaultClass = 0;
        private System.Int64 _AlternateClass = 0;
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// ConveyancePolicyId properties
        /// </summary>
        public System.Int64 ConveyancePolicyId
        {
            get { return _ConveyancePolicyId; }
            set { _ConveyancePolicyId = value; }
        }
        /// <summary>
        /// GradeId properties
        /// </summary>
        public System.Int64 GradeId
        {
            get { return _GradeId; }
            set { _GradeId = value; }
        }
        /// <summary>
        /// VehicleTypeId properties
        /// </summary>
        public System.Int64 VehicleTypeId
        {
            get { return _VehicleTypeId; }
            set { _VehicleTypeId = value; }
        }
        /// <summary>
        /// Gender properties
        /// </summary>
        public System.String Gender
        {
            get { return _Gender; }
            set { _Gender = value; }
        }                
        /// <summary>
        /// EffectiveFROMDate properties
        /// </summary>
        public System.DateTime EffectiveFROMDate
        {
            get { return _EffectiveFROMDate; }
            set { _EffectiveFROMDate = value; }
        }
        /// <summary>
        /// EffectiveToDate properties
        /// </summary>
        public System.DateTime EffectiveToDate
        {
            get { return _EffectiveToDate; }
            set { _EffectiveToDate = value; }
        }
        /// <summary>
        /// IsEnforcePriority properties
        /// </summary>
        public System.Boolean IsEnforcePriority
        {
            get { return _IsEnforcePriority; }
            set { _IsEnforcePriority = value; }
        }
        /// <summary>
        /// IsBehalfOfBooking properties
        /// </summary>
        public System.Boolean IsBehalfOfBooking
        {
            get { return _IsBehalfOfBooking; }
            set { _IsBehalfOfBooking = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        /// <summary>
        /// AfterOutTime properties
        /// </summary>
        public System.Int32 AfterOutTime
        {
            get { return _AfterOutTime; }
            set { _AfterOutTime = value; }
        }
        /// <summary>
        /// DefaultMode properties
        /// </summary>
        public System.String DefaultMode
        {
            get { return _DefaultMode; }
            set { _DefaultMode = value; }
        }
        /// <summary>
        /// AlternateMode properties
        /// </summary>
        public System.String AlternateMode
        {
            get { return _AlternateMode; }
            set { _AlternateMode = value; }
        }
        /// <summary>
        /// DefaultClass properties
        /// </summary>
        public System.Int64 DefaultClass
        {
            get { return _DefaultClass; }
            set { _DefaultClass = value; }
        }
        /// <summary>
        /// AlternateClass properties
        /// </summary>
        public System.Int64 AlternateClass
        {
            get { return _AlternateClass; }
            set { _AlternateClass = value; }
        }
        #endregion
    }
}
