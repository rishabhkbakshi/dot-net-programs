﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsAuthorizationsBD
    {
        #region "--Private Variable--"
        private System.Int64 _AuthorizationId = 0;
        private System.Int64 _RoleId = 0;
        private System.Int64 _ProcessId = 0;
        private System.Boolean _IsAdd;
        private System.Boolean _IsModify;
        private System.Boolean _IsDelete;
        private System.Boolean _IsView;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = "N";
        #endregion
        #region "--Public Properties--"
        /// <summary>
        /// AuthorizationId properties
        /// </summary>
        public System.Int64 AuthorizationId
        {
            get { return _AuthorizationId; }
            set { _AuthorizationId = value; }
        }
        /// <summary>
        /// RoleId properties
        /// </summary>
        public System.Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }
        /// <summary>
        /// ProcessId properties
        /// </summary>
        public System.Int64 ProcessId
        {
            get { return _ProcessId; }
            set { _ProcessId = value; }
        } 
        /// <summary>
        /// IsAdd properties
        /// </summary>
        public System.Boolean IsAdd
        {
            get { return _IsAdd; }
            set { _IsAdd = value; }
        }
        /// <summary>
        /// IsModify properties
        /// </summary>
        public System.Boolean IsModify
        {
            get { return _IsModify; }
            set { _IsModify = value; }
        }
        /// <summary>
        /// IsDelete properties
        /// </summary>
        public System.Boolean IsDelete
        {
            get { return _IsDelete; }
            set { _IsDelete = value; }
        }
        /// <summary>
        /// _IsView properties
        /// </summary>
        public System.Boolean IsView
        {
            get { return _IsView; }
            set { _IsView = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properties
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properties
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properties
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
        #endregion
    }
}
