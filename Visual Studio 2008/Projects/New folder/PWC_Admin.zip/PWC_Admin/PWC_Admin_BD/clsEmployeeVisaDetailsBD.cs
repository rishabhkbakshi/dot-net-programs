﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsEmployeeVisaDetailsBD
    {
        private System.Int64 _VisaId = 0;
        private System.String _VisaNo = string.Empty;

        
        private System.Int64 _EmployeeId = 0;
        private System.String _PassportNo = string.Empty;
        private System.Int64 _VisaType = 0;
        private System.Int64 _CountryId = 0;
        private System.DateTime _FromDate;
        private System.DateTime _ToDate;        
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;

        /// <summary>
        /// VisaId properties
        /// </summary>
        public System.Int64 VisaId
        {
            get { return _VisaId; }
            set { _VisaId = value; }
        }
        /// <summary>
        /// 
        /// </summary>
        public System.String VisaNo
        {
            get { return _VisaNo; }
            set { _VisaNo = value; }
        }
        /// <summary>
        /// EmployeeId properties
        /// </summary>
        public System.Int64 EmployeeId
        {
            get { return _EmployeeId; }
            set { _EmployeeId = value; }
        }
        /// <summary>
        /// PassportNo properties
        /// </summary>
        public System.String PassportNo
        {
            get { return _PassportNo; }
            set { _PassportNo = value; }
        }
        /// <summary>
        /// VisaType properties
        /// </summary>
        public System.Int64 VisaType
        {
            get { return _VisaType; }
            set { _VisaType = value; }
        }
        /// <summary>
        /// CountryId properties
        /// </summary>
        public System.Int64 CountryId
        {
            get { return _CountryId; }
            set { _CountryId = value; }
        }
        /// <summary>
        /// FromDate properties
        /// </summary>
        public System.DateTime FromDate
        {
            get { return _FromDate; }
            set { _FromDate = value; }
        }
        /// <summary>
        /// ToDate properties
        /// </summary>
        public System.DateTime ToDate
        {
            get { return _ToDate; }
            set { _ToDate = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }

    }//Class Close
}//NameSpace Close
