﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    public class clsCountryMasterBD
    {
        private System.Int64 _CountryId = 0;
        private System.String _CountryName = string.Empty;
        private System.String _Alias = string.Empty;
        private System.DateTime _DOC;
        private System.DateTime _DOU;
        private System.String _Status = string.Empty;
        private System.Int64 _TransactionId = 0;
        private System.String _cFlag = string.Empty;

         public clsCountryMasterBD()
        { }

        clsCountryMasterBD(System.String CFlag, System.Int64 CountryId, System.String CountryName, System.Int64 OrganisationStructureId, System.String Alias, System.DateTime DOC, System.DateTime DOU, System.String Status, System.Int64 TransactionId)
        {
            _cFlag = CFlag;
            _CountryId = CountryId;
            _CountryName = CountryName;
            _Alias = Alias;
            _DOC = DOC;
            _DOU = DOU;
            _Status = Status;
            _TransactionId = TransactionId;
        }

        /// <summary>
        /// CountryId
        /// </summary>
        public System.Int64 CountryId
        {
            get { return _CountryId; }
            set { _CountryId = value; }
        }
        /// <summary>
        /// CountryName properties
        /// </summary>
        public System.String CountryName
        {
            get { return _CountryName; }
            set { _CountryName = value; }
        }
        /// <summary>
        /// Alias properties
        /// </summary>
        public System.String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        /// <summary>
        /// DOC properies
        /// </summary>
        public System.DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        /// <summary>
        /// DOU properies
        /// </summary>
        public System.DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        /// <summary>
        /// Status properies
        /// </summary>
        public System.String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        /// <summary>
        /// TransactionId properties
        /// </summary>
        public System.Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        /// <summary>
        /// CFlag properties
        /// </summary>
        public System.String CFlag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }
}
