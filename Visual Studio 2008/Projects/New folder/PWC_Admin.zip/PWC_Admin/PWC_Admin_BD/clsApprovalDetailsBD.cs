﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    [Serializable]
    public class clsApprovalDetailsBD
    {
        #region "PRIVATE INSTANCE VARIABLES"

        String _Flag;
        Int64 _ApprovalDetailId;
        Int64 _ApprovalMasterIdr;
        Int64 _RoleId;
        String _RoleName;
        Boolean _IsEscalated;
        Int16 _EscalationDuration;
        Int64 _Unit;
        String _UnitName;
        Int16 _Sequence;
        String _Alias;
        DateTime _DOC;
        DateTime _DOU;
        String _Status;
        Int64 _TransactionId;
        
        #endregion

        #region "PUBIC PROPERTIES"

        public String Flag
        {
            get { return _Flag; }
            set { _Flag = value; }
        }
        public Int64 ApprovalDetailId
        {
            get { return _ApprovalDetailId; }
            set { _ApprovalDetailId = value; }
        }
        public Int64 ApprovalMasterId
        {
            get { return _ApprovalMasterIdr; }
            set { _ApprovalMasterIdr = value; }
        }
        public Int64 RoleId
        {
            get { return _RoleId; }
            set { _RoleId = value; }
        }
        public String RoleName
        {
            get { return _RoleName; }
            set { _RoleName = value; }
        }       
        public Boolean IsEscalated
        {
            get { return _IsEscalated; }
            set { _IsEscalated = value; }
        }
        public Int16 EscalationDuration
        {
            get { return _EscalationDuration; }
            set { _EscalationDuration = value; }
        }
        public Int64 Unit
        {
            get { return _Unit; }
            set { _Unit = value; }
        }
        public String UnitName
        {
            get { return _UnitName; }
            set { _UnitName = value; }
        }
        public Int16 Sequence
        {
            get { return _Sequence; }
            set { _Sequence = value; }
        }
        public String Alias
        {
            get { return _Alias; }
            set { _Alias = value; }
        }
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }

        #endregion
    }
}
