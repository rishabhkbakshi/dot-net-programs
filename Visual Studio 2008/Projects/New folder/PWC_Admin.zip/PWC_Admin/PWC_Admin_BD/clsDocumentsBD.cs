﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Admin.BD
{
    [Serializable]
    public class clsDocumentsBD
    {
        Int64 _DocumentId;
        Int64 _ProcessId;
        Int64 _TravelRequestId;
        String _ReferenceName;
        String _Remark;
        String _FileName;
        String _GUID;
        String _Location;
        String _Status;
        DateTime _DOC;
        DateTime _DOU;
        Int64 _TransactionId;
        private System.String _cFlag = string.Empty;

        /// <summary>
        /// Properties:DocumentId
        /// </summary>
        public Int64 DocumentId
        {
            get { return _DocumentId; }
            set { _DocumentId = value; }
        }

        /// <summary>
        /// Properties:ProcessId
        /// </summary>
        public Int64 ProcessId
        {
            get { return _ProcessId; }
            set { _ProcessId = value; }
        }

        /// <summary>
        /// Properties:TravelRequestId
        /// </summary>
        public Int64 TravelRequestId
        {
            get { return _TravelRequestId; }
            set { _TravelRequestId = value; }
        }

        /// <summary>
        /// Properties:ReferenceName
        /// </summary>
        public String ReferenceName
        {
            get { return _ReferenceName; }
            set { _ReferenceName = value; }
        }

        /// <summary>
        /// Properties:Remark
        /// </summary>
        public String Remark
        {
            get { return _Remark; }
            set { _Remark = value; }
        }

        /// <summary>
        /// Properties:FileName
        /// </summary>
        public String FileName
        {
            get { return _FileName; }
            set { _FileName = value; }
        }

        /// <summary>
        /// Properties:GUID
        /// </summary>
        public String GUID
        {
            get { return _GUID; }
            set { _GUID = value; }
        }

        /// <summary>
        /// Properties:Location
        /// </summary>
        public String Location
        {
            get { return _Location; }
            set { _Location = value; }
        }

        /// <summary>
        /// Properties:Status
        /// </summary>
        public String Status
        {
            get { return _Status; }
            set { _Status = value; }
        }

        /// <summary>
        /// Properties:DOC
        /// </summary>
        public DateTime DOC
        {
            get { return _DOC; }
            set { _DOC = value; }
        }

        /// <summary>
        /// Properties:DOU
        /// </summary>
        public DateTime DOU
        {
            get { return _DOU; }
            set { _DOU = value; }
        }

        /// <summary>
        /// Properties:TransactionId
        /// </summary>
        public Int64 TransactionId
        {
            get { return _TransactionId; }
            set { _TransactionId = value; }
        }
        public System.String Flag
        {
            get { return _cFlag; }
            set { _cFlag = value; }
        }
    }//Class Close
}//NameSpace Close
