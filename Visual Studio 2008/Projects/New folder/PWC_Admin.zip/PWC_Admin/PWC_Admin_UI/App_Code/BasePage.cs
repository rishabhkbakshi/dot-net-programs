﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Text;

using Admin.BO;
using System.IO;

public enum EFlag
{
    INSERT,
    UPDATE,
    DELETE,
    ALL,
    CURRENCY,
    UNIT,
    TRAVELTYPE,
    TRAVELMODE,
}
/// <summary>
/// Summary description for Utility
/// </summary>
public class BasePage : System.Web.UI.Page
{
    public BasePage()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    protected override void OnLoad(EventArgs e)
    {

        if (Session["USERDETAILS"] != null)
        {
            base.OnLoad(e);
        }
        else
        {
            Response.Redirect("~/Signout.aspx", false);
        }
    }

    protected void SendMail(string Content, string MailTo, string Type)
    {
        try
        {
            DataSet dsXml = new DataSet();
            string from = clsUtility.GetFromWebConfig("MailFrom");
            string xmlPath = Server.MapPath(Page.ResolveUrl("~/MailTemplate/MailData.xml"));
            dsXml.ReadXml(xmlPath);

            string BODY;
            StringBuilder content = new StringBuilder();
            StringBuilder subject = new StringBuilder();
            DataTable dt = dsXml.Tables[0];
            DataRow[] dr = null;
            string LogoPath = clsUtility.GetFromWebConfig("Logo");

            dr = dt.Select("Type='" + Type + "'");
            if (dr.Length > 0)
            {
                subject = new StringBuilder();
                content = new StringBuilder();
                subject.Append(dr[0]["Subject"].ToString());
                content.Append(dr[0]["Body"].ToString());
                content.Replace("\r\n", "<br>");
                content.Replace("<%Content%>", Content);
                clsUtility.GenerateMail(out BODY, LogoPath, content.ToString());
                clsUtility.SendMail(string.Empty, MailTo, "", subject.ToString(), BODY, true);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void ShowMessage(string Message)
    {
        try
        {
            if (string.IsNullOrEmpty(Message))
            {
                if (!string.IsNullOrEmpty(Request["MSG"]))
                {
                    switch (Request["MSG"].ToUpper())
                    {
                        case "INSERT":
                            Message = "Data Inserted Successfully.";
                            break;
                        case "UPDATE":
                            Message = "Data Updated Successfully.";
                            break;
                        case "DELETE":
                            Message = "Data Deleted Successfully.";
                            break;
                        default:
                            Message = string.Empty;
                            break;
                    }
                }
            }
            if (!string.IsNullOrEmpty(Message))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + Message + "');</script>");
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #region"FileDownload to download the document to view its contents "
    /// <summary> 
    ///Method Name:FileDownload
    ///Description:Provide Provision for Downloading the file. 
    ///Parameter Description:FilePath is to be downloaded. 
    ///Return type:void Type 
    ///Reffered Class: 
    /// </summary> 
    /// <param name="FilePath"></param> 
    public void FileDownload(string FilePath)
    {
        //if (File.Exists(Server.MapPath(FilePath)))
        if (File.Exists(FilePath))
        {
            //FileStream liveStream = new FileStream(Server.MapPath(FilePath), FileMode.Open, System.IO.FileAccess.Read);
            FileStream liveStream = new FileStream(FilePath, FileMode.Open, System.IO.FileAccess.Read);
            byte[] buffer = new byte[(int)liveStream.Length];
            liveStream.Read(buffer, 0, (
            int)liveStream.Length);
            liveStream.Close();
            Response.Clear();
            Response.ContentType = "application/octet-stream";
            Response.AddHeader("Content-Length", buffer.Length.ToString());
            Response.AddHeader("Content-Disposition", "attachment; filename=" + System.IO.Path.GetFileName(FilePath));
            Response.BinaryWrite(buffer);
            Response.End();
        }
        else
        {
            ShowMessage("File not found / File removed from specified location .... ");
        }
    }
    #endregion
}
