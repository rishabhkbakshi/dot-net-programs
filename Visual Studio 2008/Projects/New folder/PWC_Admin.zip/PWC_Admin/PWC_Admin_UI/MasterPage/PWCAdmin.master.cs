﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;

public partial class MasterPage_PWCAdmin : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["USERDETAILS"] != null)
        {
            List<AuthenticationBD> AuthenticationList = Session["USERDETAILS"] as List<AuthenticationBD>;
            string UserName = AuthenticationList[0].FirstName;
            UserName = UserName + " | " + Convert.ToString(AuthenticationList[0].EmployeeCode);
            lblSignInName.Text = UserName;
        }
    }
}
