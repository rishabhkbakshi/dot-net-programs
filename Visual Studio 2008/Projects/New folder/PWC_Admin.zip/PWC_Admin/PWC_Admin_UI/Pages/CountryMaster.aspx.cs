﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_CountryMaster : BasePage
{
    #region--Initializors--
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    DataTable dtCountryMaster = new DataTable();
    #endregion
    #region--Page load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
                Bindgrid();
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["CountryId"] != null && ViewState["CountryId"].ToString() != "0")
            {
                oclsCountryMasterBD.CFlag = EFlag.UPDATE.ToString();
                oclsCountryMasterBD.CountryId = Int64.Parse(ViewState["CountryId"].ToString());
            }
            else
            {
                oclsCountryMasterBD.CFlag = EFlag.INSERT.ToString();
                oclsCountryMasterBD.CountryId = 0;
            }
            oclsCountryMasterBD.Alias = txtAlias.Text.Trim();
            oclsCountryMasterBD.DOC = DateTime.Now;
            oclsCountryMasterBD.DOU = DateTime.Now;
            oclsCountryMasterBD.CountryName = txtCountry.Text.Trim();
            oclsCountryMasterBD.Status = "Active";
            oclsCountryMasterBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            if (oclsCountryMasterBO.InsertUpdateCountryMaster(oclsCountryMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Bindgrid();
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Duplicate Country Cannot Be Accepted.');</script>");
            }
            else
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCountry_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvCountry.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to update and delete Country
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCountry_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["CountryId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsCountryMasterBD.CountryId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsCountryMasterBO.DeleteCountryMaster(oclsCountryMasterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCountry_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        txtAlias.Text = HttpUtility.HtmlDecode(gvCountry.Rows[e.RowIndex].Cells[1].Text);
        txtCountry.Text = HttpUtility.HtmlDecode(gvCountry.Rows[e.RowIndex].Cells[0].Text);
        btnSave.Text = "Update";
    }
    protected void gvCountry_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind Country data
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            //if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            //{
            gvCountry.DataSource = dtCountryMaster;
            gvCountry.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtCountry.Text = txtAlias.Text = string.Empty;
        ViewState["CountryId"] = 0;
        btnSave.Text = "Save";
    }
    #endregion
}
