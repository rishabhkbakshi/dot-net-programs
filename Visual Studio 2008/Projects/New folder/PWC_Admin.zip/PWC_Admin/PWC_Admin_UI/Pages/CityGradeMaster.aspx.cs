﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_CityGradeMaster : BasePage
{
    #region --Initializers--
    clsCityGradeMasterBD objclsCityGradeMasterBD = new clsCityGradeMasterBD();
    clsCityGradeMasterBO objclsCityGradeMasterBO = new clsCityGradeMasterBO();
    DataTable objDataTable = new DataTable();
    #endregion
    #region--pageload method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            Bindgrid();
    }
    #endregion
    #region ----Eventhandlers-----
    /// <summary>
    /// The event is use to save and update CityGradeMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["CityGradeId"] != null && ViewState["CityGradeId"].ToString() != "0")
            {
                objclsCityGradeMasterBD.CFlag = EFlag.UPDATE.ToString();
                objclsCityGradeMasterBD.CityGradeId = Int64.Parse(ViewState["CityGradeId"].ToString());
            }
            else
            {
                objclsCityGradeMasterBD.CFlag = EFlag.INSERT.ToString();
                objclsCityGradeMasterBD.CityGradeId = 0;
            }
            objclsCityGradeMasterBD.CityGradeName = txtCityGradeName.Text.Trim();
            objclsCityGradeMasterBD.Alias = txtAlias.Text.Trim();
            objclsCityGradeMasterBD.DOC = DateTime.Now;
            objclsCityGradeMasterBD.DOU = DateTime.Now;
            objclsCityGradeMasterBD.Status = "Active";
            objclsCityGradeMasterBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            if (objclsCityGradeMasterBO.InsertUpdateCityGradeMaster(objclsCityGradeMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                ClearFields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            Bindgrid();
            ClearFields();
        }
        catch (Exception ex)
        {
            Bindgrid();
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('City Grade Name already exists.');</script>");
            }
            else
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearFields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityGrade_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //txtAlias.Text = HttpUtility.HtmlDecode(gvCityGrade.Rows[e.RowIndex].Cells[1].Text);
        txtCityGradeName.Text = HttpUtility.HtmlDecode(gvCityGrade.Rows[e.RowIndex].Cells[0].Text);
        btnSave.Text = "Update";
    }
    /// <summary>
    /// The event is use to update and delete CityGradeMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityGrade_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["CityGradeId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsCityGradeMasterBD.CityGradeId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsCityGradeMasterBO.DeleteCityGradeMaster(objclsCityGradeMasterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    ClearFields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    ClearFields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }

    }
    protected void gvCityGrade_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCityGrade_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvCityGrade.PageIndex = e.NewPageIndex;
        Bindgrid();
    }
    #endregion
    #region --Private methods--
    /// <summary>
    /// The following method is use to bind data in grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsCityGradeMasterBD.CityGradeId = 0;
            objclsCityGradeMasterBD.CFlag = EFlag.ALL.ToString();
            objDataTable = objclsCityGradeMasterBO.SelectCityGradeMaster(objclsCityGradeMasterBD);
            //if (objDataTable!= null && objDataTable.Rows.Count>0)
            //{
            gvCityGrade.DataSource = objDataTable;
            gvCityGrade.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void ClearFields()
    {
        txtAlias.Text = txtCityGradeName.Text = string.Empty;
        ViewState["CityGradeId"] = 0;
        btnSave.Text = "Save";
    }
    #endregion

}
