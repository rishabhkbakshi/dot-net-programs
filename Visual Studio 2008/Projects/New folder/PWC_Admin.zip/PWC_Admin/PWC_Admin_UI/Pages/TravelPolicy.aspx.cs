﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

using Admin.BD;
using Admin.BO;

public partial class Pages_TravelPolicy : BasePage
{
    #region --Initializers--
    clsTravelPolicyBO objclsTravelPolicyBO = new clsTravelPolicyBO();
    clsTravelPolicyBD objclsTravelPolicyBD = new clsTravelPolicyBD();

    //added by mahesh for applying policy on list of grade
    clsPolicyGradeMappingBD oclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
    clsPolicyGradeMappingBO oclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
    //ended
    #endregion
    #region --Pageload Method--
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindTravelMode();
            BindUnit();
            BindGrade();
            BindTravelType();
            BindTravelPolicyData();
            BindInitialValue();
        }
        DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
        txtEffectiveToDate.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
    }
    #endregion
    #region --private methods--
    private void BindInitialValue()
    {
        ddlAlternateClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlDefaultClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));       
    }
    private void BindTravelMode()
    {
        try
        {
            DataTable dtTravelMode = clsUtility.GetMasterValue("TravelMode");
            if (dtTravelMode != null && dtTravelMode.Rows.Count > 0)
            {

                ddlDefaultModeOfTravel.DataSource = dtTravelMode;
                ddlDefaultModeOfTravel.DataValueField = "MasterId";
                ddlDefaultModeOfTravel.DataTextField = "Value";
                ddlDefaultModeOfTravel.DataBind();
                ddlDefaultModeOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlAlternateModeOfTravel.DataSource = dtTravelMode;
                ddlAlternateModeOfTravel.DataValueField = "MasterId";
                ddlAlternateModeOfTravel.DataTextField = "Value";
                ddlAlternateModeOfTravel.DataBind();
                ddlAlternateModeOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlDefaultModeOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlAlternateModeOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void BindTravelType()
    {
        try
        {
            DataTable dtTravelType = clsUtility.GetMasterValue("TravelType");
            if (dtTravelType != null && dtTravelType.Rows.Count > 0)
            {

                ddlTravelType.DataSource = dtTravelType;
                ddlTravelType.DataValueField = "MasterId";
                ddlTravelType.DataTextField = "Value";
                ddlTravelType.DataBind();
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void BindClassOfTravel(string Class)
    {
        try
        {
            DataTable dtClass = clsUtility.GetMasterValue(Class);
            if (dtClass != null && dtClass.Rows.Count > 0)
            {
                ddlDefaultClASsOfTravel.DataSource = dtClass;
                ddlDefaultClASsOfTravel.DataValueField = "MasterId";
                ddlDefaultClASsOfTravel.DataTextField = "Value";
                ddlDefaultClASsOfTravel.DataBind();
                ddlDefaultClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlAlternateClASsOfTravel.DataSource = dtClass;
                ddlAlternateClASsOfTravel.DataValueField = "MasterId";
                ddlAlternateClASsOfTravel.DataTextField = "Value";
                ddlAlternateClASsOfTravel.DataBind();
                ddlAlternateClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlAlternateClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void BindUnit()
    {
        try
        {
            DataTable dtUnit = clsUtility.GetMasterValue("Unit");
            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlUnit.DataSource = dtUnit;
                ddlUnit.DataValueField = "MasterId";
                ddlUnit.DataTextField = "Value";
                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void BindGrade()
    {
        try
        {
            //commented and modified  by mahesh for applying policy on list of grade
            //DataTable dtGrade = objclsTravelPolicyBO.SelectGradeMaster(0);
            //if (dtGrade != null && dtGrade.Rows.Count > 0)
            //{
            //    ddlGradeName.DataSource = dtGrade;
            //    ddlGradeName.DataValueField = "GradeId";
            //    ddlGradeName.DataTextField = "GradeName";
            //    ddlGradeName.DataBind();
            //    ddlGradeName.Items.Insert(0, new ListItem("--Select--", "0"));

            //}
            //else
            //{
            //    ddlGradeName.Items.Insert(0, new ListItem("--Select--", "0"));
            //}
            DataTable dtGrade = objclsTravelPolicyBO.SelectGradeMaster(0);
            lstbxSourceGrade.DataSource =  dtGrade;
            lstbxSourceGrade.DataValueField = "GradeId";
            lstbxSourceGrade.DataTextField = "GradeName";
            lstbxSourceGrade.DataBind();
            //ended
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void Clearfields()
    {
        txtAlias.Text = txtDurationOfTravel.Text =txtEffectiveFROMDate.Text = string.Empty;       
        //ddlGradeName.SelectedIndex = 0;
        ddlTravelType.SelectedIndex = 0;
        ddlGender.SelectedIndex = 0;
        ddlDefaultModeOfTravel.SelectedIndex = 0;
        ddlDefaultClASsOfTravel.SelectedIndex = 0;
        ddlAlternateModeOfTravel.SelectedIndex = 0;
        ddlAlternateClASsOfTravel.SelectedIndex = 0;
        ddlUnit.SelectedIndex = 0;       
        chkIsBehalfOfBooking.Checked = false;
        ViewState["TRAVELPOLICYID"] = null;
        btnSave.Text = "Save";
        lstbxSourceGrade.Items.Clear();
        lstbxDestinGrade.Items.Clear();
        BindGrade();
        
    }
    private void SaveTravelPolicy()
    {
        try
        {
            int result = DateTime.Compare(Convert.ToDateTime(txtEffectiveFROMDate.Text.Trim()), Convert.ToDateTime(txtEffectiveToDate.Text.Trim()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }
            if (ViewState["TRAVELPOLICYID"] != null && ViewState["TRAVELPOLICYID"].ToString() != "0")
            {
                objclsTravelPolicyBD.CFlag = EFlag.UPDATE.ToString();
                objclsTravelPolicyBD.TravelPolicyId = Int64.Parse(ViewState["TRAVELPOLICYID"].ToString());
            }
            else
            {
                objclsTravelPolicyBD.CFlag = EFlag.INSERT.ToString();
                objclsTravelPolicyBD.TravelPolicyId = 0;
            }
            //commented and modified by mahesh for applying policy on list of grade
            //objclsTravelPolicyBD.GradeId = Int64.Parse(ddlGradeName.SelectedValue.ToString());
            objclsTravelPolicyBD.GradeId = 0;
            //ended
            objclsTravelPolicyBD.Gender = ddlGender.SelectedItem.Text;
            objclsTravelPolicyBD.TravelType = Int64.Parse(ddlTravelType.SelectedValue.ToString());
            objclsTravelPolicyBD.DurationOfTravel = decimal.Parse(txtDurationOfTravel.Text.Trim());
            objclsTravelPolicyBD.DefaultModeOfTravel = Int64.Parse(ddlDefaultModeOfTravel.SelectedValue.ToString());
            objclsTravelPolicyBD.Unit = Int64.Parse(ddlUnit.SelectedValue.ToString());
            objclsTravelPolicyBD.DefaultClASsOfTravel = Int64.Parse(ddlDefaultClASsOfTravel.SelectedValue.ToString());
            objclsTravelPolicyBD.AlternateModeOfTravel = Int64.Parse(ddlAlternateModeOfTravel.SelectedValue.ToString());
            objclsTravelPolicyBD.AlternateClASsOfTravel = Int64.Parse(ddlAlternateClASsOfTravel.SelectedValue.ToString());
            objclsTravelPolicyBD.EffectiveFROMDate = DateTime.Parse(txtEffectiveFROMDate.Text.Trim());
            objclsTravelPolicyBD.EffectiveToDate = DateTime.Parse(txtEffectiveToDate.Text.Trim());
            objclsTravelPolicyBD.Alias = txtAlias.Text.Trim();
            if (chkIsBehalfOfBooking.Checked == true)
            {
                objclsTravelPolicyBD.IsBehalfOfBooking = true;
            }
            else
            {
                objclsTravelPolicyBD.IsBehalfOfBooking = false;
            }
            objclsTravelPolicyBD.Status = "Active";
            objclsTravelPolicyBD.DOC = DateTime.Now;
            objclsTravelPolicyBD.DOU = DateTime.Now;
            objclsTravelPolicyBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            

            if (SavePolicyGrade(objclsTravelPolicyBO.InsertUpdateTravelPolicy(objclsTravelPolicyBD)))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            Clearfields();
            BindTravelPolicyData();

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }

    private bool SavePolicyGrade(long p)
    {
        int Check = 0;
        clsManageTransaction.StartTransaction();
        if (ViewState["TRAVELPOLICYID"] != null && ViewState["TRAVELPOLICYID"].ToString() != "0")
        {
            oclsPolicyGradeMappingBD.ReferencePolicyId = Int64.Parse(ViewState["TRAVELPOLICYID"].ToString());
            oclsPolicyGradeMappingBO.DeletePolicyGradeMapping(oclsPolicyGradeMappingBD);
        }
        oclsPolicyGradeMappingBD.CFlag = EFlag.INSERT.ToString();
        oclsPolicyGradeMappingBD.ReferencePolicyId = p;
        oclsPolicyGradeMappingBD.ReferencePolicyType = "Travel Policy";
        oclsPolicyGradeMappingBD.DOC = DateTime.Now;
        oclsPolicyGradeMappingBD.DOU = DateTime.Now;
        oclsPolicyGradeMappingBD.Status = "Active";
        foreach (ListItem item in lstbxDestinGrade.Items)
        {
            oclsPolicyGradeMappingBD.GradeId = Int64.Parse(item.Value);
            oclsPolicyGradeMappingBO.InsertUpdatePolicyGradeMapping(oclsPolicyGradeMappingBD);
            Check += 1;
        }
        clsManageTransaction.EndTransaction();
        return lstbxDestinGrade.Items.Count==Check;
    }

    
    private void BindTravelPolicyData()
    {
        try
        {
            DataTable dtTravelPolicy = objclsTravelPolicyBO.SelectTravelPolicyData(0);
            if (dtTravelPolicy != null && dtTravelPolicy.Rows.Count > 0)
            {
                gvTravelPolicy.DataSource = dtTravelPolicy;
                gvTravelPolicy.DataBind();

            }
            else
            {
                lblMsg.Text = "No data found.";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }  
    }
    private void BindDefaultModeOfTravel(string DelClassOfTravel)
    {
        try
        {
            DataTable dtDelfClassOfTravel = clsUtility.GetMasterValue(DelClassOfTravel);
            if (dtDelfClassOfTravel != null && dtDelfClassOfTravel.Rows.Count > 0)
            {
                ddlDefaultClASsOfTravel.DataSource = dtDelfClassOfTravel;
                ddlDefaultClASsOfTravel.DataValueField = "MasterId";
                ddlDefaultClASsOfTravel.DataTextField = "Value";
                ddlDefaultClASsOfTravel.DataBind();
                ddlDefaultClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlDefaultClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    private void BindAlternateModeOfTravel(string AltClassOfTravel)
    {
        try
        {
            DataTable dtAltClassOfTravel = clsUtility.GetMasterValue(AltClassOfTravel);
            if (dtAltClassOfTravel != null && dtAltClassOfTravel.Rows.Count > 0)
            {
                ddlAlternateClASsOfTravel.DataSource = dtAltClassOfTravel;
                ddlAlternateClASsOfTravel.DataValueField = "MasterId";
                ddlAlternateClASsOfTravel.DataTextField = "Value";
                ddlAlternateClASsOfTravel.DataBind();
                ddlAlternateClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlAlternateClASsOfTravel.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }        
    }
    #endregion
    #region--Event Handlers--
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveTravelPolicy();
        
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clearfields();
    }  
    protected void ddlDefaultModeOfTravel_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlDefaultModeOfTravel.SelectedValue != "0")
        {
            string selDelClassOfTravel = ddlDefaultModeOfTravel.SelectedItem.Text + "Class";
            BindDefaultModeOfTravel(selDelClassOfTravel);

        }
    }
    protected void ddlAlternateModeOfTravel_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlAlternateModeOfTravel.SelectedValue != "0")
        {
            string selAltClassOfTravel = ddlAlternateModeOfTravel.SelectedItem.Text + "Class";
            BindAlternateModeOfTravel(selAltClassOfTravel);
        }
    }
    protected void gvTravelPolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Clearfields();
            Int64 TravelPolicyId = Int64.Parse(gvTravelPolicy.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["TRAVELPOLICYID"] = TravelPolicyId;
            DataTable dtTravelPolicyDetails = objclsTravelPolicyBO.SelectTravelPolicyData(TravelPolicyId);
            if (dtTravelPolicyDetails != null && dtTravelPolicyDetails.Rows.Count > 0)
            {
                ddlTravelType.SelectedValue = dtTravelPolicyDetails.Rows[0]["TravelType"].ToString();
                //commented by mahesh for applying policy on list of grade
                //ddlGradeName.SelectedValue = dtTravelPolicyDetails.Rows[0]["GradeId"].ToString();
                //ended
                ddlGender.SelectedValue = dtTravelPolicyDetails.Rows[0]["Gender"].ToString();
                txtDurationOfTravel.Text = dtTravelPolicyDetails.Rows[0]["DurationOfTravel"].ToString();
                ddlUnit.SelectedValue = dtTravelPolicyDetails.Rows[0]["Unit"].ToString();
                ddlDefaultModeOfTravel.SelectedValue = dtTravelPolicyDetails.Rows[0]["DefaultModeOfTravel"].ToString();
                ddlAlternateModeOfTravel.SelectedValue = dtTravelPolicyDetails.Rows[0]["AlternateModeOfTravel"].ToString();
                txtEffectiveFROMDate.Text = Convert.ToDateTime(dtTravelPolicyDetails.Rows[0]["EffectiveFROMDate"]).ToString("MMMM d, yyyy");
                txtEffectiveToDate.Text = Convert.ToDateTime(dtTravelPolicyDetails.Rows[0]["EffectiveToDate"]).ToString("MMMM d, yyyy");
                txtAlias.Text = dtTravelPolicyDetails.Rows[0]["Alias"].ToString();

                string selDelClassOfTravel = ddlDefaultModeOfTravel.SelectedItem.Text + "Class";
                BindDefaultModeOfTravel(selDelClassOfTravel);
                string selAltClassOfTravel = ddlAlternateModeOfTravel.SelectedItem.Text + "Class";
                BindAlternateModeOfTravel(selAltClassOfTravel);
                ddlDefaultClASsOfTravel.SelectedValue = dtTravelPolicyDetails.Rows[0]["DefaultClASsOfTravel"].ToString();
                ddlAlternateClASsOfTravel.SelectedValue = dtTravelPolicyDetails.Rows[0]["AlternateClASsOfTravel"].ToString();
                if (dtTravelPolicyDetails.Rows[0]["IsBehalfOfBooking"].ToString() == "True")
                {
                    chkIsBehalfOfBooking.Checked = true;
                }
                else
                {
                    chkIsBehalfOfBooking.Checked = false;
                }
                btnSave.Text = "Update";
                BindDestinationGrade(TravelPolicyId);
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    private void BindDestinationGrade(Int64 ReferencePolicyId)
    {
        oclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
        oclsPolicyGradeMappingBD.CFlag = "TRAVELPOLICY";
        DataTable dtList = oclsPolicyGradeMappingBO.SelectPolicyGradeMapping(oclsPolicyGradeMappingBD);
        if (dtList.Rows.Count>0)
        {
            lstbxDestinGrade.DataSource = dtList;
            lstbxDestinGrade.DataTextField = "GradeName";
            lstbxDestinGrade.DataValueField = "GradeId";
            lstbxDestinGrade.DataBind();
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
                    lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);  
        }

    }
    protected void gvTravelPolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        try
        {
            Int64 TravelPolicyId = Int64.Parse(gvTravelPolicy.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();

            if (objclsTravelPolicyBO.DeleteTravelPolicy(TravelPolicyId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }            
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");

        }
        BindTravelPolicyData();
        
        
    }
    protected void gvTravelPolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvTravelPolicy.PageIndex = e.NewPageIndex;
            BindTravelPolicyData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    protected void btnOneRight_Click(object sender, EventArgs e)
    {
        if (lstbxSourceGrade.Items.Count == 0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }
        if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
        {
            if (lstbxSourceGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
            {
                if (lstbxSourceGrade.Items[i].Selected)
                    lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);
            } 
        }
        else
        {
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);

            lstbxSourceGrade.Items.Clear();            
        }

    }
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        if (lstbxDestinGrade.Items.Count==0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }

        if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
        {
            if (lstbxDestinGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                if (lstbxDestinGrade.Items[i].Selected)
                    lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Remove(lstbxSourceGrade.Items[i]);
        }
        else
        {
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            lstbxDestinGrade.Items.Clear();
        }
    }
    protected void gvTravelPolicy_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            String strBehalfOf = Convert.ToString(e.Row.Cells[10].Text);
            if (strBehalfOf != null && !String.IsNullOrEmpty(strBehalfOf))
            {
                if (strBehalfOf.TrimEnd() == "False")
                {
                    e.Row.Cells[10].Text = "No";
                }
                else
                {
                    e.Row.Cells[10].Text = "Yes";
                }
            }
        }
    }
}
