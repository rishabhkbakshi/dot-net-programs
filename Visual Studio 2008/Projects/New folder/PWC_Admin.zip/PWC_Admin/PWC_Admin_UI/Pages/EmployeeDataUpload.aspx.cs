﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;
using System.IO;
using System.Data.OleDb;
using System.Text.RegularExpressions;

public partial class Pages_EmployeeDataUpload : BasePage
{
    #region --Initializers--
    clsEmployeeBD oclsEmployeeBD = new clsEmployeeBD();
    clsCityMasterBD oclsCityMasterBD = new clsCityMasterBD();
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsStateMasterBD oclsStateMasterBD = new clsStateMasterBD();
    clsEmployeeDataUploadBO objclsEmployeeDataUploadBO = new clsEmployeeDataUploadBO();
    clsEmployeeDataUploadBD objclsEmployeeDataUploadBD = new clsEmployeeDataUploadBD();
    clsEmployeePassportUploadBD objclsEmployeePassportUploadBD = new clsEmployeePassportUploadBD();
    clsEmployeePassportUploadBO objclsEmployeePassportUploadBO = new clsEmployeePassportUploadBO();
    static int temp = 0;
    public Boolean _Check = true;
    public Boolean _CheckSave = false;
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetCountryMasterDetails();
            GetStateMasterDetails();
            GetCityMasterDetails();
            GetEmployeeMasterDetails();
        }
    }
    #endregion
    #region --private methods--     
    /// </summary>
    /// <returns></returns>
    public void BindEmployeeGrid()
    {
        try
        {
            string connString = "";
            string filename;
            if (Request.QueryString["FileName"] != null)
            {
                filename = Request.QueryString["FileName"];
            }
            else
            {
                filename = fuEmployeeData.FileName;
            }
            ViewState["FileName"] = filename;
            string strFileName = Path.GetFileName(filename);
            string UploadPath = Server.MapPath("~\\FileUpload\\" + filename);
            string strFilePath = UploadPath;
            fuEmployeeData.SaveAs(strFilePath);
            string extension = Path.GetExtension(filename);
            if (extension.ToLower() == ".xls")
            {
                connString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + UploadPath + ";Extended Properties=Excel 8.0;";
            }
            else if (extension.ToLower() == ".xlsx")
            {
                connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + UploadPath + ";Extended Properties=Excel 12.0";
            }
            OleDbConnection con = new OleDbConnection(connString);
            OleDbDataAdapter ad = new OleDbDataAdapter(@"Select * FROM [Sheet1$]", con);
            DataSet dsEmployee = new DataSet();
            ad.Fill(dsEmployee);
            if (dsEmployee.Tables[0].Columns.Count == 20)
            {

                gvEmployeeUploadData.DataSource = dsEmployee;
                gvEmployeeUploadData.DataBind();
                ViewState["EMPLOYEEDATAUPLOAD"] = dsEmployee.Tables[0];
                pnlEmployeeGrid.Visible = true;

            }
            else
            {
                Page.ClientScript.RegisterStartupScript(typeof(Page), "alert", "<script language=JavaScript>alert('Invalid Excel file.');</script>");
                pnlEmployeeGrid.Visible = false;
                string strcheck = "Yes";
                ViewState["InvalidFile"] = strcheck;
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// </summary>
    /// <returns></returns>
    private bool CheckEmpCodeDuplicate()
    {
        try
        {
            bool bReturn;
            int dupCount = 0;
            for (int x = 0; x <= gvEmployeeUploadData.Rows.Count - 1; x++)
            {
                string val = gvEmployeeUploadData.Rows[x].Cells[0].Text;
                for (int y = x + 1; y <= gvEmployeeUploadData.Rows.Count - 1; y++)
                {
                    if (val == gvEmployeeUploadData.Rows[y].Cells[0].Text)
                    {
                        gvEmployeeUploadData.Rows[x].BackColor = System.Drawing.Color.Red;
                        gvEmployeeUploadData.Rows[y].BackColor = System.Drawing.Color.Red;
                        gvEmployeeUploadData.Rows[y].ToolTip = "Employee code has some duplicate values in Excel file.";
                        gvEmployeeUploadData.Rows[x].ToolTip = "Employee code has some duplicate values in Excel file.";
                        dupCount = +1;

                    }
                }

            }
            if (dupCount > 0)
            {
                bReturn = false;
            }
            else
            {
                bReturn = true;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// </summary>
    /// <param name="inputNumber"></param>
    /// <returns></returns>
    public bool checkNumber(string inputNumber)
    {
        try
        {
            bool bReturn;

            if (inputNumber != "")
            {
                string strRegex = @"^[1-9]+[0-9]*$";
                Regex re = new Regex(strRegex);
                if (re.IsMatch(inputNumber))
                    bReturn = true;
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// </summary>
    /// <param name="strName"></param>
    /// <returns></returns>
    public bool checkName(string strName)
    {
        try
        {
            bool bReturn;
            if (strName != "")
            {
                string strRegex = @"^[A-Za-z\s]*$";
                Regex re = new Regex(strRegex);
                if (re.IsMatch(strName))
                    bReturn = true;
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To validate Country name
    /// </summary>
    /// <param name="strValue"></param>
    /// <returns> bool </returns>
    public bool checkCounty(string strValue)
    {
        try
        {
            bool bReturn;
            
                DataTable dtCounty = ViewState["vsCounty"] as DataTable;
                var varDistinctCountry = (from row in dtCounty.AsEnumerable()
                                       select row.Field<string>("CountryName")).Distinct();
             
               var dtDistinctCountry = (from e in varDistinctCountry where e.Contains(strValue) select e);
               if (dtDistinctCountry.Count() > 0)
                    bReturn = true;
                else
                    bReturn = false;
           
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    /// <summary>
    /// To validate State and Country 
    /// </summary>
    /// <param name="strState"></param>
    /// <param name="strCountry"></param>
    /// <returns>bool</returns>
    public bool checkState(string strState,string strCountry)
    {
        try
        {
            bool bReturn;

            DataTable dtState = ViewState["vsState"] as DataTable;
            var varDistinctState = (from row in dtState.AsEnumerable()
                                      select new {StateName = row. Field<string>("StateName"),CountryName= row .Field<string>("CountryName")}).Distinct();

            //var dtCountry = varDistinctCountry.Select("CountryName = " + strValue);                  
            var dtDistinctState = (from e in varDistinctState where e.StateName == strState && e.CountryName == strCountry select e);
            if (dtDistinctState.Count() > 0)
                bReturn = true;
            else
                bReturn = false;

            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To validate City ,State and Country
    /// </summary>
    /// <param name="strCity"></param>
    /// <param name="strState"></param>
    /// <param name="strCountry"></param>
    /// <returns>bool</returns>
    public bool checkCity(string strCity,string strState, string strCountry)
    {
        try
        {
            bool bReturn;

            DataTable dtCity = ViewState["vsCity"] as DataTable;
            var varDistinctCity = (from row in dtCity.AsEnumerable()
                                    select new { CityName = row.Field<string>("CityName"), StateName = row.Field<string>("StateName"), CountryName = row.Field<string>("CountryName") }).Distinct();

            //var dtCountry = varDistinctCountry.Select("CountryName = " + strValue);                  
            var dtDistinctCity = (from e in varDistinctCity where e.CityName == strCity && e.StateName == strState && e.CountryName == strCountry select e);
            if (dtDistinctCity.Count() > 0)
                bReturn = true;
            else
                bReturn = false;

            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To check employee code exists or not 
    /// </summary>
    /// <param name="strEmployee"></param>
    /// <returns>bool</returns>
    public bool checkEmployee(string strEmployee)
    {
        try
        {
            bool bReturn;

            DataTable dtEmployee = ViewState["vsEmployee"] as DataTable;
            var varDistinctCity = (from row in dtEmployee.AsEnumerable()
                                   select new { EmployeeCode = row.Field<string>("EmployeeCode")}).Distinct();

            var dtEmployeeRows = (from e in varDistinctCity where e.EmployeeCode== strEmployee select e);
            //DataRow[] dtEmployeeRows =  dtEmployee.Select("EmployeeCode = " + strEmployee);

            if (dtEmployeeRows.Count() > 0)
                bReturn = false;
            else
                bReturn = true;

            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

     /// </summary>
    /// <param name="EmployeeCode"></param>
    /// <returns></returns>
    public bool checkAlphaNumeric(string EmployeeCode)
    {
        try
        {
            bool bReturn;
            if (EmployeeCode != "")
            {
                string strRegex = @"^[A-Za-z0-9]*$";
                Regex re = new Regex(strRegex);
                if (re.IsMatch(EmployeeCode))
                    bReturn = true;
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="strEmail"></param>
    /// <returns></returns>
    public bool checkEmail(string strEmail)
    {
        try
        {
            bool bReturn;
            if (strEmail != "")
            {
                string strRegex = @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";
                Regex re = new Regex(strRegex);
                if (re.IsMatch(strEmail))
                    bReturn = true;
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
     /// </summary>
    /// <param name="strGender"></param>
    /// <returns></returns>
    public bool checkGender(string strGender)
    {
        try
        {
            bool bReturn;
            if (strGender != "")
            {
                if (strGender.ToLower() == "male" || strGender.ToLower() == "female")
                {
                    bReturn = true;
                }
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
     /// </summary>
    /// <param name="strSelfApproved"></param>
    /// <returns></returns>
    public bool checkSelfApproved(string strSelfApproved)
    {
        try
        {
            bool bReturn;
            if (strSelfApproved != "")
            {
                if (strSelfApproved.ToLower() == "true" || strSelfApproved.ToLower() == "false")
                {
                    bReturn = true;
                }
                else
                    bReturn = false;
            }
            else
            {
                bReturn = false;
            }
            return bReturn;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// </summary>
    /// <param name="inputString"></param>
    /// <returns></returns>
    public bool IsValidDate(string inputString)
    {
        bool Success;
        try
        {
            DateTime dtParse = DateTime.Parse(inputString);
            Success = true;
        }
        catch (FormatException e)
        {
            string s = e.Message;
            Success = false;
        }
        return Success;
    }   
    /// <summary>
    /// 
    /// </summary>
    public void SaveEmployeeDataUploadData()
    {
        try
        {
            DataTable dtBUlkEmployee = (DataTable)ViewState["EMPLOYEEDATAUPLOAD"];
            if (dtBUlkEmployee.Rows.Count > 0)
            {
                clsManageTransaction.StartTransaction();
                foreach (DataRow Row in dtBUlkEmployee.Rows)
                {
                    objclsEmployeeDataUploadBD.EmployeeCode = Row["EmployeeCode"].ToString();
                    objclsEmployeeDataUploadBD.FirstName = Row["FirstName"].ToString();
                    objclsEmployeeDataUploadBD.LastName = Row["LastName"].ToString();
                    if (Row["Gender"].ToString().ToLower() == "male")
                    {
                        objclsEmployeeDataUploadBD.Gender = "Male";
                    }
                    else
                    {
                        objclsEmployeeDataUploadBD.Gender = "Female";
                    }
                    objclsEmployeeDataUploadBD.ReportingManager = Row["ReportingManager"].ToString();
                    objclsEmployeeDataUploadBD.DelegatationTo = Row["DelegatationTo"].ToString();
                    objclsEmployeeDataUploadBD.Email = Row["Email"].ToString();
                    objclsEmployeeDataUploadBD.PersonalPhoneNo = Row["PersonalPhoneNo"].ToString();
                    objclsEmployeeDataUploadBD.PersonalVehicleNo = Row["PersonalVehicleNo"].ToString();
                    objclsEmployeeDataUploadBD.CompanyPhoneNo = Row["CompanyPhoneNo"].ToString();
                    objclsEmployeeDataUploadBD.CompanyVehicleNo = Row["CompanyVehicleNo"].ToString();
                    objclsEmployeeDataUploadBD.IsSelfApproved = Convert.ToBoolean(Row["IsSelfApproved"].ToString());
                    objclsEmployeeDataUploadBD.DepartmentName = Row["DepartmentName"].ToString();
                    objclsEmployeeDataUploadBD.RoleName = Row["RoleName"].ToString();
                    objclsEmployeeDataUploadBD.CFlag = EFlag.INSERT.ToString();
                    objclsEmployeeDataUploadBD.EmployeeId = 0;
                    objclsEmployeeDataUploadBD.Status = "Active";
                    objclsEmployeeDataUploadBD.TransactionId = 0;
                    objclsEmployeeDataUploadBD.DOC = DateTime.Now;
                    objclsEmployeeDataUploadBD.DOU = DateTime.Now;
                    long EmployeeId = objclsEmployeeDataUploadBO.EmployeeDataUploadIU(objclsEmployeeDataUploadBD);
                    if (Row["PassportNo"].ToString() != "" || Row["PassportNo"].ToString() == string.Empty)
                    {
                        objclsEmployeePassportUploadBD.EmployeeId = EmployeeId;
                        objclsEmployeePassportUploadBD.PassportNo = Row["PassportNo"].ToString();
                        objclsEmployeePassportUploadBD.CountryName = Row["CountryName"].ToString();
                        objclsEmployeePassportUploadBD.StateName = Row["StateName"].ToString();
                        objclsEmployeePassportUploadBD.CityName = Row["CityName"].ToString();
                        objclsEmployeePassportUploadBD.PassportIssueDate = DateTime.Parse(Row["PassportIssueDate"].ToString());
                        objclsEmployeePassportUploadBD.PassportExpiryDate = DateTime.Parse(Row["PassportExpiryDate"].ToString());
                        objclsEmployeePassportUploadBD.Status = "Active";
                        objclsEmployeePassportUploadBD.DOC = DateTime.Now;
                        objclsEmployeePassportUploadBD.DOU = DateTime.Now;
                        objclsEmployeePassportUploadBD.TransactionId = 0;
                        objclsEmployeePassportUploadBO.InsertUpdateEmployeePassportUpload(objclsEmployeePassportUploadBD);
                    }
                }
                clsManageTransaction.EndTransaction();
                lblMessage.Text = "Data save successfully.";
                lblMessage.Visible = true;
                gvEmployeeUploadData.DataSource = null;
                gvEmployeeUploadData.DataBind();
                btnSave.Visible = false;
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

    /// <summary>
    /// To get distinct Country details
    /// </summary>
    public void GetCountryMasterDetails()
    {
        try
        {
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
            DataTable dtCounty = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            ViewState["vsCounty"] = dtCounty;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To get distinct State and Country details
    /// </summary>
    public void GetStateMasterDetails()
    {
        try
        {
            oclsStateMasterBD.CFlag = EFlag.ALL.ToString();
            oclsStateMasterBD.StateId = 0;
            clsStateMasterBO oclsStateMasterBO = new clsStateMasterBO();
            DataTable dtState = oclsStateMasterBO.SelectStateMaster(oclsStateMasterBD);
            ViewState["vsState"] = dtState;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To get distinct City ,State and Country details
    /// </summary>
    public void GetCityMasterDetails()
    {
        try
        {
            oclsCityMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCityMasterBD.CityId = 0;
            clsCityMasterBO oclsCityMasterBO = new clsCityMasterBO();
            DataTable dtState = oclsCityMasterBO.SelectCityMaster(oclsCityMasterBD);
            ViewState["vsCity"] = dtState;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To get employee details
    /// </summary>
    public void GetEmployeeMasterDetails()
    {
        try
        {
            oclsEmployeeBD.CFlag = EFlag.ALL.ToString();
            oclsEmployeeBD.EmployeeId = 0;
            clsEmployeeBO oclsEmployeeBO = new clsEmployeeBO();
            DataTable dtEmployee = oclsEmployeeBO.SelectEmployee(oclsEmployeeBD);
            ViewState["vsEmployee"] = dtEmployee;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Event Handlers--
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvEmployeeUploadData_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //validate Employee code.
            if (e.Row.Cells[0].Text != "&nbsp;")
            {
                if (!checkAlphaNumeric(e.Row.Cells[0].Text) || !checkEmployee(e.Row.Cells[0].Text))
                {
                    e.Row.Cells[0].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[0].ToolTip = "Invalid Employee code.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[0].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[0].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate First Name.
            if (e.Row.Cells[1].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[1].Text))
                {
                    e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[1].ToolTip = "Invalid First Name.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[1].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[1].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate Last Name.
            if (e.Row.Cells[2].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[2].Text))
                {
                    e.Row.Cells[2].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[2].ToolTip = "Invalid Last Name.";
                    _Check = false;
                }
            }
            //validate Gender.
            if (e.Row.Cells[3].Text != "&nbsp;")
            {
                if (!checkGender(e.Row.Cells[3].Text))
                {
                    e.Row.Cells[3].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[3].ToolTip = "Invalid Gender.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[3].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[3].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate ReportingManager.
            if (e.Row.Cells[4].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[4].Text))
                {
                    e.Row.Cells[4].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[4].ToolTip = "Invalid Reporting Manager.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[4].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[4].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate DelegatationTo.
            if (e.Row.Cells[5].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[5].Text))
                {
                    e.Row.Cells[5].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[5].ToolTip = "Invalid Delegatation To.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[5].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[5].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate Email.
            if (e.Row.Cells[6].Text != "&nbsp;")
            {
                if (!checkEmail(e.Row.Cells[6].Text))
                {
                    e.Row.Cells[6].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[6].ToolTip = "Invalid Email.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[6].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[6].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate Personal PhoneNo.
            if (e.Row.Cells[7].Text != "&nbsp;")
            {
                if (!checkNumber(e.Row.Cells[7].Text))
                {
                    e.Row.Cells[7].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[7].ToolTip = "Invalid Personal Phone No.";
                    _Check = false;
                }
            }
            //validate Personal VehicleNo.
            if (e.Row.Cells[8].Text != "&nbsp;")
            {
                if (!checkAlphaNumeric(e.Row.Cells[8].Text))
                {
                    e.Row.Cells[8].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[8].ToolTip = "Invalid Personal Vehicle No.";
                    _Check = false;
                }
            }
            //validate Company PhoneNo.
            if (e.Row.Cells[9].Text != "&nbsp;")
            {
                if (!checkNumber(e.Row.Cells[9].Text))
                {
                    e.Row.Cells[9].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[9].ToolTip = "Invalid Company Phone No";
                    _Check = false;
                }
            }
            //validate Company VehicleNo.
            if (e.Row.Cells[10].Text != "&nbsp;")
            {
                if (!checkAlphaNumeric(e.Row.Cells[10].Text))
                {
                    e.Row.Cells[10].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[10].ToolTip = "Invalid Company Vehicle No.";
                    _Check = false;
                }
            }
            //validate Is SelfApproved.
            if (e.Row.Cells[11].Text != "&nbsp;")
            {
                if (!checkSelfApproved(e.Row.Cells[11].Text))
                {
                    e.Row.Cells[11].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[11].ToolTip = "Invalid Is Self Approved.";
                    _Check = false;
                }
            }
            else
            {
                temp = temp + 1;
                e.Row.Cells[11].BackColor = System.Drawing.Color.Red;
                e.Row.Cells[11].ToolTip = "Mandatory.";
                _Check = false;
            }
            //validate Department Name.
            if (e.Row.Cells[12].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[12].Text))
                {
                    e.Row.Cells[12].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[12].ToolTip = "Invalid Department Name";
                    _Check = false;
                }
            }
            //else
            //{
            //    temp = temp + 1;
            //    e.Row.Cells[12].BackColor = System.Drawing.Color.Red;
            //    e.Row.Cells[12].ToolTip = "Mandatory.";
            //    _Check = false;
            //}
            //validate Role Name.
            if (e.Row.Cells[13].Text != "&nbsp;")
            {
                if (!checkName(e.Row.Cells[13].Text))
                {
                    e.Row.Cells[13].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[13].ToolTip = "Invalid Role Name.";
                    _Check = false;
                }
            }
            //else
            //{
            //    temp = temp + 1;
            //    e.Row.Cells[13].BackColor = System.Drawing.Color.Red;
            //    e.Row.Cells[13].ToolTip = "Mandatory.";
            //    _Check = false;
            //}
            //validate PassportNo
            if (e.Row.Cells[14].Text != "&nbsp;")
            {
                if (!checkAlphaNumeric(e.Row.Cells[14].Text))
                {
                    e.Row.Cells[14].BackColor = System.Drawing.Color.Red;
                    temp = temp + 1;
                    e.Row.Cells[14].ToolTip = "Invalid Passport No.";
                    _Check = false;
                }
                else
                {
                    //validate Passport Issue Date
                    if (e.Row.Cells[15].Text != "&nbsp;")
                    {
                        if (!IsValidDate(e.Row.Cells[15].Text))
                        {
                            e.Row.Cells[15].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[15].ToolTip = "Invalid Passport Issue Date.";
                            _Check = false;
                            return;
                        }
                    }
                    else
                    {
                        temp = temp + 1;
                        e.Row.Cells[15].BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[15].ToolTip = "Mandatory.";
                        _Check = false;
                    }
                    //validate Passport Expiry Date
                    if (e.Row.Cells[16].Text != "&nbsp;")
                    {
                        if (!IsValidDate(e.Row.Cells[16].Text))
                        {
                            e.Row.Cells[16].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[16].ToolTip = "Invalid Passport Expiry Date.";
                            _Check = false;
                            return;
                        }
                    }
                    else
                    {
                        temp = temp + 1;
                        e.Row.Cells[16].BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[16].ToolTip = "Mandatory.";
                        _Check = false;
                    }
                    ////validate Passport Issue Date and Passport Expiry Date
                    if ((e.Row.Cells[15].Text != "&nbsp;") && (e.Row.Cells[16].Text != "&nbsp;"))
                    {
                        int result = DateTime.Compare(Convert.ToDateTime(e.Row.Cells[15].Text), Convert.ToDateTime(e.Row.Cells[16].Text));
                        if (result > 0)
                        {
                            e.Row.Cells[15].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[15].ToolTip = "Passport issue date should be greater than passport expiry date.";
                            _Check = false;                           
                        }
                    }
                    //validate Country Name
                    if (e.Row.Cells[17].Text != "&nbsp;")
                    {
                        if (!checkName(e.Row.Cells[17].Text) || !checkCounty(e.Row.Cells[17].Text))
                        {  
                            e.Row.Cells[17].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[17].ToolTip = "Invalid Country Name.";
                            _Check = false;
                        }
                       
                    }
                    else
                    {
                        temp = temp + 1;
                        e.Row.Cells[17].BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[17].ToolTip = "Mandatory.";
                        _Check = false;
                    }
                    //validate State Name
                    if (e.Row.Cells[18].Text != "&nbsp;")
                    {
                        if (!checkName(e.Row.Cells[18].Text) || !checkState(e.Row.Cells[18].Text,e.Row.Cells[17].Text))
                        {
                            e.Row.Cells[18].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[18].ToolTip = "Invalid State Name.";
                            _Check = false;
                        }
                    }
                    else
                    {
                        temp = temp + 1;
                        e.Row.Cells[18].BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[18].ToolTip = "Mandatory.";
                        _Check = false;
                    }
                    //validate City Name
                    if (e.Row.Cells[19].Text != "&nbsp;")
                    {
                        if (!checkName(e.Row.Cells[19].Text) || !checkCity(e.Row.Cells[19].Text,e.Row.Cells[18].Text,e.Row.Cells[17].Text) )
                        {
                            e.Row.Cells[19].BackColor = System.Drawing.Color.Red;
                            temp = temp + 1;
                            e.Row.Cells[19].ToolTip = "Invalid City Name.";
                            _Check = false;
                        }
                    }
                    else
                    {
                        temp = temp + 1;
                        e.Row.Cells[19].BackColor = System.Drawing.Color.Red;
                        e.Row.Cells[19].ToolTip = "Mandatory.";
                        _Check = false;
                    }
                }
            }
        }
    }
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            ViewState["InvalidFile"] = null;
            string filename = fuEmployeeData.FileName;
            string extension = Path.GetExtension(filename);
            if (fuEmployeeData.FileName != null && fuEmployeeData.FileName != string.Empty && (extension.ToLower() == ".xls") || (extension.ToLower() == ".xlsx"))
            {
                BindEmployeeGrid();
                if ((_Check != false) & (CheckEmpCodeDuplicate() != false))
                {
                    btnSave.Visible = true;
                }
                else
                {
                    btnSave.Visible = false;
                }
            }
            else
            {
                Page.ClientScript.RegisterStartupScript(typeof(Page), "alert", "<script language=JavaScript>alert('No File has been selected or Invalid file format.');</script>");
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// To save Employee Upload Data
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveEmployeeDataUploadData();
        GetEmployeeMasterDetails();
    }
    /// </summary>
    /// To download excel file form resource file.
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lbtnDownloadFile_Click(object sender, EventArgs e)
    {
        try
        {
            string FileName = "EmployeeMasterData.xlsx";
            string PathToExcelFile = Server.MapPath("~\\Resource\\" + FileName);
            FileInfo file = new FileInfo(PathToExcelFile); 
            if (file.Exists) 
            { 
                Response.Clear(); 
                Response.ClearHeaders(); 
                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment; filename=" + FileName); 
                Response.AddHeader("Content-Type", "application/Excel"); 
                Response.ContentType = "application/vnd.xls"; 
                Response.AddHeader("Content-Length", file.Length.ToString()); 
                Response.WriteFile(file.FullName); 
                Response.End(); 
            } 
            else 
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('File does not exist.');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Problem in downloading file.');</script>");
        }
       
    }
    #endregion    
}
