﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_TelephonePolicy : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ViewState["TPID"] = 0;
                BindGrade();
                BindCurrency();
                BindType();
                BindTelephonePolicy();
                ShowMessage(string.Empty);
                Session["TP"] = Server.UrlEncode(System.DateTime.Now.ToString());
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["TP"] = Session["TP"];
    }
    private void BindGrade()
    {
        clsGradeMasterBD oGradeMasterBD = new clsGradeMasterBD();
        oGradeMasterBD.CFlag = "PARENT";
        oGradeMasterBD.GradeId = 0;
        clsGradeMasterBO oGradeMasterBO = new clsGradeMasterBO();
        DataTable dtGrade = oGradeMasterBO.SelectGradeMaster(oGradeMasterBD);
        ddlGrade.DataSource = dtGrade;
        ddlGrade.DataTextField = "GradeName";
        ddlGrade.DataValueField = "GradeId";
        ddlGrade.DataBind();
        ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    private void BindCurrency()
    {
        try
        {
            ddlCurrency.DataSource = clsUtility.GetMasterValue("Currency");
            ddlCurrency.DataTextField = "Value";
            ddlCurrency.DataValueField = "MasterId";
            ddlCurrency.DataBind();
            ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    private void BindType()
    {
        try
        {
            ddlType.DataSource = clsUtility.GetMasterValue("TelephoneType");
            ddlType.DataTextField = "Value";
            ddlType.DataValueField = "MasterId";
            ddlType.DataBind();
            ddlType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// 
    /// </summary>
    private void BindTelephonePolicy()
    {
        try
        {
            DataTable dtTelephonePolicy = (new clsTelephonePolicyBO()).SelectTelephonePolicies("ALL", 0);
            gvTelephonePolicy.DataSource = dtTelephonePolicy;
            gvTelephonePolicy.DataBind();

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update process
    /// </summary>
    /// <param name="Flag"></param>
    /// <returns></returns>
    private long InsertOrUpdateTelephonePolicy(string Flag)
    {
        try
        {
            long PPId = 0;
            clsTelephonePolicyBO oTelephonePolicyBO = new clsTelephonePolicyBO();
            clsTelephonePolicyBD oTelephonePolicyBD = new clsTelephonePolicyBD();
            oTelephonePolicyBD.TPId = Convert.ToInt64(ViewState["TPID"]);
            oTelephonePolicyBD.GradeId = Convert.ToInt64(ddlGrade.SelectedValue);
            oTelephonePolicyBD.Amount = Convert.ToDecimal(txtAmount.Text.Trim());
            oTelephonePolicyBD.CurrencyId = Convert.ToInt64(ddlCurrency.SelectedItem.Value);
            oTelephonePolicyBD.Type = ddlType.SelectedItem.Text;
            oTelephonePolicyBD.Alias = txtAlias.Text.Trim();
            oTelephonePolicyBD.Status = "Active";
            oTelephonePolicyBD.DOC = DateTime.Now;
            oTelephonePolicyBD.DOU = DateTime.Now;
            oTelephonePolicyBD.TransactionId = 1;

            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            PPId = oTelephonePolicyBO.InsertUpdateTelephonePolicies(oTelephonePolicyBD, Flag);
            ViewState["TPID"] = 0;
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................
            return PPId;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="ProcessId"></param>
    private void SetControls(Int64 TPId)
    {
        try
        {
            ViewState["TPID"] = TPId;
            clsTelephonePolicyBD oTelephonePolicyBD = new clsTelephonePolicyBD();
            oTelephonePolicyBD.TPId = TPId;
            DataTable dtTelephonePolicy = (new clsTelephonePolicyBO()).SelectTelephonePolicies("TPId", TPId);
            if (dtTelephonePolicy.Rows.Count > 0)
            {
                string GradeId = Convert.ToString(dtTelephonePolicy.Rows[0]["GradeId"]);
                ListItem GradeItem = ddlGrade.Items.FindByValue(GradeId) as ListItem;
                if (GradeItem != null)
                {
                    ddlGrade.ClearSelection();
                    GradeItem.Selected = true;
                }
                txtAmount.Text = Convert.ToString(dtTelephonePolicy.Rows[0]["Amount"]);
                string CurrencyId = Convert.ToString(dtTelephonePolicy.Rows[0]["CurrencyId"]);
                ListItem CurrencyItem = ddlCurrency.Items.FindByValue(CurrencyId) as ListItem;
                if (CurrencyItem != null)
                {
                    ddlCurrency.ClearSelection();
                    CurrencyItem.Selected = true;
                }

                string Type = Convert.ToString(dtTelephonePolicy.Rows[0]["Type"]);
                ListItem TypeItem = ddlType.Items.FindByText(Type) as ListItem;
                if (TypeItem != null)
                {
                    ddlType.ClearSelection();
                    TypeItem.Selected = true;
                }
                txtAlias.Text = Convert.ToString(dtTelephonePolicy.Rows[0]["Alias"]);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["TP"].ToString() == ViewState["TP"].ToString())
            {
                Session["TP"] = Server.UrlEncode(System.DateTime.Now.ToString()); string Flag = EFlag.INSERT.ToString();
                if (Convert.ToInt64(ViewState["TPID"]) > 0)
                {
                    Flag = EFlag.UPDATE.ToString();
                }
                InsertOrUpdateTelephonePolicy(Flag);
                Response.Redirect(Request.Path + "?MSG=" + Flag, false);
            }
            else
            {
                Response.Redirect(Request.Path, false);
            }
        }
        catch (Exception ex)
        {

            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
    }
    /// <summary>
    /// The event is use to update process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvTelephonePolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 PPId = Convert.ToInt64(gvTelephonePolicy.DataKeys[e.RowIndex].Value);
            SetControls(PPId);
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To delete(make inactive) Process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvTelephonePolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 PPId = Convert.ToInt64(gvTelephonePolicy.DataKeys[e.RowIndex].Value);
            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            (new clsTelephonePolicyBO()).DeleteTelephonePolicies(PPId);
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................
            Response.Redirect(Request.Path + "?MSG=" + EFlag.DELETE.ToString(), false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

}
