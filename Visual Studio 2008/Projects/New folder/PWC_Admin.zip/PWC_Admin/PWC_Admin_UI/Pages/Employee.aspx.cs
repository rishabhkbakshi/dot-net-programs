﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_Employee : BasePage
{

    #region--Initializers--
    clsEmployeeBD oclsEmployeeBD = new clsEmployeeBD();
    clsEmployeeBO oclsEmployeeBO = new clsEmployeeBO();
    clsRoleMasterBO objclsRoleMasterBO = new clsRoleMasterBO();
    clsRoleMasterBD objclsRoleMasterBD = new clsRoleMasterBD();
    clsOrganizationStructureBO objclsOrganizationStructureBO = new clsOrganizationStructureBO();
    clsOrganizationStructureBD objclsOrganizationStructureBD = new clsOrganizationStructureBD();
    DataTable dtEmployee = new DataTable();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Bindgrid();
                Binddropdown();
                BindRoleName();
                BindLocation();
                lblEmail.Text = clsUtility.GetFromWebConfig("Email");
                lblMsg.Text = string.Empty;
            }
            tcEmployee.ActiveTabIndex = 0;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }


    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update Employee
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            bool flag = true;
            if (ViewState["EmployeeId"] != null && ViewState["EmployeeId"].ToString() != "0")
            {
                oclsEmployeeBD.CFlag = EFlag.UPDATE.ToString();
                oclsEmployeeBD.EmployeeId = Int64.Parse(ViewState["EmployeeId"].ToString());
                flag = false;
            }
            else
            {
                oclsEmployeeBD.CFlag = EFlag.INSERT.ToString();
                oclsEmployeeBD.EmployeeId = 0;
            }
            oclsEmployeeBD.Alias = txtAlias.Text.Trim();
            oclsEmployeeBD.CompanyPhoneNo = txtCompanyPhoneNo.Text.Trim() + "-" + txtCompanyPhoneNo2.Text.Trim() + "-" + txtCompanyPhoneNo3.Text.Trim();
            oclsEmployeeBD.CompanyVehicleNo = txtCompanyVehicleNo.Text.Trim();
            oclsEmployeeBD.DelegatationTo = 0;
            oclsEmployeeBD.DOC = DateTime.Now;
            oclsEmployeeBD.DOU = DateTime.Now;
            oclsEmployeeBD.Email = txtEmail.Text.Trim() + lblEmail.Text;
            oclsEmployeeBD.EmployeeCode = txtEmployeeCode.Text.Trim();
            oclsEmployeeBD.FirstName = txtFirstName.Text.Trim();
            oclsEmployeeBD.Gender = ddlGender.SelectedItem.Text;
            oclsEmployeeBD.IsSelfApproved = chkIsSelfApproved.Checked;
            oclsEmployeeBD.LastName = txtLastName.Text.Trim();
            oclsEmployeeBD.PersonalPhoneNo = txtPersonalPhoneNo.Text.Trim() + "-" + txtPersonalPhoneNo2.Text.Trim();
            oclsEmployeeBD.PersonalVehicleNo = txtPersonalVehicleNo.Text.Trim();
            oclsEmployeeBD.ReportingManager = Int64.Parse(ddlReportingManager.SelectedValue);//Need to be changed
            oclsEmployeeBD.Status = "Active";
            oclsEmployeeBD.TransactionId = 1;//Need to be changed
            oclsEmployeeBD.DepartmentId = Int64.Parse(hdnDepartmentId.Value);
            oclsEmployeeBD.RoleId = Int64.Parse(ddlRoleName.SelectedValue);
            oclsEmployeeBD.LocationId = Convert.ToInt64(ddlLocation.SelectedValue);

            clsManageTransaction.StartTransaction();
            if (oclsEmployeeBO.InsertUpdateEmployee(oclsEmployeeBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                if (flag)
                {
                    lblMsg.Text = "Employee Created Successfully.";
                }
                else
                {
                    lblMsg.Text = "Employee Updated Successfully.";
                }
            }
            else
            {
                clsManageTransaction.EndTransaction();
                lblMsg.Text = "Not Successfully done.";
            }
            Bindgrid();
            Binddropdown();
            BindLocation();
            Clearfields();
            ucPassportDetails1.Flag = 1;
            ucVisaDetails1.Flag = 1;
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Employee already exists.');</script>");
            }
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvEmployee_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvEmployee.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The event is use to update and delete Employee
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvEmployee_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["EmployeeId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsEmployeeBD.EmployeeId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsEmployeeBO.DeleteEmployee(oclsEmployeeBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvEmployee_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            oclsEmployeeBD.CFlag = "SINGLE";
            oclsEmployeeBD.EmployeeId = Int64.Parse(gvEmployee.DataKeys[e.RowIndex].Value.ToString());
            dtEmployee = oclsEmployeeBO.SelectEmployee(oclsEmployeeBD);
            if (dtEmployee != null && dtEmployee.Rows.Count > 0)
            {
                txtAlias.Text = dtEmployee.Rows[0]["Alias"].ToString();
                txtCompanyVehicleNo.Text = dtEmployee.Rows[0]["CompanyVehicleNo"].ToString();
                txtEmployeeCode.Text = dtEmployee.Rows[0]["EmployeeCode"].ToString();
                txtFirstName.Text = dtEmployee.Rows[0]["FirstName"].ToString();
                txtLastName.Text = dtEmployee.Rows[0]["LastName"].ToString();
                if (!string.IsNullOrEmpty(Convert.ToString(dtEmployee.Rows[0]["PersonalPhoneNo"])))
                {
                    string[] PersonalPhoneNo = Convert.ToString(dtEmployee.Rows[0]["PersonalPhoneNo"]).Split('-');
                    txtPersonalPhoneNo.Text = PersonalPhoneNo[0];
                    txtPersonalPhoneNo2.Text = PersonalPhoneNo[1];
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dtEmployee.Rows[0]["CompanyPhoneNo"])))
                {
                    string[] CompanyPhoneNo = Convert.ToString(dtEmployee.Rows[0]["CompanyPhoneNo"]).Split('-');
                    txtCompanyPhoneNo.Text = CompanyPhoneNo[0];
                    txtCompanyPhoneNo2.Text = CompanyPhoneNo[1];
                    txtCompanyPhoneNo3.Text = CompanyPhoneNo[2];
                }
                txtPersonalVehicleNo.Text = dtEmployee.Rows[0]["PersonalVehicleNo"].ToString();
                ddlGender.SelectedIndex = dtEmployee.Rows[0]["Gender"].ToString() == "Male" ? 1 : 2;
                ddlReportingManager.SelectedIndex = ddlReportingManager.Items.IndexOf(ddlReportingManager.Items.FindByValue(dtEmployee.Rows[0]["ReportingManager"].ToString()));
                chkIsSelfApproved.Checked = dtEmployee.Rows[0]["IsSelfApproved"].ToString() == "True" ? true : false;
                txtDepartment.Text = dtEmployee.Rows[0]["DepartmentName"].ToString();
                hdnDepartmentId.Value = dtEmployee.Rows[0]["DepartmentId"].ToString();
                ddlRoleName.SelectedIndex = ddlRoleName.Items.IndexOf(ddlRoleName.Items.FindByValue(dtEmployee.Rows[0]["RoleId"].ToString()));
                ddlLocation.SelectedValue = dtEmployee.Rows[0]["LocationId"].ToString();
                string Email = Convert.ToString(dtEmployee.Rows[0]["Email"]);
                string WebEmail = clsUtility.GetFromWebConfig("Email");
                if (Email.Length > WebEmail.Length)
                {
                    Email = Email.Substring(0, (Email.Length - WebEmail.Length));
                }
                txtEmail.Text = Email;
                btnSave.Text = "Update";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void gvEmployee_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind Employee data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsEmployeeBD.CFlag = EFlag.ALL.ToString();
            oclsEmployeeBD.EmployeeId = 0;
            dtEmployee = oclsEmployeeBO.SelectEmployee(oclsEmployeeBD);
            //if (dtEmployee!=null && dtEmployee.Rows.Count>0)
            //{
            gvEmployee.DataSource = dtEmployee;
            gvEmployee.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtPersonalVehicleNo.Text = txtPersonalPhoneNo.Text = txtLastName.Text = txtFirstName.Text = txtEmployeeCode.Text = txtEmail.Text = txtCompanyVehicleNo.Text = txtCompanyPhoneNo.Text = txtAlias.Text = string.Empty;
        chkIsSelfApproved.Checked = false;
        ViewState["EmployeeId"] = ddlGender.SelectedIndex = ddlReportingManager.SelectedIndex = 0;
        txtDepartment.Text = string.Empty;
        ddlRoleName.SelectedIndex = 0;
        btnSave.Text = "Save";
        lblMsg.Text = string.Empty;
        txtCompanyPhoneNo2.Text = string.Empty;
        txtCompanyPhoneNo3.Text = string.Empty;
        txtPersonalPhoneNo2.Text = string.Empty;
        ddlLocation.SelectedIndex = 0;
    }
    /// <summary>
    /// The following method is use to bind ReportingManager dropdown
    /// </summary>
    private void Binddropdown()
    {
        try
        {
            oclsEmployeeBD.CFlag = EFlag.ALL.ToString();
            oclsEmployeeBD.EmployeeId = 0;
            dtEmployee = new DataView(oclsEmployeeBO.SelectEmployee(oclsEmployeeBD)).ToTable(false, new string[] { "EmployeeId", "FirstName", "LastName", "EmployeeCode" });
            if (dtEmployee != null && dtEmployee.Rows.Count > 0)
            {
                //Start:Added By Raju Prajapati(11-July-2012) for Concatenating the Name and EmployeeCode
                var dict = new Dictionary<int, string>();
                foreach (DataRow row in dtEmployee.Rows)
                {
                    dict.Add(Convert.ToInt32(row["EmployeeId"]), row["FirstName"] + " " + row["LastName"] + " (" + row["EmployeeCode"] + ")");
                }
                //End:Added By Raju Prajapati(11-July-2012) for Concatenating the Name and EmployeeCode

                ddlReportingManager.DataSource = dict;//dtEmployee;
                ddlReportingManager.DataTextField = "Value";//"EmployeeFullNameWithCode";
                ddlReportingManager.DataValueField = "Key";//"EmployeeId";
                ddlReportingManager.DataBind();
            }
            ddlReportingManager.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The following method is use to bind RoleName to grid
    /// </summary>
    private void BindRoleName()
    {
        try
        {
            objclsRoleMasterBD.CFlag = EFlag.ALL.ToString();
            objclsRoleMasterBD.RoleId = 0;
            DataTable objDataTable = objclsRoleMasterBO.SelectRoleMaster(objclsRoleMasterBD);
            if (objDataTable.Rows.Count > 0)
            {
                ddlRoleName.DataSource = objDataTable;
                ddlRoleName.DataSource = objDataTable;
                ddlRoleName.DataValueField = "RoleId";
                ddlRoleName.DataTextField = "Name";
                ddlRoleName.DataBind();
                ddlRoleName.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlRoleName.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    private void BindLocation()
    {
        try
        {
            DataTable dtLocationDataTable = objclsOrganizationStructureBO.SelectLocation();
            if (dtLocationDataTable.Rows.Count > 0)
            {
                ddlLocation.DataSource = dtLocationDataTable;
                ddlLocation.DataValueField = "OrganisationStructureId";
                ddlLocation.DataTextField = "Name";
                ddlLocation.DataBind();
                ddlLocation.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlLocation.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    #endregion
}
