﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_GradeMaster : BasePage
{
    #region--Initializers--
    clsGradeMasterBD objclsGradeMasterBD = new clsGradeMasterBD();
    clsGradeMasterBO objclsGradeMasterBO = new clsGradeMasterBO();
    DataTable objDataTable = new DataTable();
    #endregion
    #region--PageLoad--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Bindgrid();
                Binddropdown();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }


    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update Grade
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["GradeId"] != null && ViewState["GradeId"].ToString() != "0")
            {
                objclsGradeMasterBD.CFlag = EFlag.UPDATE.ToString();
                objclsGradeMasterBD.GradeId = int.Parse(ViewState["GradeId"].ToString());
            }
            else
            {
                objclsGradeMasterBD.CFlag = EFlag.INSERT.ToString();
                objclsGradeMasterBD.GradeId = 0;
            }
            objclsGradeMasterBD.GradeName = txtGradeName.Text.Trim();
            objclsGradeMasterBD.Descriptions = txtDescriptions.Text.Trim();
            objclsGradeMasterBD.Alias = txtAlias.Text.Trim();
            objclsGradeMasterBD.DOC = DateTime.Now;
            objclsGradeMasterBD.DOU = DateTime.Now;
            objclsGradeMasterBD.Status = "Active";
            objclsGradeMasterBD.TransactionId = 1;
            if (ddlParent.SelectedValue.ToString() != "0")
            {
                objclsGradeMasterBD.ParentId = Int64.Parse(ddlParent.SelectedValue.ToString());
            }
            else
            {
                objclsGradeMasterBD.ParentId = 0;
            }
            objclsGradeMasterBD.Level = txtLevel.Text.Trim();
            clsManageTransaction.StartTransaction();
            if (objclsGradeMasterBO.InsertUpdateGradeMaster(objclsGradeMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Bindgrid();
                Binddropdown();
                ClearFields();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Bindgrid();
                Binddropdown();
                ClearFields();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearFields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //txtAlias.Text = HttpUtility.HtmlDecode(gvGradeMaster.Rows[e.RowIndex].Cells[2].Text);
        txtGradeName.Text = HttpUtility.HtmlDecode(gvGradeMaster.Rows[e.RowIndex].Cells[0].Text);
        txtDescriptions.Text = HttpUtility.HtmlDecode(gvGradeMaster.Rows[e.RowIndex].Cells[1].Text);
        txtLevel.Text = gvGradeMaster.Rows[e.RowIndex].Cells[2].Text == "&nbsp;" ? string.Empty : gvGradeMaster.Rows[e.RowIndex].Cells[2].Text;
        if (gvGradeMaster.Rows[e.RowIndex].Cells[3].Text != string.Empty)
            ddlParent.SelectedIndex = ddlParent.Items.IndexOf(ddlParent.Items.FindByText(gvGradeMaster.Rows[e.RowIndex].Cells[3].Text));
        ddlParent.Enabled = false;
        btnSave.Text = "Update";
    }
    /// <summary>
    /// The event is use to update and delete Grade
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeMaster_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["GradeId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                clsManageTransaction.StartTransaction();
                objclsGradeMasterBD.GradeId = Int64.Parse(e.CommandArgument.ToString());
                if (IsParentExists(Int64.Parse(e.CommandArgument.ToString())))
                {
                    if (objclsGradeMasterBO.DeleteGradeMaster(objclsGradeMasterBD) > 0)
                    {
                        clsManageTransaction.EndTransaction();
                        ClearFields();
                        Bindgrid();
                        Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                    }
                    else
                    {
                        clsManageTransaction.EndTransaction();
                        ClearFields();
                        Bindgrid();
                        Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                    }
                }
                else
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please delete the child grade before deleting the parent.');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvGradeMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvGradeMaster.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind Grade data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objDataTable = objclsGradeMasterBO.SelectGradeMaster(new clsGradeMasterBD() { CFlag = EFlag.ALL.ToString(), GradeId = 0 });
            //if (objDataTable != null && objDataTable.Rows.Count>0)
            //{
            gvGradeMaster.DataSource = objDataTable;
            gvGradeMaster.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void ClearFields()
    {
        txtLevel.Text = txtAlias.Text = txtDescriptions.Text = txtGradeName.Text = string.Empty;
        ViewState["GradeId"] = ddlParent.SelectedIndex = 0;
        ddlParent.Enabled = true;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind Parent grade dropdown
    /// </summary>
    private void Binddropdown()
    {
        try
        {
            objDataTable = objclsGradeMasterBO.SelectGradeMaster(new clsGradeMasterBD() { CFlag = EFlag.ALL.ToString(), GradeId = 0 });
            if (objDataTable != null && objDataTable.Rows.Count > 0)
            {
                ddlParent.DataSource = objDataTable;
                ddlParent.DataTextField = "GradeName";
                ddlParent.DataValueField = "GradeId";
                ddlParent.DataBind();
            }
            ddlParent.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to validate for particular grade parent exists or not.
    /// </summary>
    /// <param name="ParentId"></param>
    /// <returns></returns>
    private bool IsParentExists(Int64 ParentId)
    {
        try
        {
            objDataTable = objclsGradeMasterBO.SelectGradeMaster(new clsGradeMasterBD() { CFlag = EFlag.ALL.ToString(), GradeId = 0 });
            return objDataTable.Select("ParentId = '" + ParentId + "'").Count() < 1;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    #endregion
}
