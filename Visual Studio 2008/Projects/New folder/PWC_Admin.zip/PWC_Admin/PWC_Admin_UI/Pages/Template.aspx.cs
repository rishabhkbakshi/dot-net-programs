﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Admin.BD;
using Admin.BO;
public partial class Pages_Template : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
