﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;
public partial class Pages_MessageTicker : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindgvMessageTicker();
            BindddlRole();
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
             clsMessageTickerBD oclsMessageTickerBD = new clsMessageTickerBD();
            if (!string.IsNullOrEmpty(txtMessage.Text))
            {
                oclsMessageTickerBD.Message = txtMessage.Text;
            }
            if (ddlRole.SelectedIndex > 0)
            {
                oclsMessageTickerBD.RoleID = Convert.ToInt64(ddlRole.SelectedValue);
            }
            if (!string.IsNullOrEmpty(cpColor.Color))
            {
                oclsMessageTickerBD.Color = cpColor.Color;
            }
            if (ViewState["MTID"] != null)
            {
                oclsMessageTickerBD.Flag = "U";
                oclsMessageTickerBD.MTID = Convert.ToInt64(ViewState["MTID"]);
                ViewState["MTID"] = null;
            }
            else
            {
                oclsMessageTickerBD.Flag = "I";
            }
            oclsMessageTickerBD.Status = "Active";
            oclsMessageTickerBD.DOC = DateTime.Now;
            oclsMessageTickerBD.DOU = DateTime.Now;
            clsMessageTickerBO.InsertUpdateMessageTickerData(oclsMessageTickerBD);
            BindgvMessageTicker();
            Clear();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            Clear();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gvMessageTicker_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvMessageTicker.PageIndex = e.NewPageIndex;
            BindgvMessageTicker();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gvMessageTicker_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            long MTID = Convert.ToInt64(gvMessageTicker.DataKeys[e.RowIndex].Value);
            clsMessageTickerBO.DeleteMessageTickerData(MTID);
            BindgvMessageTicker();
            Clear();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gvMessageTicker_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            ViewState["MTID"] = gvMessageTicker.DataKeys[e.RowIndex].Value;
            txtMessage.Text = gvMessageTicker.Rows[e.RowIndex].Cells[0].Text;
            ListItem lstItemRoleId = ddlRole.Items.FindByText(gvMessageTicker.Rows[e.RowIndex].Cells[1].Text);
            if (lstItemRoleId != null)
            {
                ddlRole.ClearSelection();
                lstItemRoleId.Selected = true;
            }
            cpColor.Color = gvMessageTicker.Rows[e.RowIndex].Cells[2].Text;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindgvMessageTicker()
    {
        try
        {
            DataTable dtMessageTicker = clsMessageTickerBO.GetMessageTickerData("Grid", 0);
            if (dtMessageTicker.Rows.Count > 0)
            {
                gvMessageTicker.DataSource = dtMessageTicker;
                gvMessageTicker.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindddlRole()
    {
        try
        {
            DataTable dtMessageTicker = clsMessageTickerBO.GetMessageTickerData("DropDown", 0);
            if (dtMessageTicker.Rows.Count > 0)
            {
                ddlRole.DataSource = dtMessageTicker;
                ddlRole.DataTextField = "Name";
                ddlRole.DataValueField = "RoleId";
                ddlRole.DataBind();
            }
            ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    void Clear()
    {
        txtMessage.Text = string.Empty;
        ListItem lstItmRole = ddlRole.Items.FindByText("--Select--");
        if (lstItmRole != null)
        {
            ddlRole.ClearSelection();
            lstItmRole.Selected = true;
        }
        cpColor.Color = string.Empty;
    }
}
