﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;


public partial class Pages_AccomodationPolicy : BasePage
{
    #region --Initializers--
    clsTravelPolicyBO objclsTravelPolicyBO = new clsTravelPolicyBO();
    clsAccomodationRateBO objclsAccomodationRateBO = new clsAccomodationRateBO();
    clsAccomodationPolicyBD objclsAccomodationPolicyBD = new clsAccomodationPolicyBD();
    clsAccomodationPolicyBO objclsAccomodationPolicyBO = new clsAccomodationPolicyBO();
    clsAccomodationPriorityBD objclsAccomodationPriorityBD = new clsAccomodationPriorityBD();
    clsPolicyGradeMappingBD oclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
    clsPolicyGradeMappingBO oclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindTravelType();
            BindGrade();
            BindAccomodationRate();
            BindAccomodationPolicyData();
            BindAccomodationType(0);
        }
        DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
        txtEffectiveToDate.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind the travel type dropdown.
    /// </summary>
    private void BindTravelType()
    {
        try
        {
            DataTable dtTravelType = clsUtility.GetMasterValue("TravelType");
            if (dtTravelType != null && dtTravelType.Rows.Count > 0)
            {

                ddlTravelType.DataSource = dtTravelType;
                ddlTravelType.DataValueField = "MasterId";
                ddlTravelType.DataTextField = "Value";
                ddlTravelType.DataBind();
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to bind grade dropdown.
    /// </summary>
    private void BindGrade()
    {
        try
        {
            DataTable dtGrade = objclsTravelPolicyBO.SelectGradeMaster(0);
            lstbxSourceGrade.DataSource = dtGrade;
            lstbxSourceGrade.DataValueField = "GradeId";
            lstbxSourceGrade.DataTextField = "GradeName";
            lstbxSourceGrade.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind AccomodationRate dropdown
    /// </summary>
    private void BindAccomodationRate()
    {
        try
        {
            DataTable dtAccomodationRate = objclsAccomodationRateBO.SelectAccomodationRateData(0);
            if (dtAccomodationRate != null && dtAccomodationRate.Rows.Count > 0)
            {
                ddlAccomodationRate.DataSource = dtAccomodationRate;
                ddlAccomodationRate.DataValueField = "AccomodationRateId";
                ddlAccomodationRate.DataTextField = "Alias";
                ddlAccomodationRate.DataBind();
                ddlAccomodationRate.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlAccomodationRate.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to save Accomodation policy
    /// </summary>
    private void SaveAccomodationPolicy()
    {
        try
        {
            if (!CheckPriorityDuplicate())
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Duplicate priority value in priority of allocation grid');</script>");
                return;
            }
            int result = DateTime.Compare(Convert.ToDateTime(txtEffectiveFROMDate.Text.Trim()), Convert.ToDateTime(txtEffectiveToDate.Text.Trim()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }
            if (ViewState["ACCOMODATIONPOLICYID"] != null && ViewState["ACCOMODATIONPOLICYID"].ToString() != "0")
            {
                objclsAccomodationPolicyBD.CFlag = EFlag.UPDATE.ToString();
                objclsAccomodationPolicyBD.AccomodationPolicyId = Int64.Parse(ViewState["ACCOMODATIONPOLICYID"].ToString());
            }
            else
            {
                objclsAccomodationPolicyBD.CFlag = EFlag.INSERT.ToString();
                objclsAccomodationPolicyBD.AccomodationPolicyId = 0;
            }
            objclsAccomodationPolicyBD.Gender = ddlGender.SelectedItem.Text;
            objclsAccomodationPolicyBD.TravelType = Int64.Parse(ddlTravelType.SelectedValue.ToString());
            objclsAccomodationPolicyBD.AccomodationRateId = Int64.Parse(ddlAccomodationRate.SelectedValue.ToString());
            objclsAccomodationPolicyBD.EffectiveFROMDate = DateTime.Parse(txtEffectiveFROMDate.Text);
            objclsAccomodationPolicyBD.EffectiveToDate = DateTime.Parse(txtEffectiveToDate.Text);
            objclsAccomodationPolicyBD.IsEnforcePriority = chkIsEnforcePriority.Checked;
            objclsAccomodationPolicyBD.IsBehalfOfBooking = chkIsBehalfOfBooking.Checked;
            objclsAccomodationPolicyBD.Status = "Active";
            objclsAccomodationPolicyBD.DOC = DateTime.Now;
            objclsAccomodationPolicyBD.DOU = DateTime.Now;
            objclsAccomodationPolicyBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            int retAccomodationPolicyId = objclsAccomodationPolicyBO.InsertUpdateAccomodationPolicy(objclsAccomodationPolicyBD);
            SavePolicyGrade(retAccomodationPolicyId);

            clsManageTransaction.StartTransaction();
            foreach (GridViewRow drow in gvPriorityOfAllocation.Rows)
            {
                objclsAccomodationPriorityBD.AccomodationPolicyId = retAccomodationPolicyId;
                Label lblAccomodationPriorityId = (Label)drow.FindControl("lblAccomodationPriorityId");
                objclsAccomodationPriorityBD.AccomodationPriorityId = Int64.Parse(lblAccomodationPriorityId.Text);
                if (Int64.Parse(lblAccomodationPriorityId.Text) > 0)
                {
                    objclsAccomodationPriorityBD.CFlag = EFlag.UPDATE.ToString();
                }
                else
                {
                    objclsAccomodationPriorityBD.CFlag = EFlag.INSERT.ToString();
                }
                Label lblAccomodationType = (Label)drow.FindControl("lblAccomodationType");
                objclsAccomodationPriorityBD.AccomodationType = Int64.Parse(lblAccomodationType.Text);
                Label lblAccomodationName = (Label)drow.FindControl("lblAccomodationName");
                objclsAccomodationPriorityBD.AccomodationName = lblAccomodationName.Text;
                TextBox txtPriority = (TextBox)drow.FindControl("txtPriority");
                objclsAccomodationPriorityBD.Priority = Int32.Parse(txtPriority.Text);
                objclsAccomodationPriorityBD.Status = "Active";
                objclsAccomodationPriorityBD.DOC = DateTime.Now;
                objclsAccomodationPriorityBD.DOU = DateTime.Now;
                objclsAccomodationPriorityBD.TransactionId = 0;
                objclsAccomodationPolicyBO.InsertUpdateAccomodationPriority(objclsAccomodationPriorityBD);
            }
            clsManageTransaction.EndTransaction();
            hdPriorityCount.Value = gvPriorityOfAllocation.Rows.Count.ToString();
            Clearfields();
            BindAccomodationPolicyData();
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The following method is use to clear the input fields
    /// </summary>
    private void Clearfields()
    {
        txtEffectiveFROMDate.Text = string.Empty;
        ddlTravelType.SelectedIndex = 0;
        ddlGender.SelectedIndex = 0;
        ddlAccomodationRate.SelectedIndex = 0;
        chkIsBehalfOfBooking.Checked = false;
        chkIsEnforcePriority.Checked = false;
        btnSave.Text = "Save";
        BindAccomodationType(0);
        lstbxSourceGrade.Items.Clear();
        lstbxDestinGrade.Items.Clear();
        BindGrade();

    }
    /// <summary>
    /// The following method is use to bind the Accomodation policy data to grid
    /// </summary>
    private void BindAccomodationPolicyData()
    {
        DataTable dtAccomodationPolicy = objclsAccomodationPolicyBO.SelectAccomodationPolicyData(0);
        if (dtAccomodationPolicy != null && dtAccomodationPolicy.Rows.Count > 0)
        {
            gvAccomodationPolicy.DataSource = dtAccomodationPolicy;
            gvAccomodationPolicy.DataBind();

        }
        else
        {
            lblMsg.Text = "No data found.";
        }
    }
    /// <summary>
    /// The following method is use to bind the travel type dropdown.
    /// </summary>
    private void BindAccomodationType(Int64 AccomodationPolicyId)
    {
        try
        {
            DataTable dtAccomodationTypeAll = objclsAccomodationPolicyBO.GetAccomodationPriorityData(AccomodationPolicyId);
            if (dtAccomodationTypeAll != null && dtAccomodationTypeAll.Rows.Count > 0)
            {
                gvPriorityOfAllocation.DataSource = dtAccomodationTypeAll;
                gvPriorityOfAllocation.DataBind();
                if (AccomodationPolicyId > 0)
                {
                    DataTable dtAccomodationType = objclsAccomodationPolicyBO.GetAccomodationPriorityData(AccomodationPolicyId);
                    if (dtAccomodationType != null && dtAccomodationType.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtAccomodationType.Rows.Count; i++)
                        {
                            Label lblAccomodationName = (Label)gvPriorityOfAllocation.Rows[i].Cells[2].FindControl("lblAccomodationName");
                            if (lblAccomodationName.Text == dtAccomodationType.Rows[i]["AccomodationName"].ToString())
                            {
                                TextBox txtPriority = (TextBox)gvPriorityOfAllocation.Rows[i].Cells[2].FindControl("txtPriority");
                                txtPriority.Text = dtAccomodationType.Rows[i]["Priority"].ToString();
                                Label lblAccomodationPriorityId = (Label)gvPriorityOfAllocation.Rows[i].Cells[2].FindControl("lblAccomodationPriorityId");
                                lblAccomodationPriorityId.Text = dtAccomodationType.Rows[i]["AccomodationPolicyId"].ToString();
                            }
                        }
                    }
                }
                hdPriorityCount.Value = gvPriorityOfAllocation.Rows.Count.ToString();
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to check duplicate value in priority column.
    /// </summary>
    private bool CheckPriorityDuplicate()
    {
        bool bReturn;
        int dupCount = 0;
        for (int x = 0; x <= gvPriorityOfAllocation.Rows.Count - 1; x++)
        {
            TextBox txtPriority = (TextBox)gvPriorityOfAllocation.Rows[x].Cells[2].FindControl("txtPriority");
            string val = txtPriority.Text.Trim();
            for (int y = x + 1; y <= gvPriorityOfAllocation.Rows.Count - 1; y++)
            {
                TextBox txtCheck = (TextBox)gvPriorityOfAllocation.Rows[y].Cells[2].FindControl("txtPriority");
                if (val == txtCheck.Text)
                {
                    dupCount = +1;
                }
            }
        }
        if (dupCount > 0)
        {
            bReturn = false;
        }
        else
        {
            bReturn = true;
        }
        return bReturn;
    }
    /// <summary>
    /// The following method is use to insert data in PalicyGradeMapping table
    /// </summary>
    private bool SavePolicyGrade(long p)
    {
        try
        {
            int Check = 0;
            oclsPolicyGradeMappingBD.CFlag = EFlag.INSERT.ToString();
            oclsPolicyGradeMappingBD.ReferencePolicyId = p;
            oclsPolicyGradeMappingBD.ReferencePolicyType = "Accomodation Policy";
            oclsPolicyGradeMappingBD.DOC = DateTime.Now;
            oclsPolicyGradeMappingBD.DOU = DateTime.Now;
            oclsPolicyGradeMappingBD.Status = "Active";
            foreach (ListItem item in lstbxDestinGrade.Items)
            {
                oclsPolicyGradeMappingBD.GradeId = Int64.Parse(item.Value);
                oclsPolicyGradeMappingBO.InsertUpdatePolicyGradeMapping(oclsPolicyGradeMappingBD);
                Check += 1;
            }
            clsManageTransaction.EndTransaction();
            return lstbxDestinGrade.Items.Count == Check;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            return false;
        }

    }
    /// <summary>
    /// The following method is use to bind Bind Destination Grade
    /// </summary>
    private void BindDestinationGrade(Int64 ReferencePolicyId)
    {
        oclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
        oclsPolicyGradeMappingBD.CFlag = "AccomodationPolicy";
        DataTable dtList = oclsPolicyGradeMappingBO.SelectPolicyGradeMapping(oclsPolicyGradeMappingBD);
        if (dtList.Rows.Count > 0)
        {
            lstbxDestinGrade.DataSource = dtList;
            lstbxDestinGrade.DataTextField = "GradeName";
            lstbxDestinGrade.DataValueField = "GradeId";
            lstbxDestinGrade.DataBind();
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
                lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);
        }

    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to clear all the input field
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to store all the accomodation policy.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveAccomodationPolicy();

    }
    /// <summary>
    /// The event is use to redirect to home page
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationPolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 AccomodationPolicyId = Int64.Parse(gvAccomodationPolicy.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["ACCOMODATIONPOLICYID"] = AccomodationPolicyId;
            DataTable dtAccomodationPolicyDetails = objclsAccomodationPolicyBO.SelectAccomodationPolicyData(AccomodationPolicyId);
            if (dtAccomodationPolicyDetails != null && dtAccomodationPolicyDetails.Rows.Count > 0)
            {
                //ddlGradeName.SelectedValue = dtAccomodationPolicyDetails.Rows[0]["GradeId"].ToString();
                ddlTravelType.SelectedValue = dtAccomodationPolicyDetails.Rows[0]["TravelType"].ToString();
                ddlGender.SelectedValue = dtAccomodationPolicyDetails.Rows[0]["Gender"].ToString();
                ddlAccomodationRate.SelectedValue = dtAccomodationPolicyDetails.Rows[0]["AccomodationRateId"].ToString();
                txtEffectiveFROMDate.Text = Convert.ToDateTime(dtAccomodationPolicyDetails.Rows[0]["EffectiveFROMDate"]).ToString("d MMMM, yyyy");
                txtEffectiveToDate.Text = Convert.ToDateTime(dtAccomodationPolicyDetails.Rows[0]["EffectiveToDate"]).ToString("d MMMM, yyyy");
                if (dtAccomodationPolicyDetails.Rows[0]["IsEnforcePriority"].ToString() == "True")
                {
                    chkIsEnforcePriority.Checked = true;
                }
                else
                {
                    chkIsEnforcePriority.Checked = false;
                }
                if (dtAccomodationPolicyDetails.Rows[0]["IsBehalfOfBooking"].ToString() == "True")
                {
                    chkIsBehalfOfBooking.Checked = true;
                }
                else
                {
                    chkIsBehalfOfBooking.Checked = false;
                }
                btnSave.Text = "Update";
                BindAccomodationType(AccomodationPolicyId);
                BindDestinationGrade(AccomodationPolicyId);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The event is use to delete(make inactive) a particular accomodation policy
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationPolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 AccomodationPolicyId = Int64.Parse(gvAccomodationPolicy.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();
            if (objclsAccomodationPolicyBO.DeleteAccomodationPolicy(AccomodationPolicyId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");

        }
        BindAccomodationPolicyData();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationPolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAccomodationPolicy.PageIndex = e.NewPageIndex;
            BindAccomodationPolicyData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to move grade value
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnOneRight_Click(object sender, EventArgs e)
    {
        if (lstbxSourceGrade.Items.Count == 0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }
        if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
        {
            if (lstbxSourceGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
            {
                if (lstbxSourceGrade.Items[i].Selected)
                    lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);
            }
        }
        else
        {
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);

            lstbxSourceGrade.Items.Clear();
        }

    }
    /// <summary>
    /// The event is use to move grade value
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        if (lstbxDestinGrade.Items.Count == 0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }

        if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
        {
            if (lstbxDestinGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                if (lstbxDestinGrade.Items[i].Selected)
                    lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Remove(lstbxSourceGrade.Items[i]);
        }
        else
        {
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            lstbxDestinGrade.Items.Clear();
        }
    }
    #endregion
    protected void gvAccomodationPolicy_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            String strBehalfOf = Convert.ToString(e.Row.Cells[6].Text);
            if (strBehalfOf != null && !String.IsNullOrEmpty(strBehalfOf))
            {
                if (strBehalfOf.TrimEnd() == "False")
                {
                    e.Row.Cells[6].Text = "No";
                }
                else
                {
                    e.Row.Cells[6].Text = "Yes";
                }
            }
            String strEnforce = Convert.ToString(e.Row.Cells[3].Text);
            if (strBehalfOf != null && !String.IsNullOrEmpty(strEnforce))
            {
                if (strEnforce.TrimEnd() == "False")
                {
                    e.Row.Cells[3].Text = "No";
                }
                else
                {
                    e.Row.Cells[3].Text = "Yes";
                }
            }
        }
    }
}
