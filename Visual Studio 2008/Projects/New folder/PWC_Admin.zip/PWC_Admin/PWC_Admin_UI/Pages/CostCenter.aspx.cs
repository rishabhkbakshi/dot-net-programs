﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;


public partial class Pages_CostCenter : BasePage
{
    #region--Initializers--
    DataTable OrgStructureDataTable = new DataTable();
    DataTable objDataTable = new DataTable();
    clsCostCenterBD objclsCostCenterBD = new clsCostCenterBD();
    clsCostCenterBO objclsCostCenterBO = new clsCostCenterBO();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update CostCenter
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["CostCenterId"] != null && ViewState["CostCenterId"].ToString() != "0")
            {
                objclsCostCenterBD.CFlag = EFlag.UPDATE.ToString();
                objclsCostCenterBD.CostCenterId = Int64.Parse(ViewState["CostCenterId"].ToString());
            }
            else
            {
                objclsCostCenterBD.CFlag = EFlag.INSERT.ToString();
                objclsCostCenterBD.CostCenterId = 0;
            }
            objclsCostCenterBD.Alias = txtAlias.Text.Trim();
            objclsCostCenterBD.CostCenter = txtCostcenter.Text.Trim();
            objclsCostCenterBD.Description = txtDescription.Text.Trim();
            objclsCostCenterBD.DOC = DateTime.Now;
            objclsCostCenterBD.DOU = DateTime.Now;
            objclsCostCenterBD.OrganisationStructureId = Int64.Parse(ddlOrganisation.SelectedValue.ToString());
            objclsCostCenterBD.Status = "Active";
            objclsCostCenterBD.TransactionId = 1;
            clsManageTransaction.StartTransaction();
            if (objclsCostCenterBO.InsertUpdateCostCenter(objclsCostCenterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to update and delete CostCenter
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCostcenter_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["CostCenterId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsCostCenterBD.CostCenterId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsCostCenterBO.DeleteCostCenter(objclsCostCenterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating CostCenter
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCostcenter_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            txtCostcenter.Text = HttpUtility.HtmlDecode(gvCostcenter.Rows[e.RowIndex].Cells[0].Text);
            ddlOrganisation.SelectedIndex = ddlOrganisation.Items.IndexOf(ddlOrganisation.Items.FindByText(gvCostcenter.Rows[e.RowIndex].Cells[1].Text));
            //txtAlias.Text = HttpUtility.HtmlDecode(gvCostcenter.Rows[e.RowIndex].Cells[1].Text);
            txtDescription.Text = (gvCostcenter.Rows[e.RowIndex].Cells[3].Text == "&nbsp;") ? string.Empty : gvCostcenter.Rows[e.RowIndex].Cells[2].Text;
            btnSave.Text = "Update";
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void gvCostcenter_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCostcenter_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvCostcenter.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtAlias.Text = txtCostcenter.Text = txtDescription.Text = string.Empty;
        ViewState["CostCenterId"] = ddlOrganisation.SelectedIndex = 0;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind CostCenter data
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsCostCenterBD.CFlag = EFlag.ALL.ToString();
            objclsCostCenterBD.CostCenterId = 0;
            objDataTable = objclsCostCenterBO.SelectCostCenter(objclsCostCenterBD);
            //if (objDataTable!=null && objDataTable.Rows.Count>0)
            //{
            gvCostcenter.DataSource = objDataTable;
            gvCostcenter.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;            
        }
    }
    /// <summary>
    /// The following method is use to bind Organisation dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            OrgStructureDataTable = new DataView(clsCommonUtilityBO.GetOrganization()).ToTable(false, new string[] { "OrganisationStructureId", "Name" });
            ddlOrganisation.DataSource = OrgStructureDataTable;
            ddlOrganisation.DataTextField = "Name";
            ddlOrganisation.DataValueField = "OrganisationStructureId";
            ddlOrganisation.DataBind();
            ddlOrganisation.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion

}
