﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Admin.BD;
using Admin.BO;
using System.Data;
public partial class Pages_Process : BasePage
{
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ViewState["PROCESSID"] = 0;
                BindProcess();
                ShowMessage(string.Empty);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    #region "Page Events"
    /// <summary>
    /// The event is use to save process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            string Flag = EFlag.INSERT.ToString();
            if (Convert.ToInt64(ViewState["PROCESSID"]) > 0)
            {
                Flag = EFlag.UPDATE.ToString();
            }
            InsertOrUpdateProcess(Flag);
            Response.Redirect(Request.Path + "?MSG=" + Flag, false);
        }
        catch (Exception ex)
        {

            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
    }
    /// <summary>
    /// The event is use to update process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProcess_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 ProcessId = Convert.ToInt64(gvProcess.DataKeys[e.RowIndex].Value);
            SetControls(ProcessId);
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To delete(make inactive) Process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvProcess_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 ProcessId = Convert.ToInt64(gvProcess.DataKeys[e.RowIndex].Value);
            clsProcessBD oProcessBD = new clsProcessBD();
            oProcessBD.ProcessId = ProcessId;

            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            (new clsProcessBO()).DeleteProcess(oProcessBD);
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................
            Response.Redirect(Request.Path + "?MSG=" + EFlag.DELETE.ToString(), false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

    #endregion

    #region "Customized Methods"
    /// <summary>
    /// The event is use to save and update process
    /// </summary>
    /// <param name="Flag"></param>
    /// <returns></returns>
    private long InsertOrUpdateProcess(string Flag)
    {
        try
        {
            long ProcessId = 0;
            clsProcessBO oProcessBO = new clsProcessBO();
            clsProcessBD oProcessBD = new clsProcessBD();
            oProcessBD.Flag = Flag;
            oProcessBD.ProcessId = Convert.ToInt64(ViewState["PROCESSID"]);
            oProcessBD.ProcessName = txtProcess.Text.Trim();
            oProcessBD.ParentId = Convert.ToInt64(ddlParentProcess.SelectedValue);
            oProcessBD.NeedDocumentMgt = chkNeedDocumentMgt.Checked;
            oProcessBD.NeedApprovers = chkNeedApprovers.Checked;
            oProcessBD.NeedEnforceSLA = chkNeedEnforceSLA.Checked;
            oProcessBD.DefaultURL = txtDefaultURL.Text.Trim();
            oProcessBD.OnErrorURL = txtOnErrorURL.Text.Trim();
            oProcessBD.SequenceNo = Convert.ToInt16(txtSequenceNo.Text.Trim());
            oProcessBD.Alias = txtAlias.Text;
            oProcessBD.DOC = DateTime.Now;
            oProcessBD.DOU = DateTime.Now;
            oProcessBD.Status = "Active";

            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            ProcessId = oProcessBO.InsertUpdateProcess(oProcessBD);
            ViewState["PROCESSID"] = 0;
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................

            return ProcessId;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="ProcessId"></param>
    private void SetControls(Int64 ProcessId)
    {
        try
        {
            ViewState["PROCESSID"] = ProcessId;
            clsProcessBD oProcessBD = new clsProcessBD();
            oProcessBD.Flag = "PROCESSID";
            oProcessBD.ProcessId = ProcessId;
            DataTable dtProcess = (new clsProcessBO()).SelectProcess(oProcessBD);
            if (dtProcess.Rows.Count > 0)
            {
                txtProcess.Text = Convert.ToString(dtProcess.Rows[0]["ProcessName"]);
                string ParentId = Convert.ToString(dtProcess.Rows[0]["ParentId"]);
                ListItem ParentItem = ddlParentProcess.Items.FindByValue(ParentId) as ListItem;
                if (ParentItem != null)
                {
                    ddlParentProcess.ClearSelection();
                    ParentItem.Selected = true;
                }
                chkNeedDocumentMgt.Checked = Convert.ToBoolean(dtProcess.Rows[0]["NeedDocumentMgt"]);
                chkNeedApprovers.Checked = Convert.ToBoolean(dtProcess.Rows[0]["NeedApprovers"]);
                chkNeedEnforceSLA.Checked = Convert.ToBoolean(dtProcess.Rows[0]["NeedEnforceSLA"]);
                txtDefaultURL.Text = Convert.ToString(dtProcess.Rows[0]["DefaultURL"]);
                txtOnErrorURL.Text = Convert.ToString(dtProcess.Rows[0]["OnErrorURL"]);
                txtSequenceNo.Text = Convert.ToString(dtProcess.Rows[0]["SequenceNo"]);
                txtAlias.Text = Convert.ToString(dtProcess.Rows[0]["Alias"]);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    private void BindProcess()
    {
        try
        {
            clsProcessBD oProcessBD = new clsProcessBD();
            oProcessBD.ProcessId = 0;
            oProcessBD.Flag = "ALL";
            DataTable dtProcess = (new clsProcessBO()).SelectProcess(oProcessBD);
            gvProcess.DataSource = dtProcess;
            gvProcess.DataBind();

            ddlParentProcess.DataSource = dtProcess;
            ddlParentProcess.DataTextField = "ProcessName";
            ddlParentProcess.DataValueField = "ProcessId";
            ddlParentProcess.DataBind();
            ddlParentProcess.Items.Insert(0, new ListItem("--Parent--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    #endregion
}
