﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_EmployeeVisaDetails : BasePage
{
    #region--Initializers--
    clsEmployeeBD oclsEmployeeBD = new clsEmployeeBD();
    clsEmployeeBO oclsEmployeeBO = new clsEmployeeBO();

    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();

    clsEmployeeVisaDetailsBD oclsEmployeeVisaDetailsBD = new clsEmployeeVisaDetailsBD();
    clsEmployeeVisaDetailsBO oclsEmployeeVisaDetailsBO = new clsEmployeeVisaDetailsBO();

    DataTable dtEmployeeVisaDetails = new DataTable();
    #endregion
    #region--Page Load--
    protected void Page_Load(object sender, EventArgs e)
    {        
        if (!IsPostBack)
        {
            BindDropdown();
            Bindgrid();
        }
    }
    #endregion
    #region--Private Methods--
    private void Bindgrid()
    {
        try
        {
            oclsEmployeeVisaDetailsBD.CFlag = EFlag.ALL.ToString();
            oclsEmployeeVisaDetailsBD.VisaId=0;
            dtEmployeeVisaDetails = oclsEmployeeVisaDetailsBO.SelectEmployeeVisaDetails(oclsEmployeeVisaDetailsBD);
            gvdtEmployeeVisaDetails.DataSource = dtEmployeeVisaDetails;
            gvdtEmployeeVisaDetails.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    private void BindDropdown()
    {
        try
        {
            DataTable dtUnit = clsUtility.GetMasterValue("Visa Type");
            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlVisaType.DataSource = dtUnit;
                ddlVisaType.DataValueField = "MasterId";
                ddlVisaType.DataTextField = "Value";
                ddlVisaType.DataBind();
                ddlVisaType.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlVisaType.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            oclsEmployeeBD.CFlag = EFlag.ALL.ToString();
            oclsEmployeeBD.EmployeeId = 0;
            DataTable dtEmployee = new DataView(oclsEmployeeBO.SelectEmployee(oclsEmployeeBD)).ToTable(false, new string[] { "EmployeeId", "EmployeeName" });


            if (dtEmployee != null && dtEmployee.Rows.Count > 0)
            {
                if (dtEmployee != null && dtEmployee.Rows.Count > 0)
                {
                    ddlEmployee.DataSource = dtEmployee;
                    ddlEmployee.DataTextField = "EmployeeName";
                    ddlEmployee.DataValueField = "EmployeeId";
                    ddlEmployee.DataBind();
                    ddlEmployee.Items.Insert(0, new ListItem("--Select--", "0"));
                }
            }
            else
                ddlEmployee.Items.Insert(0, new ListItem("--Select--", "0"));


            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            DataTable dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    private void Clearfields()
    {
        txtFROMDate.Text = txtPassportNo.Text = txtToDate.Text = txtVisaNo.Text = string.Empty;
        ViewState["VisaId"]=ddlCountry.SelectedIndex = ddlEmployee.SelectedIndex = ddlVisaType.SelectedIndex = 0;
    }
    #endregion
    #region--Event Handlers--
    protected void btnReset_Click(object sender, EventArgs e)
    {
            
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try 
	    {
            int result = DateTime.Compare(Convert.ToDateTime(txtFROMDate.Text.Trim().ToString()), Convert.ToDateTime(txtToDate.Text.Trim().ToString()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }

            if ( ViewState["VisaId"]!=null &&  ViewState["VisaId"].ToString()!="0")
            {
                oclsEmployeeVisaDetailsBD.CFlag = EFlag.UPDATE.ToString();
                oclsEmployeeVisaDetailsBD.VisaId = Int64.Parse( ViewState["VisaId"].ToString()); 
            }
            else
            {
                oclsEmployeeVisaDetailsBD.CFlag = EFlag.INSERT.ToString();
                oclsEmployeeVisaDetailsBD.VisaId = 0;  
            }
            oclsEmployeeVisaDetailsBD.CountryId = Int64.Parse(ddlEmployee.SelectedValue.ToString());
            oclsEmployeeVisaDetailsBD.DOC = DateTime.Now;
            oclsEmployeeVisaDetailsBD.DOU = DateTime.Now;
            oclsEmployeeVisaDetailsBD.EmployeeId=Int64.Parse(ddlEmployee.SelectedValue.ToString());
            oclsEmployeeVisaDetailsBD.FromDate = DateTime.Parse(txtFROMDate.Text.Trim());
            oclsEmployeeVisaDetailsBD.PassportNo = txtPassportNo.Text.Trim();
            oclsEmployeeVisaDetailsBD.Status="Active";
            oclsEmployeeVisaDetailsBD.ToDate = DateTime.Parse(txtToDate.Text.Trim());
            oclsEmployeeVisaDetailsBD.TransactionId=1;
            oclsEmployeeVisaDetailsBD.VisaNo = txtVisaNo.Text.Trim();
            oclsEmployeeVisaDetailsBD.VisaType=Int64.Parse(ddlVisaType.SelectedValue.ToString()); 
            clsManageTransaction.StartTransaction();
            if (oclsEmployeeVisaDetailsBO.InsertUpdateEmployeeVisaDetails(oclsEmployeeVisaDetailsBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
	    }
	    catch (Exception ex)
	    {
    		clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
	    }
    }    
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    protected void gvdtEmployeeVisaDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvdtEmployeeVisaDetails.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void gvdtEmployeeVisaDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    protected void gvdtEmployeeVisaDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        txtFROMDate.Text=gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[5].Text;
        txtPassportNo.Text = gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[1].Text;
        txtToDate.Text = gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[6].Text;
        txtVisaNo.Text = gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[4].Text;
        ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[2].Text));
        ddlVisaType.SelectedIndex = ddlVisaType.Items.IndexOf(ddlVisaType.Items.FindByText(gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[3].Text));
        ddlEmployee.SelectedIndex = ddlEmployee.Items.IndexOf(ddlEmployee.Items.FindByText(gvdtEmployeeVisaDetails.Rows[e.RowIndex].Cells[0].Text));
    }
    protected void gvdtEmployeeVisaDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["VisaId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsEmployeeVisaDetailsBD.VisaId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsEmployeeVisaDetailsBO.DeleteEmployeeVisaDetails(oclsEmployeeVisaDetailsBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    #endregion
}
