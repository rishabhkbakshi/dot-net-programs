﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_CityMaster : BasePage
{
    #region--Initializers--
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    clsCityGradeMasterBD oclsCityGradeMasterBD = new clsCityGradeMasterBD();
    clsCityGradeMasterBO oclsCityGradeMasterBO = new clsCityGradeMasterBO();
    DataTable dtCountryMaster = new DataTable();
    DataTable dtCityGradeMaster = new DataTable();
    DataTable dtCityMaster = new DataTable();
    DataTable dtLocation = new DataTable();
    clsCityMasterBD oclsCityMasterBD = new clsCityMasterBD();
    clsCityMasterBO oclsCityMasterBO = new clsCityMasterBO();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Bindgrid();
                Binddropdown();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind State & CityGrade dropdown
    /// </summary>
    private void Binddropdown()
    {
        try
        {
            //oclsStateMasterBD.CFlag = EFlag.ALL.ToString();
            //oclsStateMasterBD.StateId = 0;
            //dtStateMaster = oclsStateMasterBO.SelectStateMaster(oclsStateMasterBD);
            //if (dtStateMaster!=null && dtStateMaster.Rows.Count>0)
            //{
            //    ddlState.DataSource = dtStateMaster;
            //    ddlState.DataTextField = "StateName";
            //    ddlState.DataValueField = "StateId";
            //    ddlState.DataBind();
            //    ddlState.Items.Insert(0, new ListItem("--Select--", "0")); 
            //}

            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no grade available.');</script>");
                ddlCountry.Enabled = btnSave.Enabled = false;
            }


            oclsCityGradeMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCityGradeMasterBD.CityGradeId = 0;
            dtCityGradeMaster = oclsCityGradeMasterBO.SelectCityGradeMaster(oclsCityGradeMasterBD);
            if (dtCityGradeMaster!= null && dtCityGradeMaster.Rows.Count>0)
            {
                ddlCityGrade.DataSource = dtCityGradeMaster;
                ddlCityGrade.DataTextField = "CityGradeName";
                ddlCityGrade.DataValueField = "CityGradeId";
                ddlCityGrade.DataBind();
                ddlCityGrade.Items.Insert(0, new ListItem("--Select--", "0"));  
            }

            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));


        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind CityMaster data in grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsCityMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCityMasterBD.CityId = 0;
            dtCityMaster = oclsCityMasterBO.SelectCityMaster(oclsCityMasterBD);
            //if (dtCityMaster != null && dtCityMaster.Rows.Count>0)
            //{
                gvCity.DataSource = dtCityMaster;
                gvCity.DataBind(); 
            //}

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    ///The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtAlias.Text = txtCityName.Text = string.Empty;
        
        ddlCountry.Enabled=ddlState.Enabled = true;
        //ddlState.DataSource = null;
        //ddlState.DataBind();
        ddlState.Items.Clear();
        Binddropdown();
        ddlCityGrade.SelectedIndex = ddlState.SelectedIndex = 0;
        btnSave.Text = "Save";

    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update CityMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["CityId"] != null && ViewState["CityId"].ToString() != "0")
            {
                oclsCityMasterBD.CFlag = EFlag.UPDATE.ToString();
                oclsCityMasterBD.CityId = Int64.Parse(ViewState["CityId"].ToString());
            }
            else
            {
                oclsCityMasterBD.CFlag = EFlag.INSERT.ToString();
                oclsCityMasterBD.CityId = 0;
            }
            oclsCityMasterBD.Alias = txtAlias.Text;
            oclsCityMasterBD.CityName = txtCityName.Text.Trim();
            oclsCityMasterBD.CityGradeId = Int64.Parse(ddlCityGrade.SelectedValue.ToString());
            oclsCityMasterBD.StateId = Int64.Parse(ddlState.SelectedValue.ToString());
            oclsCityMasterBD.DOC = DateTime.Now;
            oclsCityMasterBD.DOU = DateTime.Now;
            oclsCityMasterBD.Status = "Active";
            oclsCityMasterBD.TransactionId = 1;
            clsManageTransaction.StartTransaction();
            if (oclsCityMasterBO.InsertUpdateCityMaster(oclsCityMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Duplicate Country Cannot Be Accepted.');</script>");
            }
            else
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
    }
    /// <summary>
    /// The following method is use to i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCity_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvCity.PageIndex = e.NewPageIndex;
        Bindgrid();
    }
    /// <summary>
    /// The event is use to update and delete CityMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCity_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["CityId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsCityMasterBD.CityId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsCityMasterBO.DeleteCityMaster(oclsCityMasterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvCity_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(gvCity.Rows[e.RowIndex].Cells[0].Text));
            ddlCountry_SelectedIndexChanged(sender, e);
            ddlState.SelectedIndex = ddlState.Items.IndexOf(ddlState.Items.FindByText(gvCity.Rows[e.RowIndex].Cells[1].Text));
            //txtAlias.Text = gvCity.Rows[e.RowIndex].Cells[3].Text == "&nbsp;" ? string.Empty : gvCity.Rows[e.RowIndex].Cells[3].Text;
            txtCityName.Text=gvCity.Rows[e.RowIndex].Cells[2].Text;
            ddlCityGrade.SelectedIndex = ddlCityGrade.Items.IndexOf(ddlCityGrade.Items.FindByText(gvCity.Rows[e.RowIndex].Cells[3].Text));
            ddlCountry.Enabled=ddlState.Enabled = false;
            btnSave.Text = "Update";
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvCity_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    #endregion
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            /*ddlState*/
            if (ddlCountry.SelectedValue.ToString() != "0")
            {
                ddlState.Enabled = true;                
                dtLocation = new DataView(clsUtility.GetStateData("ByCountry", Int64.Parse(ddlCountry.SelectedValue.ToString()))).ToTable(false, new string[] { "StateId", "StateName" });
                if (dtLocation.Rows.Count > 0)
                {
                    ddlState.DataSource = dtLocation;
                    ddlState.DataTextField = "StateName";
                    ddlState.DataValueField = "StateId";
                    ddlState.DataBind();
                    ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no state available for this country');</script>");
                    //ddlState.Enabled = btnSave.Enabled = false;
                }
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
}
