﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_StateMaster : BasePage
{
    #region--Initializers--
    DataTable dtStateMaster = new DataTable();
    clsStateMasterBD oclsStateMasterBD = new clsStateMasterBD();
    clsStateMasterBO oclsStateMasterBO = new clsStateMasterBO();
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    DataTable dtCountryMaster = new DataTable();
    #endregion
    #region--Pageload--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind StateMaster data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsStateMasterBD.CFlag = EFlag.ALL.ToString();
            oclsStateMasterBD.StateId = 0;
            dtStateMaster = oclsStateMasterBO.SelectStateMaster(oclsStateMasterBD);
            gv.DataSource = dtStateMaster;
            gv.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Country dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtAlias.Text = txtStateName.Text = string.Empty;
        ddlCountry.SelectedIndex = 0;
        ddlCountry.Enabled = true;
        btnSave.Text = "Save";
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update StateMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["StateId"] != null && ViewState["StateId"].ToString() != "0")
            {
                oclsStateMasterBD.CFlag = EFlag.UPDATE.ToString();
                oclsStateMasterBD.StateId = Int64.Parse(ViewState["StateId"].ToString());
            }
            else
            {
                oclsStateMasterBD.CFlag = EFlag.INSERT.ToString();
                oclsStateMasterBD.StateId = 0;
            }
            oclsStateMasterBD.StateName = txtStateName.Text.Trim();
            oclsStateMasterBD.Alias = txtAlias.Text.Trim();
            oclsStateMasterBD.CountryId = Int64.Parse(ddlCountry.SelectedValue.ToString());
            oclsStateMasterBD.Status = "Active";
            oclsStateMasterBD.TransactionId = 0;
            oclsStateMasterBD.DOC = DateTime.Now;
            oclsStateMasterBD.DOU = DateTime.Now;
            clsManageTransaction.StartTransaction();
            if (oclsStateMasterBO.InsertUpdateStateMaster(oclsStateMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('State Name for selected Country already exists.');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gv_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gv.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to update and delete StateMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gv_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["StateId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsStateMasterBD.StateId = Int64.Parse(e.CommandArgument.ToString());
                oclsStateMasterBD.Status = "Inactive";
                oclsStateMasterBD.TransactionId = 0;
                clsManageTransaction.StartTransaction();
                if (oclsStateMasterBO.DeleteStateMaster(oclsStateMasterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gv_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            txtStateName.Text = HttpUtility.HtmlDecode(gv.Rows[e.RowIndex].Cells[0].Text);
            ddlCountry.SelectedIndex = ddlCountry.Items.IndexOf(ddlCountry.Items.FindByText(gv.Rows[e.RowIndex].Cells[1].Text));
            ddlCountry.Enabled = false;
            btnSave.Text = "Update";
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void gv_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    #endregion
}
