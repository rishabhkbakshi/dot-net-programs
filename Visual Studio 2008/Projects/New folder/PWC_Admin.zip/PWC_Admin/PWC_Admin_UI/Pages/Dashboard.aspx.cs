﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;

public partial class Pages_Dashboard : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //int iOne = 0;
            //int iZero = 0;
            //int iResult = iOne / iZero;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
}
