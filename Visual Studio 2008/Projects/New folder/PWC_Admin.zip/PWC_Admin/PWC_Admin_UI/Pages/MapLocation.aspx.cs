﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;
using System.Globalization;
public partial class Pages_MapLocation : BasePage
{
    DateTimeFormatInfo oDateTimeFormat = new DateTimeFormatInfo();
    /// <summary>
    /// Page_Load
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindYearDropDown();
            BindDropDownLists(ddlCountry, "COUNTRY", 0);
        }
    }

    /// <summary>
    /// btnView_Click
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void btnView_Click(object sender, EventArgs e)
    {
        try
        {
            oDateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
            clsLocationDistanceMappingBD oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
            if (ddlCountry.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.Country = ddlCountry.SelectedItem.Text;
            }
            if (ddlState.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.State = ddlState.SelectedItem.Text;
            }
            if (ddlCity.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.City = ddlCity.SelectedItem.Text;
            }
            if (ddlYear.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.ForYear = Convert.ToInt32(ddlYear.SelectedItem.Text);
            }
            if (!string.IsNullOrEmpty(txtFromDate.Text))
            {
                oclsLocationDistanceMappingBD.FromDate = Convert.ToDateTime(txtFromDate.Text, oDateTimeFormat);
            }
            if (!string.IsNullOrEmpty(txtToDate.Text))
            {
                oclsLocationDistanceMappingBD.ToDate = Convert.ToDateTime(txtToDate.Text, oDateTimeFormat);
            }
            BindGrid(oclsLocationDistanceMappingBD);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// btnSubmit_Click
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            oDateTimeFormat.ShortDatePattern = "dd/MM/yyyy";
            clsLocationDistanceMappingBD oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
            if (ddlCountry.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.Country = ddlCountry.SelectedItem.Text;
            }
            if (ddlState.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.State = ddlState.SelectedItem.Text;
            }
            if (ddlCity.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.City = ddlCity.SelectedItem.Text;
            }
            if (ddlYear.SelectedIndex > 0)
            {
                oclsLocationDistanceMappingBD.ForYear = Convert.ToInt32(ddlYear.SelectedItem.Text);
            }
            if (!string.IsNullOrEmpty(txtFromDate.Text))
            {
                oclsLocationDistanceMappingBD.FromDate = Convert.ToDateTime(txtFromDate.Text, oDateTimeFormat);
            }
            if (!string.IsNullOrEmpty(txtToDate.Text))
            {
                oclsLocationDistanceMappingBD.ToDate = Convert.ToDateTime(txtToDate.Text, oDateTimeFormat);
            }
            oclsLocationDistanceMappingBD.TransactionID = 0;
            oclsLocationDistanceMappingBD.DOC = DateTime.Now;
            oclsLocationDistanceMappingBD.DOU = DateTime.Now;
            oclsLocationDistanceMappingBD.Status = "Active";
            bool Status = true;
            if ((!string.IsNullOrEmpty(hfLocationDistanceMappingMaster_ID.Value)))
            {
                Status = false;
                oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = Convert.ToInt64(hfLocationDistanceMappingMaster_ID.Value);
            }
            else
            {
                Status = true;
                oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = 0;
            }
            oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = clsLocationDistanceMapping.InsertUpdateLocationDistanceMapingMaster(oclsLocationDistanceMappingBD);
            if (!Status)
            {
                oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = Convert.ToInt64(hfLocationDistanceMappingMaster_ID.Value);
            }
            hfLocationDistanceMappingMaster_ID.Value = Convert.ToString(oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID);
            clsLocationDistanceMapping.DeleteLocationMapping(Convert.ToInt64(hfLocationDistanceMappingMaster_ID.Value));
            foreach (GridViewRow gvRow in gvMapLocation.Rows)
            {
                oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
                HiddenField hfLocationDistanceMapping_ID = gvRow.FindControl("hfLocationDistanceMapping_ID") as HiddenField;
                TextBox txtFromLocation = gvRow.FindControl("txtFromLocation") as TextBox;
                TextBox txtToLocation = gvRow.FindControl("txtToLocation") as TextBox;
                TextBox txtDistance = gvRow.FindControl("txtDistance") as TextBox;
                TextBox txtPickUpDrop = gvRow.FindControl("txtPickUpDrop") as TextBox;
                TextBox txtRate = gvRow.FindControl("txtRate") as TextBox;
                TextBox txtFullVehicle = gvRow.FindControl("txtFullVehicle") as TextBox;
                TextBox txtWaitingCharges = gvRow.FindControl("txtWaitingCharges") as TextBox;
                oclsLocationDistanceMappingBD.FromLocation = txtFromLocation.Text;
                oclsLocationDistanceMappingBD.ToLocation = txtToLocation.Text;
                oclsLocationDistanceMappingBD.Distance = txtDistance.Text;
                oclsLocationDistanceMappingBD.PickUpDropLocation = txtPickUpDrop.Text;
                oclsLocationDistanceMappingBD.Rate = txtRate.Text;
                oclsLocationDistanceMappingBD.FullVehicle = txtFullVehicle.Text;
                oclsLocationDistanceMappingBD.WaitingCharges = txtWaitingCharges.Text;
                oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = Convert.ToInt64(hfLocationDistanceMappingMaster_ID.Value);
                oclsLocationDistanceMappingBD.TransactionID = 0;
                oclsLocationDistanceMappingBD.DOC = DateTime.Now;
                oclsLocationDistanceMappingBD.DOU = DateTime.Now;
                oclsLocationDistanceMappingBD.Status = "Active";
                clsLocationDistanceMapping.InsertLocationDistanceMaping(oclsLocationDistanceMappingBD);
            }
            ClearFields();
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// btnReset_Click
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            ClearFields();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// BindGrid
    /// </summary>
    /// <param name="oclsLocationDistanceMappingBD">clsLocationDistanceMappingBD</param>
    private void BindGrid(clsLocationDistanceMappingBD oclsLocationDistanceMappingBD)
    {
        try
        {
            List<clsLocationDistanceMappingBD> oclsLocationDistanceMappingBDList = clsLocationDistanceMapping.GetLocationMappedWithDistance(oclsLocationDistanceMappingBD);
            if (oclsLocationDistanceMappingBDList.Count > 0 && oclsLocationDistanceMappingBDList != null)
            {
                hfLocationDistanceMappingMaster_ID.Value = Convert.ToString(oclsLocationDistanceMappingBDList[0].LocationDistanceMappingMaster_ID);
                gvMapLocation.DataSource = oclsLocationDistanceMappingBDList;
                gvMapLocation.DataBind();
            }
            else
            {
                BindGridDummyData();
            }
            btnReset.Visible = true;
            btnSubmit.Visible = true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// BindGridDummyData
    /// </summary>
    private void BindGridDummyData()
    {
        try
        {
            clsLocationDistanceMappingBD oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
            List<clsLocationDistanceMappingBD> oclsLocationDistanceMappingBDList = new List<clsLocationDistanceMappingBD>();

            oclsLocationDistanceMappingBD.LocationDistanceMapping_ID = 0;
            oclsLocationDistanceMappingBD.FromLocation = "";
            oclsLocationDistanceMappingBD.ToLocation = "";
            oclsLocationDistanceMappingBD.Distance = "";
            oclsLocationDistanceMappingBD.PickUpDropLocation = "";
            oclsLocationDistanceMappingBD.Rate = "";
            oclsLocationDistanceMappingBD.FullVehicle = "";
            oclsLocationDistanceMappingBD.WaitingCharges = "";
            oclsLocationDistanceMappingBDList.Add(oclsLocationDistanceMappingBD);
            gvMapLocation.DataSource = oclsLocationDistanceMappingBDList;
            gvMapLocation.DataBind();
            Button btnRemove = gvMapLocation.Rows[0].FindControl("btnRemove") as Button;
            if (gvMapLocation.Rows.Count == 1)
            {
                btnRemove.Visible = false;
            }
            else
            {
                btnRemove.Visible = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// ClearFields
    /// </summary>
    private void ClearFields()
    {
        try
        {
            ListItem lstItemCountry = ddlCountry.Items.FindByText("--Select--");
            if (lstItemCountry != null)
            {
                ddlCountry.ClearSelection();
                lstItemCountry.Selected = true;
            }
            ListItem lstItemState = ddlState.Items.FindByText("--Select--");
            if (lstItemState != null)
            {
                ddlState.ClearSelection();
                lstItemState.Selected = true;
            }
            ListItem lstItemCity = ddlCity.Items.FindByText("--Select--");
            if (lstItemCity != null)
            {
                ddlCity.ClearSelection();
                lstItemCity.Selected = true;
            }
            ListItem lstItemYear = ddlYear.Items.FindByText("--Select--");
            if (lstItemYear != null)
            {
                ddlYear.ClearSelection();
                lstItemYear.Selected = true;
            }
            txtFromDate.Text = string.Empty;
            txtToDate.Text = string.Empty;
            gvMapLocation.DataSource = null;
            gvMapLocation.DataBind();
            btnSubmit.Visible = false;
            btnReset.Visible = false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// BindDropDownLists
    /// </summary>
    /// <param name="ddlCommon">DropDownList</param>
    /// <param name="Flag">string</param>
    /// <param name="ID">long</param>
    private void BindDropDownLists(DropDownList ddlCommon, string Flag, long ID)
    {
        try
        {
            DataTable dtCity = clsLocationDistanceMapping.GetCountryStateCity(Flag, ID);
            DataTable dtnull = new DataTable();
            string DataTextField = string.Empty;
            string DataValueField = string.Empty;
            switch (Flag)
            {
                case "COUNTRY":
                    DataTextField = "CountryName";
                    DataValueField = "CountryId";
                    break;

                case "STATE":
                    DataTextField = "StateName";
                    DataValueField = "StateId";
                    break;

                case "CITY":
                    DataTextField = "CityName";
                    DataValueField = "CityId";
                    break;
            }
            if (string.Compare(Flag, "COUNTRY") == 0)
            {
                ddlCity.DataSource = dtnull;
                ddlCity.DataTextField = "";
                ddlCity.DataValueField = "";
                ddlCity.DataBind();
                ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlState.DataSource = dtnull;
                ddlState.DataTextField = "";
                ddlState.DataValueField = "";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            if (dtCity.Rows.Count > 0)
            {
                ddlCommon.DataSource = dtCity;
                ddlCommon.DataTextField = DataTextField;
                ddlCommon.DataValueField = DataValueField;
                ddlCommon.DataBind();
                ddlCommon.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCommon.DataSource = dtnull;
                ddlCommon.DataTextField = "";
                ddlCommon.DataValueField = "";
                ddlCommon.DataBind();
                ddlCommon.Items.Insert(0, new ListItem("--Select--", "0"));
                if (string.Compare(Flag, "STATE") == 0)
                {
                    ddlCity.DataSource = dtnull;
                    ddlCity.DataTextField = "";
                    ddlCity.DataValueField = "";
                    ddlCity.DataBind();
                    ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// ddlCountry_SelectedIndexChanged
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ListItem lstItemState = ddlState.Items.FindByText("--Select--");
            if (lstItemState != null)
            {
                ddlState.ClearSelection();
                lstItemState.Selected = true;
            }
            ListItem lstItemCity = ddlCity.Items.FindByText("--Select--");
            if (lstItemCity != null)
            {
                ddlCity.ClearSelection();
                lstItemCity.Selected = true;
            }
            if (ddlCountry.SelectedIndex > 0)
            {
                BindDropDownLists(ddlState, "STATE", Convert.ToInt64(ddlCountry.SelectedValue));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// ddlState_SelectedIndexChanged
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            BindDropDownLists(ddlCity, "CITY", Convert.ToInt64(ddlState.SelectedValue));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// BindYearDropDown
    /// </summary>
    protected void BindYearDropDown()
    {
        try
        {
            DataTable dtYear = clsLocationDistanceMapping.GetYear();
            if (dtYear.Rows.Count > 0)
            {
                ddlYear.DataSource = dtYear;
                ddlYear.DataTextField = "Year";
                ddlYear.DataValueField = "Year";
                ddlYear.DataBind();
                ddlYear.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// gvMapLocation_RowCommand
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">GridViewCommandEventArgs</param>
    protected void gvMapLocation_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Add")
            {
                AddDeleteGridViewRow("Add", 0);
            }
            else
            {
                GridViewRow gvRow = ((Button)e.CommandSource).NamingContainer as GridViewRow;
                int Index = gvRow.RowIndex;
                AddDeleteGridViewRow("Remove", Index);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// AddDeleteGridViewRow
    /// </summary>
    /// <param name="Flag">string</param>
    private void AddDeleteGridViewRow(string Flag, int Index)
    {
        try
        {
            clsLocationDistanceMappingBD oclsLocationDistanceMappingBD;
            List<clsLocationDistanceMappingBD> clsLocationDistanceMappingBDList = new List<clsLocationDistanceMappingBD>();

            foreach (GridViewRow gvRow in gvMapLocation.Rows)
            {
                oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
                HiddenField hfLocationDistanceMapping_ID = gvRow.FindControl("hfLocationDistanceMapping_ID") as HiddenField;
                TextBox txtFromLocation = gvRow.FindControl("txtFromLocation") as TextBox;
                TextBox txtToLocation = gvRow.FindControl("txtToLocation") as TextBox;
                TextBox txtDistance = gvRow.FindControl("txtDistance") as TextBox;
                TextBox txtPickUpDrop = gvRow.FindControl("txtPickUpDrop") as TextBox;
                TextBox txtRate = gvRow.FindControl("txtRate") as TextBox;
                TextBox txtFullVehicle = gvRow.FindControl("txtFullVehicle") as TextBox;
                TextBox txtWaitingCharges = gvRow.FindControl("txtWaitingCharges") as TextBox;
                oclsLocationDistanceMappingBD.LocationDistanceMapping_ID = Convert.ToInt64(hfLocationDistanceMapping_ID.Value);
                oclsLocationDistanceMappingBD.FromLocation = txtFromLocation.Text;
                oclsLocationDistanceMappingBD.ToLocation = txtToLocation.Text;
                oclsLocationDistanceMappingBD.Distance = txtDistance.Text;
                oclsLocationDistanceMappingBD.PickUpDropLocation = txtPickUpDrop.Text;
                oclsLocationDistanceMappingBD.Rate = txtRate.Text;
                oclsLocationDistanceMappingBD.FullVehicle = txtFullVehicle.Text;
                oclsLocationDistanceMappingBD.WaitingCharges = txtWaitingCharges.Text;
                clsLocationDistanceMappingBDList.Add(oclsLocationDistanceMappingBD);
            }
            if (Flag == "Add")
            {
                oclsLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
                oclsLocationDistanceMappingBD.LocationDistanceMapping_ID = 0;
                oclsLocationDistanceMappingBD.FromLocation = "";
                oclsLocationDistanceMappingBD.ToLocation = "";
                oclsLocationDistanceMappingBD.Distance = "";
                oclsLocationDistanceMappingBD.PickUpDropLocation = "";
                oclsLocationDistanceMappingBD.Rate = "";
                oclsLocationDistanceMappingBD.FullVehicle = "";
                oclsLocationDistanceMappingBD.WaitingCharges = "";
                clsLocationDistanceMappingBDList.Add(oclsLocationDistanceMappingBD);
            }
            else
            {
                clsLocationDistanceMappingBDList.RemoveAt(Index);
            }
            gvMapLocation.DataSource = clsLocationDistanceMappingBDList;
            gvMapLocation.DataBind();
            Button btnRemove = gvMapLocation.Rows[0].FindControl("btnRemove") as Button;
            if (gvMapLocation.Rows.Count == 1)
            {
                btnRemove.Visible = false;
            }
            else
            {
                btnRemove.Visible = true;
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
