﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_VehicleType : BasePage
{
    #region--Initializers--
    clsVehicleTypeBD objclsVehicleTypeBD = new clsVehicleTypeBD();
    clsVehicleTypeBO objclsVehicleTypeBO = new clsVehicleTypeBO();
    DataTable objDataTable = new DataTable();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update VehicleType
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["VehicleTypeId"] != null && ViewState["VehicleTypeId"].ToString() != "0")
            {
                objclsVehicleTypeBD.CFlag = EFlag.UPDATE.ToString();
                objclsVehicleTypeBD.VehicleTypeId = Int64.Parse(ViewState["VehicleTypeId"].ToString());
            }
            else
            {
                objclsVehicleTypeBD.CFlag = EFlag.INSERT.ToString();
                objclsVehicleTypeBD.VehicleTypeId = 0;
            }
            objclsVehicleTypeBD.Alias = txtAlias.Text.Trim();
            objclsVehicleTypeBD.Currency = Int64.Parse(ddlCurrency.SelectedValue.ToString());
            objclsVehicleTypeBD.DOC = DateTime.Now;
            objclsVehicleTypeBD.DOU = DateTime.Now;
            objclsVehicleTypeBD.Is4Wheeler = chkIs4wheeler.Checked;
            objclsVehicleTypeBD.IsAc = chkIsAC.Checked;
            objclsVehicleTypeBD.Rate = Decimal.Parse(txtRate.Text.Trim());
            objclsVehicleTypeBD.Status = "Active";
            objclsVehicleTypeBD.TransactionId = 1;
            objclsVehicleTypeBD.Unit = Int64.Parse(ddlUnit.SelectedValue.ToString());
            objclsVehicleTypeBD.VehicleName = txtVehicleName.Text.Trim();
            clsManageTransaction.StartTransaction();
            if (objclsVehicleTypeBO.InsertUpdateVehicleType(objclsVehicleTypeBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to update and delete VehicleType
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicle_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["VehicleTypeId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsVehicleTypeBD.VehicleTypeId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsVehicleTypeBO.DeleteVehicleType(objclsVehicleTypeBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }

    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicle_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            //txtAlias.Text = gvVehicle.Rows[e.RowIndex].Cells[1].Text;
            txtVehicleName.Text = gvVehicle.Rows[e.RowIndex].Cells[0].Text;
            chkIsAC.Checked = gvVehicle.Rows[e.RowIndex].Cells[1].Text == "A/C" ? true : false;
            chkIs4wheeler.Checked = gvVehicle.Rows[e.RowIndex].Cells[2].Text == "4 Wheeler" ? true : false;
            txtRate.Text = gvVehicle.Rows[e.RowIndex].Cells[3].Text;
            ddlUnit.SelectedIndex = ddlUnit.Items.IndexOf(ddlUnit.Items.FindByText(gvVehicle.Rows[e.RowIndex].Cells[4].Text));
            ddlCurrency.SelectedIndex = ddlCurrency.Items.IndexOf(ddlCurrency.Items.FindByText(gvVehicle.Rows[e.RowIndex].Cells[5].Text));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    protected void gvVehicle_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicle_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvVehicle.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtAlias.Text = txtRate.Text = txtVehicleName.Text = string.Empty;
        ViewState["VehicleTypeId"] = ddlCurrency.SelectedIndex = ddlUnit.SelectedIndex = 0;
        chkIs4wheeler.Checked = chkIsAC.Checked = false;
    }
    /// <summary>
    /// The event is use to bind VehicleType data in grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsVehicleTypeBD.CFlag = "ALL";
            objclsVehicleTypeBD.VehicleTypeId = 0;
            objDataTable = objclsVehicleTypeBO.SelectVehicleType(objclsVehicleTypeBD);
            gvVehicle.DataSource = objDataTable;
            gvVehicle.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Unit & Currency dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            DataTable dtUnit = clsUtility.GetMasterValue("Unit");
            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlUnit.DataSource = dtUnit;
                ddlUnit.DataValueField = "MasterId";
                ddlUnit.DataTextField = "Value";
                ddlUnit.DataBind();
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            DataTable dtCurrency = clsUtility.GetMasterValue("Currency");
            if (dtCurrency != null && dtCurrency.Rows.Count > 0)
            {
                ddlCurrency.DataSource = dtCurrency;
                ddlCurrency.DataValueField = "MasterId";
                ddlCurrency.DataTextField = "Value";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion

}
