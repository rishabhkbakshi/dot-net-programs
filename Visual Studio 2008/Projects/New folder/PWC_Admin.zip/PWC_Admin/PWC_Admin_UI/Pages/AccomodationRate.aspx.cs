﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_AccomodationRate : BasePage
{
    #region --Initializers--
    clsAccomodationRateBD objclsAccomodationRateBD = new clsAccomodationRateBD();
    clsAccomodationRateBO objclsAccomodationRateBO = new clsAccomodationRateBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindUnit();
            BindCurrency();
            BindCityGradeName();
            BindAccomodationRateData();
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to save and update accomodation rate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveAccomodationRate();
    }
    /// <summary>
    /// It will redirect to home page
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationRate_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 AccomodationRateId = Int64.Parse(gvAccomodationRate.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["ACCOMODATIONRATEID"] = AccomodationRateId;
            DataTable dtAccomodationRateDetails = objclsAccomodationRateBO.SelectAccomodationRateData(AccomodationRateId);
            if (dtAccomodationRateDetails != null && dtAccomodationRateDetails.Rows.Count > 0)
            {
                ddlCityGrade.SelectedValue = dtAccomodationRateDetails.Rows[0]["CityGradeId"].ToString();
                ddlCurrency.SelectedValue = dtAccomodationRateDetails.Rows[0]["Currency"].ToString();
                txtRate.Text = dtAccomodationRateDetails.Rows[0]["Rate"].ToString();
                ddlUnit.SelectedValue = dtAccomodationRateDetails.Rows[0]["Unit"].ToString();
                txtAlias.Text = dtAccomodationRateDetails.Rows[0]["Alias"].ToString();
                btnSave.Text = "Update";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to delete(make inactive) the particullar acc. rate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationRate_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        try
        {
            Int64 AccomodationRateId = Int64.Parse(gvAccomodationRate.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();

            if (objclsAccomodationRateBO.DeleteAccomodationRate(AccomodationRateId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
            BindAccomodationRateData();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
        }
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodationRate_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAccomodationRate.PageIndex = e.NewPageIndex;
            BindAccomodationRateData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind data to City grade
    /// </summary>
    private void BindCityGradeName()
    {
        try
        {
            clsCityGradeMasterBO objclsCityGradeMasterBO = new clsCityGradeMasterBO();
            clsCityGradeMasterBD objclsCityGradeMasterBD = new clsCityGradeMasterBD();
            objclsCityGradeMasterBD.CFlag = EFlag.ALL.ToString();
            objclsCityGradeMasterBD.CityGradeId = 0;
            DataTable dtCityGrade = objclsCityGradeMasterBO.SelectCityGradeMaster(objclsCityGradeMasterBD);
            if (dtCityGrade != null && dtCityGrade.Rows.Count > 0)
            {
                ddlCityGrade.DataSource = dtCityGrade;
                ddlCityGrade.DataValueField = "CityGradeId";
                ddlCityGrade.DataTextField = "CityGradeName";
                ddlCityGrade.DataBind();
                ddlCityGrade.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlCityGrade.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to bind data to unit dropdown.
    /// </summary>
    private void BindUnit()
    {
        try
        {
            DataTable dtUnit = clsUtility.GetMasterValue("Unit");

            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlUnit.DataSource = dtUnit;
                ddlUnit.DataValueField = "MasterId";
                ddlUnit.DataTextField = "Value";
                ddlUnit.DataBind();
                ListItem Item = ddlUnit.Items.FindByText("Days") as ListItem;
                if (Item != null)
                {
                    ddlUnit.Items.Clear();
                    ddlUnit.Items.Add(Item);
                }
                ddlUnit.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to bind data to Currency dropdown
    /// </summary>
    private void BindCurrency()
    {
        try
        {
            DataTable dtCurrency = clsUtility.GetMasterValue("Currency");
            if (dtCurrency != null && dtCurrency.Rows.Count > 0)
            {
                ddlCurrency.DataSource = dtCurrency;
                ddlCurrency.DataValueField = "MasterId";
                ddlCurrency.DataTextField = "Value";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            ListItem ItemCurrency = ddlCurrency.Items.FindByText("INR") as ListItem;
            if (ItemCurrency != null)
            {
                ddlCurrency.ClearSelection();
                ItemCurrency.Selected = true;
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use  to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        ViewState["ACCOMODATIONRATEID"] = null;
        txtAlias.Text = txtRate.Text = string.Empty;
        ddlCityGrade.SelectedIndex = 0;
        ddlUnit.SelectedIndex = 0;
        ddlCurrency.SelectedIndex = 0;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The event is use to save and update Accomodation rate
    /// </summary>
    private void SaveAccomodationRate()
    {
        try
        {
            if (ViewState["ACCOMODATIONRATEID"] != null && ViewState["ACCOMODATIONRATEID"].ToString() != "0")
            {
                objclsAccomodationRateBD.CFlag = EFlag.UPDATE.ToString();
                objclsAccomodationRateBD.AccomodationRateId = Int64.Parse(ViewState["ACCOMODATIONRATEID"].ToString());
            }
            else
            {
                objclsAccomodationRateBD.CFlag = EFlag.INSERT.ToString();
                objclsAccomodationRateBD.AccomodationRateId = 0;
            }
            objclsAccomodationRateBD.CityGradeId = Int64.Parse(ddlCityGrade.SelectedValue.ToString());
            objclsAccomodationRateBD.Currency = Int64.Parse(ddlCurrency.SelectedValue.ToString());
            objclsAccomodationRateBD.Unit = Int64.Parse(ddlUnit.SelectedValue.ToString());
            objclsAccomodationRateBD.Alias = txtAlias.Text.Trim();
            objclsAccomodationRateBD.Rate = decimal.Parse(txtRate.Text.Trim());
            objclsAccomodationRateBD.Status = "Active";
            objclsAccomodationRateBD.DOC = DateTime.Now;
            objclsAccomodationRateBD.DOU = DateTime.Now;
            objclsAccomodationRateBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            if (objclsAccomodationRateBO.InsertUpdateAccomodationRate(objclsAccomodationRateBD))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Data Already Exists');</script>");
            }
            Clearfields();
            BindAccomodationRateData();
        }
        catch (Exception ex)
        {
            BindAccomodationRateData();
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Data Already Exists');</script>");
            }
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The following method is use to bind data in grid
    /// </summary>
    private void BindAccomodationRateData()
    {
        DataTable dtAccomodationRate = objclsAccomodationRateBO.SelectAccomodationRateData(0);
        if (dtAccomodationRate != null && dtAccomodationRate.Rows.Count > 0)
        {
            gvAccomodationRate.DataSource = dtAccomodationRate;
            gvAccomodationRate.DataBind();
        }
        else
        {
            gvAccomodationRate.DataSource = null;
            gvAccomodationRate.DataBind();
            //lblMsg.Text = "No data found.";
        }
    }
    #endregion
}
