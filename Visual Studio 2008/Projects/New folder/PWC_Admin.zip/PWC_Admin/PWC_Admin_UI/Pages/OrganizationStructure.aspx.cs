﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_OrganizationStructure : BasePage
{
    #region--Initializers--
    DataTable OrgDataTable = new DataTable();
    DataTable objDataTable = new DataTable();
    DataTable OrganizationTypeDataTable = new DataTable();
    clsOrganizationStructureTypeBO objclsOrganizationStructureTypeBO = new clsOrganizationStructureTypeBO();
    clsOrganizationStructureBO objclsOrganizationStructureBO = new clsOrganizationStructureBO();
    clsOrganizationStructureBD objclsOrganizationStructureBD = new clsOrganizationStructureBD();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Bindgrid();
                BindDropdown();
                BindParent();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update OrganizationStructure
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["OrganisationStructureId"] != null && ViewState["OrganisationStructureId"].ToString() != "0")
            {
                objclsOrganizationStructureBD.OrganisationStructureId = Int64.Parse(ViewState["OrganisationStructureId"].ToString());
                objclsOrganizationStructureBD.CFlag = EFlag.UPDATE.ToString();
            }
            else
            {
                objclsOrganizationStructureBD.OrganisationStructureId = 0;
                //if (OrganizationType())
                objclsOrganizationStructureBD.CFlag = EFlag.INSERT.ToString();
                //else
                //{
                //    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Only one name is allowed for this Organization Structure type');</script>");
                //    return;
                // }
            }
            objclsOrganizationStructureBD.Name = txtName.Text.Trim();
            objclsOrganizationStructureBD.Alias = txtAlias.Text.Trim();
            objclsOrganizationStructureBD.CostCenter = txtCostCenter.Text.Trim();
            objclsOrganizationStructureBD.DOC = DateTime.Now;
            objclsOrganizationStructureBD.DOU = DateTime.Now;
            objclsOrganizationStructureBD.OrganisationStructureTypeId = Int64.Parse(ddlOrgStructureType.SelectedValue.ToString());
            objclsOrganizationStructureBD.Status = "Active";
            objclsOrganizationStructureBD.TransactionId = 1;
            objclsOrganizationStructureBD.ParentId = Convert.ToInt64(ddlParent.SelectedValue);
            clsManageTransaction.StartTransaction();
            if (objclsOrganizationStructureBO.InsertUpdateOrganizationStructureType(objclsOrganizationStructureBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            BindParent();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to update and delete OrganizationStructure
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrganization_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToString().ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["OrganisationStructureId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsOrganizationStructureBD.OrganisationStructureId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsOrganizationStructureBO.DeleteOrganizationStructure(objclsOrganizationStructureBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrganization_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            txtName.Text = HttpUtility.HtmlDecode(gvOrganization.Rows[e.RowIndex].Cells[0].Text);

            //ddlOrgStructureType.Enabled = false;
            //txtAlias.Text = HttpUtility.HtmlDecode(gvOrganization.Rows[e.RowIndex].Cells[1].Text);
            txtName.Text = gvOrganization.Rows[e.RowIndex].Cells[0].Text;
            ddlOrgStructureType.SelectedIndex = ddlOrgStructureType.Items.IndexOf(ddlOrgStructureType.Items.FindByText(gvOrganization.Rows[e.RowIndex].Cells[1].Text));
            txtCostCenter.Text = HttpUtility.HtmlDecode(gvOrganization.Rows[e.RowIndex].Cells[2].Text);
            string ParentId = ((Label)gvOrganization.Rows[e.RowIndex].FindControl("lblParentId")).Text;
            ListItem ParentItem = ddlParent.Items.FindByValue(ParentId) as ListItem;
            if (ParentItem != null)
            {
                ddlParent.ClearSelection();
                ParentItem.Selected = true;
            }
            btnSave.Text = "Update";
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void gvOrganization_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrganization_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvOrganization.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtName.Text = txtAlias.Text = txtCostCenter.Text = string.Empty;
        ViewState["OrganisationStructureId"] = ddlOrgStructureType.SelectedIndex = 0;
        ddlOrgStructureType.Enabled = true;
        ddlParent.SelectedIndex = -1;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind Organization StructureType dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            OrgDataTable = new DataView(clsCommonUtilityBO.GetOrganizationType()).ToTable(false, new string[] { "OrganisationStructureTypeId", "Name" });
            ddlOrgStructureType.DataSource = OrgDataTable;
            ddlOrgStructureType.DataTextField = "Name";
            ddlOrgStructureType.DataValueField = "OrganisationStructureTypeId";
            ddlOrgStructureType.DataBind();
            ddlOrgStructureType.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Organization data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objDataTable = objclsOrganizationStructureBO.SelectOrganizationStructure(new clsOrganizationStructureBD() { CFlag = EFlag.ALL.ToString(), OrganisationStructureId = 0 });
            gvOrganization.DataSource = objDataTable;
            gvOrganization.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to validate adding organization to the OrganisationStructureType of IsMultiple
    /// </summary>
    /// <returns></returns>
    private bool OrganizationType()
    {
        try
        {
            OrganizationTypeDataTable = objclsOrganizationStructureTypeBO.SelectOrganizationStructureType(new clsOrganizationStructureTypeBD() { CFlag = "SINGLE", OrganisationStructureTypeId = Int64.Parse(ddlOrgStructureType.SelectedValue.ToString()) });
            if (OrganizationTypeDataTable.Rows[0].ItemArray[2].ToString().ToUpper() == "TRUE")
                return true;
            else
            {
                objDataTable = objclsOrganizationStructureBO.SelectOrganizationStructure(new clsOrganizationStructureBD() { CFlag = EFlag.ALL.ToString(), OrganisationStructureId = 0 });
                if (objDataTable != null && objDataTable.Rows.Count > 0)
                    return objDataTable.Select("OrganisationStructureTypeId = '" + Int64.Parse(ddlOrgStructureType.SelectedValue.ToString()) + "'").Count() < 1;
            }
            return true;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// BindParent: A method to Bind the parent of 'Organization Structure'(if any)
    /// </summary>
    private void BindParent()
    {
        try
        {
            DataTable dtParent = new DataView(objclsOrganizationStructureBO.SelectOrganizationStructure(new clsOrganizationStructureBD() { CFlag = EFlag.ALL.ToString(), OrganisationStructureId = 0 })).ToTable(true, new string[] { "OrganisationStructureId", "Name" });
            if (dtParent != null && dtParent.Rows.Count > 0)
            {
                ddlParent.DataSource = dtParent;
                ddlParent.DataValueField = "OrganisationStructureId";
                ddlParent.DataTextField = "Name";
                ddlParent.DataBind();
                ddlParent.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
}
