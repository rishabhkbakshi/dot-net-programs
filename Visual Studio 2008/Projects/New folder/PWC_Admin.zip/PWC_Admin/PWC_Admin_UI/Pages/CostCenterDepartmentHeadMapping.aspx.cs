﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;
public partial class Pages_CostCenterDepartmentHeadMapping : BasePage
{
    #region--Initializers--
    clsCostCenterDepartmentHeadMappingBD oclsCostcenterBD = new clsCostCenterDepartmentHeadMappingBD();
    clsCostCenterDepartmentHeadMappingBO oclsCostCenterBO = new clsCostCenterDepartmentHeadMappingBO();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindCostCenter();
                BindGrade();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindGrade()
    {
        try
        {
            clsGradeMasterBD oclsGradeMasterBD = new clsGradeMasterBD();
            clsGradeMasterBO oclsGradeMasterBO = new clsGradeMasterBO();
            oclsGradeMasterBD.CFlag = EFlag.ALL.ToString();
            oclsGradeMasterBD.GradeId = 0;
            DataTable dtGradeMaster = new DataView(oclsGradeMasterBO.SelectGradeMaster(oclsGradeMasterBD)).ToTable(false, new string[] { "GradeId", "GradeName" });
            ddlGrade.DataSource = dtGradeMaster;
            ddlGrade.DataTextField = "GradeName";
            ddlGrade.DataValueField = "GradeId";
            ddlGrade.DataBind();
            ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void BindCostCenter()
    {
        try
        {
            clsOrganizationStructureBO oOrganizationStructureBO = new clsOrganizationStructureBO();
            clsOrganizationStructureBD oOrganizationStructureBD = new clsOrganizationStructureBD();
            oOrganizationStructureBD.CFlag = "COSTCENTER";
            oOrganizationStructureBD.OrganisationStructureId = 0;
            ddlCostCenter.DataSource = oOrganizationStructureBO.SelectOrganizationStructure(oOrganizationStructureBD);
            ddlCostCenter.DataTextField = "CostCenter";
            ddlCostCenter.DataValueField = "OrganisationStructureId";
            ddlCostCenter.DataBind();
            ddlCostCenter.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void ddlGrade_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindEmployee();
    }

    private void BindEmployee()
    {
        try
        {
            clsEmployeeBO oEmployeeBO = new clsEmployeeBO();
            clsEmployeeBD oEmployeeBD = new clsEmployeeBD();
            oEmployeeBD.CFlag = "Grade";
            oEmployeeBD.EmployeeId = Convert.ToInt32(ddlGrade.SelectedValue);
            DataTable dtEmployee = oEmployeeBO.SelectEmployee(oEmployeeBD);
            ViewState["EMPLOYEE"] = dtEmployee;
            ddlEmployee.DataSource = dtEmployee;
            ddlEmployee.DataTextField = "Employee";
            ddlEmployee.DataValueField = "EmployeeId";
            ddlEmployee.DataBind();
            ddlEmployee.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void ddlEmployee_SelectedIndexChanged(object sender, EventArgs e)
    {
        clsCostCenterBD oclsCostcenterBD = new clsCostCenterBD();
        clsCostCenterBO oclsCostCenterBO = new clsCostCenterBO();
        try
        {
            if (ViewState["EMPLOYEE"] != null)
            {
                DataTable dtEmployee = ViewState["EMPLOYEE"] as DataTable;
                DataView dvEmployee = dtEmployee.DefaultView;
                string query = "1=1";
                if (ddlEmployee.SelectedIndex > 0)
                {
                    query = "EmployeeId='" + ddlEmployee.SelectedItem.Value + "'";
                }
                dvEmployee.RowFilter = query;

                if (dvEmployee.Count > 0)
                {
                    txtEmail.Text = Convert.ToString(dvEmployee[0]["Email"]);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            bool flag = true;
            if (ViewState["Employee"] != null && ViewState["Employee"].ToString() != "0")
            {
                oclsCostcenterBD.Flag = EFlag.UPDATE.ToString();
                oclsCostcenterBD.CDHID = Int64.Parse(ViewState["Employee"].ToString());
                flag = false;
            }
            else
            {
                oclsCostcenterBD.Flag = EFlag.INSERT.ToString();
                oclsCostcenterBD.CDHID = 0;
            }
            oclsCostcenterBD.CDHID = 0;
            oclsCostcenterBD.OSID = Convert.ToInt64(ddlEmployee.SelectedValue);
            oclsCostcenterBD.CostCenter = ddlCostCenter.SelectedValue;
            oclsCostcenterBD.EmpId = 0;
            oclsCostcenterBD.Email = txtEmail.Text;
            oclsCostcenterBD.DOC = DateTime.Now;
            oclsCostcenterBD.DOU = DateTime.Now;
            oclsCostcenterBD.Status = "Active";
            oclsCostcenterBD.GradeId = Convert.ToInt64(ddlGrade.SelectedValue);
            clsManageTransaction.StartTransaction();
            if (clsCostCenterDepartmentHeadMappingBO.CostCenterDepartmentHeadMapping(oclsCostcenterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                if (flag)
                {
                    lblMsg.Text = "Data Inserted Successfully.";
                }
                else
                {
                    lblMsg.Text = "Data Updated Successfully.";
                }
            }
            else
            {
                clsManageTransaction.EndTransaction();
                lblMsg.Text = "Not Successfully done.";
            }
            BindCostCenter();
            BindGrade();
            BindEmployee();
            Bindgrid();
            Clearfields();
            //ucPassportDetails1.Flag = 1;
            //ucVisaDetails1.Flag = 1;
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Data already exists.');</script>");
            }
        }
    }

    private void Clearfields()
    {
        
        ListItem lstitemCostCenter = ddlCostCenter.Items.FindByText("--Select--");
        if (lstitemCostCenter != null)
        {
            ddlCostCenter.ClearSelection();
            lstitemCostCenter.Selected = true;
        }
        ListItem lstItemEmployee = ddlEmployee.Items.FindByText("--Select--");
        if (lstItemEmployee != null)
        {
            ddlEmployee.ClearSelection();
            lstItemEmployee.Selected = true;
        }
        ListItem lstItemGrade = ddlGrade.Items.FindByText("--Select--");
        if (lstItemGrade != null)
        {
            ddlGrade.ClearSelection();
            lstItemGrade.Selected = true;
        }

        txtEmail.Text = string.Empty;
    }
    private void Bindgrid()
    {
        try
        {
            oclsCostcenterBD.Flag = "ALL";
            oclsCostcenterBD.CDHID = 0;
            DataTable dtCostCenter = clsCostCenterDepartmentHeadMappingBO.GetCostCenterDepartmentHeadMapping();
            if (dtCostCenter.Rows.Count > 0)
            {
                gvCostCenter.DataSource = dtCostCenter;
                gvCostCenter.DataBind();
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void gvCostCenter_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            ListItem lstCostCenter = ddlCostCenter.Items.FindByValue(gvCostCenter.Rows[e.RowIndex].Cells[2].Text);
            if (lstCostCenter != null)
            {
                ddlCostCenter.ClearSelection();
                lstCostCenter.Selected = true;
            }

           
            ListItem lstGrade = ddlGrade.Items.FindByValue(gvCostCenter.Rows[e.RowIndex].Cells[5].Text);
            if (lstGrade != null)
            {
                ddlGrade.ClearSelection();
                lstGrade.Selected = true;
                ddlGrade_SelectedIndexChanged(null, null);
            }
            ListItem lstEmployee = ddlEmployee.Items.FindByValue(gvCostCenter.Rows[e.RowIndex].Cells[1].Text);
            if (lstEmployee != null)
            {
                ddlEmployee.ClearSelection();
                lstEmployee.Selected = true;
            }
            ViewState["CDHID"] = gvCostCenter.DataKeys[e.RowIndex].Value;
            txtEmail.Text = gvCostCenter.Rows[e.RowIndex].Cells[4].Text;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvCostCenter_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            if (Convert.ToString(Session["value"]) == Convert.ToString(ViewState["value"]))
            {
                Session["value"] = Server.UrlEncode(System.DateTime.Now.ToString());
                long CDHID = Convert.ToInt64(gvCostCenter.DataKeys[e.RowIndex].Value);
                clsCostCenterDepartmentHeadMappingBO.DeleteCostCenterDepartmentHeadMapping(CDHID);
            }

            Bindgrid();
        }

        catch (Exception ex)
        {

            throw ex;

        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }

    protected void gvCostCenter_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvCostCenter.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
}

    #endregion

