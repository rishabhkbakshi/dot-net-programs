﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using Admin.BD;
using Admin.BO;
public partial class Pages_Accomodations : BasePage
{
    #region --Initializers--
    clsAccomodationsBD oclsAccomodationsBD;
    clsAccomodationsBO oclsAccomodationsBO;
    #endregion
    #region "PAGE EVENTS"
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindAccomodationType("AccomodationType");
            BindCountries();
            BindAccomodationsData();
            txtAccomodationAddress.Attributes.Add("onkeydown", "limitText(" + txtAccomodationAddress.ClientID + ", 200,200);");
            txtAccomodationAddress.Attributes.Add("onkeyup", "limitText(" + txtAccomodationAddress.ClientID + ", 200,200);");
            txtDescription.Attributes.Add("onkeydown", "limitText(" + txtDescription.ClientID + ", 200,200);");
            txtDescription.Attributes.Add("onkeyup", "limitText(" + txtDescription.ClientID + ", 200,200);");
        }
    }
    /// <summary>
    /// The event is use to delete(make inactive) Accomodations
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodations_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 AccomodationId = Int64.Parse(gvAccomodations.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();
            oclsAccomodationsBO = new clsAccomodationsBO();
            if (oclsAccomodationsBO.DeleteAccomodation(AccomodationId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");

        }
        BindAccomodationsData();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating Accomodations
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodations_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 AccomodationID = Int64.Parse(gvAccomodations.DataKeys[e.RowIndex].Value.ToString());
            ViewState["AccomodationID"] = AccomodationID;
            oclsAccomodationsBO = new clsAccomodationsBO();
            DataTable dtAccomodations = oclsAccomodationsBO.SelectAccomodationData(AccomodationID);
            if (dtAccomodations != null && dtAccomodations.Rows.Count > 0)
            {
                ddlAccomodations.SelectedValue = Convert.ToString(dtAccomodations.Rows[0]["MasterID"] != null ? dtAccomodations.Rows[0]["MasterID"] : 0);
                txtAccomodationName.Text = Convert.ToString(dtAccomodations.Rows[0]["AccomodationName"]);
                ListItem CountryItem = ddlCountry.Items.FindByValue(Convert.ToString(dtAccomodations.Rows[0]["CountryId"] != null ? dtAccomodations.Rows[0]["CountryId"] : 0));
                if (CountryItem != null)
                {
                    ddlCountry.ClearSelection();
                    CountryItem.Selected = true;
                }
                ddlCountry_SelectedIndexChanged(null, null);
                ddlState.SelectedValue = Convert.ToString(dtAccomodations.Rows[0]["StateId"] != null ? dtAccomodations.Rows[0]["StateId"] : 0);
                ddlState_SelectedIndexChanged(null, null);
                ddlCity.SelectedValue = Convert.ToString(dtAccomodations.Rows[0]["CityID"] != null ? dtAccomodations.Rows[0]["CityID"] : 0);
                txtAccomodationAddress.Text = Convert.ToString(dtAccomodations.Rows[0]["AccomodationAddress"]);
                //txtAlias.Text = Convert.ToString(dtAccomodations.Rows[0]["Alias"]);
                txtContactPerson.Text = Convert.ToString(dtAccomodations.Rows[0]["ContactPerson"]);
                if (!string.IsNullOrEmpty(Convert.ToString(dtAccomodations.Rows[0]["ContactNumber"])))
                {
                    string[] ContactNumber = Convert.ToString(dtAccomodations.Rows[0]["ContactNumber"]).Split('-');
                    txtContactNumber.Text = ContactNumber[0];
                    txtContactNumber2.Text = ContactNumber[1];
                }
                if (!string.IsNullOrEmpty(Convert.ToString(dtAccomodations.Rows[0]["ContactPersonMobileNumber"])))
                {
                    string[] ContactPersonMobileNumber = Convert.ToString(dtAccomodations.Rows[0]["ContactPersonMobileNumber"]).Split('-');
                    txtContactPersonNumber.Text = ContactPersonMobileNumber[0];
                    txtContactPersonNumber2.Text = ContactPersonMobileNumber[1];
                    txtContactPersonNumber3.Text = ContactPersonMobileNumber[2];
                }
                txtNumberOfRooms.Text = Convert.ToString(dtAccomodations.Rows[0]["NumberOfRoom"]);
                txtEmail.Text = Convert.ToString(dtAccomodations.Rows[0]["Email"]);
                txtAprRoomRate.Text = Convert.ToString(dtAccomodations.Rows[0]["ApprovedRoomRate"]);
                txtDescription.Text = Convert.ToString(dtAccomodations.Rows[0]["Description"]) == string.Empty ? "" : Convert.ToString(dtAccomodations.Rows[0]["Description"]);

                btnSave.Text = "Update";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to bind state data to dropdown.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedValue != "0")
        {
            BindStates(Convert.ToInt64(ddlCountry.SelectedValue));
            ddlState.Enabled = true;
        }
        else
        {
            ddlState.SelectedIndex = -1;
            ddlState.Enabled = false;
        }
    }
    /// <summary>
    /// The event is use to city data to dropdown.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(ddlState.SelectedValue) && ddlState.SelectedValue != "0")
        {
            BindCities(Convert.ToInt64(ddlState.SelectedValue));
            ddlCity.Enabled = true;
        }
        else
        {
            ddlCity.SelectedIndex = -1;
            ddlCity.Enabled = false;
        }

    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearFields();
    }
    /// <summary>
    /// The event is use to save and update Accomodations
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["AccomodationID"] != null)
            {
                if (InsertUpdateAccomodations(EFlag.UPDATE.ToString(), Convert.ToInt64(ViewState["AccomodationID"])))
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record updated successfully.');</script>");
                }
            }
            else
            {
                if (InsertUpdateAccomodations(EFlag.INSERT.ToString(), 0))
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record added successfully.');</script>");
                }
            }
            ClearFields();
            BindAccomodationsData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAccomodations_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvAccomodations.PageIndex = e.NewPageIndex;
        BindAccomodationsData();
    }
    #endregion
    #region "CUSTOM METHODS"
    /// <summary>
    /// The following method is use to bind AccomodationType
    /// </summary>
    /// <param name="Kewword"></param>
    private void BindAccomodationType(string Kewword)
    {
        try
        {
            DataTable dtAccomodationType = clsUtility.GetMasterValue(Kewword);
            ddlAccomodations.DataSource = dtAccomodationType;
            ddlAccomodations.DataTextField = "Value";
            ddlAccomodations.DataValueField = "MasterId";
            ddlAccomodations.DataBind();
            ddlAccomodations.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Countries
    /// </summary>
    private void BindCountries()
    {
        try
        {
            clsCountryMasterBO objclsCountryMasterBO = new clsCountryMasterBO();
            clsCountryMasterBD objclsCountryMasterBD = new clsCountryMasterBD();
            objclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            objclsCountryMasterBD.CountryId = 0;
            DataTable dtCountries = new DataView(objclsCountryMasterBO.SelectCountryMaster(objclsCountryMasterBD)).ToTable(true, new string[] { "CountryId", "CountryName" });
            ddlCountry.DataSource = dtCountries;
            ddlCountry.DataTextField = "CountryName";
            ddlCountry.DataValueField = "CountryId";
            ddlCountry.DataBind();
            ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind States based on country
    /// </summary>
    /// <param name="CountryId"></param>
    private void BindStates(Int64 CountryId)
    {
        try
        {
            clsStateMasterBO objclsStateMasterBO = new clsStateMasterBO();
            clsStateMasterBD objclsStateMasterBD = new clsStateMasterBD();
            objclsStateMasterBD.CFlag = "ByCountry";
            objclsStateMasterBD.StateId = CountryId;
            DataTable dtCountries = new DataView(objclsStateMasterBO.SelectStateMaster(objclsStateMasterBD)).ToTable(true, new string[] { "StateId", "StateName" });
            ddlState.DataSource = dtCountries;
            ddlState.DataTextField = "StateName";
            ddlState.DataValueField = "StateId";
            ddlState.DataBind();
            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind city based on state
    /// </summary>
    /// <param name="StateId"></param>
    private void BindCities(Int64 StateId)
    {
        try
        {
            clsCityMasterBO objclsCityMasterBO = new clsCityMasterBO();
            clsCityMasterBD objclsCityMasterBD = new clsCityMasterBD();
            objclsCityMasterBD.CFlag = "ByState";
            objclsCityMasterBD.CityId = StateId;
            DataTable dtCountries = new DataView(objclsCityMasterBO.SelectCityMaster(objclsCityMasterBD)).ToTable(true, new string[] { "CityId", "CityName" });
            ddlCity.DataSource = dtCountries;
            ddlCity.DataTextField = "CityName";
            ddlCity.DataValueField = "CityId";
            ddlCity.DataBind();
            ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method  is use to save and update
    /// </summary>
    /// <param name="flag"></param>
    /// <param name="AccomodationId"></param>
    /// <returns></returns>
    private bool InsertUpdateAccomodations(String flag, Int64 AccomodationId)
    {
        bool res = false;
        try
        {
            oclsAccomodationsBD = new clsAccomodationsBD();
            oclsAccomodationsBO = new clsAccomodationsBO();
            oclsAccomodationsBD.CFlag = flag;
            oclsAccomodationsBD.AccomodationID = AccomodationId;
            oclsAccomodationsBD.MasterID = Convert.ToInt64(ddlAccomodations.SelectedValue);
            oclsAccomodationsBD.CityID = Convert.ToInt64(ddlCity.SelectedValue);
            oclsAccomodationsBD.AccomodationName = txtAccomodationName.Text.Trim();
            oclsAccomodationsBD.AccomodationAddress = txtAccomodationAddress.Text.Trim();
            oclsAccomodationsBD.ContactNumber = txtContactNumber.Text.Trim() + "-" + txtContactNumber2.Text.Trim();
            oclsAccomodationsBD.ContactPerson = txtContactPerson.Text.Trim();
            oclsAccomodationsBD.ContactPersonMobileNumber = txtContactPersonNumber.Text.Trim() + "-" + txtContactPersonNumber2.Text.Trim() + "-" + txtContactPersonNumber3.Text.Trim();
            oclsAccomodationsBD.NumberOfRoom = Convert.ToInt32(txtNumberOfRooms.Text.Trim());
            oclsAccomodationsBD.Email = txtEmail.Text.Trim();
            oclsAccomodationsBD.Alias = txtAlias.Text.Trim();
            oclsAccomodationsBD.DOC = DateTime.Now;
            oclsAccomodationsBD.DOU = DateTime.Now;
            oclsAccomodationsBD.Status = "Active";
            oclsAccomodationsBD.TransactionID = 0;
            oclsAccomodationsBD.ApprovedRoomRate = Decimal.Parse(txtAprRoomRate.Text.Trim());
            if (txtDescription.Text != "")
            {
                oclsAccomodationsBD.Description = txtDescription.Text.Trim();
            }
            clsManageTransaction.StartTransaction();
            res = oclsAccomodationsBO.InsertUpdateAccomodations(oclsAccomodationsBD);
            clsManageTransaction.EndTransaction();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
        return res;
    }
    /// <summary>
    /// The following method is use to bind data in grid
    /// </summary>
    private void BindAccomodationsData()
    {
        oclsAccomodationsBO = new clsAccomodationsBO();
        DataTable dtAccomodations = oclsAccomodationsBO.SelectAccomodationData(0);
        try
        {
            if (dtAccomodations != null && dtAccomodations.Rows.Count > 0)
            {
                gvAccomodations.DataSource = dtAccomodations;
                gvAccomodations.DataBind();
            }
            else
            {
                gvAccomodations.EmptyDataText = "No Accomodations details found.";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void ClearFields()
    {
        try
        {
            ddlAccomodations.SelectedValue = "0";
            ddlCountry.SelectedValue = "0";
            ddlState.SelectedValue = "0";
            ddlState.Enabled = false;
            ddlCity.SelectedValue = "0";
            ddlCity.Enabled = false;
            txtAccomodationName.Text = string.Empty;
            txtAccomodationAddress.Text = string.Empty;
            txtContactNumber.Text = string.Empty;
            txtContactNumber2.Text = string.Empty;
            txtContactPerson.Text = string.Empty;
            txtAlias.Text = string.Empty;
            txtContactPersonNumber.Text = string.Empty;
            txtContactPersonNumber2.Text = string.Empty;
            txtContactPersonNumber3.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtNumberOfRooms.Text = string.Empty;
            ViewState["AccomodationID"] = null;
            txtAprRoomRate.Text = string.Empty;
            txtDescription.Text = string.Empty;
            btnSave.Text = "Save";

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    #endregion

}
