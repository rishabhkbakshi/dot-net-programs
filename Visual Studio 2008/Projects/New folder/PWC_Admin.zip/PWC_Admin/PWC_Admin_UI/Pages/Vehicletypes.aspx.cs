﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;


public partial class Pages_Vehicletypes : BasePage
{
    #region--Initializers--
    clsVehicleTypesBD oclsVehicleTypesBD = new clsVehicleTypesBD();
    clsVehicleTypesBO oclsVehicleTypesBO = new clsVehicleTypesBO();
    DataTable dtVehicleTypes = new DataTable();
    #endregion
    #region--Page Load--
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Bindgrid();
            Binddropdown();
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event allow you to Insert and update Vehicle Types into VehicleTypes
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (!(DateTime.Parse(txtTo.Text) > DateTime.Parse(txtFrom.Text)))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please enter valid From and To dates');</script>");
                return;
            }

            if (ViewState["VehicleTypesId"] != null && ViewState["VehicleTypesId"].ToString() !="0")
            {
                oclsVehicleTypesBD.CFlag = EFlag.UPDATE.ToString();
                oclsVehicleTypesBD.VehicleTypesId = Int64.Parse(ViewState["VehicleTypesId"].ToString()); 
            }
            else
            {
                oclsVehicleTypesBD.CFlag = EFlag.INSERT.ToString();
                oclsVehicleTypesBD.VehicleTypesId = 0; 
            }
            oclsVehicleTypesBD.ApprovedRate = Decimal.Parse(txtApprovedRate.Text);
            oclsVehicleTypesBD.CC = txtCC.Text.Trim();
            oclsVehicleTypesBD.ClassOfVehicle = Int64.Parse(ddlClassOfVehicle.SelectedValue.ToString());
            oclsVehicleTypesBD.DOC = DateTime.Now;
            oclsVehicleTypesBD.DOU = DateTime.Now;
            oclsVehicleTypesBD.FromDate = DateTime.Parse(txtFrom.Text.Trim().ToString());
            oclsVehicleTypesBD.Status = "Active";
            oclsVehicleTypesBD.ToDate = DateTime.Parse(txtTo.Text.Trim().ToString());
            oclsVehicleTypesBD.TransactionId = 1;
            oclsVehicleTypesBD.TypeOfBody = Int64.Parse(ddlTypeOfBody.SelectedValue.ToString());
            clsManageTransaction.StartTransaction();
            if (oclsVehicleTypesBO.InsertUpdateVehicleTypes(oclsVehicleTypesBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event allow to clear the i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event took place while paging of the grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicleTypes_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvVehicleTypes.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is triggered while updating the particular row
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicleTypes_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        txtApprovedRate.Text = gvVehicleTypes.Rows[e.RowIndex].Cells[3].Text;
        txtCC.Text = gvVehicleTypes.Rows[e.RowIndex].Cells[2].Text;
        txtFrom.Text = gvVehicleTypes.Rows[e.RowIndex].Cells[4].Text;
        txtTo.Text = gvVehicleTypes.Rows[e.RowIndex].Cells[5].Text;
        ddlClassOfVehicle.SelectedIndex = ddlClassOfVehicle.Items.IndexOf(ddlClassOfVehicle.Items.FindByText(gvVehicleTypes.Rows[e.RowIndex].Cells[0].Text));
        ddlTypeOfBody.SelectedIndex = ddlTypeOfBody.Items.IndexOf(ddlTypeOfBody.Items.FindByText(gvVehicleTypes.Rows[e.RowIndex].Cells[1].Text));
        btnSave.Text = "Update";
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicleTypes_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is used to update and delete the Vehicles types
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicleTypes_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["VehicleTypesId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsVehicleTypesBD.VehicleTypesId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsVehicleTypesBO.DeleteVehicleTypes(oclsVehicleTypesBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
   
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The method is used to bind vehicles types data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsVehicleTypesBD.CFlag = EFlag.ALL.ToString();
            oclsVehicleTypesBD.VehicleTypesId = 0;
            dtVehicleTypes = oclsVehicleTypesBO.SelectVehicleTypes(oclsVehicleTypesBD);
            gvVehicleTypes.DataSource = dtVehicleTypes;
            gvVehicleTypes.DataBind();

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The method is used clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtApprovedRate.Text = txtCC.Text = txtFrom.Text = txtTo.Text = string.Empty;
        ViewState["VehicleTypesId"] = ddlClassOfVehicle.SelectedIndex = ddlTypeOfBody.SelectedIndex = 0;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The method is used to bind dropdown ClassOfVehicle & TypeOfBody
    /// </summary>
    private void Binddropdown()
    {
        try
        {
            DataTable dtClassOfVehicle = clsUtility.GetMasterValue("Class of Vehicle");
            if (dtClassOfVehicle != null && dtClassOfVehicle.Rows.Count > 0)
            {
                ddlClassOfVehicle.DataSource = dtClassOfVehicle;
                ddlClassOfVehicle.DataValueField = "MasterId";
                ddlClassOfVehicle.DataTextField = "Value";
                ddlClassOfVehicle.DataBind();
                ddlClassOfVehicle.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlClassOfVehicle.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            DataTable dtTypeOfBody = clsUtility.GetMasterValue("Type of Body");
            if (dtTypeOfBody != null && dtTypeOfBody.Rows.Count > 0)
            {
                ddlTypeOfBody.DataSource = dtTypeOfBody;
                ddlTypeOfBody.DataValueField = "MasterId";
                ddlTypeOfBody.DataTextField = "Value";
                ddlTypeOfBody.DataBind();
                ddlTypeOfBody.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlTypeOfBody.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
}
