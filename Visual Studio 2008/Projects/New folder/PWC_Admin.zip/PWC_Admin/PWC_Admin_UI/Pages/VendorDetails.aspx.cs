﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_VendorDetails : BasePage
{
    #region --Initializers--
    clsVendorAddressBD objclsVendorAddressBD = new clsVendorAddressBD();
    clsVendorContactDetailsBD objclsVendorContactDetailsBD = new clsVendorContactDetailsBD();
    List<clsVendorAddressBD> lstclsVendorAddressBD = new List<clsVendorAddressBD>();
    List<clsVendorContactDetailsBD> lstclsVendorContactDetailsBD = new List<clsVendorContactDetailsBD>();
    clsVendorMasterBD objclsVendorMasterBD = new clsVendorMasterBD();
    clsVendorDetailsBO objclsVendorDetailsBO = new clsVendorDetailsBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindVendorType();
            BindCountry();
            BindAddressType();
            BindVendorDetailsData();
            BindInitialValue();
            tcVendorDetails.ActiveTabIndex = 0;
        }
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind first list item to all dropdown
    /// </summary>
    private void BindInitialValue()
    {
        try
        {
            ddlStateVA.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlStateVC.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCityVC.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCityVA.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind AccomodationPolicy data in grid
    /// </summary>
    private void BindVendorDetailsData()
    {
        try
        {
            DataTable dtAccomodationPolicy = objclsVendorDetailsBO.SelectVendrMasterData(0);
            if (dtAccomodationPolicy != null && dtAccomodationPolicy.Rows.Count > 0)
            {
                gvVendorMaster.DataSource = dtAccomodationPolicy;
                gvVendorMaster.DataBind();

            }
            else
            {
                lblMsg.Text = "No data found.";
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }


    }
    /// <summary>
    /// The following method is use to bind VendorType dropdown
    /// </summary>
    private void BindVendorType()
    {
        try
        {
            DataTable dtTravelType = clsUtility.GetMasterValue("VendorType");
            if (dtTravelType != null && dtTravelType.Rows.Count > 0)
            {

                ddlVendorType.DataSource = dtTravelType;
                ddlVendorType.DataValueField = "MasterId";
                ddlVendorType.DataTextField = "Value";
                ddlVendorType.DataBind();
                ddlVendorType.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlVendorType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Country dropdown
    /// </summary>
    private void BindCountry()
    {
        try
        {
            DataTable dtCountry = clsUtility.GetCountryData("ALL", 0);
            if (dtCountry != null && dtCountry.Rows.Count > 0)
            {

                ddlCountryVA.DataSource = dtCountry;
                ddlCountryVA.DataValueField = "CountryId";
                ddlCountryVA.DataTextField = "CountryName";
                ddlCountryVA.DataBind();
                ddlCountryVA.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCountryVC.DataSource = dtCountry;
                ddlCountryVC.DataValueField = "CountryId";
                ddlCountryVC.DataTextField = "CountryName";
                ddlCountryVC.DataBind();
                ddlCountryVC.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlCountryVA.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlCountryVC.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind AddressType dropdown
    /// </summary>
    private void BindAddressType()
    {
        try
        {
            DataTable dtAddressType = clsUtility.GetMasterValue("AddressType");
            if (dtAddressType != null && dtAddressType.Rows.Count > 0)
            {

                ddlAddressType.DataSource = dtAddressType;
                ddlAddressType.DataValueField = "MasterId";
                ddlAddressType.DataTextField = "Value";
                ddlAddressType.DataBind();
                ddlAddressType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlAddressType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void ClearVendorMasterfields()
    {
        txtVendorName.Text = txtAlias.Text = string.Empty;
        ddlVendorType.SelectedIndex = 0;

    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void ClearVendorAddressfields()
    {
        txtZipCodeVA.Text = txtVendorAddressVA.Text = txtWebSiteVA.Text = string.Empty;
        txtEmailVA.Text = txtPhone1VA.Text = txtPhone2VA.Text = txtFaxVA.Text = string.Empty;
        ddlAddressType.SelectedIndex = 0;
        ddlCityVA.SelectedIndex = 0;
        ddlCountryVA.SelectedIndex = 0;
        ddlStateVA.SelectedIndex = 0;
        chkIsPreferred.Checked = false;

    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void ClearVendorContactfields()
    {
        txtZipCodeVC.Text = txtVendorAddressVC.Text = txtWebSiteVC.Text = string.Empty;
        txtEmailVC.Text = txtPhone1VC.Text = txtPhone2VC.Text = txtFaxVC.Text = string.Empty;
        ddlCityVC.SelectedIndex = 0;
        ddlCountryVC.SelectedIndex = 0;
        ddlStateVC.SelectedIndex = 0;

    }
    /// <summary>
    /// The following method is use to  save VendorAddress
    /// </summary>
    private void SaveVendorAddress()
    {
        try
        {
            if (ViewState["ROWIDVA"] != null && ViewState["ROWIDVA"].ToString() != "-1")
            {
                int rowid = Int32.Parse(ViewState["ROWIDVA"].ToString());
                List<clsVendorAddressBD> listAddressDetails = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
                listAddressDetails[rowid].VendorAddressId = 0;
                listAddressDetails[rowid].VendorId = 1;
                listAddressDetails[rowid].AddressType = Int64.Parse(ddlAddressType.SelectedValue.ToString());
                if (chkIsPreferred.Checked == true)
                {
                    listAddressDetails[rowid].IsPreferred = true;
                }
                else
                {
                    listAddressDetails[rowid].IsPreferred = false;
                }
                listAddressDetails[rowid].VAddress = txtVendorAddressVA.Text.Trim();
                listAddressDetails[rowid].CityId = Int64.Parse(ddlCityVA.SelectedValue.ToString());
                listAddressDetails[rowid].StateId = Int64.Parse(ddlStateVA.SelectedValue.ToString());
                listAddressDetails[rowid].CountryId = Int64.Parse(ddlCountryVA.SelectedValue.ToString());
                listAddressDetails[rowid].CityName = ddlCityVA.SelectedItem.Text;
                listAddressDetails[rowid].StateName = ddlStateVA.SelectedItem.Text;
                listAddressDetails[rowid].CountryName = ddlCountryVA.SelectedItem.Text;
                listAddressDetails[rowid].ZipCode = txtZipCodeVA.Text.Trim();
                listAddressDetails[rowid].WebSite = txtWebSiteVA.Text.Trim();
                listAddressDetails[rowid].Email = txtEmailVA.Text.Trim();
                listAddressDetails[rowid].Phone1 = txtPhone1VA.Text.Trim();
                if (txtPhone2VA.Text.Trim() != string.Empty || txtPhone2VA.Text.Trim() != "")
                {
                    listAddressDetails[rowid].Phone2 = txtPhone2VA.Text.Trim();
                }
                else
                {
                    listAddressDetails[rowid].Phone2 = "";
                }
                listAddressDetails[rowid].Fax = txtFaxVA.Text.Trim();
                //listAddressDetails[rowid].Alias = txtAliasVA.Text;
                listAddressDetails[rowid].Status = "Active";
                listAddressDetails[rowid].DOC = DateTime.Now;
                listAddressDetails[rowid].DOU = DateTime.Now;
                listAddressDetails[rowid].CFlag = EFlag.INSERT.ToString();
                listAddressDetails[rowid].TransactionId = 0;
                ViewState["ROWIDVA"] = null;
                btnSaveVendorAddress.Text = "Save Vendor Contact";

            }
            else
            {
                objclsVendorAddressBD.VendorAddressId = 0;
                objclsVendorAddressBD.VendorId = 1;
                objclsVendorAddressBD.AddressType = Int64.Parse(ddlAddressType.SelectedValue.ToString());
                if (chkIsPreferred.Checked == true)
                {
                    objclsVendorAddressBD.IsPreferred = true;
                }
                else
                {
                    objclsVendorAddressBD.IsPreferred = false;
                }
                objclsVendorAddressBD.VAddress = txtVendorAddressVA.Text.Trim();
                objclsVendorAddressBD.CityId = Int64.Parse(ddlCityVA.SelectedValue.ToString());
                objclsVendorAddressBD.StateId = Int64.Parse(ddlStateVA.SelectedValue.ToString());
                objclsVendorAddressBD.CountryId = Int64.Parse(ddlCountryVA.SelectedValue.ToString());
                objclsVendorAddressBD.CityName = ddlCityVA.SelectedItem.Text;
                objclsVendorAddressBD.StateName = ddlStateVA.SelectedItem.Text;
                objclsVendorAddressBD.CountryName = ddlCountryVA.SelectedItem.Text;
                objclsVendorAddressBD.ZipCode = txtZipCodeVA.Text.Trim();
                objclsVendorAddressBD.WebSite = txtWebSiteVA.Text.Trim();
                objclsVendorAddressBD.Email = txtEmailVA.Text.Trim();
                objclsVendorAddressBD.Phone1 = txtPhone1VA.Text.Trim();
                if (txtPhone2VA.Text.Trim() != string.Empty || txtPhone2VA.Text.Trim() != "")
                {
                    objclsVendorAddressBD.Phone2 = txtPhone2VA.Text.Trim();
                }
                else
                {
                    objclsVendorAddressBD.Phone2 = "";
                }
                objclsVendorAddressBD.Fax = txtFaxVA.Text.Trim();
                //objclsVendorAddressBD.Alias = txtAliasVA.Text;
                objclsVendorAddressBD.Status = "Active";
                objclsVendorAddressBD.DOC = DateTime.Now;
                objclsVendorAddressBD.DOU = DateTime.Now;
                objclsVendorAddressBD.CFlag = EFlag.INSERT.ToString();
                objclsVendorAddressBD.TransactionId = 0;
                if (ViewState["LISTVENDORADDRESS"] != null)
                {
                    List<clsVendorAddressBD> list = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
                    list.Add(objclsVendorAddressBD);
                    ViewState["LISTVENDORADDRESS"] = list;
                }
                else
                {
                    lstclsVendorAddressBD.Add(objclsVendorAddressBD);
                    ViewState["LISTVENDORADDRESS"] = lstclsVendorAddressBD;
                }
            }
            ClearVendorAddressfields();
            BindVendorAddressGrid();
        }
        catch (Exception ex)
        {

            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The following method is use to  save VendorContactDetails
    /// </summary>
    private void SaveVendorVendorContact()
    {

        try
        {
            if (ViewState["ROWIDVC"] != null && ViewState["ROWIDVC"].ToString() != "-1")
            {
                int rowid = Int32.Parse(ViewState["ROWIDVC"].ToString());
                List<clsVendorContactDetailsBD> listContactDetails = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
                listContactDetails[rowid].VENDorContactDetailId = 0;
                listContactDetails[rowid].VendorId = 1;
                listContactDetails[rowid].VAddress = txtVendorAddressVC.Text.Trim();
                listContactDetails[rowid].CityId = Int64.Parse(ddlCityVC.SelectedValue.ToString());
                listContactDetails[rowid].StateId = Int64.Parse(ddlStateVC.SelectedValue.ToString());
                listContactDetails[rowid].CountryId = Int64.Parse(ddlCountryVC.SelectedValue.ToString());
                listContactDetails[rowid].CityName = ddlCityVC.SelectedItem.Text;
                listContactDetails[rowid].StateName = ddlStateVC.SelectedItem.Text;
                listContactDetails[rowid].CountryName = ddlCountryVC.SelectedItem.Text;
                listContactDetails[rowid].ZipCode = txtZipCodeVC.Text.Trim();
                listContactDetails[rowid].WebSite = txtWebSiteVC.Text.Trim();
                listContactDetails[rowid].Email = txtEmailVC.Text.Trim();
                listContactDetails[rowid].PhoneNo1 = txtPhone1VC.Text.Trim();
                if (txtPhone2VC.Text.Trim() != string.Empty || txtPhone2VC.Text.Trim() != "")
                {
                    listContactDetails[rowid].PhoneNo2 = txtPhone2VC.Text.Trim();
                }
                else
                {
                    listContactDetails[rowid].PhoneNo2 = "";
                }
                listContactDetails[rowid].Fax = txtFaxVC.Text.Trim();
                //listContactDetails[rowid].Alias = txtAliasVC.Text;
                listContactDetails[rowid].Status = "Active";
                listContactDetails[rowid].DOC = DateTime.Now;
                listContactDetails[rowid].DOU = DateTime.Now;
                listContactDetails[rowid].CFlag = EFlag.INSERT.ToString();
                listContactDetails[rowid].TransactionId = 0;
                ViewState["ROWIDVC"] = null;
                btnSaveVendorContact.Text = "Save Vendor Contact";

            }
            else
            {
                objclsVendorContactDetailsBD.VENDorContactDetailId = 0;
                objclsVendorContactDetailsBD.VendorId = 1;
                objclsVendorContactDetailsBD.VAddress = txtVendorAddressVC.Text.Trim();
                objclsVendorContactDetailsBD.CityId = Int64.Parse(ddlCityVC.SelectedValue.ToString());
                objclsVendorContactDetailsBD.StateId = Int64.Parse(ddlStateVC.SelectedValue.ToString());
                objclsVendorContactDetailsBD.CountryId = Int64.Parse(ddlCountryVC.SelectedValue.ToString());
                objclsVendorContactDetailsBD.CityName = ddlCityVC.SelectedItem.Text;
                objclsVendorContactDetailsBD.StateName = ddlStateVC.SelectedItem.Text;
                objclsVendorContactDetailsBD.CountryName = ddlCountryVC.SelectedItem.Text;
                objclsVendorContactDetailsBD.ZipCode = txtZipCodeVC.Text.Trim();
                objclsVendorContactDetailsBD.WebSite = txtWebSiteVC.Text.Trim();
                objclsVendorContactDetailsBD.Email = txtEmailVC.Text.Trim();
                objclsVendorContactDetailsBD.PhoneNo1 = txtPhone1VC.Text.Trim();
                if (txtPhone2VC.Text.Trim() != string.Empty || txtPhone2VC.Text.Trim() != "")
                {
                    objclsVendorContactDetailsBD.PhoneNo2 = txtPhone2VC.Text.Trim();
                }
                else
                {
                    objclsVendorContactDetailsBD.PhoneNo2 = "";
                }
                objclsVendorContactDetailsBD.Fax = txtFaxVC.Text.Trim();
                //objclsVendorContactDetailsBD.Alias = txtAliasVC.Text;
                objclsVendorContactDetailsBD.Status = "Active";
                objclsVendorContactDetailsBD.DOC = DateTime.Now;
                objclsVendorContactDetailsBD.DOU = DateTime.Now;
                objclsVendorContactDetailsBD.CFlag = EFlag.INSERT.ToString();
                objclsVendorContactDetailsBD.TransactionId = 0;
                if (ViewState["LISTVENDORCONTACT"] != null)
                {
                    List<clsVendorContactDetailsBD> list = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
                    list.Add(objclsVendorContactDetailsBD);
                    ViewState["LISTVENDORCONTACT"] = list;
                }
                else
                {
                    lstclsVendorContactDetailsBD.Add(objclsVendorContactDetailsBD);
                    ViewState["LISTVENDORCONTACT"] = lstclsVendorContactDetailsBD;
                }
            }
            ClearVendorContactfields();
            BindVendorContactGrid();
        }
        catch (Exception ex)
        {

            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to bind  BindVendorAddress data in grid
    /// </summary>
    private void BindVendorAddressGrid()
    {
        try
        {
            if (ViewState["LISTVENDORADDRESS"] != null)
            {
                List<clsVendorAddressBD> lstVendorAddress = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
                gvVendorAddress.DataSource = lstVendorAddress;
                gvVendorAddress.DataBind();
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to bind VendorContact data in grid
    /// </summary>
    private void BindVendorContactGrid()
    {
        try
        {
            if (ViewState["LISTVENDORCONTACT"] != null)
            {
                List<clsVendorContactDetailsBD> lstVendorAddress = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
                gvVendorContactDetail.DataSource = lstVendorAddress;
                gvVendorContactDetail.DataBind();
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  save VendorDetailsData
    /// </summary>
    private void SaveVendorDetailsData()
    {
        try
        {
            if (ViewState["VENDORID"] != null && ViewState["VENDORID"].ToString() != "0")
            {
                objclsVendorMasterBD.CFlag = EFlag.UPDATE.ToString();
                objclsVendorMasterBD.VendorId = Int64.Parse(ViewState["VENDORID"].ToString());
            }
            else
            {
                objclsVendorMasterBD.CFlag = EFlag.INSERT.ToString();
                objclsVendorMasterBD.VendorId = 0;
            }
            objclsVendorMasterBD.VendorName = txtVendorName.Text.Trim();
            objclsVendorMasterBD.VendorType = Int64.Parse(ddlVendorType.SelectedValue.ToString());
            objclsVendorMasterBD.Alias = txtAlias.Text.Trim();
            objclsVendorMasterBD.Status = "Active";
            objclsVendorMasterBD.DOC = DateTime.Now;
            objclsVendorMasterBD.DOU = DateTime.Now;
            objclsVendorMasterBD.TransactionId = 0;
            clsManageTransaction.StartTransaction();
            int retVendorID = objclsVendorDetailsBO.InsertUpdateVendorMaster(objclsVendorMasterBD);
            if (ViewState["LISTVENDORADDRESS"] != null)
            {
                List<clsVendorAddressBD> list = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
                foreach (clsVendorAddressBD objclsVendorAddressBD in list)
                {
                    objclsVendorAddressBD.VendorId = retVendorID;
                    objclsVendorDetailsBO.InsertUpdateVendorAddress(objclsVendorAddressBD);
                }
            }
            if (ViewState["LISTVENDORCONTACT"] != null)
            {
                List<clsVendorContactDetailsBD> list = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
                foreach (clsVendorContactDetailsBD objclsVendorContactDetailsBD in list)
                {
                    objclsVendorContactDetailsBD.VendorId = retVendorID;
                    objclsVendorDetailsBO.InsertUpdateVendorContact(objclsVendorContactDetailsBD);

                }

            }
            clsManageTransaction.EndTransaction();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
        btnSave.Text = "Save";
        ClearVendorMasterfields();
        ClearVendorAddressfields();
        ClearVendorContactfields();
        BindVendorDetailsData();

    }
    /// <summary>
    /// The event is use to bind VendorAddress data in grid
    /// </summary>
    /// <param name="VendorId"></param>
    private void BindVendorAddressByVendor(long VendorId)
    {
        try
        {
            DataTable dtVendorAddressData = objclsVendorDetailsBO.SelectVendorAddressData(VendorId, "ByVendor");
            if (dtVendorAddressData != null && dtVendorAddressData.Rows.Count > 0)
            {
                gvVendorAddress.DataSource = dtVendorAddressData;
                gvVendorAddress.DataBind();

                for (int i = 0; i < dtVendorAddressData.Rows.Count; i++)
                {
                    objclsVendorAddressBD.VendorAddressId = Int64.Parse(dtVendorAddressData.Rows[i]["VendorAddressId"].ToString());
                    objclsVendorAddressBD.VendorId = Int64.Parse(dtVendorAddressData.Rows[i]["VendorId"].ToString());
                    objclsVendorAddressBD.AddressType = Int64.Parse(dtVendorAddressData.Rows[i]["AddressType"].ToString());
                    if (dtVendorAddressData.Rows[i]["IsPreferred"].ToString() == "true")
                    {
                        objclsVendorAddressBD.IsPreferred = true;
                    }
                    else
                    {
                        objclsVendorAddressBD.IsPreferred = false;
                    }
                    objclsVendorAddressBD.VAddress = dtVendorAddressData.Rows[i]["VAddress"].ToString();
                    objclsVendorAddressBD.CityId = Int64.Parse(dtVendorAddressData.Rows[i]["CityId"].ToString());
                    objclsVendorAddressBD.StateId = Int64.Parse(dtVendorAddressData.Rows[i]["StateId"].ToString());
                    objclsVendorAddressBD.CountryId = Int64.Parse(dtVendorAddressData.Rows[i]["CountryId"].ToString());
                    objclsVendorAddressBD.ZipCode = dtVendorAddressData.Rows[i]["ZipCode"].ToString();
                    objclsVendorAddressBD.WebSite = dtVendorAddressData.Rows[i]["WebSite"].ToString();
                    objclsVendorAddressBD.Email = dtVendorAddressData.Rows[i]["Email"].ToString();
                    objclsVendorAddressBD.Phone1 = dtVendorAddressData.Rows[i]["Phone1"].ToString();
                    objclsVendorAddressBD.Phone2 = dtVendorAddressData.Rows[i]["Phone2"].ToString();
                    objclsVendorAddressBD.Fax = dtVendorAddressData.Rows[i]["Fax"].ToString();
                    objclsVendorAddressBD.Alias = dtVendorAddressData.Rows[i]["Alias"].ToString();
                    objclsVendorAddressBD.Status = "Active";
                    objclsVendorAddressBD.DOC = DateTime.Now;
                    objclsVendorAddressBD.DOU = DateTime.Now;
                    objclsVendorAddressBD.CFlag = EFlag.UPDATE.ToString();
                    objclsVendorAddressBD.TransactionId = 0;
                    lstclsVendorAddressBD.Add(objclsVendorAddressBD);
                }
                ViewState["LISTVENDORADDRESS"] = lstclsVendorAddressBD;


            }
            else
            {
                ViewState["LISTVENDORADDRESS"] = lstclsVendorAddressBD;
                lblMsg.Text = "No data found.";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// to bind  BindVendorContact By Vendor data in grid
    /// </summary>
    /// <param name="VendorId"></param>
    private void BindVendorContactByVendor(long VendorId)
    {
        try
        {
            DataTable dtVendorContact = objclsVendorDetailsBO.SelectVendorContactData(VendorId, "ByVendor");
            if (dtVendorContact != null && dtVendorContact.Rows.Count > 0)
            {
                gvVendorContactDetail.DataSource = dtVendorContact;
                gvVendorContactDetail.DataBind();

                for (int i = 0; i < dtVendorContact.Rows.Count; i++)
                {
                    objclsVendorContactDetailsBD.VENDorContactDetailId = Int64.Parse(dtVendorContact.Rows[i]["VENDorContactDetailId"].ToString());
                    objclsVendorContactDetailsBD.VendorId = Int64.Parse(dtVendorContact.Rows[i]["VendorId"].ToString());
                    objclsVendorContactDetailsBD.VAddress = dtVendorContact.Rows[i]["VAddress"].ToString();
                    objclsVendorContactDetailsBD.CityId = Int64.Parse(dtVendorContact.Rows[i]["CityId"].ToString());
                    objclsVendorContactDetailsBD.StateId = Int64.Parse(dtVendorContact.Rows[i]["StateId"].ToString());
                    objclsVendorContactDetailsBD.CountryId = Int64.Parse(dtVendorContact.Rows[i]["CountryId"].ToString());
                    objclsVendorContactDetailsBD.ZipCode = dtVendorContact.Rows[i]["Zipcode"].ToString();
                    objclsVendorContactDetailsBD.WebSite = dtVendorContact.Rows[i]["WebSite"].ToString();
                    objclsVendorContactDetailsBD.Email = dtVendorContact.Rows[i]["Email"].ToString();
                    objclsVendorContactDetailsBD.PhoneNo1 = dtVendorContact.Rows[i]["PhoneNo1"].ToString();
                    objclsVendorContactDetailsBD.PhoneNo2 = dtVendorContact.Rows[i]["PhoneNo2"].ToString();
                    objclsVendorContactDetailsBD.Fax = dtVendorContact.Rows[i]["Fax"].ToString();
                    objclsVendorContactDetailsBD.Alias = dtVendorContact.Rows[i]["Alias"].ToString();
                    objclsVendorContactDetailsBD.Status = "Active";
                    objclsVendorContactDetailsBD.DOC = DateTime.Now;
                    objclsVendorContactDetailsBD.DOU = DateTime.Now;
                    objclsVendorContactDetailsBD.CFlag = EFlag.UPDATE.ToString();
                    objclsVendorContactDetailsBD.TransactionId = 0;
                    lstclsVendorContactDetailsBD.Add(objclsVendorContactDetailsBD);

                }
                ViewState["LISTVENDORCONTACT"] = lstclsVendorContactDetailsBD;


            }
            else
            {
                ViewState["LISTVENDORCONTACT"] = lstclsVendorContactDetailsBD;
                lblMsg.Text = "No data found.";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind StateVA dropdown
    /// </summary>
    private void BindStateVA(long CountryId)
    {
        try
        {
            DataTable dtStateVA = clsUtility.GetStateData("ByCountry", CountryId);
            if (dtStateVA != null && dtStateVA.Rows.Count > 0)
            {
                ddlStateVA.DataSource = dtStateVA;
                ddlStateVA.DataValueField = "StateId";
                ddlStateVA.DataTextField = "StateName";
                ddlStateVA.DataBind();
                ddlStateVA.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlStateVA.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind CityVA dropdown
    /// </summary>
    private void BindCityVA(long CityId)
    {
        try
        {
            DataTable dtCityVA = clsUtility.GetCityData("ByState", CityId);
            if (dtCityVA != null && dtCityVA.Rows.Count > 0)
            {
                ddlCityVA.DataSource = dtCityVA;
                ddlCityVA.DataValueField = "StateId";
                ddlCityVA.DataTextField = "CityName";
                ddlCityVA.DataBind();
                ddlCityVA.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCityVA.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind StateVC dropdown
    /// </summary>
    private void BindStateVC(long CountryId)
    {
        try
        {
            DataTable dtStateVC = clsUtility.GetStateData("ByCountry", CountryId);
            if (dtStateVC != null && dtStateVC.Rows.Count > 0)
            {
                ddlStateVC.DataSource = dtStateVC;
                ddlStateVC.DataValueField = "StateId";
                ddlStateVC.DataTextField = "StateName";
                ddlStateVC.DataBind();
            }
            ddlStateVC.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind CityVC dropdown
    /// </summary>
    private void BindCityVC(long CityId)
    {
        try
        {
            DataTable dtCityVC = clsUtility.GetCityData("ByState", CityId);
            if (dtCityVC != null && dtCityVC.Rows.Count > 0)
            {
                ddlCityVC.DataSource = dtCityVC;
                ddlCityVC.DataValueField = "StateId";
                ddlCityVC.DataTextField = "CityName";
                ddlCityVC.DataBind();
            }
            ddlCityVC.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region --Event Handlers--
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearVendorMasterfields();
        ClearVendorAddressfields();
        ClearVendorContactfields();
        Server.Transfer(Request.Path);
    }
    /// <summary>
    /// The event is use to save VendorDetailsData
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveVendorDetailsData();
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    //protected void btnCancel_Click(object sender, EventArgs e)
    //{
    //    ClearVendorMasterfields();
    //    ClearVendorAddressfields();
    //    ClearVendorContactfields();
    //    BindInitialValue();
    //}
    /// <summary>
    /// The event is use to save VendorAddress
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSaveVendorAddress_Click(object sender, EventArgs e)
    {
        SaveVendorAddress();
    }
    protected void btnCancelVendorAddress_Click(object sender, EventArgs e)
    {
        ddlAddressType.SelectedIndex = ddlCityVA.SelectedIndex = ddlCountryVA.SelectedIndex = ddlStateVA.SelectedIndex = 0;
        txtEmailVA.Text = txtFaxVA.Text = txtPhone1VA.Text = txtPhone2VA.Text = txtVendorAddressVA.Text = txtWebSiteVA.Text = txtZipCodeVA.Text = string.Empty;
    }
    /// <summary>
    /// The event is use to save VendorContact
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSaveVendorContact_Click(object sender, EventArgs e)
    {
        SaveVendorVendorContact();
    }
    protected void tbnCancelVendorContact_Click(object sender, EventArgs e)
    {
        ddlCityVC.SelectedIndex = ddlCountryVC.SelectedIndex = ddlStateVC.SelectedIndex = 0;
        txtEmailVC.Text = txtFaxVC.Text = txtPhone1VC.Text = txtPhone2VC.Text = txtVendorAddressVC.Text = txtWebSiteVC.Text = txtZipCodeVC.Text = string.Empty;
    }
    /// <summary>
    /// The event is use to bind data State to dropdown on selecting Country
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlCountryVA_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCountryVA.SelectedIndex > 0)
            {
                long CountryId = Int64.Parse(ddlCountryVA.SelectedValue.ToString());
                BindStateVA(CountryId);
            }
            else
            {
                ddlStateVA.Items.Insert(0, new ListItem("--Select--", "0"));

            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The event is use to bind data city to dropdown on selecting State
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlStateVA_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlStateVA.SelectedIndex > 0)
            {
                long CityId = Int64.Parse(ddlStateVA.SelectedValue.ToString());
                BindCityVA(CityId);
            }
            else
            {
                ddlCityVA.Items.Insert(0, new ListItem("--Select--", "0"));

            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to bind data State to dropdown on selecting Country
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlCountryVC_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCountryVC.SelectedIndex > 0)
            {
                long CountryId = Int64.Parse(ddlCountryVC.SelectedValue.ToString());
                BindStateVC(CountryId);
            }
            else
            {
                ddlStateVC.Items.Insert(0, new ListItem("--Select--", "0"));

            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to bind data city to dropdown on selecting State
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlStateVC_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlStateVC.SelectedIndex > 0)
            {
                long CityId = Int64.Parse(ddlStateVC.SelectedValue.ToString());
                BindCityVC(CityId);
            }
            else
            {
                ddlCityVC.Items.Insert(0, new ListItem("--Select--", "0"));

            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update vendor
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorMaster_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 VendorId = Int64.Parse(gvVendorMaster.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["VENDORID"] = VendorId;
            DataTable dtVendorMasterDetails = objclsVendorDetailsBO.SelectVendrMasterData(VendorId);
            if (dtVendorMasterDetails != null && dtVendorMasterDetails.Rows.Count > 0)
            {
                ddlVendorType.SelectedValue = dtVendorMasterDetails.Rows[0]["VendorType"].ToString();
                //txtVendorName.Text = dtVendorMasterDetails.Rows[0]["VendorTypeName"].ToString();//VendorName
                txtVendorName.Text = dtVendorMasterDetails.Rows[0]["VendorName"].ToString();//VendorName
                //txtAlias.Text = dtVendorMasterDetails.Rows[0]["Alias"].ToString();
                btnSave.Text = "Update";
                BindVendorAddressByVendor(VendorId);
                BindVendorContactByVendor(VendorId);

            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to delete VendorMaster
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorMaster_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 VendorId = Int64.Parse(gvVendorMaster.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();
            if (objclsVendorDetailsBO.DeleteVendorMaster(VendorId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");

        }
        BindVendorDetailsData();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorMaster_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvVendorMaster.PageIndex = e.NewPageIndex;
            BindVendorDetailsData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update vendorcontact
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorContactDetail_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int rowid = e.RowIndex;
            ViewState["ROWIDVC"] = rowid;

            List<clsVendorContactDetailsBD> listContactDetails;
            //= (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
            if (ViewState["LISTVENDORCONTACT"] != null)
            {
                listContactDetails = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
                clsVendorContactDetailsBD oVendorContactDetailsBD = listContactDetails[rowid];

                txtVendorAddressVC.Text = oVendorContactDetailsBD.VAddress;
                ListItem CountryContactItem = new ListItem();
                CountryContactItem = ddlCountryVC.Items.FindByValue(Convert.ToString(oVendorContactDetailsBD.CountryId)) as ListItem;
                if (CountryContactItem != null)
                {
                    ddlCountryVC.ClearSelection();
                    CountryContactItem.Selected = true;
                }
                BindStateVC(oVendorContactDetailsBD.CountryId);

                ListItem StateContactItem = new ListItem();
                StateContactItem = ddlStateVC.Items.FindByValue(Convert.ToString(oVendorContactDetailsBD.StateId)) as ListItem;
                if (StateContactItem != null)
                {
                    ddlStateVC.ClearSelection();
                    StateContactItem.Selected = true;
                }
                BindCityVC(oVendorContactDetailsBD.StateId);

                ListItem CityContactItem = new ListItem();
                CityContactItem = ddlCityVC.Items.FindByValue(Convert.ToString(oVendorContactDetailsBD.StateId)) as ListItem;
                if (CityContactItem != null)
                {
                    ddlCityVC.ClearSelection();
                    CityContactItem.Selected = true;
                }
                txtZipCodeVC.Text = oVendorContactDetailsBD.ZipCode;
                txtEmailVC.Text = oVendorContactDetailsBD.Email;
                txtPhone1VC.Text = oVendorContactDetailsBD.PhoneNo1;
                txtPhone2VC.Text = oVendorContactDetailsBD.PhoneNo2;
                txtWebSiteVC.Text = oVendorContactDetailsBD.WebSite;
                txtFaxVC.Text = oVendorContactDetailsBD.Fax;
                //txtAliasVC.Text = oVendorContactDetailsBD.Alias;
                btnSaveVendorContact.Text = "Edit Vendor Contact";
            }
            tcVendorDetails.ActiveTabIndex = 2;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to  delete VendorContactDetail
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorContactDetail_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int rowid = e.RowIndex;
            List<clsVendorContactDetailsBD> listContactDetails = (List<clsVendorContactDetailsBD>)ViewState["LISTVENDORCONTACT"];
            Int64 VENDorContactDetailId = listContactDetails[rowid].VENDorContactDetailId;
            if (VENDorContactDetailId > 0)
            {
                clsManageTransaction.StartTransaction();
                if (objclsVendorDetailsBO.DeleteContactDetails(VENDorContactDetailId))
                {
                    clsManageTransaction.EndTransaction();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
                }
            }
            listContactDetails.RemoveAt(rowid);
            ViewState["LISTVENDORCONTACT"] = listContactDetails;
            BindVendorContactGrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update VendorAddress
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorAddress_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            int rowid = e.RowIndex;
            ViewState["ROWIDVA"] = rowid;
            List<clsVendorAddressBD> listAddressDetails;
            if (ViewState["LISTVENDORADDRESS"] != null)
            {
                listAddressDetails = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
                clsVendorAddressBD oVendorAddressBD = listAddressDetails[rowid];

                ListItem AddressTypeItem = new ListItem();
                AddressTypeItem = ddlAddressType.Items.FindByValue(Convert.ToString(oVendorAddressBD.AddressType)) as ListItem;
                if (AddressTypeItem != null)
                {
                    ddlAddressType.ClearSelection();
                    AddressTypeItem.Selected = true;
                }
                chkIsPreferred.Checked = oVendorAddressBD.IsPreferred;
                txtVendorAddressVA.Text = oVendorAddressBD.VAddress;

                ListItem CountryAddressItem = new ListItem();
                CountryAddressItem = ddlCountryVA.Items.FindByValue(Convert.ToString(oVendorAddressBD.CountryId)) as ListItem;
                if (CountryAddressItem != null)
                {
                    ddlCountryVA.ClearSelection();
                    CountryAddressItem.Selected = true;
                }
                BindStateVA(oVendorAddressBD.CountryId);
                ListItem StateAddressItem = new ListItem();
                StateAddressItem = ddlStateVA.Items.FindByValue(Convert.ToString(oVendorAddressBD.StateId)) as ListItem;
                if (StateAddressItem != null)
                {
                    ddlStateVA.ClearSelection();
                    StateAddressItem.Selected = true;
                }
                BindCityVA(oVendorAddressBD.StateId);
                ListItem CityAddressItem = new ListItem();
                CityAddressItem = ddlCityVA.Items.FindByValue(Convert.ToString(oVendorAddressBD.StateId)) as ListItem;
                if (CityAddressItem != null)
                {
                    ddlCityVA.ClearSelection();
                    CityAddressItem.Selected = true;
                }

                txtZipCodeVA.Text = oVendorAddressBD.ZipCode;
                txtEmailVA.Text = oVendorAddressBD.Email;
                txtPhone1VA.Text = oVendorAddressBD.Phone1;
                txtPhone2VA.Text = oVendorAddressBD.Phone2;
                txtWebSiteVA.Text = oVendorAddressBD.WebSite;
                txtFaxVA.Text = oVendorAddressBD.Fax;
                //txtAliasVA.Text = oVendorAddressBD.Alias;
                btnSaveVendorAddress.Text = "Edit Vendor Address";
            }
            tcVendorDetails.ActiveTabIndex = 1;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to delete VendorAddress
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVendorAddress_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int rowid = e.RowIndex;
            List<clsVendorAddressBD> listAddressDetails = (List<clsVendorAddressBD>)ViewState["LISTVENDORADDRESS"];
            Int64 VendorAddressId = listAddressDetails[rowid].VendorAddressId;
            //Int64 temp= Int64.Parse(gvVendorAddress.DataKeys[e.RowIndex].Values[0].ToString());
            if (VendorAddressId > 0)
            {
                clsManageTransaction.StartTransaction();
                if (objclsVendorDetailsBO.DeleteVendorAddress(VendorAddressId))
                {
                    clsManageTransaction.EndTransaction();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
                }
            }
            listAddressDetails.RemoveAt(rowid);
            ViewState["LISTVENDORADDRESS"] = listAddressDetails;
            BindVendorAddressGrid();
            btnCancelVendorAddress_Click(sender, e);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

    #endregion
}
