﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_PerDiemPolicy : BasePage
{
    #region--Initializers--
    clsGradeMasterBO objclsGradeMasterBO = new clsGradeMasterBO();
    clsGradeMasterBD objclsGradeMasterBD = new clsGradeMasterBD();
    clsPerDiemPolicyBD objclsPerDiemPolicyBD = new clsPerDiemPolicyBD();
    clsPerDiemPolicyBO objclsPerDiemPolicyBO = new clsPerDiemPolicyBO();
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    DataTable objDataTable = new DataTable();

    //added by mahesh for applying policy on list of grade
    clsPolicyGradeMappingBD oclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
    clsPolicyGradeMappingBO oclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
    //ended
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //System.Globalization.DateTimeFormatInfo gdFormat = new System.Globalization.DateTimeFormatInfo();
            //gdFormat.ShortDatePattern = "dd/MM/yyyy";
            
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid();
                BindGrade();
            }
            DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
            txtEffectiveTo.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update  PerDiemPolicy
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            int result = DateTime.Compare(Convert.ToDateTime(txtEffectiveFrom.Text.ToString()), Convert.ToDateTime(txtEffectiveTo.Text.ToString()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }

            if (ViewState["PerDiemPolicyId"] != null && ViewState["PerDiemPolicyId"].ToString() != "0")
            {
                objclsPerDiemPolicyBD.CFlag = EFlag.UPDATE.ToString();
                objclsPerDiemPolicyBD.PerDiemPolicyId = Int64.Parse(ViewState["PerDiemPolicyId"].ToString());
            }
            else
            {
                objclsPerDiemPolicyBD.CFlag = EFlag.INSERT.ToString();
                objclsPerDiemPolicyBD.PerDiemPolicyId = 0;
            }

            objclsPerDiemPolicyBD.Alias = txtAlias.Text.Trim();
            objclsPerDiemPolicyBD.Amount = System.Decimal.Parse(txtAmount.Text.Trim());
            objclsPerDiemPolicyBD.Currency = Int64.Parse(ddlCurrency.SelectedValue.ToString());
            objclsPerDiemPolicyBD.DOC = DateTime.Now;
            objclsPerDiemPolicyBD.DOU = DateTime.Now;
            objclsPerDiemPolicyBD.EffectiveFrom = DateTime.Parse(txtEffectiveFrom.Text.Trim());
            objclsPerDiemPolicyBD.EffectiveTo = DateTime.Parse(txtEffectiveTo.Text.Trim());
            //commented and modified by mahesh for applying policy on list of grade
            //objclsPerDiemPolicyBD.GradeId = Int64.Parse(ddlGrade.SelectedValue.ToString());
            objclsPerDiemPolicyBD.GradeId = 0;
            //ended
            objclsPerDiemPolicyBD.IsEquivalent = chkIsEquivalent.Checked;
            objclsPerDiemPolicyBD.ForValue = txtForValue.Text.Trim();
            objclsPerDiemPolicyBD.ForUnit = txtForUnit.Text.Trim();
            //objclsPerDiemPolicyBD.Specific = ddlSpecific.SelectedItem.ToString();
            objclsPerDiemPolicyBD.Specific = ddlSpecific.SelectedValue.ToString();
            objclsPerDiemPolicyBD.Status = "Active";
            objclsPerDiemPolicyBD.TransactionId = 1;
            objclsPerDiemPolicyBD.TravelType = Int64.Parse(ddlTravelType.SelectedValue);
            objclsPerDiemPolicyBD.Allowance = ddlAllowanceType.SelectedItem.Text;
            objclsPerDiemPolicyBD.CountryId = Int64.Parse(ddlCountry.SelectedValue);
            clsManageTransaction.StartTransaction();
            if (SavePolicyGrade(objclsPerDiemPolicyBO.InsertUpdatePerDiemPolicy(objclsPerDiemPolicyBD)))
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

    private bool SavePolicyGrade(long p)
    {
        int Check = 0;
        //clsManageTransaction.StartTransaction();
        if (ViewState["PerDiemPolicyId"] != null && ViewState["PerDiemPolicyId"].ToString() != "0")
        {
            oclsPolicyGradeMappingBD.ReferencePolicyId = Int64.Parse(ViewState["PerDiemPolicyId"].ToString());
            oclsPolicyGradeMappingBO.DeletePolicyGradeMapping(oclsPolicyGradeMappingBD);
        }
        oclsPolicyGradeMappingBD.CFlag = EFlag.INSERT.ToString();
        oclsPolicyGradeMappingBD.ReferencePolicyId = p;
        oclsPolicyGradeMappingBD.ReferencePolicyType = "PerDiem Policy";
        oclsPolicyGradeMappingBD.DOC = DateTime.Now;
        oclsPolicyGradeMappingBD.DOU = DateTime.Now;
        oclsPolicyGradeMappingBD.Status = "Active";
        foreach (ListItem item in lstbxDestinGrade.Items)
        {
            oclsPolicyGradeMappingBD.GradeId = Int64.Parse(item.Value);
            oclsPolicyGradeMappingBO.InsertUpdatePolicyGradeMapping(oclsPolicyGradeMappingBD);
            Check += 1;
        }
        //clsManageTransaction.EndTransaction();
        return lstbxDestinGrade.Items.Count == Check;
    }

    private void BindDestinationGrade(Int64 ReferencePolicyId)
    {
        BindGrade();
        oclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
        oclsPolicyGradeMappingBD.CFlag = "PERDIEMPOLICY";
        DataTable dtList = oclsPolicyGradeMappingBO.SelectPolicyGradeMapping(oclsPolicyGradeMappingBD);
        if (dtList.Rows.Count > 0)
        {
            lstbxDestinGrade.DataSource = dtList;
            lstbxDestinGrade.DataTextField = "GradeName";
            lstbxDestinGrade.DataValueField = "GradeId";
            lstbxDestinGrade.DataBind();
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
                lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);
        }

    }
    private void BindGrade()
    {
        try
        {
            objclsGradeMasterBD.CFlag = EFlag.ALL.ToString();
            objclsGradeMasterBD.GradeId = 0;
            DataTable dtGrade = objclsGradeMasterBO.SelectGradeMaster(objclsGradeMasterBD);
            lstbxSourceGrade.DataSource = dtGrade;
            lstbxSourceGrade.DataValueField = "GradeId";
            lstbxSourceGrade.DataTextField = "GradeName";
            lstbxSourceGrade.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPerDiem_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvPerDiem.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to update and delete
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPerDiem_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
            {
                Clearfields();
                ViewState["PerDiemPolicyId"] = e.CommandArgument.ToString();
                BindDestinationGrade(Int64.Parse(e.CommandArgument.ToString()));
            }
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsPerDiemPolicyBD.PerDiemPolicyId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsPerDiemPolicyBO.DeletePerDiemPolicy(objclsPerDiemPolicyBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvPerDiem_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPerDiem_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        ddlTravelType.SelectedIndex = ddlTravelType.Items.IndexOf(ddlTravelType.Items.FindByText(gvPerDiem.Rows[e.RowIndex].Cells[0].Text));
        txtForValue.Text = gvPerDiem.Rows[e.RowIndex].Cells[1].Text == "&nbsp;" ? String.Empty : gvPerDiem.Rows[e.RowIndex].Cells[1].Text;
        txtForUnit.Text = gvPerDiem.Rows[e.RowIndex].Cells[2].Text == "&nbsp;" ? String.Empty : gvPerDiem.Rows[e.RowIndex].Cells[2].Text;
        ddlSpecific.SelectedIndex = ddlSpecific.Items.IndexOf(ddlSpecific.Items.FindByValue(gvPerDiem.DataKeys[e.RowIndex].Value.ToString()));
        txtAmount.Text = gvPerDiem.Rows[e.RowIndex].Cells[4].Text;
        ddlCurrency.SelectedIndex = ddlCurrency.Items.IndexOf(ddlCurrency.Items.FindByText(gvPerDiem.Rows[e.RowIndex].Cells[5].Text));
        chkIsEquivalent.Checked = gvPerDiem.Rows[e.RowIndex].Cells[6].Text.ToString() == "Equivalent" ? true : false;
        txtEffectiveFrom.Text = gvPerDiem.Rows[e.RowIndex].Cells[7].Text;
        txtEffectiveTo.Text = gvPerDiem.Rows[e.RowIndex].Cells[8].Text;
        ListItem AllowanceTypeItem = ddlAllowanceType.Items.FindByText(gvPerDiem.Rows[e.RowIndex].Cells[9].Text);
        if (AllowanceTypeItem != null)
        {
            ddlAllowanceType.ClearSelection();
            AllowanceTypeItem.Selected = true;
        }
        btnSave.Text = "Update";

    }
    /// <summary>
    /// The event is use to bind spec & Equivalent
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPerDiem_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                e.Row.Cells[6].Text = e.Row.Cells[6].Text.ToString() == "True" ? "Equivalent" : "Not Equivalent";
                switch (e.Row.Cells[4].Text.ToString())
                {
                    case "1":
                        e.Row.Cells[4].Text = "<";
                        break;
                    case "2":
                        e.Row.Cells[4].Text = ">";
                        break;
                    case "3":
                        e.Row.Cells[4].Text = ">=";
                        break;
                    case "4":
                        e.Row.Cells[4].Text = "<=";
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        ViewState["PerDiemPolicyId"] = ddlCurrency.SelectedIndex = /*ddlGrade.SelectedIndex =*/ ddlSpecific.SelectedIndex = ddlTravelType.SelectedIndex = 0;
        txtForUnit.Text = txtAlias.Text = txtAmount.Text = txtEffectiveFrom.Text = txtForValue.Text = string.Empty;
        chkIsEquivalent.Checked = false;
        lstbxDestinGrade.Items.Clear();
        lstbxSourceGrade.Items.Clear();
        ddlAllowanceType.SelectedIndex = -1;
        ddlCountry.SelectedIndex = -1;
        BindGrade();
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind Equivalentto grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsPerDiemPolicyBD.CFlag = EFlag.ALL.ToString();
            objDataTable = objclsPerDiemPolicyBO.SelectPerDiemPolicy(objclsPerDiemPolicyBD);
            gvPerDiem.DataSource = objDataTable;
            gvPerDiem.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to bind TravelType dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            DataTable dtUnit = clsUtility.GetMasterValue("TravelType");
            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlTravelType.DataSource = dtUnit;
                ddlTravelType.DataValueField = "MasterId";
                ddlTravelType.DataTextField = "Value";
                ddlTravelType.DataBind();
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            DataTable dtCurrency = clsUtility.GetMasterValue("Currency");
            if (dtCurrency != null && dtCurrency.Rows.Count > 0)
            {
                ddlCurrency.DataSource = dtCurrency;
                ddlCurrency.DataValueField = "MasterId";
                ddlCurrency.DataTextField = "Value";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            DataTable dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    #endregion
    protected void btnOneRight_Click(object sender, EventArgs e)
    {
        if (lstbxSourceGrade.Items.Count == 0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }
        if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
        {
            if (lstbxSourceGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
            {
                if (lstbxSourceGrade.Items[i].Selected)
                    lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Remove(lstbxDestinGrade.Items[i]);
            }
        }
        else
        {
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Add(lstbxSourceGrade.Items[i]);

            lstbxSourceGrade.Items.Clear();
        }

    }
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        if (lstbxDestinGrade.Items.Count == 0)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item');</script>");
            return;
        }

        if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
        {
            if (lstbxDestinGrade.SelectedIndex == -1)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('No item is selected');</script>");
                return;
            }
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                if (lstbxDestinGrade.Items[i].Selected)
                    lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            for (int i = 0; i < lstbxSourceGrade.Items.Count; i++)
                lstbxDestinGrade.Items.Remove(lstbxSourceGrade.Items[i]);
        }
        else
        {
            for (int i = 0; i < lstbxDestinGrade.Items.Count; i++)
            {
                lstbxSourceGrade.Items.Add(lstbxDestinGrade.Items[i]);
            }
            lstbxDestinGrade.Items.Clear();
        }
    }
}
