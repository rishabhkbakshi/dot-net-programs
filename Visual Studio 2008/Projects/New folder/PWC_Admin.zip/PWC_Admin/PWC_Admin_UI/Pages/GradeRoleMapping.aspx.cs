﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_GradeRoleMapping : BasePage
{
    #region--Initializers--
    clsGradeMasterBO objclsGradeMasterBO = new clsGradeMasterBO();
    clsRoleMasterBO objclsRoleMasterBO = new clsRoleMasterBO();
    clsGradeMasterBD objclsGradeMasterBD = new clsGradeMasterBD();
    clsRoleMasterBD objclsRoleMasterBD = new clsRoleMasterBD();
    clsGradeRoleMappingBD objclsGradeRoleMappingBD = new clsGradeRoleMappingBD();
    clsGradeRoleMappingBO objclsGradeRoleMappingBO = new clsGradeRoleMappingBO();
    DataTable GradeDataTable = new DataTable();
    DataTable RoleDataTable = new DataTable();
    DataTable objDataTable = new DataTable();

    DataTable OrgDataTable = new DataTable();
    #endregion
    #region--Page load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update GradeRole
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["GradeRoleMappingId"] != null && ViewState["GradeRoleMappingId"].ToString() != "0")
            {
                if (OnConditionValidate())
                {
                    objclsGradeRoleMappingBD.CFlag = EFlag.UPDATE.ToString();
                    objclsGradeRoleMappingBD.GradeRoleMappingId = Int64.Parse(ViewState["GradeRoleMappingId"].ToString());
                }
                else
                {
                    Clearfields();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Grade and role is already mapped');</script>");
                    return;
                }
            }
            else
            {
                if (OnValidate())
                {
                    objclsGradeRoleMappingBD.CFlag = EFlag.INSERT.ToString();
                    objclsGradeRoleMappingBD.GradeRoleMappingId = 0;
                }
                else
                {
                    Clearfields();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Grade and role is already mapped');</script>");
                    return;
                }
            }
            objclsGradeRoleMappingBD.Alias = txtAlias.Text.Trim();
            objclsGradeRoleMappingBD.GradeId = Int64.Parse(ddlGrade.SelectedValue.ToString());
            objclsGradeRoleMappingBD.RoleId = Int64.Parse(ddlRole.SelectedValue.ToString());
            objclsGradeRoleMappingBD.DOC = DateTime.Now;
            objclsGradeRoleMappingBD.DOU = DateTime.Now;
            objclsGradeRoleMappingBD.Status = "Active";
            objclsGradeRoleMappingBD.TransactionId = 1;
            clsManageTransaction.StartTransaction();
            if (objclsGradeRoleMappingBO.InsertUpdateGradeRoleMapping(objclsGradeRoleMappingBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to update and delete GradeRole
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeRole_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["GradeRoleMappingId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsGradeRoleMappingBD.GradeRoleMappingId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsGradeRoleMappingBO.DeleteGradeRoleMapping(objclsGradeRoleMappingBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeRole_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        ddlOrgStructureType.SelectedIndex = ddlOrgStructureType.Items.IndexOf(ddlOrgStructureType.Items.FindByText(HttpUtility.HtmlDecode(gvGradeRole.Rows[e.RowIndex].Cells[0].Text)));
        ddlOrgStructureType_SelectedIndexChanged(sender, e);
        ddlOrganisation.SelectedIndex = ddlOrganisation.Items.IndexOf(ddlOrganisation.Items.FindByText(HttpUtility.HtmlDecode(gvGradeRole.Rows[e.RowIndex].Cells[1].Text)));
        ddlOrganisation_SelectedIndexChanged(sender, e);
        ddlOrganisation.Enabled = ddlOrgStructureType.Enabled = false;
        ddlRole.SelectedIndex = ddlRole.Items.IndexOf(ddlRole.Items.FindByText(HttpUtility.HtmlDecode(gvGradeRole.Rows[e.RowIndex].Cells[2].Text)));
        ddlGrade.SelectedIndex = ddlGrade.Items.IndexOf(ddlGrade.Items.FindByText(HttpUtility.HtmlDecode(gvGradeRole.Rows[e.RowIndex].Cells[3].Text)));
        //txtAlias.Text = HttpUtility.HtmlDecode(gvGradeRole.Rows[e.RowIndex].Cells[4].Text);
        btnSave.Text = "Update";
    }
    protected void gvGradeRole_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvGradeRole_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvGradeRole.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void ddlOrgStructureType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (string.Compare(ddlOrgStructureType.SelectedValue.ToString(), "0") != 0)
            {
                ddlOrganisation.Enabled = true;
                OrgDataTable = new DataView(clsCommonUtilityBO.GetOrganizationBasedOnType(Int64.Parse(ddlOrgStructureType.SelectedValue.ToString()))).ToTable(false, new string[] { "OrganisationStructureId", "Name" });
                ddlOrganisation.DataSource = OrgDataTable;
                ddlOrganisation.DataTextField = "Name";
                ddlOrganisation.DataValueField = "OrganisationStructureId";
                ddlOrganisation.DataBind();
                ddlOrganisation.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
   protected void ddlOrganisation_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (string.Compare(ddlOrganisation.SelectedValue, "0") != 0)
            {
                ddlOrganisation.Enabled = true;
                objclsRoleMasterBD.CFlag = "OS";
                objclsRoleMasterBD.RoleId = Int64.Parse(ddlOrganisation.SelectedValue.ToString());
                RoleDataTable = new DataView(objclsRoleMasterBO.SelectRoleMaster(objclsRoleMasterBD)).ToTable(false, new string[] { "RoleId", "Name" });
                ddlRole.DataSource = RoleDataTable;
                ddlRole.DataValueField = "RoleId";
                ddlRole.DataTextField = "Name";
                ddlRole.DataBind();
                ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind GradeRoleMapping 
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsGradeRoleMappingBD.CFlag = EFlag.ALL.ToString();
            objclsGradeRoleMappingBD.GradeRoleMappingId = 0;
            objDataTable = objclsGradeRoleMappingBO.SelectGradeRoleMapping(objclsGradeRoleMappingBD);
            gvGradeRole.DataSource = objDataTable;
            gvGradeRole.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
       
        ddlOrganisation.Enabled = ddlOrgStructureType.Enabled=ddlGrade.Enabled = ddlGrade.Enabled = true;
        txtAlias.Text = string.Empty;
        ddlRole.Items.Clear();
        ddlOrganisation.Items.Clear();
        ddlGrade.Items.Clear();
        ddlRole.Items.Clear();
        BindDropdown();
        ViewState["GradeRoleMappingId"] = ddlGrade.SelectedIndex = ddlRole.SelectedIndex = 0;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind Grade & Role dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            objclsGradeMasterBD.CFlag = EFlag.ALL.ToString();
            objclsGradeMasterBD.GradeId = 0;
            GradeDataTable = new DataView(objclsGradeMasterBO.SelectGradeMaster(objclsGradeMasterBD)).ToTable(false, new string[] { "GradeId", "GradeName" });
            ddlGrade.DataSource = GradeDataTable;
            ddlGrade.DataValueField = "GradeId";
            ddlGrade.DataTextField = "GradeName";
            ddlGrade.DataBind();
            ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));


            //Following commented for new changes---on 12:19 PM 7/2/2012
            //objclsRoleMasterBD.CFlag = EFlag.ALL.ToString();
            //objclsRoleMasterBD.RoleId = 0;
            //RoleDataTable = new DataView(objclsRoleMasterBO.SelectRoleMaster(objclsRoleMasterBD)).ToTable(false, new string[] { "RoleId", "Name" });
            //ddlRole.DataSource = RoleDataTable;
            //ddlRole.DataValueField = "RoleId";
            //ddlRole.DataTextField = "Name";
            //ddlRole.DataBind();
            //ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));
            //ended

            OrgDataTable = new DataView(clsCommonUtilityBO.GetOrganizationType()).ToTable(false, new string[] { "OrganisationStructureTypeId", "Name" });
            ddlOrgStructureType.DataSource = OrgDataTable;
            ddlOrgStructureType.DataTextField = "Name";
            ddlOrgStructureType.DataValueField = "OrganisationStructureTypeId";
            ddlOrgStructureType.DataBind();
            ddlOrgStructureType.Items.Insert(0, new ListItem("--Select--", "0"));            

            ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlOrganisation.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to validate grade and role is already mapped or not
    /// </summary>
    /// <returns></returns>
    private bool OnValidate()
    {
        try
        {
            objclsGradeRoleMappingBD.CFlag = EFlag.ALL.ToString();
            objclsGradeRoleMappingBD.GradeRoleMappingId = 0;
            objDataTable = objclsGradeRoleMappingBO.SelectGradeRoleMapping(objclsGradeRoleMappingBD);
            if (objDataTable != null && objDataTable.Rows.Count > 0)
                return objDataTable.Select("GradeId='" + ddlGrade.SelectedValue.ToString() + "' and RoleId='" + ddlRole.SelectedValue.ToString() + "'").Count() < 1;
            return true;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to validate grade and role is already mapped or not while updating
    /// </summary>
    /// <returns></returns>
    private bool OnConditionValidate()
    {
        try
        {
            objclsGradeRoleMappingBD.CFlag = EFlag.ALL.ToString();
            objclsGradeRoleMappingBD.GradeRoleMappingId = 0;
            objDataTable = objclsGradeRoleMappingBO.SelectGradeRoleMapping(objclsGradeRoleMappingBD);
            if (objDataTable != null && objDataTable.Rows.Count > 0)
            {
                if (objDataTable.Select("GradeId='" + ddlGrade.SelectedValue.ToString() + "' and RoleId='" + ddlRole.SelectedValue.ToString() + "' and GradeRoleMappingId='" + Int64.Parse(ViewState["GradeRoleMappingId"].ToString()) + "'").Count() == 1)
                    return true;
                return OnValidate();
            }
            return true;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion

   
}
