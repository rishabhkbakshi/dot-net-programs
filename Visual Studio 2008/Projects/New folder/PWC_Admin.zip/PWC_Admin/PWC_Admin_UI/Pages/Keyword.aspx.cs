﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_Keyword : BasePage
{
    #region--Initializers--
    clsKeywordMasterBD objclsKeywordMasterBD = new clsKeywordMasterBD();
    clsKeywordMasterBO objclsKeywordMasterBO = new clsKeywordMasterBO();
    DataTable objDataTable = new DataTable();
    public int KeywordId
    {
        get { return int.Parse(ViewState["KeywordId"].ToString()); }
        set { ViewState["KeywordId"] = value; }
    }
    #endregion
    #region--PageLoad--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region --Event Handlers--
    /// <summary>
    /// The event is use to save and update Keyword
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["KeywordId"] != null && ViewState["KeywordId"].ToString() != "0")
            {
                objclsKeywordMasterBD.CFlag = 'U';
                objclsKeywordMasterBD.KeywordId = KeywordId;
            }
            else
            {
                objclsKeywordMasterBD.CFlag = 'I';

            }
            objclsKeywordMasterBD.Alias = txtAlias.Text.Trim();
            objclsKeywordMasterBD.Keyword = txtKeyword.Text.Trim();
            objclsKeywordMasterBD.TransactionId = 0;
            objclsKeywordMasterBD.Status = "Active";
            clsManageTransaction.StartTransaction();
            if (objclsKeywordMasterBO.InsertUpdateKeywordMaster(objclsKeywordMasterBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                ClearFields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");

            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Bindgrid();
            if (ex.Message.Contains("duplicate key"))
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Data already exists.');</script>");
            }
            else
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }

    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        ClearFields();
    }
    /// <summary>
    /// The event is use to update and delete  Keyword
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvKeyword_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
            {
                KeywordId = int.Parse(e.CommandArgument.ToString());
            }
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsKeywordMasterBD.KeywordId = int.Parse(e.CommandArgument.ToString());
                objclsKeywordMasterBD.Status = "Inactive";
                clsManageTransaction.StartTransaction();
                if (objclsKeywordMasterBO.DelKeywordMaster(objclsKeywordMasterBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    ClearFields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    ClearFields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }

    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvKeyword_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        txtKeyword.Text = HttpUtility.HtmlDecode(gvKeyword.Rows[e.RowIndex].Cells[0].Text.Trim());
        //txtAlias.Text = HttpUtility.HtmlDecode(gvKeyword.Rows[e.RowIndex].Cells[1].Text.Trim());
        btnSave.Text = "Update";
    }
    protected void gvKeyword_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Bindgrid();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvKeyword_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvKeyword.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region --Private Methods--
    /// <summary>
    /// The following method is use to bind Keyword data to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objDataTable = objclsKeywordMasterBO.SelectKeywordMaster();
            //if (objDataTable != null && objDataTable.Rows.Count > 0)
            //{
            gvKeyword.DataSource = objDataTable;
            gvKeyword.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void ClearFields()
    {
        txtKeyword.Text = txtAlias.Text = string.Empty;
        KeywordId = 0;
        btnSave.Text = "Save";
    }
    #endregion

}
