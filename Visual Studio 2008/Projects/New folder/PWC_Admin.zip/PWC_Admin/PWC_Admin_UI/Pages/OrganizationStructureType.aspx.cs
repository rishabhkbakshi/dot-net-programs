﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;


public partial class Pages_OrganizationStructureType : BasePage
{
    #region --Initializers--
    clsOrganizationStructureTypeBO objclsOrganizationStructureTypeBO = new clsOrganizationStructureTypeBO();
    clsOrganizationStructureTypeBD objclsOrganizationStructureTypeBD = new clsOrganizationStructureTypeBD();
    DataTable objDataTable = new DataTable();
    #endregion
    #region --Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
                Bindgrid();
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region --Event Handlers--
    /// <summary>
    /// The event is use to save and update OrganizationStructureType
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["OrganisationStructureTypeId"] != null && ViewState["OrganisationStructureTypeId"].ToString() != "0")
            {
                objclsOrganizationStructureTypeBD.CFlag = EFlag.UPDATE.ToString();
                objclsOrganizationStructureTypeBD.OrganisationStructureTypeId = Int64.Parse(ViewState["OrganisationStructureTypeId"].ToString());
            }
            else
            {
                objclsOrganizationStructureTypeBD.CFlag = EFlag.INSERT.ToString();
                objclsOrganizationStructureTypeBD.OrganisationStructureTypeId = 0;
            }
            objclsOrganizationStructureTypeBD.Alias = txtAlias.Text.Trim();
            objclsOrganizationStructureTypeBD.Level = txtLevel.Text.Trim();
            objclsOrganizationStructureTypeBD.Name = txtName.Text.Trim();
            objclsOrganizationStructureTypeBD.DOC = DateTime.Now;
            objclsOrganizationStructureTypeBD.DOU = DateTime.Now;
            objclsOrganizationStructureTypeBD.Status = "Active";
            objclsOrganizationStructureTypeBD.TransactionId = 1;
            clsManageTransaction.StartTransaction();
            if (objclsOrganizationStructureTypeBO.InsertUpdateOrganizationStructureType(objclsOrganizationStructureTypeBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrgStructure_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        //txtAlias.Text = HttpUtility.HtmlDecode(gvOrgStructure.Rows[e.RowIndex].Cells[1].Text);
        txtName.Text = HttpUtility.HtmlDecode(gvOrgStructure.Rows[e.RowIndex].Cells[0].Text);
        //chkIsMultiple.Checked = gvOrgStructure.Rows[e.RowIndex].Cells[2].Text.ToUpper() == "TRUE" ? true : false;
        txtLevel.Text = gvOrgStructure.Rows[e.RowIndex].Cells[1].Text == "&nbsp;" ? string.Empty : gvOrgStructure.Rows[e.RowIndex].Cells[1].Text;
        btnSave.Text = "Update";
    }
    /// <summary>
    /// The event is use to update and delete OrganizationStructureType 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrgStructure_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["OrganisationStructureTypeId"] = Int64.Parse(e.CommandArgument.ToString());
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                objclsOrganizationStructureTypeBD.OrganisationStructureTypeId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (objclsOrganizationStructureTypeBO.DeleteOrganizationStructureType(objclsOrganizationStructureTypeBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvOrgStructure_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvOrgStructure_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvOrgStructure.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region --Private method--
    /// <summary>
    /// The following method is use to bind OrganizationStructureType to grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            objclsOrganizationStructureTypeBD.CFlag = EFlag.ALL.ToString();
            objclsOrganizationStructureTypeBD.OrganisationStructureTypeId = 0;
            objDataTable = objclsOrganizationStructureTypeBO.SelectOrganizationStructureType(objclsOrganizationStructureTypeBD);
            gvOrgStructure.DataSource = objDataTable;
            gvOrgStructure.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtLevel.Text = txtName.Text = txtAlias.Text = string.Empty;
        ViewState["OrganisationStructureTypeId"] = 0;
        btnSave.Text = "Save";
    }
    #endregion

}
