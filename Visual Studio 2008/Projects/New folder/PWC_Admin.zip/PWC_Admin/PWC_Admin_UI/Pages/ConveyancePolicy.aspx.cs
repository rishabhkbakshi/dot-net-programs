﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_ConveyancePolicy : BasePage
{
    #region --Initializers--
    clsTravelPolicyBO objclsTravelPolicyBO = new clsTravelPolicyBO();
    clsConveyancePolicyBO objclsConveyancePolicyBO = new clsConveyancePolicyBO();
    clsConveyancePolicyBD objclsConveyancePolicyBD = new clsConveyancePolicyBD();
    clsPolicyGradeMappingBD oclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
    clsPolicyGradeMappingBO oclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindGrade();
            BindVehicleName();
            BindConveyancePolicyData();
            BindClass();
            BindAfterOutTime();
        }
        DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
        txtEffectiveToDate.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind Vehicle dropdown
    /// </summary>
    private void BindVehicleName()
    {
        try
        {
            DataTable dtGrade = objclsConveyancePolicyBO.SelectVehicleType(0);
            if (dtGrade != null && dtGrade.Rows.Count > 0)
            {
                ddlVehicleName.DataSource = dtGrade;
                ddlVehicleName.DataValueField = "VehicleTypesId";
                ddlVehicleName.DataTextField = "Alias";
                ddlVehicleName.DataBind();
                ddlVehicleName.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlVehicleName.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Class
    /// </summary>
    private void BindClass()
    {
        try
        {
            DataTable dtClass = clsUtility.GetMasterValue("BusClass");
            if (dtClass != null && dtClass.Rows.Count > 0)
            {
                ddlDefaultClass.DataSource = dtClass;
                ddlDefaultClass.DataValueField = "MasterId";
                ddlDefaultClass.DataTextField = "Value";
                ddlDefaultClass.DataBind();
                ddlDefaultClass.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlAlternateClass.DataSource = dtClass;
                ddlAlternateClass.DataValueField = "MasterId";
                ddlAlternateClass.DataTextField = "Value";
                ddlAlternateClass.DataBind();
                ddlAlternateClass.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlDefaultClass.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlAlternateClass.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind BindAfterOutTime
    /// </summary>
    private void BindAfterOutTime()
    {
        try
        {
            ddlAfterOutTime.Items.Insert(0, new ListItem("--Select--", "0"));
            for (int i = 1; i <= 24; i++)
            {
                ddlAfterOutTime.Items.Insert(i, new ListItem(i.ToString(), i.ToString()));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtAlias.Text = txtEffectiveToDate.Text = txtEffectiveFROMDate.Text = string.Empty;
        //ddlGradeName.SelectedIndex = 0;
        ddlVehicleName.SelectedIndex = 0;
        ddlGender.SelectedIndex = 0;
        ddlAfterOutTime.SelectedIndex = 0;
        ddlDefaultMode.SelectedIndex = 0;
        ddlAlternateMode.SelectedIndex = 0;
        ddlDefaultClass.SelectedIndex = 0;
        ddlAlternateClass.SelectedIndex = 0;
        chkIsBehalfOfBooking.Checked = false;
        chkIsEnforcePriority.Checked = false;
        btnSave.Text = "Save";
    }
    /// <summary>
    /// The following method is use to bind ConveyancePolicyData to grid
    /// </summary>
    private void BindConveyancePolicyData()
    {
        try
        {
            DataTable dtConveyancePolicy = objclsConveyancePolicyBO.SelectConveyancePolicyData(0);
            gvConveyancePolicy.DataSource = dtConveyancePolicy;
            gvConveyancePolicy.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to save and update
    /// </summary>
    private void SaveAccomodationPolicy()
    {
        try
        {
            int result = DateTime.Compare(Convert.ToDateTime(txtEffectiveFROMDate.Text.Trim()), Convert.ToDateTime(txtEffectiveToDate.Text.Trim()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }
            if (ViewState["CONVEYANCEPOLICYID"] != null && ViewState["CONVEYANCEPOLICYID"].ToString() != "0")
            {
                objclsConveyancePolicyBD.CFlag = EFlag.UPDATE.ToString();
                objclsConveyancePolicyBD.ConveyancePolicyId = Int64.Parse(ViewState["CONVEYANCEPOLICYID"].ToString());
            }
            else
            {
                objclsConveyancePolicyBD.CFlag = EFlag.INSERT.ToString();
                objclsConveyancePolicyBD.ConveyancePolicyId = 0;
            }
            objclsConveyancePolicyBD.Gender = ddlGender.SelectedItem.Text;
            objclsConveyancePolicyBD.VehicleTypeId = Int64.Parse(ddlVehicleName.SelectedValue);
            objclsConveyancePolicyBD.EffectiveFROMDate = DateTime.Parse(txtEffectiveFROMDate.Text.Trim());
            objclsConveyancePolicyBD.EffectiveToDate = DateTime.Parse(txtEffectiveToDate.Text.Trim());
            objclsConveyancePolicyBD.IsEnforcePriority = chkIsEnforcePriority.Checked;
            objclsConveyancePolicyBD.IsBehalfOfBooking = chkIsBehalfOfBooking.Checked;
            objclsConveyancePolicyBD.Alias = txtAlias.Text.Trim();
            objclsConveyancePolicyBD.Status = "Active";
            objclsConveyancePolicyBD.DOC = DateTime.Now;
            objclsConveyancePolicyBD.DOU = DateTime.Now;
            objclsConveyancePolicyBD.TransactionId = 0;
            objclsConveyancePolicyBD.AfterOutTime = Int32.Parse(ddlAfterOutTime.SelectedValue.ToString());
            objclsConveyancePolicyBD.DefaultMode = ddlDefaultMode.SelectedValue.ToString();
            objclsConveyancePolicyBD.AlternateMode = ddlAlternateMode.SelectedValue.ToString();
            objclsConveyancePolicyBD.DefaultClass = Int64.Parse(ddlDefaultClass.SelectedValue.ToString());
            objclsConveyancePolicyBD.AlternateClass = Int64.Parse(ddlAlternateClass.SelectedValue.ToString());
            clsManageTransaction.StartTransaction();
            int refPolicyId = objclsConveyancePolicyBO.InsertUpdateConveyancePolicy(objclsConveyancePolicyBD);
            if (refPolicyId > 0)
            {
                if (InsertUpdatePolicyGradeMapping(refPolicyId) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            Clearfields();
            BindConveyancePolicyData();

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// BindGrade: This method is to bind the Grades Availables with ListBox
    /// </summary>
    private void BindGrade()
    {
        try
        {
            clsTravelPolicyBO objclsTravelPolicyBO = new clsTravelPolicyBO();
            DataTable dtGrade = objclsTravelPolicyBO.SelectGradeMaster(0);
            lbAvailableGrades.DataSource = dtGrade;
            lbAvailableGrades.DataValueField = "GradeId";
            lbAvailableGrades.DataTextField = "GradeName";
            lbAvailableGrades.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// InsertUpdatePolicyGradeMapping: This method is to be used for Insert or Update the Policy Grade Mapping
    /// </summary>
    /// <param name="ReferencePolicyId">int</param>
    /// <returns>int</returns>
    private int InsertUpdatePolicyGradeMapping(int ReferencePolicyId)
    {
        int res = 0;
        try
        {
            clsPolicyGradeMappingBD objclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
            clsPolicyGradeMappingBO objclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
            objclsPolicyGradeMappingBD.CFlag = "INSERT";
            objclsPolicyGradeMappingBD.PolicyGradeMappingId = 0;
            objclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
            objclsPolicyGradeMappingBD.ReferencePolicyType = "Conveyance Policy";
            objclsPolicyGradeMappingBD.Alias = "";
            objclsPolicyGradeMappingBD.DOC = DateTime.Now;
            objclsPolicyGradeMappingBD.DOU = DateTime.Now;
            objclsPolicyGradeMappingBD.Status = "Active";
            for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
            {
                objclsPolicyGradeMappingBD.GradeId = Convert.ToInt64(lbSelectedGrades.Items[i].Value);
                res = objclsPolicyGradeMappingBO.InsertUpdatePolicyGradeMapping(objclsPolicyGradeMappingBD);
            }
        }
        catch (Exception ex)
        {
            res = -1;
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
        return res;
    }
    /// <summary>
    /// The following method is use to bind Bind Destination Grade
    /// </summary>
    private void BindDestinationGrade(Int64 ReferencePolicyId)
    {
        oclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
        oclsPolicyGradeMappingBD.CFlag = "CONVEYANCEPOLICY";
        DataTable dtList = oclsPolicyGradeMappingBO.SelectPolicyGradeMapping(oclsPolicyGradeMappingBD);
        if (dtList.Rows.Count > 0)
        {
            lbSelectedGrades.DataSource = dtList;
            lbSelectedGrades.DataTextField = "GradeName";
            lbSelectedGrades.DataValueField = "GradeId";
            lbSelectedGrades.DataBind();
            for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
            if (lbSelectedGrades.Items.Count > 0)
            {
                lbSelectedGrades.SelectedIndex = 0;
            }
        }
        else
        {
            lbSelectedGrades.Items.Clear();
            BindGrade();
        }

    }
    #endregion
    #region--Event Handlers--
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path,false);
    }
    /// <summary>
    /// The event is use to save and update
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveAccomodationPolicy();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvConveyancePolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 ConveyancePolicyId = Int64.Parse(gvConveyancePolicy.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["CONVEYANCEPOLICYID"] = ConveyancePolicyId;
            DataTable dtConveyancePolicyDetails = objclsConveyancePolicyBO.SelectConveyancePolicyData(ConveyancePolicyId);
            if (dtConveyancePolicyDetails != null && dtConveyancePolicyDetails.Rows.Count > 0)
            {

                //ddlGradeName.SelectedValue = dtConveyancePolicyDetails.Rows[0]["GradeId"].ToString();
                //ddlVehicleName.SelectedValue = 
                string ParentId = dtConveyancePolicyDetails.Rows[0]["VehicleTypeId"].ToString(); ;
                ListItem ParentItem = ddlVehicleName.Items.FindByValue(ParentId) as ListItem;
                if (ParentItem != null)
                {
                    ddlVehicleName.ClearSelection();
                    ParentItem.Selected = true;
                }

                ddlGender.SelectedValue = dtConveyancePolicyDetails.Rows[0]["Gender"].ToString();
                txtEffectiveFROMDate.Text = Convert.ToDateTime(dtConveyancePolicyDetails.Rows[0]["EffectiveFROMDate"]).ToString("dd/MM/yyyy");
                txtEffectiveToDate.Text = Convert.ToDateTime(dtConveyancePolicyDetails.Rows[0]["EffectiveToDate"]).ToString("dd/MM/yyyy");
                //txtAlias.Text = dtConveyancePolicyDetails.Rows[0]["Alias"].ToString();
                if (dtConveyancePolicyDetails.Rows[0]["IsEnforcePriority"].ToString() == "True")
                {
                    chkIsEnforcePriority.Checked = true;
                }
                else
                {
                    chkIsEnforcePriority.Checked = false;
                }
                if (dtConveyancePolicyDetails.Rows[0]["IsBehalfOfBooking"].ToString() == "True")
                {
                    chkIsBehalfOfBooking.Checked = true;
                }
                else
                {
                    chkIsBehalfOfBooking.Checked = false;
                }
                ddlAfterOutTime.SelectedIndex = ddlAfterOutTime.Items.IndexOf(ddlAfterOutTime.Items.FindByText(dtConveyancePolicyDetails.Rows[0]["AfterOutTime"].ToString()));
                ddlDefaultMode.SelectedIndex = ddlDefaultMode.Items.IndexOf(ddlDefaultMode.Items.FindByText(dtConveyancePolicyDetails.Rows[0]["DefaultMode"].ToString()));
                ddlAlternateMode.SelectedIndex = ddlAlternateMode.Items.IndexOf(ddlAlternateMode.Items.FindByText(dtConveyancePolicyDetails.Rows[0]["AlternateMode"].ToString()));
                ddlDefaultClass.SelectedValue = ddlDefaultClass.Items.FindByValue(dtConveyancePolicyDetails.Rows[0]["DefaultClass"].ToString()) != null ? dtConveyancePolicyDetails.Rows[0]["DefaultClass"].ToString() : "0";
                ddlAlternateClass.SelectedValue = ddlAlternateClass.Items.FindByValue(dtConveyancePolicyDetails.Rows[0]["AlternateClass"].ToString()) != null ? dtConveyancePolicyDetails.Rows[0]["AlternateClass"].ToString() : "0";
                btnSave.Text = "Update";
                BindDestinationGrade(ConveyancePolicyId);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to delete(make inactive) ConveyancePolicy
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvConveyancePolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        try
        {
            Int64 ConveyancePolicy = Int64.Parse(gvConveyancePolicy.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();

            if (objclsConveyancePolicyBO.DeleteConveyancePolicy(ConveyancePolicy))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");

        }
        BindConveyancePolicyData();


    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvConveyancePolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvConveyancePolicy.PageIndex = e.NewPageIndex;
            BindConveyancePolicyData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    /// <summary>
    /// The event is use to move the available Grades List  back to availableGrade ListBox
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        try
        {
            if (lbSelectedGrades.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Allocated Grade Lists');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
            {
                if (lbSelectedGrades.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Assigned Grades');</script>");
                    return;
                }

                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    if (lbSelectedGrades.Items[i].Selected)
                    {
                        lbAvailableGrades.Items.Add(lbSelectedGrades.Items[i]);
                    }
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Remove(lbAvailableGrades.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Add(lbSelectedGrades.Items[i]);
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Remove(lbAvailableGrades.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    /// <summary>
    /// btnRight_Click: This event is to move the available grades to Allocated Grades ListBox
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void btnAllRight_Click(object sender, EventArgs e)
    {
        try
        {
            if (lbAvailableGrades.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Available Grade Lists');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
            {
                if (lbAvailableGrades.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Available Grades');</script>");
                    return;
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    if (lbAvailableGrades.Items[i].Selected)
                    {
                        lbSelectedGrades.Items.Add(lbAvailableGrades.Items[i]);
                    }
                }
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Add(lbAvailableGrades.Items[i]);
                }
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
}
