﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_Authorizations : BasePage
{
    #region --Initializers--
    clsRoleMasterBO objclsRoleMasterBO = new clsRoleMasterBO();
    clsRoleMasterBD objclsRoleMasterBD = new clsRoleMasterBD();
    clsAuthorizationsBO objclsAuthorizationsBO = new clsAuthorizationsBO();
    clsAuthorizationsBD objclsAuthorizationsBD = new clsAuthorizationsBD();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindRole();    
        }
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind Role dropdown
    /// </summary>
    private void BindRole()
    {
        try
        {
            objclsRoleMasterBD.CFlag = EFlag.ALL.ToString();
            objclsRoleMasterBD.RoleId = 0;
            DataTable dtRole = objclsRoleMasterBO.SelectRoleMaster(objclsRoleMasterBD);
            if (dtRole != null && dtRole.Rows.Count > 0)
            {
                ddlRole.DataSource = dtRole;
                ddlRole.DataValueField = "RoleId";
                ddlRole.DataTextField = "Name";
                ddlRole.DataBind();
                ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlRole.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void Clearfields()
    {
       
        ddlRole.SelectedIndex = 0;        
        btnSave.Text = "Save";
        gvAuthorizations.DataSource = null;
        gvAuthorizations.DataBind();
        ViewState["EFLAG"] = null;

       
    }
    /// <summary>
    /// The following method is use to  save and update
    /// </summary>
    private void SaveAuthorizations()
    {
        try
        {
            clsManageTransaction.StartTransaction();
            foreach (GridViewRow drow in gvAuthorizations.Rows)
            {
                objclsAuthorizationsBD.RoleId = Int64.Parse(ddlRole.SelectedValue.ToString());
                Label lblAuthorizationId = (Label)drow.FindControl("lblAuthorizationId");
                objclsAuthorizationsBD.AuthorizationId = Int64.Parse(lblAuthorizationId.Text);
                Label lblProcessId = (Label)drow.FindControl("lblProcessId");
                objclsAuthorizationsBD.ProcessId = Int64.Parse(lblProcessId.Text);
                if (ViewState["EFLAG"] != null)
                {
                    if (lblAuthorizationId.Text == "0")
                    {
                        objclsAuthorizationsBD.CFlag = EFlag.INSERT.ToString();   
                    }
                    else
                    {
                        objclsAuthorizationsBD.CFlag = EFlag.UPDATE.ToString();
                    }                  
                }
                else
                {
                    objclsAuthorizationsBD.CFlag = EFlag.INSERT.ToString();                    
                }
                CheckBox chkAdd = (CheckBox)drow.FindControl("chkAdd");
                if (chkAdd != null && chkAdd.Checked)
                {
                    objclsAuthorizationsBD.IsAdd = true;
                }
                else
                {
                    objclsAuthorizationsBD.IsAdd = false;
                }
                CheckBox chkModify = (CheckBox)drow.FindControl("chkModify");
                if (chkModify != null && chkModify.Checked)
                {
                    objclsAuthorizationsBD.IsModify = true;
                }
                else
                {
                    objclsAuthorizationsBD.IsModify = false;
                }
                CheckBox chkDelete = (CheckBox)drow.FindControl("chkDelete");
                if (chkDelete != null && chkDelete.Checked)
                {
                    objclsAuthorizationsBD.IsDelete = true;
                }
                else
                {
                    objclsAuthorizationsBD.IsDelete = false;
                }
                CheckBox chkView = (CheckBox)drow.FindControl("chkView");
                if (chkView != null && chkView.Checked)
                {
                    objclsAuthorizationsBD.IsView = true;
                }
                else
                {
                    objclsAuthorizationsBD.IsView = false;
                }
                TextBox txtAlias = (TextBox)drow.FindControl("txtAlias");
                objclsAuthorizationsBD.Alias = txtAlias.Text.Trim();
                objclsAuthorizationsBD.Status = "Active";
                objclsAuthorizationsBD.DOC = DateTime.Now;
                objclsAuthorizationsBD.DOU = DateTime.Now;
                objclsAuthorizationsBD.TransactionId = 0;                
                objclsAuthorizationsBO.InsertUpdateAuthorizations(objclsAuthorizationsBD);
            }
            clsManageTransaction.EndTransaction();
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            Clearfields();
            ViewState["EFLAG"] = null;
          }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    #endregion
    #region--Event Handlers--    
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlRole_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlRole.SelectedIndex > 0)
        {
            DataTable dtAuthorizations = objclsAuthorizationsBO.SelectAuthorizationsData(Int64.Parse(ddlRole.SelectedValue));
            if (dtAuthorizations != null && dtAuthorizations.Rows.Count > 0)
            {
                gvAuthorizations.DataSource = dtAuthorizations;
                gvAuthorizations.DataBind();
                int count = 0;
                foreach (GridViewRow drow in gvAuthorizations.Rows)
                {
                    CheckBox chkAdd = (CheckBox)drow.FindControl("chkAdd");
                    if (dtAuthorizations.Rows[count]["IsAdd"].ToString() == "True")
                    {
                        chkAdd.Checked = true;
                    }
                    else
                    {
                        chkAdd.Checked = false;
                    }                    
                    CheckBox chkModify = (CheckBox)drow.FindControl("chkModify");
                    if (dtAuthorizations.Rows[count]["IsModify"].ToString() == "True")
                    {
                        chkModify.Checked = true;
                    }
                    else
                    {
                        chkModify.Checked = false;
                    }
                    CheckBox chkDelete = (CheckBox)drow.FindControl("chkDelete");
                    if (dtAuthorizations.Rows[count]["IsDelete"].ToString() == "True")
                    {
                        chkDelete.Checked = true;
                    }
                    else
                    {
                        chkDelete.Checked = false;
                    }
                    CheckBox chkView = (CheckBox)drow.FindControl("chkView");
                    if (dtAuthorizations.Rows[count]["IsView"].ToString() == "True")
                    {
                        chkView.Checked = true;
                    }
                    else
                    {
                        chkView.Checked = false;
                    }
                    TextBox txtAlias = (TextBox)drow.FindControl("txtAlias");
                    txtAlias.Text = dtAuthorizations.Rows[count]["Alias"].ToString();
                    count++;
                }                
                btnSave.Text = "Update";
                ViewState["EFLAG"] = "Update";
            }
            else
            {
                DataTable dtAllProcess = objclsAuthorizationsBO.SelectProcessAll();
                if (dtAllProcess != null && dtAllProcess.Rows.Count > 0)
                {
                    gvAuthorizations.DataSource = dtAllProcess;
                    gvAuthorizations.DataBind();
                    btnSave.Text = "Save";
                }
            }
        }             
    }  
    /// <summary>
    /// The event is use to save and update
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SaveAuthorizations();
        Session["Modules"] = null;
    }    
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// To check all checkbox of Authorizations
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ckbAddAll_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (((CheckBox)gvAuthorizations.HeaderRow.FindControl("ckbAddAll")).Checked == true)
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkAdd")).Checked = true;
                }
            }
            else
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkAdd")).Checked = false;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void chkModifyAll_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (((CheckBox)gvAuthorizations.HeaderRow.FindControl("chkModifyAll")).Checked == true)
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkModify")).Checked = true;
                }
            }
            else
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkModify")).Checked = false;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void chkDeleteAll_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (((CheckBox)gvAuthorizations.HeaderRow.FindControl("chkDeleteAll")).Checked == true)
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkDelete")).Checked = true;
                }
            }
            else
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkDelete")).Checked = false;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void chkViewAll_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            if (((CheckBox)gvAuthorizations.HeaderRow.FindControl("chkViewAll")).Checked == true)
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkView")).Checked = true;
                }
            }
            else
            {
                for (int count = 0; count < gvAuthorizations.Rows.Count; count++)
                {
                    ((CheckBox)gvAuthorizations.Rows[count].Cells[2].FindControl("chkView")).Checked = false;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}
