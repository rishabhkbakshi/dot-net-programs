﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AjaxControlToolkit;
using Admin.BD;
using Admin.BO;
using System.Data;
public partial class Pages_ApprovalMatrix : BasePage
{
    #region "PAGE EVENTS"

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindApprovalMatrix();
            BindProcess();
            BindUnit(EFlag.UNIT.ToString(), ddlUnit);
            BindUnit(EFlag.UNIT.ToString(), ddlEscalationUnit);
            BindCurrency(EFlag.CURRENCY.ToString());
            BindRoles(ddlRole);
            ViewState.Clear();
            ViewState["APPROVALMASTERID"] = 0;
            ShowMessage(string.Empty);
            btnSave.Text = "Save";
        }
        DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
        txtToDate.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            SaveApprovalMatrix();
            string Flag = EFlag.INSERT.ToString();
            if (Convert.ToInt64(ViewState["APPROVALMASTERID"]) > 0)
            {
                Flag = EFlag.UPDATE.ToString();
            }
            Response.Redirect(Request.Path + "?MSG=" + Flag, false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            throw ex;
        }
    }
    protected void btnAddApprover_Click(object sender, EventArgs e)
    {
        try
        {
            List<clsApprovalDetailsBD> ApprovalDetailsList = new List<clsApprovalDetailsBD>();
            ApprovalDetailsList = AddApproverList(ApprovalDetailsList);
            dlApprovalList.DataSource = ApprovalDetailsList;
            dlApprovalList.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void chkIsEscalated_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            pnlEscalation.Visible = chkIsEscalated.Checked;
            if (chkIsEscalated.Checked)
            {
                rfvEscalationAlertDuration.ValidationGroup = "ApprovalMatrix";
                rfvUnit.ValidationGroup = "ApprovalMatrix";
            }
            else
            {
                rfvEscalationAlertDuration.ValidationGroup = "ApprovalMatrix_Temp";
                rfvUnit.ValidationGroup = "ApprovalMatrix_Temp";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void dlApprovalList_ItemCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), "ESCALATION") == 0)
            {
                GridView gvApprovalList_Escalation = e.Item.FindControl("gvApprovalList_Escalation") as GridView;
                DropDownList ddlRoleEscalation = e.Item.FindControl("ddlRoleEscalation") as DropDownList;
                TextBox txtSequenceEscalation = e.Item.FindControl("txtSequenceEscalation") as TextBox;

                if (gvApprovalList_Escalation != null && ddlRoleEscalation != null && txtSequenceEscalation != null)
                {
                    List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = new List<clsApprovalEscalationDetailsBD>();
                    Int64 RoleId = Convert.ToInt64(ddlRoleEscalation.SelectedValue);
                    string RoleName = ddlRoleEscalation.SelectedItem.Text;
                    short Sequence = Convert.ToInt16(txtSequenceEscalation.Text.Trim());
                    gvApprovalList_Escalation.DataSource = AddApprovalEscalationDetailsList(ApprovalEscalationDetailsList, RoleId, RoleName, Sequence, e.Item.ItemIndex);
                    gvApprovalList_Escalation.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void dlApprovalList_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                string ViewStateKeyForApprovalDetailId = "APPROVALDETAILID" + Convert.ToString(e.Item.ItemIndex);
                ViewState[ViewStateKeyForApprovalDetailId] = dlApprovalList.DataKeys[e.Item.ItemIndex];
                DropDownList ddlRoleEscalation = e.Item.FindControl("ddlRoleEscalation") as DropDownList;
                CheckBox chkIsEscalate_Display = e.Item.FindControl("chkIsEscalate_Display") as CheckBox;
                if (ddlRoleEscalation != null)
                {
                    BindRoles(ddlRoleEscalation);
                }
                RequiredFieldValidator rfvRoleEscalation = e.Item.FindControl("rfvRoleEscalation") as RequiredFieldValidator;
                RequiredFieldValidator rfvSequenceEscalation = e.Item.FindControl("rfvSequenceEscalation") as RequiredFieldValidator;
                Button btnAddApproverForEscalation = e.Item.FindControl("btnAddApproverForEscalation") as Button;
                if (rfvRoleEscalation != null && rfvSequenceEscalation != null && btnAddApproverForEscalation != null)
                {
                    rfvRoleEscalation.ValidationGroup = "EscalationApprovalDetail" + Convert.ToString(e.Item.ItemIndex);
                    rfvSequenceEscalation.ValidationGroup = "EscalationApprovalDetail" + Convert.ToString(e.Item.ItemIndex);
                    btnAddApproverForEscalation.ValidationGroup = "EscalationApprovalDetail" + Convert.ToString(e.Item.ItemIndex);
                }
                string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(e.Item.ItemIndex);
                if (ViewState[ViewStateKey] != null)
                {
                    List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = (List<clsApprovalEscalationDetailsBD>)ViewState[ViewStateKey];
                    GridView gvApprovalList_Escalation = e.Item.FindControl("gvApprovalList_Escalation") as GridView;
                    if (gvApprovalList_Escalation != null)
                    {
                        gvApprovalList_Escalation.DataSource = ApprovalEscalationDetailsList;
                        gvApprovalList_Escalation.DataBind();
                    }
                }

                //Reinitialising control after click the update from gvApprovalMatrix gridview
                if (ViewState["APPROVALDETAILSLIST"] != null)
                {
                    List<clsApprovalDetailsBD> ApprovalDetailsList = new List<clsApprovalDetailsBD>();
                    ApprovalDetailsList = ViewState["APPROVALDETAILSLIST"] as List<clsApprovalDetailsBD>;
                    clsApprovalDetailsBD oApprovalDetailsBD = new clsApprovalDetailsBD();
                    oApprovalDetailsBD = ApprovalDetailsList[e.Item.ItemIndex];
                    if (chkIsEscalate_Display != null)
                    {
                        chkIsEscalate_Display.Checked = oApprovalDetailsBD.IsEscalated;
                        CollapsiblePanelExtender cpeAddApproverEscalation = e.Item.FindControl("cpeAddApproverEscalation") as CollapsiblePanelExtender;
                        if (cpeAddApproverEscalation != null)
                        {
                            if (chkIsEscalate_Display.Checked)
                            {
                                cpeAddApproverEscalation.Collapsed = false;
                                cpeAddApproverEscalation.ClientState = "false";
                            }
                            else
                            {
                                cpeAddApproverEscalation.Collapsed = true;
                                cpeAddApproverEscalation.ClientState = "true";
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void dlApprovalList_DeleteCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (ViewState["APPROVALDETAILSLIST"] != null)
            {
                List<clsApprovalDetailsBD> ApprovalDetailsList = (List<clsApprovalDetailsBD>)ViewState["APPROVALDETAILSLIST"];
                ApprovalDetailsList.RemoveAt(e.Item.ItemIndex);
                ViewState["APPROVALDETAILSLIST"] = ApprovalDetailsList;
                dlApprovalList.DataSource = ApprovalDetailsList;
                dlApprovalList.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void dlApprovalList_UpdateCommand(object source, DataListCommandEventArgs e)
    {
        try
        {
            if (ViewState["APPROVALDETAILSLIST"] != null)
            {
                List<clsApprovalDetailsBD> ApprovalDetailsList = (List<clsApprovalDetailsBD>)ViewState["APPROVALDETAILSLIST"];
                clsApprovalDetailsBD oApprovalDetailsBD = ApprovalDetailsList[e.Item.ItemIndex];
                ListItem RoleItem = ddlRole.Items.FindByValue(Convert.ToString(oApprovalDetailsBD.RoleId)) as ListItem;
                if (RoleItem != null)
                {
                    ddlRole.ClearSelection();
                    RoleItem.Selected = true;
                }
                txtSequence.Text = Convert.ToString(oApprovalDetailsBD.Sequence);
                divEscalationForApprover.Visible = chkIsEscalate.Checked = oApprovalDetailsBD.IsEscalated;
                if (chkIsEscalate.Checked)
                {
                    txtEscalationDuration.Text = Convert.ToString(oApprovalDetailsBD.Unit);
                    ListItem EscalationUnitItem = ddlEscalationUnit.Items.FindByValue(Convert.ToString(oApprovalDetailsBD.Unit)) as ListItem;
                    if (EscalationUnitItem != null)
                    {
                        ddlEscalationUnit.ClearSelection();
                        EscalationUnitItem.Selected = true;
                    }
                }
                ViewState["AD_ITEMINDEX"] = e.Item.ItemIndex;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvApprovalList_Escalation_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            GridView gvApprovalList_Escalation = (GridView)sender;
            DataListItem dataListItem = (gvApprovalList_Escalation.NamingContainer) as DataListItem;
            TextBox txtSequenceEscalation = dataListItem.FindControl("txtSequenceEscalation") as TextBox;
            DropDownList ddlRoleEscalation = dataListItem.FindControl("ddlRoleEscalation") as DropDownList;
            string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(dataListItem.ItemIndex);
            if (ViewState[ViewStateKey] != null)
            {
                List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = (List<clsApprovalEscalationDetailsBD>)ViewState[ViewStateKey];
                if (txtSequenceEscalation != null && ddlRoleEscalation != null)
                {
                    txtSequenceEscalation.Text = Convert.ToString(ApprovalEscalationDetailsList[e.RowIndex].Sequence);
                    ListItem RoleEscalationItem = new ListItem();
                    RoleEscalationItem = ddlRoleEscalation.Items.FindByValue(Convert.ToString(ApprovalEscalationDetailsList[e.RowIndex].RoleId));
                    if (RoleEscalationItem != null)
                    {
                        ddlRoleEscalation.ClearSelection();
                        RoleEscalationItem.Selected = true;
                    }
                    ViewState["ESC_ROWINDEX"] = e.RowIndex;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvApprovalList_Escalation_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            GridView gvApprovalList_Escalation = (GridView)sender;
            DataListItem dataListItem = (gvApprovalList_Escalation.NamingContainer) as DataListItem;
            string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(dataListItem.ItemIndex);
            if (ViewState[ViewStateKey] != null)
            {
                List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = (List<clsApprovalEscalationDetailsBD>)ViewState[ViewStateKey];
                ApprovalEscalationDetailsList.RemoveAt(e.RowIndex);
                ViewState[ViewStateKey] = ApprovalEscalationDetailsList;
                if (gvApprovalList_Escalation != null)
                {
                    gvApprovalList_Escalation.DataSource = ApprovalEscalationDetailsList;
                    gvApprovalList_Escalation.DataBind();
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvApprovalList_Escalation_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                GridView gvApprovalList = (GridView)sender;
                string EscalationKey = "APPROVALESCALATIONDETAILID" + Convert.ToString(e.Row.RowIndex);
                ViewState[EscalationKey] = gvApprovalList.DataKeys[e.Row.RowIndex].Value;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvApprovalMatrix_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            List<clsApprovalDetailsBD> ApprovalDetailsList = new List<clsApprovalDetailsBD>();
            clsApprovalMasterBO oApprovalMasterBO = new clsApprovalMasterBO();
            clsApprovalMasterBD oApprovalMasterBD = new clsApprovalMasterBD();
            oApprovalMasterBD.Flag = "AMID";
            ViewState["APPROVALMASTERID"] = Convert.ToInt64(gvApprovalMatrix.DataKeys[e.RowIndex].Value);
            oApprovalMasterBD.ApprovalMasterId = Convert.ToInt64(gvApprovalMatrix.DataKeys[e.RowIndex].Value);
            DataSet dsApprovalMaster = oApprovalMasterBO.Select(oApprovalMasterBD);
            ApprovalDetailsList = ReInitialiseApprovalDetails(dsApprovalMaster, ApprovalDetailsList);
            ViewState["APPROVALDETAILSLIST"] = ApprovalDetailsList;
            dlApprovalList.DataSource = ApprovalDetailsList;
            dlApprovalList.DataBind();
            cpeAddApprover.Collapsed = false;
            cpeAddApprover.ClientState = "false";

            //Fill the Approval Master Details
            FillApprovalMasterDetails(dsApprovalMaster);
            //Reseting the Approvaldetails
            ddlRole.SelectedIndex = -1;
            chkIsEscalate.Checked = false;
            divEscalationForApprover.Visible = false;
            txtSequence.Text = string.Empty;
            btnSave.Text = "Update";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void chkIsEscalate_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            divEscalationForApprover.Visible = chkIsEscalate.Checked;
            rfvEscalationUnit.ValidationGroup = chkIsEscalate.Checked ? "ApprovalDetail" : "ApprovalDetail0";
            rfvEscalationDuration.ValidationGroup = chkIsEscalate.Checked ? "ApprovalDetail" : "ApprovalDetail0";
            txtEscalationDuration.Text = string.Empty;
            ddlEscalationUnit.SelectedIndex = -1;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvApprovalMatrix_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            clsApprovalMasterBO oApprovalMasterBO = new clsApprovalMasterBO();
            Int64 ApprovalMasterId = Convert.ToInt64(gvApprovalMatrix.DataKeys[e.RowIndex].Value);
            clsManageTransaction.StartTransaction();
            oApprovalMasterBO.Delete(ApprovalMasterId);
            clsManageTransaction.EndTransaction();
            Response.Redirect(Request.Path + "?MSG=" + EFlag.DELETE.ToString(), false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            throw ex;
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect(Request.Path);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion

    #region "CUSTOM METHODS"

    private void SaveApprovalMatrix()
    {
        try
        {
            System.Globalization.DateTimeFormatInfo gDateFormat = new System.Globalization.DateTimeFormatInfo();
            gDateFormat.ShortDatePattern = "dd/MM/yyyy";
            gDateFormat.ShortTimePattern = "hh:mm:ss tt";

            clsApprovalMasterBD oApprovalMasterBD = new clsApprovalMasterBD();
            Int64 ApprovalMasterId = 0;
            oApprovalMasterBD.ApprovalMasterId = Convert.ToInt64(ViewState["APPROVALMASTERID"]);
            oApprovalMasterBD.Flag = Convert.ToInt64(ViewState["APPROVALMASTERID"]) > 0 ? EFlag.UPDATE.ToString() : EFlag.INSERT.ToString();
            oApprovalMasterBD.ProcessId = Convert.ToInt64(ddlProcess.SelectedValue);
            oApprovalMasterBD.FromDate = Convert.ToDateTime(txtFromDate.Text.Trim(), gDateFormat);
            oApprovalMasterBD.ToDate = Convert.ToDateTime(txtToDate.Text.Trim(), gDateFormat);
            oApprovalMasterBD.IsEscalated = chkIsEscalated.Checked;
            oApprovalMasterBD.EscalationAlertDuration = chkIsEscalated.Checked ? Convert.ToInt16(txtEscalationAlertDuration.Text.Trim()) : (short)0;
            oApprovalMasterBD.Unit = chkIsEscalated.Checked ? Convert.ToInt64(ddlUnit.SelectedValue) : -1;
            oApprovalMasterBD.Currency = Convert.ToInt64(ddlCurrency.SelectedValue);
            oApprovalMasterBD.Alias = string.Empty;
            oApprovalMasterBD.DOC = DateTime.Now;
            oApprovalMasterBD.DOU = DateTime.Now;
            oApprovalMasterBD.Status = "Active";
            oApprovalMasterBD.TransactionId = 0;

            clsManageTransaction.StartTransaction();
            ApprovalMasterId = (new clsApprovalMasterBO()).InsertUpdate(oApprovalMasterBD);

            int index = 0;
            if (ApprovalMasterId > 0)
            {
                if (dlApprovalList.Items.Count > 0)
                {
                    if (ViewState["APPROVALDETAILSLIST"] != null)
                    {
                        List<clsApprovalDetailsBD> ApprovalDetailsList = (List<clsApprovalDetailsBD>)ViewState["APPROVALDETAILSLIST"];
                        (new clsApprovalDetailsBO()).Delete("APPROVALMASTERID", ApprovalMasterId);
                        foreach (clsApprovalDetailsBD oApprovalDetailsBD in ApprovalDetailsList)
                        {
                            string ViewStateKeyForApprovalDetailId = "APPROVALDETAILID" + Convert.ToString(index);
                            oApprovalDetailsBD.Flag = Convert.ToInt64(ViewState[ViewStateKeyForApprovalDetailId]) > 0 ? EFlag.UPDATE.ToString() : EFlag.INSERT.ToString();
                            oApprovalDetailsBD.ApprovalDetailId = Convert.ToInt64(ViewState[ViewStateKeyForApprovalDetailId]);
                            oApprovalDetailsBD.ApprovalMasterId = ApprovalMasterId;
                            ViewState[ViewStateKeyForApprovalDetailId] = (new clsApprovalDetailsBO()).InsertUpdate(oApprovalDetailsBD);
                            index++;
                        }
                    }
                }
                for (int iApprovalIndex = 0; iApprovalIndex < index; iApprovalIndex++)
                {
                    string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(iApprovalIndex);
                    if (ViewState[ViewStateKey] != null)
                    {
                        List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = (List<clsApprovalEscalationDetailsBD>)ViewState[ViewStateKey];
                        string ViewStateKeyForApprovalDetailId = "APPROVALDETAILID" + Convert.ToString(iApprovalIndex);
                        (new clsApprovalEscalationDetailsBO()).Delete("APPROVALDETAILID", Convert.ToInt64(ViewState[ViewStateKeyForApprovalDetailId]));
                        int EscIndex = 0;
                        foreach (clsApprovalEscalationDetailsBD oApprovalEscalationDetailsBD in ApprovalEscalationDetailsList)
                        {
                            string EscalationKey = "APPROVALESCALATIONDETAILID" + Convert.ToString(EscIndex);
                            oApprovalEscalationDetailsBD.Flag = Convert.ToInt64(ViewState[EscalationKey]) > 0 ? EFlag.UPDATE.ToString() : EFlag.INSERT.ToString();
                            oApprovalEscalationDetailsBD.ApprovalEscalationDetailId = Convert.ToInt64(ViewState[EscalationKey]);
                            oApprovalEscalationDetailsBD.ApprovalDetailId = Convert.ToInt64(ViewState[ViewStateKeyForApprovalDetailId]);
                            (new clsApprovalEscalationDetailsBO()).InsertUpdate(oApprovalEscalationDetailsBD);
                            EscIndex++;
                        }
                        ViewState[ViewStateKeyForApprovalDetailId] = 0;
                    }
                }
            }
            clsManageTransaction.EndTransaction();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindApprovalMatrix()
    {
        try
        {
            clsApprovalMasterBO oApprovalMasterBO = new clsApprovalMasterBO();
            clsApprovalMasterBD oApprovalMasterBD = new clsApprovalMasterBD();
            oApprovalMasterBD.Flag = "ALL";
            oApprovalMasterBD.ApprovalMasterId = 0;
            gvApprovalMatrix.DataSource = oApprovalMasterBO.Select(oApprovalMasterBD);
            gvApprovalMatrix.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindProcess()
    {
        try
        {
            clsProcessBD oProcessBD = new clsProcessBD();
            oProcessBD.ProcessId = 0;
            oProcessBD.Flag = "ALL";
            DataTable dtProcess = (new clsProcessBO()).SelectProcess(oProcessBD);

            ddlProcess.DataSource = dtProcess;
            ddlProcess.DataTextField = "ProcessName";
            ddlProcess.DataValueField = "ProcessId";
            ddlProcess.DataBind();
            ddlProcess.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public void BindUnit(string Kewword, DropDownList ddlCommonUnit)
    {
        try
        {
            DataTable dtProcess = clsUtility.GetMasterValue(Kewword);
            ddlCommonUnit.DataSource = dtProcess;
            ddlCommonUnit.DataTextField = "Value";
            ddlCommonUnit.DataValueField = "MasterId";
            ddlCommonUnit.DataBind();
            ddlCommonUnit.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindCurrency(string Kewword)
    {
        try
        {
            DataTable dtCurrency = clsUtility.GetMasterValue(Kewword);
            ddlCurrency.DataSource = dtCurrency;
            ddlCurrency.DataTextField = "Value";
            ddlCurrency.DataValueField = "MasterId";
            ddlCurrency.DataBind();
            ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindRoles(DropDownList ddlRoles)
    {
        try
        {
            clsRoleMasterBO oRoleMasterBO = new clsRoleMasterBO();
            DataTable dtRoleMaster = oRoleMasterBO.SelectRoleMaster(new clsRoleMasterBD() { CFlag = EFlag.ALL.ToString(), RoleId = 0 });
            ddlRoles.DataSource = dtRoleMaster;
            ddlRoles.DataTextField = "Name";
            ddlRoles.DataValueField = "RoleId";
            ddlRoles.DataBind();
            ddlRoles.Items.Insert(0, new ListItem("-Select-", "0"));
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message + "');</script>");
        }
    }
    private List<clsApprovalDetailsBD> AddApproverList(List<clsApprovalDetailsBD> ApprovalDetailsList)
    {
        try
        {
            if (ViewState["APPROVALDETAILSLIST"] != null)
            {
                ApprovalDetailsList = (List<clsApprovalDetailsBD>)ViewState["APPROVALDETAILSLIST"];
            }
            clsApprovalDetailsBD oApprovalDetailsBD;
            if (ViewState["AD_ITEMINDEX"] == null)
            {
                oApprovalDetailsBD = new clsApprovalDetailsBD();
                oApprovalDetailsBD.ApprovalDetailId = 0;
                oApprovalDetailsBD.ApprovalMasterId = 0;
            }
            else
            {
                oApprovalDetailsBD = ApprovalDetailsList[Convert.ToInt32(ViewState["AD_ITEMINDEX"])];
            }
            oApprovalDetailsBD.RoleId = Convert.ToInt64(ddlRole.SelectedItem.Value);
            oApprovalDetailsBD.RoleName = Convert.ToString(ddlRole.SelectedItem.Text);
            oApprovalDetailsBD.IsEscalated = chkIsEscalate.Checked;
            oApprovalDetailsBD.EscalationDuration = string.IsNullOrEmpty(txtEscalationDuration.Text.Trim()) ? (short)0 : Convert.ToInt16(txtEscalationDuration.Text.Trim());
            oApprovalDetailsBD.Unit = Convert.ToInt64(ddlEscalationUnit.SelectedItem.Value);
            oApprovalDetailsBD.UnitName = ddlEscalationUnit.SelectedIndex > 0 ? Convert.ToString(ddlEscalationUnit.SelectedItem.Text) : string.Empty;
            oApprovalDetailsBD.Sequence = Convert.ToInt16(txtSequence.Text.Trim());
            oApprovalDetailsBD.Alias = string.Empty;
            oApprovalDetailsBD.DOC = DateTime.Now;
            oApprovalDetailsBD.DOU = DateTime.Now;
            oApprovalDetailsBD.Status = "Active";
            oApprovalDetailsBD.TransactionId = 0;
            if (ViewState["AD_ITEMINDEX"] == null)
            {
                ApprovalDetailsList.Add(oApprovalDetailsBD);
            }
            ViewState["APPROVALDETAILSLIST"] = ApprovalDetailsList;

            //Reseting the control after adding in list.
            ViewState["AD_ITEMINDEX"] = null;
            ddlRole.SelectedIndex = -1;
            txtSequence.Text = string.Empty;
            ddlEscalationUnit.SelectedIndex = -1;
            txtEscalationDuration.Text = string.Empty;
            chkIsEscalate.Checked = false;
            divEscalationForApprover.Visible = false;
            return ApprovalDetailsList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private List<clsApprovalEscalationDetailsBD> AddApprovalEscalationDetailsList(List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList, Int64 RoleId, String RoleName, Int16 Sequence, int Index)
    {
        try
        {
            string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(Index);
            if (ViewState[ViewStateKey] != null)
            {
                ApprovalEscalationDetailsList = (List<clsApprovalEscalationDetailsBD>)ViewState[ViewStateKey];
            }
            clsApprovalEscalationDetailsBD oApprovalEscalationDetailsBD;
            if (ViewState["ESC_ROWINDEX"] == null)
            {
                oApprovalEscalationDetailsBD = new clsApprovalEscalationDetailsBD();
                oApprovalEscalationDetailsBD.ApprovalEscalationDetailId = 0;
                oApprovalEscalationDetailsBD.ApprovalDetailId = 0;
            }
            else
            {
                oApprovalEscalationDetailsBD = ApprovalEscalationDetailsList[Convert.ToInt32(ViewState["ESC_ROWINDEX"])];
            }
            oApprovalEscalationDetailsBD.RoleId = RoleId;
            oApprovalEscalationDetailsBD.RoleName = RoleName;
            oApprovalEscalationDetailsBD.Sequence = Sequence;
            oApprovalEscalationDetailsBD.Alias = string.Empty;
            oApprovalEscalationDetailsBD.DOC = DateTime.Now;
            oApprovalEscalationDetailsBD.DOU = DateTime.Now;
            oApprovalEscalationDetailsBD.Status = "Active";
            oApprovalEscalationDetailsBD.TransactionId = 0;
            if (ViewState["ESC_ROWINDEX"] == null)
            {
                ApprovalEscalationDetailsList.Add(oApprovalEscalationDetailsBD);
            }
            ViewState[ViewStateKey] = ApprovalEscalationDetailsList;
            ViewState["ESC_ROWINDEX"] = null;
            return ApprovalEscalationDetailsList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private List<clsApprovalDetailsBD> ReInitialiseApprovalDetails(DataSet dsApprovalMaster, List<clsApprovalDetailsBD> ApprovalDetailsList)
    {
        try
        {
            int ItemIndex = 0;
            foreach (DataRow drApprovalDetails in dsApprovalMaster.Tables[1].Rows)
            {
                clsApprovalDetailsBD oApprovalDetailsBD = new clsApprovalDetailsBD();
                oApprovalDetailsBD.ApprovalDetailId = Convert.ToInt64(drApprovalDetails["ApprovalDetailId"]);
                oApprovalDetailsBD.ApprovalMasterId = Convert.ToInt64(drApprovalDetails["ApprovalMasterId"]);
                oApprovalDetailsBD.RoleId = Convert.ToInt64(drApprovalDetails["RoleId"]);
                oApprovalDetailsBD.RoleName = Convert.ToString(drApprovalDetails["RoleName"]);
                oApprovalDetailsBD.IsEscalated = Convert.ToBoolean(drApprovalDetails["IsEscalated"]);
                oApprovalDetailsBD.EscalationDuration = Convert.ToInt16(drApprovalDetails["EscalationDuration"]);
                oApprovalDetailsBD.Unit = Convert.ToInt64(drApprovalDetails["Unit"]);
                oApprovalDetailsBD.UnitName = Convert.ToString(drApprovalDetails["UnitName"]);
                oApprovalDetailsBD.Sequence = Convert.ToInt16(drApprovalDetails["Sequence"]);
                oApprovalDetailsBD.Alias = string.Empty;
                oApprovalDetailsBD.DOC = DateTime.Now;
                oApprovalDetailsBD.DOU = DateTime.Now;
                oApprovalDetailsBD.Status = "Active";
                oApprovalDetailsBD.TransactionId = 0;
                ApprovalDetailsList.Add(oApprovalDetailsBD);

                string ViewStateKey = "ESCALATIONLIST" + Convert.ToString(ItemIndex);
                //Reinitialisation of viewstate for escalation details
                clsApprovalMasterBD oApprovalMasterBD = new clsApprovalMasterBD();
                DataTable dtApprovalEscalationDetails = new DataTable();
                oApprovalMasterBD.Flag = "ADID";
                //ApprovalMasterId is used to store the Approval detail id
                oApprovalMasterBD.ApprovalMasterId = Convert.ToInt64(drApprovalDetails["ApprovalDetailId"]);

                dtApprovalEscalationDetails = ((new clsApprovalMasterBO()).Select(oApprovalMasterBD)).Tables[0];
                ViewState[ViewStateKey] = ReInitialiseApprovalEscalationDetails(dtApprovalEscalationDetails);
                ItemIndex++;

            }
            return ApprovalDetailsList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private List<clsApprovalEscalationDetailsBD> ReInitialiseApprovalEscalationDetails(DataTable dtApprovalEscalationDetails)
    {
        try
        {
            List<clsApprovalEscalationDetailsBD> ApprovalEscalationDetailsList = new List<clsApprovalEscalationDetailsBD>();
            foreach (DataRow drApprovalEscalationDetail in dtApprovalEscalationDetails.Rows)
            {
                clsApprovalEscalationDetailsBD oApprovalEscalationDetailsBD = new clsApprovalEscalationDetailsBD();
                oApprovalEscalationDetailsBD.ApprovalEscalationDetailId = Convert.ToInt64(drApprovalEscalationDetail["ApprovalEscalationDetailId"]);
                oApprovalEscalationDetailsBD.ApprovalDetailId = Convert.ToInt64(drApprovalEscalationDetail["ApprovalDetailId"]);
                oApprovalEscalationDetailsBD.RoleId = Convert.ToInt64(drApprovalEscalationDetail["RoleId"]);
                oApprovalEscalationDetailsBD.RoleName = Convert.ToString(drApprovalEscalationDetail["RoleName"]);
                oApprovalEscalationDetailsBD.Sequence = Convert.ToInt16(drApprovalEscalationDetail["Sequence"]);
                oApprovalEscalationDetailsBD.Alias = Convert.ToString(drApprovalEscalationDetail["Alias"]);
                oApprovalEscalationDetailsBD.DOC = Convert.ToDateTime(drApprovalEscalationDetail["DOC"]);
                oApprovalEscalationDetailsBD.DOU = Convert.ToDateTime(drApprovalEscalationDetail["DOU"]);
                oApprovalEscalationDetailsBD.Status = "Active";
                oApprovalEscalationDetailsBD.TransactionId = 0;
                ApprovalEscalationDetailsList.Add(oApprovalEscalationDetailsBD);
            }
            return ApprovalEscalationDetailsList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void FillApprovalMasterDetails(DataSet dsApprovalMaster)
    {
        try
        {
            System.Globalization.DateTimeFormatInfo gDateFormat = new System.Globalization.DateTimeFormatInfo();
            gDateFormat.ShortDatePattern = "dd/MM/yyyy";
            gDateFormat.ShortTimePattern = "hh:mm:ss tt";
            if (dsApprovalMaster.Tables[0].Rows.Count > 0)
            {
                ListItem ProcessItem = ddlProcess.Items.FindByValue(Convert.ToString(dsApprovalMaster.Tables[0].Rows[0]["ProcessId"])) as ListItem;
                if (ProcessItem != null)
                {
                    ddlProcess.ClearSelection();
                    ProcessItem.Selected = true;
                }
                ListItem CurrencyItem = ddlCurrency.Items.FindByValue(Convert.ToString(dsApprovalMaster.Tables[0].Rows[0]["Currency"])) as ListItem;
                if (CurrencyItem != null)
                {
                    ddlCurrency.ClearSelection();
                    CurrencyItem.Selected = true;
                }
                ListItem UnitItem = ddlUnit.Items.FindByValue(Convert.ToString(dsApprovalMaster.Tables[0].Rows[0]["Unit"])) as ListItem;
                if (UnitItem != null)
                {
                    ddlUnit.ClearSelection();
                    UnitItem.Selected = true;
                }
                chkIsEscalated.Checked = Convert.ToBoolean(dsApprovalMaster.Tables[0].Rows[0]["IsEscalated"]);
                if (chkIsEscalated.Checked)
                {
                    pnlEscalation.Visible = true;
                }
                else
                {
                    pnlEscalation.Visible = false;
                }
                txtFromDate.Text = Convert.ToDateTime(dsApprovalMaster.Tables[0].Rows[0]["FromDate"], gDateFormat).ToString("dd/MM/yyyy");
                txtToDate.Text = Convert.ToDateTime(dsApprovalMaster.Tables[0].Rows[0]["ToDate"], gDateFormat).ToString("dd/MM/yyyy");
                txtEscalationAlertDuration.Text = Convert.ToString(dsApprovalMaster.Tables[0].Rows[0]["EscalationAlertDuration"]);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #endregion

}
