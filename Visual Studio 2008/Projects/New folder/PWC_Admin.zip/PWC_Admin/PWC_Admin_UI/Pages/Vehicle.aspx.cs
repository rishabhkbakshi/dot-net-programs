﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_Vehicle : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindVehicleType();
            BindVehicles();
            ShowMessage(string.Empty);
        }
    }
    /// <summary>
    /// The event is use to update process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicle_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 VehicleId = Convert.ToInt64(gvVehicle.DataKeys[e.RowIndex].Value);
            SetControls(VehicleId);
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To delete(make inactive) Process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvVehicle_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 VehicleId = Convert.ToInt64(gvVehicle.DataKeys[e.RowIndex].Value);
            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            (new clsVehicleBO()).DeleteVehicle(VehicleId);
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................
            Response.Redirect(Request.Path + "?MSG=" + EFlag.DELETE.ToString(), false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvVehicle_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
    private void SetControls(Int64 VehicleId)
    {
        try
        {
            ViewState["VEHICLEID"] = VehicleId;
            DataTable dtVehicle = (new clsVehicleBO()).SelectVehicle("VEHICLEID", VehicleId);
            if (dtVehicle.Rows.Count > 0)
            {
                txtMake.Text = Convert.ToString(dtVehicle.Rows[0]["Make"]);
                txtModel.Text = Convert.ToString(dtVehicle.Rows[0]["Model"]);
                string VehicleType = Convert.ToString(dtVehicle.Rows[0]["VehicleType"]);
                ListItem VehicleTypeItem = ddlVehicleType.Items.FindByValue(VehicleType) as ListItem;
                if (VehicleTypeItem != null)
                {
                    ddlVehicleType.ClearSelection();
                    VehicleTypeItem.Selected = true;
                }
                txtRegistrationNumber.Text = Convert.ToString(dtVehicle.Rows[0]["RegistrationNumber"]);
                lblAllocatedTo.Text = Convert.ToString(dtVehicle.Rows[0]["AllocatedTo"]);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    private void BindVehicleType()
    {
        try
        {
            clsVehicleTypesBO oVehicleTypesBO = new clsVehicleTypesBO();
            clsVehicleTypesBD oVehicleTypesBD = new clsVehicleTypesBD();
            oVehicleTypesBD.VehicleTypesId = 0;
            oVehicleTypesBD.CFlag = "VEHICLE";
            ddlVehicleType.DataSource = oVehicleTypesBO.SelectVehicleTypes(oVehicleTypesBD);
            ddlVehicleType.DataTextField = "ClassOfVehicle_TypeOfBody";
            ddlVehicleType.DataValueField = "VehicleTypesId";
            ddlVehicleType.DataBind();
            ddlVehicleType.Items.Insert(0, new ListItem("--Select--", "-1"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            string Flag = EFlag.INSERT.ToString();
            if (Convert.ToInt64(ViewState["VEHICLEID"]) > 0)
            {
                Flag = EFlag.UPDATE.ToString();
            }
            InsertOrUpdateVehicle(Flag);
            Response.Redirect(Request.Path + "?MSG=" + Flag, false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to save and update process
    /// </summary>
    /// <param name="Flag"></param>
    /// <returns></returns>
    private long InsertOrUpdateVehicle(string Flag)
    {
        try
        {
            long VehicleId = 0;
            clsVehicleBO oVehicleBO = new clsVehicleBO();
            clsVehicleBD oVehicleBD = new clsVehicleBD();
            oVehicleBD.Flag = Flag;
            oVehicleBD.VehicleId = Convert.ToInt64(ViewState["VEHICLEID"]);
            oVehicleBD.Make = txtMake.Text.Trim();
            oVehicleBD.Model = txtModel.Text.Trim();
            oVehicleBD.VehicleType = string.Compare("-1", ddlVehicleType.SelectedValue) == 0 ? 0 : Convert.ToInt64(ddlVehicleType.SelectedValue);
            oVehicleBD.RegistrationNumber = txtRegistrationNumber.Text.Trim();
            oVehicleBD.AllocatedTo = lblAllocatedTo.Text.Trim();
            oVehicleBD.Alias = "NA";
            oVehicleBD.DOC = DateTime.Now;
            oVehicleBD.DOU = DateTime.Now;
            oVehicleBD.Status = "Active";
            oVehicleBD.TransactionId = 0;

            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            VehicleId = oVehicleBO.InsertUpdateVehicle(oVehicleBD);
            ViewState["VEHICLEID"] = 0;
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................

            return VehicleId;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    private void BindVehicles()
    {
        try
        {
            clsVehicleBO oVehicleBO = new clsVehicleBO();
            gvVehicle.DataSource = oVehicleBO.SelectVehicle("ALL", 0);
            gvVehicle.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
    }
}
