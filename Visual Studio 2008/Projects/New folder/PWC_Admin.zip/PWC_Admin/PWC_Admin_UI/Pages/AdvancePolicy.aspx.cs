﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BO;
using Admin.BD;
using System.Data;

public partial class Pages_AdvancePolicy : BasePage
{
    #region --Initializers--
    clsGradeMasterBD oclsGradeMasterBD = new clsGradeMasterBD();
    clsGradeMasterBO oclsGradeMasterBO = new clsGradeMasterBO();
    clsAdvancePolicyBD oclsAdvancePolicyBD = new clsAdvancePolicyBD();
    clsAdvancePolicyBO oclsAdvancePolicyBO = new clsAdvancePolicyBO();
    clsPolicyGradeMappingBD oclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
    clsPolicyGradeMappingBO oclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    DataTable dtAdvancePolicy = new DataTable();
    #endregion
    #region --Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                BindGrade();
                Bindgrid();
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region --Event Handlers--
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAdvancepolicy_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvAdvancepolicy.PageIndex = e.NewPageIndex;
            Bindgrid();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to update and delete Advancepolicy
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAdvancepolicy_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (string.Compare(e.CommandName.ToUpper(), EFlag.UPDATE.ToString()) == 0)
                ViewState["AdvancePolicyId"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), EFlag.DELETE.ToString()) == 0)
            {
                oclsAdvancePolicyBD.AdvancePolicyId = Int64.Parse(e.CommandArgument.ToString());
                clsManageTransaction.StartTransaction();
                if (oclsAdvancePolicyBO.DeleteAdvancePolicy(oclsAdvancePolicyBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvAdvancepolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 AdvancePolicyId = Int64.Parse(gvAdvancepolicy.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["ADVANCEDPOLICYID"] = AdvancePolicyId;
            ddlTravelType.SelectedIndex = ddlTravelType.Items.IndexOf(ddlTravelType.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[0].Text));
            txtAPFrom.Text = gvAdvancepolicy.Rows[e.RowIndex].Cells[1].Text;
            txtAPTo.Text = gvAdvancepolicy.Rows[e.RowIndex].Cells[2].Text;
            ddlFromUnit.SelectedIndex = ddlFromUnit.Items.IndexOf(ddlFromUnit.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[3].Text));
            ddlToUnit.SelectedIndex = ddlToUnit.Items.IndexOf(ddlToUnit.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[4].Text));
            txtAmount.Text = gvAdvancepolicy.Rows[e.RowIndex].Cells[5].Text;
            ddlCurrency.SelectedIndex = ddlCurrency.Items.IndexOf(ddlCurrency.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[6].Text));
            //ddlGrade.SelectedIndex = ddlGrade.Items.IndexOf(ddlGrade.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[1].Text));
            //txtAlias.Text = HttpUtility.HtmlDecode(gvAdvancepolicy.Rows[e.RowIndex].Cells[7].Text);
            txtPermAmount.Text = gvAdvancepolicy.Rows[e.RowIndex].Cells[7].Text == "" ? string.Empty : gvAdvancepolicy.Rows[e.RowIndex].Cells[7].Text;
            ddlAppGrade.SelectedIndex = ddlAppGrade.Items.IndexOf(ddlAppGrade.Items.FindByText(gvAdvancepolicy.Rows[e.RowIndex].Cells[8].Text));
            btnSave.Text = "Update";
            BindDestinationGrade(AdvancePolicyId);

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void gvAdvancepolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
        //Clearfields();
    }
    /// <summary>
    /// The event is use to save and update
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        int RefPolicyId = 0;
        try
        {
            if (lbSelectedGrades.Items.Count > 0)
            {

                if (ViewState["AdvancePolicyId"] != null && ViewState["AdvancePolicyId"].ToString() != "0")
                {
                    oclsAdvancePolicyBD.CFlag = EFlag.UPDATE.ToString();
                    oclsAdvancePolicyBD.AdvancePolicyId = Int64.Parse(ViewState["AdvancePolicyId"].ToString());
                }
                else
                {
                    oclsAdvancePolicyBD.CFlag = EFlag.INSERT.ToString();
                    oclsAdvancePolicyBD.AdvancePolicyId = 0;
                }

                oclsAdvancePolicyBD.Alias = txtAlias.Text.Trim();
                oclsAdvancePolicyBD.Amount = System.Decimal.Parse(txtAmount.Text.Trim());
                oclsAdvancePolicyBD.APFrom = Decimal.Parse(txtAPFrom.Text.Trim());
                oclsAdvancePolicyBD.APTo = Decimal.Parse(txtAPTo.Text.Trim());
                oclsAdvancePolicyBD.Currency = Int64.Parse(ddlCurrency.SelectedValue.ToString());
                oclsAdvancePolicyBD.DOC = DateTime.Now;
                oclsAdvancePolicyBD.DOU = DateTime.Now;
                oclsAdvancePolicyBD.FromUnit = Int64.Parse(ddlFromUnit.SelectedValue.ToString());
                //oclsAdvancePolicyBD.GradeId = Int64.Parse(ddlGrade.SelectedValue.ToString());
                oclsAdvancePolicyBD.PermissibleUnsettledAmount = Decimal.Parse(txtPermAmount.Text);
                oclsAdvancePolicyBD.ApproverGradeId = Int64.Parse(ddlAppGrade.SelectedValue.ToString());
                oclsAdvancePolicyBD.Status = "Active";
                oclsAdvancePolicyBD.ToUnit = Int64.Parse(ddlToUnit.SelectedValue.ToString());
                oclsAdvancePolicyBD.TransactionId = 1;
                oclsAdvancePolicyBD.TravelType = Int64.Parse(ddlTravelType.SelectedValue.ToString());
                oclsAdvancePolicyBD.CountryId = Int64.Parse(ddlCountry.SelectedValue.ToString());
                clsManageTransaction.StartTransaction();
                RefPolicyId = oclsAdvancePolicyBO.InsertUpdateAdvancePolicy(oclsAdvancePolicyBD);
                oclsPolicyGradeMappingBD.ReferencePolicyId = RefPolicyId;
                oclsPolicyGradeMappingBO.DeletePolicyGradeMapping(oclsPolicyGradeMappingBD);
                if (RefPolicyId > 0)
                {
                    if (InsertUpdatePolicyGradeMapping(RefPolicyId) > 0)
                    {
                        clsManageTransaction.EndTransaction();
                        Clearfields();
                        Bindgrid();
                        BindGrade();
                        Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                    }
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    BindGrade();
                    Bindgrid();
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
            else
            {
                btnAllRight.Focus();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Enter Policy Grade.');</script>");
            }

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    /// <summary>
    /// The event is use to move the available Grades List  back to availableGrade ListBox
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        try
        {
            if (lbSelectedGrades.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Allocated Grade Lists');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
            {
                if (lbSelectedGrades.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Assigned Grades');</script>");
                    return;
                }

                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    if (lbSelectedGrades.Items[i].Selected)
                    {
                        lbAvailableGrades.Items.Add(lbSelectedGrades.Items[i]);
                    }
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Remove(lbAvailableGrades.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Add(lbSelectedGrades.Items[i]);
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Remove(lbAvailableGrades.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    /// <summary>
    /// btnRight_Click: This event is to move the available grades to Allocated Grades ListBox
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void btnAllRight_Click(object sender, EventArgs e)
    {
        try
        {
            if (lbAvailableGrades.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Available Grade Lists');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
            {
                if (lbAvailableGrades.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Available Grades');</script>");
                    return;
                }
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    if (lbAvailableGrades.Items[i].Selected)
                    {
                        lbSelectedGrades.Items.Add(lbAvailableGrades.Items[i]);
                    }
                }
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lbAvailableGrades.Items.Count; i++)
                {
                    lbSelectedGrades.Items.Add(lbAvailableGrades.Items[i]);
                }
                for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                {
                    lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }

    #endregion
    #region --Private Methods--
    /// <summary>
    /// The following method is use to bind data in grid
    /// </summary>
    private void Bindgrid()
    {
        try
        {
            oclsAdvancePolicyBD.AdvancePolicyId = 0;
            oclsAdvancePolicyBD.CFlag = EFlag.ALL.ToString();
            dtAdvancePolicy = oclsAdvancePolicyBO.SelectAdvancePolicy(oclsAdvancePolicyBD);
            //if (dtAdvancePolicy != null && dtAdvancePolicy.Rows.Count > 0)
            //{
            gvAdvancepolicy.DataSource = dtAdvancePolicy;
            gvAdvancepolicy.DataBind();
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to bind Currency,Grade,TravelType,FromUnit & ToUnit dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            DataTable dtCurrency = clsUtility.GetMasterValue("Currency");
            if (dtCurrency != null && dtCurrency.Rows.Count > 0)
            {
                ddlCurrency.DataSource = dtCurrency;
                ddlCurrency.DataValueField = "MasterId";
                ddlCurrency.DataTextField = "Value";
                ddlCurrency.DataBind();
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlCurrency.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            oclsGradeMasterBD.CFlag = EFlag.ALL.ToString();
            oclsGradeMasterBD.GradeId = 0;
            DataTable dtGrade = oclsGradeMasterBO.SelectGradeMaster(oclsGradeMasterBD);
            if (dtGrade != null && dtGrade.Rows.Count > 0)
            {
                //ddlGrade.DataSource = dtGrade;
                //ddlGrade.DataValueField = "GradeId";
                //ddlGrade.DataTextField = "GradeName";
                //ddlGrade.DataBind();
                //ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));

                ddlAppGrade.DataSource = dtGrade;
                ddlAppGrade.DataValueField = "GradeId";
                ddlAppGrade.DataTextField = "GradeName";
                ddlAppGrade.DataBind();
                ddlAppGrade.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                //ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
                ddlAppGrade.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            DataTable dtTravelType = clsUtility.GetMasterValue("TravelType");
            if (dtTravelType != null && dtTravelType.Rows.Count > 0)
            {

                ddlTravelType.DataSource = dtTravelType;
                ddlTravelType.DataValueField = "MasterId";
                ddlTravelType.DataTextField = "Value";
                ddlTravelType.DataBind();
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
                ListItem travelTypeItem = ddlTravelType.Items.FindByText("Domestic") as ListItem;
                if (travelTypeItem != null)
                {
                    ddlTravelType.Items.Remove(travelTypeItem);
                }
            }
            else
            {
                ddlTravelType.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            DataTable dtFromUnit = clsUtility.GetMasterValue("Unit");
            if (dtFromUnit != null && dtFromUnit.Rows.Count > 0)
            {
                ddlFromUnit.DataSource = dtFromUnit;
                ddlFromUnit.DataValueField = "MasterId";
                ddlFromUnit.DataTextField = "Value";
                ddlFromUnit.DataBind();
                ListItem Item = ddlFromUnit.Items.FindByText("Days") as ListItem;
                if (Item != null)
                {
                    ddlFromUnit.Items.Clear();
                    ddlFromUnit.Items.Add(Item);
                }
                ddlFromUnit.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlFromUnit.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            DataTable dtToUnit = clsUtility.GetMasterValue("Unit");
            if (dtToUnit != null && dtToUnit.Rows.Count > 0)
            {
                ddlToUnit.DataSource = dtFromUnit;
                ddlToUnit.DataValueField = "MasterId";
                ddlToUnit.DataTextField = "Value";
                ddlToUnit.DataBind();
                ListItem Item = ddlToUnit.Items.FindByText("Days") as ListItem;
                if (Item != null)
                {
                    ddlToUnit.Items.Clear();
                    ddlToUnit.Items.Add(Item);
                }
                ddlToUnit.Items.Insert(0, new ListItem("--Select--", "0"));

            }
            else
            {
                ddlToUnit.Items.Insert(0, new ListItem("--Select--", "0"));
            }

            //binding country dropdown
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            DataTable dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtPermAmount.Text = txtAlias.Text = txtAmount.Text = txtAPFrom.Text = txtAPTo.Text = string.Empty;
        ViewState["AdvancePolicyId"] = ddlAppGrade.SelectedIndex = ddlCurrency.SelectedIndex = ddlFromUnit.SelectedIndex = ddlToUnit.SelectedIndex = ddlTravelType.SelectedIndex = 0;
        btnSave.Text = "Save"; lbSelectedGrades.Items.Clear();
    }
    private void BindGrade()
    {
        try
        {
            clsTravelPolicyBO objclsTravelPolicyBO = new clsTravelPolicyBO();
            DataTable dtGrade = objclsTravelPolicyBO.SelectGradeMaster(0);
            lbAvailableGrades.DataSource = dtGrade;
            lbAvailableGrades.DataValueField = "GradeId";
            lbAvailableGrades.DataTextField = "GradeName";
            lbAvailableGrades.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }

    private int InsertUpdatePolicyGradeMapping(int ReferencePolicyId)
    {
        int res = 0;
        try
        {
            clsPolicyGradeMappingBD objclsPolicyGradeMappingBD = new clsPolicyGradeMappingBD();
            clsPolicyGradeMappingBO objclsPolicyGradeMappingBO = new clsPolicyGradeMappingBO();
            objclsPolicyGradeMappingBD.CFlag = "INSERT";
            objclsPolicyGradeMappingBD.PolicyGradeMappingId = 0;
            objclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
            objclsPolicyGradeMappingBD.ReferencePolicyType = "Advanced Policy";
            objclsPolicyGradeMappingBD.Alias = "";
            objclsPolicyGradeMappingBD.DOC = DateTime.Now;
            objclsPolicyGradeMappingBD.DOU = DateTime.Now;
            objclsPolicyGradeMappingBD.Status = "Active";
            for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
            {
                objclsPolicyGradeMappingBD.GradeId = Convert.ToInt64(lbSelectedGrades.Items[i].Value);
                res = objclsPolicyGradeMappingBO.InsertUpdatePolicyGradeMapping(objclsPolicyGradeMappingBD);
            }
        }
        catch (Exception ex)
        {
            res = -1;
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
        return res;
    }

    /// <summary>
    /// The following method is use to bind Bind Destination Grade
    /// </summary>
    private void BindDestinationGrade(Int64 ReferencePolicyId)
    {
        oclsPolicyGradeMappingBD.ReferencePolicyId = ReferencePolicyId;
        oclsPolicyGradeMappingBD.CFlag = "ADVANCEDPOLICY";
        DataTable dtList = oclsPolicyGradeMappingBO.SelectPolicyGradeMapping(oclsPolicyGradeMappingBD);
        if (dtList.Rows.Count > 0)
        {
            lbSelectedGrades.DataSource = dtList;
            lbSelectedGrades.DataTextField = "GradeName";
            lbSelectedGrades.DataValueField = "GradeId";
            lbSelectedGrades.DataBind();
            for (int i = 0; i < lbSelectedGrades.Items.Count; i++)
                lbAvailableGrades.Items.Remove(lbSelectedGrades.Items[i]);
            if (lbSelectedGrades.Items.Count > 0)
            {
                lbSelectedGrades.SelectedIndex = 0;
            }
        }
        else
        {
            lbSelectedGrades.Items.Clear();
            BindGrade();
        }

    }
    #endregion


}
