﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BO;
using Admin.BD;
public partial class Pages_VendorServiceCharges : BasePage
{
    #region "--Initializers--"
        clsVendorServiceChargesBD objclsVendorServiceChargesBD = new clsVendorServiceChargesBD();
        clsVendorServiceChargesBO objclsVendorServiceChargesBO = new clsVendorServiceChargesBO();
    #endregion "--Initializers--"
    #region "--Pageload Method--"
    /// <summary>
    /// Page_Load: 
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindServiceChargeData();
            BindVenderDropdown();
            BindTravelDropdowns(ddlTypeofTravel, 6);
            BindTravelDropdowns(ddlCharge, 12);
            BindTravelDropdowns(ddlTravelMode, 7);
            BindTravelDropdowns(ddlServiceType, 34);
        }
        DateTime dttxtEffectiveToDate = Convert.ToDateTime("12/31/2099");
        txtEffectiveTo.Text = dttxtEffectiveToDate.ToString("MMMM d, yyyy");
    }
    private void BindServiceChargeData()
    {
        try
        {
            DataTable dtSerivceCharge = objclsVendorServiceChargesBO.SelectVendorServiceData(0);
            if (dtSerivceCharge != null && dtSerivceCharge.Rows.Count > 0)
            {
                gvVendorServiceCharge.DataSource = dtSerivceCharge;
                gvVendorServiceCharge.DataBind();

            }
            //else
            //{
            //    lblMsg.Text = "No data found.";
            //}
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion "--Pageload Method--"
    #region "--Event Handlers--"
    protected void ddlVendor_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlVendor.SelectedValue != "0")
            {
                DataTable dtVenders = new DataView((new clsVendorDetailsBO()).SelectVendrMasterData(Convert.ToInt64(ddlVendor.SelectedValue))).ToTable(true, new string[] { "Alias" });
                if (dtVenders != null && dtVenders.Rows.Count == 1)
                {
                    lblVendorCode.Text = Convert.ToString(dtVenders.Rows[0][0]);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    #endregion "--Event Handlers--"
    #region "--User Defined Methods--"
    private void BindVenderDropdown()
    {
        try
        {
            DataTable dtVenders = new DataView((new clsVendorDetailsBO()).SelectVendrMasterData(0)).ToTable(true, new string[] { "VendorId", "VendorName" });
            if (dtVenders != null && dtVenders.Rows.Count > 0)
            {
                ddlVendor.DataSource = dtVenders;
                ddlVendor.DataTextField = "VendorName";
                ddlVendor.DataValueField = "VendorId";
                ddlVendor.DataBind();
                ddlVendor.Items.Insert(0, new ListItem("-Select-", "0"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    private void BindTravelDropdowns(DropDownList ddl, int KeywordId)
    {
        try
        {
            DataTable dtTravelTypes = new DataView((new clsMastersBO()).SelectMasters("", KeywordId)).ToTable(true, new string[] { "MasterId", "Value" });
            if (dtTravelTypes != null && dtTravelTypes.Rows.Count > 0)
            {
                ddl.DataSource = dtTravelTypes;
                ddl.DataTextField = "Value";
                ddl.DataValueField = "MasterId";
                ddl.DataBind();
                ddl.Items.Insert(0, new ListItem("-Select-", "0"));
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion "--User Defined Methods--"
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        SaveVendorServiceCharges();
    }
    private void SaveVendorServiceCharges()
    {
        try
        {
            int result = DateTime.Compare(Convert.ToDateTime(txtEffectiveFrom.Text.Trim()), Convert.ToDateTime(txtEffectiveTo.Text.Trim()));
            if (result > 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Effective to date should be greater than effective from date.');</script>");
                return;
            }
            if (ViewState["VendorServiceChargeId"] != null && ViewState["VendorServiceChargeId"].ToString() != "0")
            {
                objclsVendorServiceChargesBD.CFlag = EFlag.UPDATE.ToString();
                objclsVendorServiceChargesBD.VendorServiceChargeId = Int64.Parse(ViewState["VendorServiceChargeId"].ToString());
            }
            else
            {
                objclsVendorServiceChargesBD.CFlag = EFlag.INSERT.ToString();
                objclsVendorServiceChargesBD.VendorServiceChargeId = 0;
            }
            objclsVendorServiceChargesBD.VendorId = Int64.Parse(ddlVendor.SelectedValue.ToString());
            objclsVendorServiceChargesBD.TypeOfTravelId = Int64.Parse(ddlTypeofTravel.SelectedValue.ToString());
            objclsVendorServiceChargesBD.TravelModeId = Int64.Parse(ddlTravelMode.SelectedValue.ToString());
            objclsVendorServiceChargesBD.EffectiveFromDate = DateTime.Parse(txtEffectiveFrom.Text.Trim());
            objclsVendorServiceChargesBD.EffectiveToDate = DateTime.Parse(txtEffectiveTo.Text.Trim());
            objclsVendorServiceChargesBD.Status =(ddlStatus.SelectedItem.Text.Trim());
            objclsVendorServiceChargesBD.Amount = Decimal.Parse(txtPerTransaction.Text.Trim());
            objclsVendorServiceChargesBD.CurrencyId = Int64.Parse(ddlCharge.SelectedValue.ToString());
            objclsVendorServiceChargesBD.DOC = DateTime.Now;
            objclsVendorServiceChargesBD.DOU = DateTime.Now;
            objclsVendorServiceChargesBD.TransactionId = 0;
            objclsVendorServiceChargesBD.ServiceTypeID = Int64.Parse(ddlServiceType.SelectedValue.ToString());
            clsManageTransaction.StartTransaction();
            Int64 ServicechargeId = objclsVendorServiceChargesBO.InsertUpdatecVendorServiceCharges(objclsVendorServiceChargesBD);
            clsManageTransaction.EndTransaction();
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            Clearfields();
            BindServiceChargeData();

        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    private void Clearfields()
    {
        txtEffectiveFrom.Text = string.Empty;
        txtPerTransaction.Text =  string.Empty;
        ddlServiceType.SelectedIndex = 0;
        ddlCharge.SelectedIndex = 0;
        ddlStatus.SelectedValue = "Active";
        ddlTravelMode.SelectedIndex = 0;
        ddlTypeofTravel.SelectedIndex = 0;
        ddlVendor.SelectedIndex = 0;
        lblVendorCode.Text = "Please select Vendor";
        btnSubmit.Text = "Submit";
        ViewState["VendorServiceChargeId"] = "0";
    }
    protected void gvVendorServiceCharge_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Clearfields();
            Int64 VendorServiceId = Int64.Parse(gvVendorServiceCharge.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["VendorServiceChargeId"] = VendorServiceId;
            DataTable dtServiceChargeDetails = objclsVendorServiceChargesBO.SelectVendorServiceData(VendorServiceId);
            if (dtServiceChargeDetails != null && dtServiceChargeDetails.Rows.Count > 0)
            {
                ddlVendor.SelectedValue = dtServiceChargeDetails.Rows[0]["VendorId"].ToString();
                lblVendorCode.Text = dtServiceChargeDetails.Rows[0]["VendorCode"].ToString();
                ListItem TypeOfTravelItem = new ListItem();
                TypeOfTravelItem = ddlTypeofTravel.Items.FindByValue(Convert.ToString(dtServiceChargeDetails.Rows[0]["TypeOfTravelId"])) as ListItem;
                if (TypeOfTravelItem != null)
                {
                    ddlTypeofTravel.ClearSelection();
                    TypeOfTravelItem.Selected = true;
                }
                txtPerTransaction.Text = dtServiceChargeDetails.Rows[0]["Amount"].ToString();
                ListItem ChargeItem = new ListItem();
                ChargeItem = ddlCharge.Items.FindByValue(Convert.ToString( dtServiceChargeDetails.Rows[0]["CurrencyId"])) as ListItem;
                if(ChargeItem!=null)
                {
                    ddlCharge.ClearSelection();
                    ChargeItem.Selected=true;
                }
                ListItem ModeItem = new ListItem();
                ChargeItem = ddlTravelMode.Items.FindByValue(Convert.ToString(dtServiceChargeDetails.Rows[0]["TravelModeId"])) as ListItem;
                if (ChargeItem != null)
                {
                    ddlTravelMode.ClearSelection();
                    ModeItem.Selected = true;
                }
                ListItem ServiceItem = new ListItem();
                ServiceItem = ddlCharge.Items.FindByValue(Convert.ToString(dtServiceChargeDetails.Rows[0]["ServiceTypeID"])) as ListItem;
                if (ServiceItem != null)
                {
                    ddlCharge.ClearSelection();
                    ServiceItem.Selected = true;
                }
                txtEffectiveFrom.Text = Convert.ToDateTime(dtServiceChargeDetails.Rows[0]["EffectiveFromDate"]).ToString("MMMM d, yyyy");
                txtEffectiveTo.Text = Convert.ToDateTime(dtServiceChargeDetails.Rows[0]["EffectiveToDate"]).ToString("MMMM d, yyyy");
                btnSubmit.Text = "Update";
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
        BindServiceChargeData();
    }
    protected void gvVendorServiceCharge_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 VendorServiceId = Int64.Parse(gvVendorServiceCharge.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();

            if (objclsVendorServiceChargesBO.DeleteServiceCharge(VendorServiceId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");

        }
        BindServiceChargeData();
    }
    
}
