﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;

public partial class Pages_AccomodationGradeMapping : BasePage
{
    #region--Initializers--
    clsCountryMasterBD oclsCountryMasterBD = new clsCountryMasterBD();
    clsCountryMasterBO oclsCountryMasterBO = new clsCountryMasterBO();
    clsGradeMasterBD oclsGradeMasterBD = new clsGradeMasterBD();
    clsGradeMasterBO oclsGradeMasterBO = new clsGradeMasterBO();
    clsAccomodationsBD oclsAccomodationsBD = new clsAccomodationsBD();
    clsAccomodationsBO oclsAccomodationsBO = new clsAccomodationsBO();
    clsAccomodationGradeMappingBD oclsAccomodationGradeMappingBD = new clsAccomodationGradeMappingBD();
    clsAccomodationGradeMappingBO oclsAccomodationGradeMappingBO = new clsAccomodationGradeMappingBO();
    DataTable dtLocation = new DataTable();
    DataTable dtCountryMaster = new DataTable();
    DataTable dtGradeMaster = new DataTable();
    DataTable dtAccomadation = new DataTable();
    #endregion
    #region--Page Load--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                Binddropdown();
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    #endregion
    #region--Private Methods--
    /// <summary>
    /// The following method is use to bind country,Grade & Accomodation type.
    /// </summary>
    private void Binddropdown()
    {
        try
        {
            //binding country dropdown
            oclsCountryMasterBD.CFlag = EFlag.ALL.ToString();
            oclsCountryMasterBD.CountryId = 0;
            dtCountryMaster = oclsCountryMasterBO.SelectCountryMaster(oclsCountryMasterBD);
            if (dtCountryMaster != null && dtCountryMaster.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountryMaster;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));                
            }
            else
            {
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no grade available.');</script>");
                ddlCountry.Enabled = btnSave.Enabled = false;
            }
            //ended
            //binding grade dropdown
            oclsGradeMasterBD.CFlag = EFlag.ALL.ToString();
            oclsGradeMasterBD.GradeId = 0;
            dtGradeMaster = new DataView(oclsGradeMasterBO.SelectGradeMaster(oclsGradeMasterBD)).ToTable(false, new string[] { "GradeId", "GradeName" }); 
            if (dtGradeMaster != null && dtGradeMaster.Rows.Count > 0)
            {
                ddlGrade.DataSource = dtGradeMaster;
                ddlGrade.DataTextField =  "GradeName";
                ddlGrade.DataValueField = "GradeId";
                ddlGrade.DataBind();
                ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no grade available.');</script>");
                ddlGrade.Enabled = btnSave.Enabled = false;
            }
            //ended
            //binding Unit dropdown
            DataTable dtUnit = clsUtility.GetMasterValue("AccomodationType");
            if (dtUnit != null && dtUnit.Rows.Count > 0)
            {
                ddlAccType.DataSource = dtUnit;
                ddlAccType.DataValueField = "MasterId";
                ddlAccType.DataTextField = "Value";
                ddlAccType.DataBind();
                ddlAccType.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlAccType.Items.Insert(0, new ListItem("--Select--", "0"));
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no Accomodation type available.');</script>");
                ddlAccType.Enabled = btnSave.Enabled = false;
            }
            //ended
            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
            ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The method use to display all the available Accomodation. 
    /// </summary>
    private void BindListBox()
    {
        try
        {
            oclsAccomodationsBD.CFlag = "CITYACCOMODATIONTYPE";
            oclsAccomodationsBD.MasterID = Int64.Parse(ddlAccType.SelectedValue.ToString());
            oclsAccomodationsBD.CityID = Int64.Parse(ddlCity.SelectedValue.ToString());
            dtAccomadation = oclsAccomodationsBO.SelectAccomodationData(oclsAccomodationsBD);
            if (dtAccomadation != null && dtAccomadation.Rows.Count > 0)
            {
                lsbSource.DataSource = dtAccomadation;
                lsbSource.DataTextField = "AccomodationName";
                lsbSource.DataValueField = "AccomodationID";
                lsbSource.DataBind();
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    ///  The method use to display all the available Accomodation for selected grade and accomodation type
    /// </summary>
    private void BindDestinationList()
    {
        try
        {
            BindListBox();
            oclsAccomodationsBD.CFlag = "CITYACCOMODATIONGRADE";
            oclsAccomodationsBD.MasterID = Int64.Parse(ddlAccType.SelectedValue.ToString());
            oclsAccomodationsBD.CityID = Int64.Parse(ddlCity.SelectedValue.ToString());
            dtAccomadation = oclsAccomodationsBO.SelectAccomodationData(oclsAccomodationsBD, Int64.Parse(ddlGrade.SelectedValue.ToString()));
            lsbDestination.DataSource = dtAccomadation;
            lsbDestination.DataTextField = "AccomodationName";
            lsbDestination.DataValueField = "AccomodationID";
            lsbDestination.DataBind();
            if (lsbDestination.Items.Count > 0)
            {
                for (int i = 0; i < lsbDestination.Items.Count; i++)
                {
                    lsbSource.Items.Remove(lsbDestination.Items[i]);
                }
            }
            else
                BindListBox();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save all the selected accomodation for the paticular grade and city.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            clsManageTransaction.StartTransaction();
            oclsAccomodationGradeMappingBD.GradeId = Int64.Parse(ddlGrade.SelectedValue.ToString());
            oclsAccomodationGradeMappingBO.DeleteAccomodationGradeMapping(oclsAccomodationGradeMappingBD,Int64.Parse(ddlAccType.SelectedValue.ToString()),Int64.Parse(ddlCity.SelectedValue.ToString()));
            clsManageTransaction.EndTransaction();
            int CheckValue = 0;
            oclsAccomodationGradeMappingBD.CFlag = EFlag.INSERT.ToString();
            oclsAccomodationGradeMappingBD.DOC = DateTime.Now;
            oclsAccomodationGradeMappingBD.DOU = DateTime.Now;
            oclsAccomodationGradeMappingBD.Status="Active";
            oclsAccomodationGradeMappingBD.AGMId = 0;
            oclsAccomodationGradeMappingBD.TransactionId = 1;
            foreach (ListItem item in lsbDestination.Items)
	        {
                oclsAccomodationGradeMappingBD.AccomodationId = Int64.Parse(item.Value.ToString());
                clsManageTransaction.StartTransaction();
                oclsAccomodationGradeMappingBO.InsertUpdateAccomodationGradeMapping(oclsAccomodationGradeMappingBD);
                CheckValue += 1;
                clsManageTransaction.EndTransaction();
	        }
            if(lsbDestination.Items.Count==CheckValue)
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Accomodation is alloted to the grade');</script>");
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);           
        }
    }
    /// <summary>
    /// The event is use to clear the  input fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        //Response.Redirect(Request.Path,false);
        Server.Transfer(Request.Path);
    }   
    /// <summary>
    /// The event is use to bind the state for the selected country
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            /*ddlState*/ 
            if (ddlCountry.SelectedValue.ToString() != "0")
            {
                ddlState.Enabled = true;
                ddlCity.DataSource = null;
                dtLocation = new DataView(clsUtility.GetStateData("ByCountry", Int64.Parse(ddlCountry.SelectedValue.ToString()))).ToTable(false, new string[] { "StateId", "StateName" });
                if (dtLocation.Rows.Count > 0)
                {
                    ddlState.DataSource = dtLocation;
                    ddlState.DataTextField = "StateName";
                    ddlState.DataValueField = "StateId";
                    ddlState.DataBind();
                    ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no state available for this country');</script>");
                    ddlState.Enabled = btnSave.Enabled = false;
                }
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);            
        }
    }
    /// <summary>
    /// The event is use to bind city for selected state
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            /*ddlCity*/
            if (ddlState.SelectedValue.ToString() != "0")
            {
                ddlCity.Enabled = true;
                dtLocation = new DataView(clsUtility.GetCityData("ByState", Int64.Parse(ddlState.SelectedValue.ToString()))).ToTable(false, new string[] { "CityId", "CityName" });
                if (dtLocation.Rows.Count > 0)
                {
                    ddlCity.DataSource = dtLocation;
                    ddlCity.DataTextField = "CityName";
                    ddlCity.DataValueField = "CityId";
                    ddlCity.DataBind();
                    ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
                }
                else
                {
                    ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no city available for this state');</script>");
                    ddlCity.Enabled = btnSave.Enabled = false;
                }
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);           
        }
    }
    /// <summary>
    /// The event is use to bind accomodation for selected accomodation type
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlAccType_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlCity.Items.Count > 1 && ddlCity.SelectedValue.ToString() != "0")
                BindListBox();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);            
        }
    }
    /// <summary>
    /// The event is use to bind accomodation for selected city
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlAccType.SelectedValue.ToString() != "0")
                BindListBox();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);            
        }
    }    
    /// <summary>
    /// The event is use to move the available accomodation to destination accomodtion listbox
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnOneRight_Click(object sender, EventArgs e)
    {
        try
        {
            if (lsbSource.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Available Accomodation');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneRight") == 0)
            {
                if (lsbSource.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Available Accomodation');</script>");
                    return;
                }
                for (int i = 0; i < lsbSource.Items.Count; i++)
                {
                    if (lsbSource.Items[i].Selected)
                    {
                        lsbDestination.Items.Add(lsbSource.Items[i]);
                    }
                }
                for (int i = 0; i < lsbDestination.Items.Count; i++)
                {
                    lsbSource.Items.Remove(lsbDestination.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lsbSource.Items.Count; i++)
                {
                    lsbDestination.Items.Add(lsbSource.Items[i]);
                }
                for (int i = 0; i < lsbDestination.Items.Count; i++)
                {
                    lsbSource.Items.Remove(lsbDestination.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);            
        }
    }
    /// <summary>
    /// The event is use to move the available destination accomodtion listbox  back to available
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnAllLeft_Click(object sender, EventArgs e)
    {
        try
        {
            if (lsbDestination.Items.Count == 0)
            {
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('There is no item in Assigned Accomodation');</script>");
                return;
            }
            if (string.Compare(((Button)sender).CommandName.ToString(), "OneLeft") == 0)
            {
                if (lsbDestination.SelectedIndex == -1)
                {
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Please select the item in Assigned Accomodation');</script>");
                    return;
                }

                for (int i = 0; i < lsbDestination.Items.Count; i++)
                {
                    if (lsbDestination.Items[i].Selected)
                    {
                        lsbSource.Items.Add(lsbDestination.Items[i]);
                    }
                }
                for (int i = 0; i < lsbSource.Items.Count; i++)
                {
                    lsbDestination.Items.Remove(lsbSource.Items[i]);
                }
            }
            else
            {
                for (int i = 0; i < lsbDestination.Items.Count; i++)
                {
                    lsbSource.Items.Add(lsbDestination.Items[i]);
                }
                for (int i = 0; i < lsbSource.Items.Count; i++)
                {
                    lsbDestination.Items.Remove(lsbSource.Items[i]);
                }
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);            
        }
    }
    /// <summary>
    /// The event is use to bind accomodation for selected grade
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ddlGrade_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindDestinationList();
    }
    #endregion
}