﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BD;
using Admin.BO;

public partial class Pages_Masters : BasePage
{
    #region --Initializers--
    clsKeywordMasterBO objclsKeywordMasterBO = new clsKeywordMasterBO();
    DataTable KeywordDataTable = new DataTable();
    clsMastersBD objclsMastersBD = new clsMastersBD();
    clsMastersBO objclsMastersBO = new clsMastersBO();
    DataTable objDataTable = new DataTable();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                BindDropdown();
                Bindgrid("ALL", 0);
            }
        }
        catch (Exception ex)
        {
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('" + ex.Message.Replace("'", "") + "');</script>");
        }
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The following method is use to bind Keyword dropdown
    /// </summary>
    private void BindDropdown()
    {
        try
        {
            KeywordDataTable = new DataView(objclsKeywordMasterBO.SelectKeywordMaster()).ToTable(false, new string[] { "KeywordId", "Keyword" });
            if (KeywordDataTable != null && KeywordDataTable.Rows.Count > 0)
            {
                ddlKeyword.DataSource = KeywordDataTable;
                ddlKeyword.DataValueField = "KeywordId";
                ddlKeyword.DataTextField = "Keyword";
                ddlKeyword.DataBind();
                ddlKeyword.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
                btnSave.Enabled = ddlKeyword.Enabled = false;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }

    }
    /// <summary>
    /// The following method is use to bind Masters data to grid
    /// </summary>
    private void Bindgrid(string Flag, Int64 Id)
    {
        try
        {
            objDataTable = objclsMastersBO.SelectMasters(Flag, Id);
            gvMasters.DataSource = objDataTable;
            gvMasters.DataBind();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The following method is use to  clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtKey1.Text = txtKey2.Text = txtKey3.Text = txtKey4.Text = txtKey5.Text = txtAlias.Text = txtValue.Text = string.Empty;
        ddlKeyword.SelectedIndex = 0;
        ddlKeyword.Enabled = true;
        btnSave.Text = "Save";
    }
    #endregion
    #region--Event Handlers--
    /// <summary>
    /// The event is use to save and update Masters
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (ViewState["Masterid"] != null && ViewState["Masterid"].ToString() != "0")
            {
                objclsMastersBD.CFlag = 'U';
                objclsMastersBD.MasterId = Int64.Parse(ViewState["Masterid"].ToString());
            }
            else
            {
                objclsMastersBD.CFlag = 'I';
                objclsMastersBD.MasterId = 0;
            }
            objclsMastersBD.Value = txtValue.Text.Trim();
            objclsMastersBD.Alias = txtAlias.Text.Trim();
            objclsMastersBD.KeywordId = Int64.Parse(ddlKeyword.SelectedValue.ToString());
            objclsMastersBD.Status = "Active";
            objclsMastersBD.TransactionId = 0;
            objclsMastersBD.Key1 = txtKey1.Text.Trim();
            objclsMastersBD.Key2 = txtKey2.Text.Trim();
            objclsMastersBD.Key3 = txtKey3.Text.Trim();
            objclsMastersBD.Key4 = txtKey4.Text.Trim();
            objclsMastersBD.Key5 = txtKey5.Text.Trim();
            clsManageTransaction.StartTransaction();
            if (objclsMastersBO.InsertUpdateMasters(objclsMastersBD) > 0)
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid("ALL", 0);
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Clearfields();
                Bindgrid("ALL", 0);
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
            }
            ViewState["Masterid"] = null;
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvMasters_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        ddlKeyword.SelectedIndex = ddlKeyword.Items.IndexOf(ddlKeyword.Items.FindByText(gvMasters.Rows[e.RowIndex].Cells[0].Text));
        txtValue.Text = gvMasters.Rows[e.RowIndex].Cells[1].Text;
        //txtAlias.Text = gvMasters.Rows[e.RowIndex].Cells[2].Text;        
        txtKey1.Text = gvMasters.Rows[e.RowIndex].Cells[2].Text == "&nbsp;" ? string.Empty : gvMasters.Rows[e.RowIndex].Cells[2].Text;
        txtKey2.Text = gvMasters.Rows[e.RowIndex].Cells[3].Text == "&nbsp;" ? string.Empty : gvMasters.Rows[e.RowIndex].Cells[3].Text;
        txtKey3.Text = gvMasters.Rows[e.RowIndex].Cells[4].Text == "&nbsp;" ? string.Empty : gvMasters.Rows[e.RowIndex].Cells[4].Text;
        txtKey4.Text = gvMasters.Rows[e.RowIndex].Cells[5].Text == "&nbsp;" ? string.Empty : gvMasters.Rows[e.RowIndex].Cells[5].Text;
        txtKey5.Text = gvMasters.Rows[e.RowIndex].Cells[6].Text == "&nbsp;" ? string.Empty : gvMasters.Rows[e.RowIndex].Cells[6].Text;
        ddlKeyword.Enabled = false;
        btnSave.Text = "Update";
    }
    /// <summary>
    /// The event is use to update and delete Masters
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvMasters_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            if (e.CommandName == "Update")
                ViewState["Masterid"] = e.CommandArgument.ToString();
            else if (string.Compare(e.CommandName.ToUpper(), "DELETE") == 0)
            {
                objclsMastersBD.MasterId = Int64.Parse(e.CommandArgument.ToString());
                objclsMastersBD.Status = "Inactive";
                objclsMastersBD.TransactionId = 0;
                clsManageTransaction.StartTransaction();
                if (objclsMastersBO.DeleteMasters(objclsMastersBD) > 0)
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid("ALL", 0);
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Successfully done');</script>");
                }
                else
                {
                    clsManageTransaction.EndTransaction();
                    Clearfields();
                    Bindgrid("ALL", 0);
                    Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    protected void gvMasters_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvMasters_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvMasters.PageIndex = e.NewPageIndex;
            Bindgrid("ALL", 0);
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is used to filter the master records by selected keyword.
    /// </summary>
    /// <param name="sender">object</param>
    /// <param name="e">EventArgs</param>
    protected void ddlKeyword_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            Bindgrid("KEYWORD", Convert.ToInt64(ddlKeyword.SelectedValue));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion
}

