﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Admin.BD;
using Admin.BO;
using System.Data;

public partial class Pages_PetrolPolicy : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ViewState["PPID"] = 0;
                BindGrade();
                BindPetrolPolicy();
                BindUnits();
                ShowMessage(string.Empty);
                Session["PP"] = Server.UrlEncode(System.DateTime.Now.ToString());
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    protected void Page_PreRender(object sender, EventArgs e)
    {
        ViewState["PP"] = Session["PP"];
    }


    private void BindUnits()
    {
        try
        {
            ddlLimitUnit.DataSource = clsUtility.GetMasterValue("LimitUnit");
            ddlLimitUnit.DataTextField = "Value";
            ddlLimitUnit.DataValueField = "MasterId";
            ddlLimitUnit.DataBind();
            ddlLimitUnit.Items.Insert(0, new ListItem("--Select--", "0"));

            ddlPUnit.DataSource = clsUtility.GetMasterValue("PeriodUnit");
            ddlPUnit.DataTextField = "Value";
            ddlPUnit.DataValueField = "MasterId";
            ddlPUnit.DataBind();
            ddlPUnit.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }

    private void BindGrade()
    {
        clsGradeMasterBD oGradeMasterBD = new clsGradeMasterBD();
        oGradeMasterBD.CFlag = "PARENT";
        oGradeMasterBD.GradeId = 0;
        clsGradeMasterBO oGradeMasterBO = new clsGradeMasterBO();
        DataTable dtGrade = oGradeMasterBO.SelectGradeMaster(oGradeMasterBD);
        ddlGrade.DataSource = dtGrade;
        ddlGrade.DataTextField = "GradeName";
        ddlGrade.DataValueField = "GradeId";
        ddlGrade.DataBind();
        ddlGrade.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    /// <summary>
    /// 
    /// </summary>
    private void BindPetrolPolicy()
    {
        try
        {
            DataTable dtPetrolPolicy = (new clsPetrolPoliciesBO()).SelectPetrolPolicies("ALL", 0);
            gvPetrolPolicy.DataSource = dtPetrolPolicy;
            gvPetrolPolicy.DataBind();

            //ddlParentProcess.DataSource = dtProcess;
            //ddlParentProcess.DataTextField = "ProcessName";
            //ddlParentProcess.DataValueField = "ProcessId";
            //ddlParentProcess.DataBind();
            //ddlParentProcess.Items.Insert(0, new ListItem("--Parent--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update process
    /// </summary>
    /// <param name="Flag"></param>
    /// <returns></returns>
    private long InsertOrUpdatePetrolPolicy(string Flag)
    {
        try
        {

            long PPId = 0;
            clsPetrolPoliciesBO oPetrolPoliciesBO = new clsPetrolPoliciesBO();
            clsPetrolPoliciesBD oPetrolPoliciesBD = new clsPetrolPoliciesBD();
            oPetrolPoliciesBD.PPId = Convert.ToInt64(ViewState["PPID"]);
            oPetrolPoliciesBD.GradeId = Convert.ToInt64(ddlGrade.SelectedValue);
            oPetrolPoliciesBD.Limit = Convert.ToDecimal(txtLimit.Text.Trim());
            oPetrolPoliciesBD.Unit = ddlLimitUnit.SelectedItem.Text;
            oPetrolPoliciesBD.Period = Convert.ToDecimal(txtPeriod.Text.Trim());
            oPetrolPoliciesBD.PUnit = ddlPUnit.SelectedItem.Text;
            oPetrolPoliciesBD.Alias = txtAlias.Text.Trim();
            oPetrolPoliciesBD.Status = "Active";
            oPetrolPoliciesBD.DOC = DateTime.Now;
            oPetrolPoliciesBD.DOU = DateTime.Now;
            oPetrolPoliciesBD.TransactionId = 1;

            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            PPId = oPetrolPoliciesBO.InsertUpdatePetrolPolicies(oPetrolPoliciesBD, Flag);
            ViewState["PPID"] = 0;
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................

            return PPId;
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="ProcessId"></param>
    private void SetControls(Int64 PPId)
    {
        try
        {
            ViewState["PPID"] = PPId;
            clsPetrolPoliciesBD oPetrolPoliciesBD = new clsPetrolPoliciesBD();
            oPetrolPoliciesBD.PPId = PPId;
            DataTable dtPetrolPolicies = (new clsPetrolPoliciesBO()).SelectPetrolPolicies("PPID", PPId);
            if (dtPetrolPolicies.Rows.Count > 0)
            {
                string GradeId = Convert.ToString(dtPetrolPolicies.Rows[0]["GradeId"]);
                ListItem GradeItem = ddlGrade.Items.FindByValue(GradeId) as ListItem;
                if (GradeItem != null)
                {
                    ddlGrade.ClearSelection();
                    GradeItem.Selected = true;
                }
                txtLimit.Text = Convert.ToString(dtPetrolPolicies.Rows[0]["Limit"]);
                string Unit = Convert.ToString(dtPetrolPolicies.Rows[0]["Unit"]);
                ListItem UnitItem = ddlLimitUnit.Items.FindByText(Unit) as ListItem;
                if (UnitItem != null)
                {
                    ddlLimitUnit.ClearSelection();
                    UnitItem.Selected = true;
                }
                txtPeriod.Text = Convert.ToString(dtPetrolPolicies.Rows[0]["Period"]);

                string PUnit = Convert.ToString(dtPetrolPolicies.Rows[0]["PUnit"]);
                ListItem PUnitItem = ddlPUnit.Items.FindByText(PUnit) as ListItem;
                if (PUnitItem != null)
                {
                    ddlPUnit.ClearSelection();
                    PUnitItem.Selected = true;
                }
                txtAlias.Text = Convert.ToString(dtPetrolPolicies.Rows[0]["Alias"]);
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (Session["PP"].ToString() == ViewState["PP"].ToString())
            {
                Session["PP"] = Server.UrlEncode(System.DateTime.Now.ToString()); string Flag = EFlag.INSERT.ToString();
                if (Convert.ToInt64(ViewState["PPID"]) > 0)
                {
                    Flag = EFlag.UPDATE.ToString();
                }
                InsertOrUpdatePetrolPolicy(Flag);
                Response.Redirect(Request.Path + "?MSG=" + Flag, false);
            }
            else
            {
                Response.Redirect(Request.Path, false);
            }
        }
        catch (Exception ex)
        {

            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }
    /// <summary>
    /// The event is use to clear i/p fields
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
    }
    /// <summary>
    /// The event is use to update process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPetrolPolicy_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            Int64 PPId = Convert.ToInt64(gvPetrolPolicy.DataKeys[e.RowIndex].Value);
            SetControls(PPId);
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// To delete(make inactive) Process
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPetrolPolicy_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            Int64 PPId = Convert.ToInt64(gvPetrolPolicy.DataKeys[e.RowIndex].Value);
            //START:Handling the Transaction............................................
            clsManageTransaction.StartTransaction();
            (new clsPetrolPoliciesBO()).DeletePetrolPolicies(PPId);
            clsManageTransaction.EndTransaction();
            //END:Handling the Transaction..............................................
            Response.Redirect(Request.Path + "?MSG=" + EFlag.DELETE.ToString(), false);
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Not Successfully done');</script>");
        }
    }

}
