﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
public partial class UserControls_ucMenu : System.Web.UI.UserControl
{
    public long? EmployeeCode { get; set; }
    long? lRoleCode = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        PopulateMenu();
    }

    void PopulateMenu()
    {
        if (Session["RoleId"] != null)
        {
            Int64 lRoleCode = Convert.ToInt64(Session["RoleId"]);
            if (Session["Modules"] == null)
            {
                Session["Modules"] = (new clsProcessBO()).GetProcessByParent(0, lRoleCode);
            }
            if (Session["Modules"] != null)
            {
                List<clsProcessBD> oProcessList = new List<clsProcessBD>();
                oProcessList = Session["Modules"] as List<clsProcessBD>;
                foreach (clsProcessBD oProcess in oProcessList)
                {
                    AddSubMenu(oProcess, mnuEMS.Items, lRoleCode);
                }
            }
        }
    }
    private void AddSubMenu(clsProcessBD oProcessBD, MenuItemCollection objMenuItemCollection, long? lRoleCode)
    {
        string DefaultURL = oProcessBD.DefaultURL;
        MenuItem obj;
        clsProcessBO oProcessBO = new clsProcessBO();
        List<clsProcessBD> subProcessList = oProcessBO.GetProcessByParent(oProcessBD.ProcessId, lRoleCode);
        if (subProcessList.Count <= 0)
        {
            obj = new MenuItem(oProcessBD.ProcessName, Convert.ToString(oProcessBD.ProcessId), "", DefaultURL);
        }
        else
        {
            obj = new MenuItem(oProcessBD.ProcessName, Convert.ToString(oProcessBD.ProcessId));
            obj.Selectable = false;
        }
        objMenuItemCollection.Add(obj);
        List<clsProcessBD> ProcessList = oProcessBO.GetProcessByParent(oProcessBD.ProcessId, lRoleCode);
        foreach (clsProcessBD osubProcess in ProcessList)
        {
            AddSubMenu(osubProcess, obj.ChildItems, lRoleCode);
        }
    }

}
