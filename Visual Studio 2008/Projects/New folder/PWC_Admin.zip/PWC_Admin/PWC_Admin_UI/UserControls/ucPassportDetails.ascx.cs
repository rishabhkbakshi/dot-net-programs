﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;
using Admin.BD;
using Admin.BO;

public partial class UserControls_ucPassportDetails : System.Web.UI.UserControl
{
    private int _Flag;
    public int Flag
    {
        set
        {
            _Flag = value;
            if (_Flag == 1)
            {
                BindEmployee();
            }
        }
    }

    #region --Initializers--
    clsEmployeeBO oclsEmployeeBO = new clsEmployeeBO();
    clsEmployeeBD oclsEmployeeBD = new clsEmployeeBD();
    clsPassportDetailsBD objclsPassportDetailsBD = new clsPassportDetailsBD();
    clsPassportDetailsBO objclsPassportDetailsBO = new clsPassportDetailsBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
        //dtFormat.ShortDatePattern = "dd/MM/yyyy";
        dtFormat.ShortDatePattern = "MM/dd/yyyy";

        if (!IsPostBack)
        {
            BindCountry();
            BindEmployee();
            BindPassportDetailsData();
            //BindInitialValue();
            //rvPassportIssueDate.MinimumValue = Convert.ToDateTime("09/09/1999").ToString("MM/dd/yyyy");
            //rvPassportIssueDate.MaximumValue = Convert.ToDateTime(DateTime.Now).ToString("MM/dd/yyyy");
        }
    }
    #endregion
    #region --private methods--
    /// <summary>
    /// The method is use to bind the initial value of control 
    /// </summary>
    private void BindInitialValue()
    {
        ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
        ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
    }
    /// <summary>
    /// The method is use to bind the Country
    /// </summary>
    private void BindCountry()
    {
        try
        {
            DataTable dtCountry = clsUtility.GetCountryData("ALL", 0);
            if (dtCountry != null && dtCountry.Rows.Count > 0)
            {
                ddlCountry.DataSource = dtCountry;
                ddlCountry.DataValueField = "CountryId";
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlCountry.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The method is use to bind the Employee 
    /// </summary>
    private void BindEmployee()
    {
        try
        {
            oclsEmployeeBD.CFlag = "ALL";
            oclsEmployeeBD.EmployeeId = 0;
            DataTable dtEmployee = oclsEmployeeBO.SelectEmployee(oclsEmployeeBD);
            if (dtEmployee != null && dtEmployee.Rows.Count > 0)
            {
                ddlEmployeeName.DataSource = dtEmployee;
                ddlEmployeeName.DataValueField = "EmployeeId";
                ddlEmployeeName.DataTextField = "EmployeeName";
                ddlEmployeeName.DataBind();
                ddlEmployeeName.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlEmployeeName.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The method is use to bind the PassportDetails in grid 
    /// </summary>
    private void BindPassportDetailsData()
    {
        try
        {
            DataTable dtPassportDetails = objclsPassportDetailsBO.SelectPassportDetailsData(0);
            if (dtPassportDetails != null && dtPassportDetails.Rows.Count > 0)
            {
                gvPassportDetails.DataSource = dtPassportDetails;
                gvPassportDetails.DataBind();
            }
            else
            {
                gvPassportDetails.DataSource = null;
                gvPassportDetails.DataBind();
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The method is use to bind the PassportDetails in grid 
    /// </summary>
    private void BindPassportDetailsDataEmployeeWise(string EmployeeId)
    {
        try
        {
            long employeeId = Convert.ToInt64(EmployeeId);
            DataTable dtPassportDetails = objclsPassportDetailsBO.SelectPassportDetailsDataEmployeeWise(employeeId);
            if (dtPassportDetails != null && dtPassportDetails.Rows.Count > 0)
            {
                gvPassportDetails.DataSource = dtPassportDetails;
                gvPassportDetails.DataBind();
            }
            else
            {
                gvPassportDetails.DataSource = null;
                gvPassportDetails.DataBind();
            }
        }
        catch (Exception ex)
        {

            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to save and update PassportDetails 
    /// </summary>
    private void SavePassportDetails()
    {
        try
        {
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "dd/MM/yyyy";
            bool Flag = true;
            int result = DateTime.Compare(Convert.ToDateTime(txtPassportIssueDate.Text.Trim(), dtFormat), Convert.ToDateTime(txtPassportExpiryDate.Text.Trim(), dtFormat));
            if (result > 0)
            {
                lblMsg.Text = "Passport issue date should be greater than passport expiry date.";
                return;
            }
            if (string.Compare(Convert.ToString(Convert.ToDateTime(txtPassportIssueDate.Text, dtFormat)), Convert.ToString(Convert.ToDateTime(txtPassportExpiryDate.Text, dtFormat))) == 0)
            {
                lblMsg.Text = "Passport cannot be issued and expired on same date.";
                return;
            }
            if (ViewState["PASSPORTDETAILSID"] != null && ViewState["PASSPORTDETAILSID"].ToString() != "0")
            {
                objclsPassportDetailsBD.CFlag = EFlag.UPDATE.ToString();
                objclsPassportDetailsBD.PassportDetailsId = Int64.Parse(ViewState["PASSPORTDETAILSID"].ToString());
                Flag = false;
            }
            else
            {
                objclsPassportDetailsBD.CFlag = EFlag.INSERT.ToString();
                objclsPassportDetailsBD.PassportDetailsId = 0;
            }
            objclsPassportDetailsBD.EmployeeId = Int64.Parse(ddlEmployeeName.SelectedValue.ToString());
            objclsPassportDetailsBD.PassportNo = txtPassportNo.Text.Trim();
            objclsPassportDetailsBD.CountryId = Int64.Parse(ddlCountry.SelectedValue.ToString());
            objclsPassportDetailsBD.StateId = Int64.Parse(ddlState.SelectedValue.ToString());
            objclsPassportDetailsBD.CityId = Int64.Parse(ddlCity.SelectedValue.ToString());
            objclsPassportDetailsBD.PassportIssueDate = Convert.ToDateTime(txtPassportIssueDate.Text.Trim(), dtFormat);
            objclsPassportDetailsBD.PassportExpiryDate = Convert.ToDateTime(txtPassportExpiryDate.Text.Trim(), dtFormat);
            objclsPassportDetailsBD.Status = "Active";
            objclsPassportDetailsBD.DOC = DateTime.Now;
            objclsPassportDetailsBD.DOU = DateTime.Now;
            objclsPassportDetailsBD.TransactionId = 0;

            clsManageTransaction.StartTransaction();
            if (objclsPassportDetailsBO.InsertUpdatePassportDetails(objclsPassportDetailsBD))
            {
                clsManageTransaction.EndTransaction();
                if (Flag)
                {
                    lblMsg.Text = "Passport Saved Successfully.";
                }
                else
                {
                    lblMsg.Text = "Passport Updated Successfully.";
                }
            }
            else
            {
                clsManageTransaction.EndTransaction();
                lblMsg.Text = "Passport Details for the Employee already exists";
            }
            Clearfields();
            BindPassportDetailsData();
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    /// <summary>
    /// The following method is use  to clear i/p fields
    /// </summary>
    private void Clearfields()
    {
        txtPassportExpiryDate.Text = txtPassportIssueDate.Text = txtPassportNo.Text = string.Empty;
        ddlEmployeeName.SelectedIndex = 0;
        ddlCountry.SelectedIndex = 0;
        ddlState.SelectedIndex = 0;
        ddlCity.SelectedIndex = 0;
        btnSave.Text = "Save";
    }
    private void BindState(long CountryId)
    {
        try
        {
            DataTable dtStateVA = clsUtility.GetStateData("ByCountry", CountryId);
            if (dtStateVA != null && dtStateVA.Rows.Count > 0)
            {
                ddlState.DataSource = dtStateVA;
                ddlState.DataValueField = "StateId";
                ddlState.DataTextField = "StateName";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
            }
            else
            {
                ddlState.Items.Clear();
                ddlState.Items.Insert(0, new ListItem("--Select--", "0"));
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    private void BindCity(long StateId)
    {
        try
        {
            DataTable dtCityVA = clsUtility.GetCityData("ByState", StateId);
            ddlCity.DataSource = dtCityVA;
            ddlCity.DataValueField = "CityId";
            ddlCity.DataTextField = "CityName";
            ddlCity.DataBind();
            ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    #region--Event Handlers--
    protected void btnSave_Click(object sender, EventArgs e)
    {
        SavePassportDetails();
    }
    protected void btnCance_Click(object sender, EventArgs e)
    {
        Clearfields();
    }
    protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCountry.SelectedIndex > 0)
        {
            long CountryId = Int64.Parse(ddlCountry.SelectedValue.ToString());
            BindState(CountryId);

        }
        else
        {
            ddlState.Items.Insert(0, new ListItem("--Select--", "0"));

        }
    }
    protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlState.SelectedIndex > 0)
        {
            //long CityId = Int64.Parse(ddlState.SelectedValue.ToString());
            long StateId = Int64.Parse(ddlState.SelectedValue.ToString());
            BindCity(StateId);

        }
        else
        {
            ddlCity.Items.Insert(0, new ListItem("--Select--", "0"));

        }
    }
    /// <summary>
    /// The event is use to display data in i/p fields while updating
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPassportDetails_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            DateTimeFormatInfo dtFormat = new DateTimeFormatInfo();
            dtFormat.ShortDatePattern = "dd/MM/yyyy";
            Int64 PassportDetailsId = Int64.Parse(gvPassportDetails.DataKeys[e.RowIndex].Values[0].ToString());
            ViewState["PASSPORTDETAILSID"] = PassportDetailsId;
            DataTable dtPassportDetails = objclsPassportDetailsBO.SelectPassportDetailsData(PassportDetailsId);
            if (dtPassportDetails != null && dtPassportDetails.Rows.Count > 0)
            {
                ddlEmployeeName.SelectedValue = dtPassportDetails.Rows[0]["EmployeeId"].ToString();
                txtPassportNo.Text = dtPassportDetails.Rows[0]["PassportNo"].ToString();
                ddlCountry.SelectedValue = dtPassportDetails.Rows[0]["CountryId"].ToString();
                BindState(Int64.Parse(ddlCountry.SelectedValue));
                ListItem StateItem = ddlState.Items.FindByValue(Convert.ToString(dtPassportDetails.Rows[0]["StateId"])) as ListItem;
                if (StateItem != null)
                {
                    ddlState.ClearSelection();
                    StateItem.Selected = true;
                }
                BindCity(Int64.Parse(ddlState.SelectedValue));
                ListItem CityItem = ddlCity.Items.FindByValue(Convert.ToString(dtPassportDetails.Rows[0]["CityId"])) as ListItem;
                if (CityItem != null)
                {
                    ddlCity.ClearSelection();
                    CityItem.Selected = true;
                }
                txtPassportIssueDate.Text = Convert.ToDateTime(dtPassportDetails.Rows[0]["PassportIssueDate"], dtFormat).ToString("dd/MM/yyyy");
                txtPassportExpiryDate.Text = Convert.ToDateTime(dtPassportDetails.Rows[0]["PassportExpiryDate"], dtFormat).ToString("dd/MM/yyyy");
                btnSave.Text = "Update";
            }
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    /// <summary>
    /// The event is use to delete(make inactive) the particullar acc. rate
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPassportDetails_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        try
        {
            Int64 PassportDetailsId = Int64.Parse(gvPassportDetails.DataKeys[e.RowIndex].Values[0].ToString());
            clsManageTransaction.StartTransaction();
            if (objclsPassportDetailsBO.DeletePassportDetails(PassportDetailsId))
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record deleted successfully');</script>");
            }
            else
            {
                clsManageTransaction.EndTransaction();
                Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
            Page.RegisterStartupScript("alert", "<script language=JavaScript>alert('Record not deleted');</script>");
        }
        BindPassportDetailsData();
    }
    /// <summary>
    /// The event is use to move across pages in grid
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void gvPassportDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvPassportDetails.PageIndex = e.NewPageIndex;
            BindPassportDetailsData();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
            throw ex;
        }
    }
    #endregion
    protected void ddlEmployeeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlEmployeeName.SelectedIndex > 0)
            {
                BindPassportDetailsDataEmployeeWise(ddlEmployeeName.SelectedValue);
            }
            else
            {
                BindPassportDetailsData();
            }

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
}
