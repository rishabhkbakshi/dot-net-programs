﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.IO;
public partial class UserControls_ucDocuments : BaseControl
{
    #region "Public properties"

    public Int64 ProcessId { get; set; }
    public Int64 TravelRequestId { get; set; }

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    public void SaveDocuments()
    {
        try
        {
            string DocumentLocation_Temp = clsUtility.GetFromWebConfig("DocumentLocation_Temp");
            List<clsDocumentsBD> DocumentsList;
            if (Session["DOCUMENTSLIST"] != null && ProcessId > 0 && TravelRequestId > 0)
            {
                DocumentsList = Session["DOCUMENTSLIST"] as List<clsDocumentsBD>;
                foreach (clsDocumentsBD oDocumentsBD in DocumentsList)
                {
                    string sourceFilePath = DocumentLocation_Temp + oDocumentsBD.GUID + oDocumentsBD.FileName;
                    string destinationFilePath = oDocumentsBD.Location + oDocumentsBD.GUID + oDocumentsBD.FileName;
                    if (File.Exists(sourceFilePath))
                    {
                        File.Move(sourceFilePath, destinationFilePath);
                        oDocumentsBD.Flag = oDocumentsBD.DocumentId > 0 ? EFlag.UPDATE.ToString() : EFlag.INSERT.ToString();
                        oDocumentsBD.ProcessId = ProcessId;
                        oDocumentsBD.TravelRequestId = TravelRequestId;
                        clsManageTransaction.StartTransaction(); 
                        (new clsDocumentsBO()).InsertUpdateDocuments(oDocumentsBD);
                        clsManageTransaction.EndTransaction();
                    }
                }
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            throw ex;
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string DocumentLocation = clsUtility.GetFromWebConfig("DocumentLocation");
            string DocumentLocation_Temp = clsUtility.GetFromWebConfig("DocumentLocation_Temp");
            List<clsDocumentsBD> DocumentsList;
            clsDocumentsBD oDocumentsBD;
            string sGUID = Convert.ToString(Guid.NewGuid());
            string FilePath = DocumentLocation_Temp + sGUID + fuDocuments.FileName;

            fuDocuments.SaveAs(FilePath);
            if (Session["DOCUMENTSLIST"] != null)
            {
                DocumentsList = Session["DOCUMENTSLIST"] as List<clsDocumentsBD>;
            }
            else
            {
                DocumentsList = new List<clsDocumentsBD>();
            }
            if (ViewState["INDEX"] != null)
            {
                oDocumentsBD = DocumentsList[Convert.ToInt16(ViewState["INDEX"])];
            }
            else
            {
                oDocumentsBD = new clsDocumentsBD();
                oDocumentsBD.DocumentId = 0;
                oDocumentsBD.ProcessId = 0;
                oDocumentsBD.TravelRequestId = 0;
            }
            oDocumentsBD.ReferenceName = string.Empty;
            oDocumentsBD.Remark = txtRemark.Text;
            oDocumentsBD.FileName = fuDocuments.FileName;
            oDocumentsBD.GUID = sGUID;
            oDocumentsBD.Location = DocumentLocation;
            oDocumentsBD.Status = "Active";
            oDocumentsBD.DOC = DateTime.Now;
            oDocumentsBD.DOU = DateTime.Now;
            oDocumentsBD.TransactionId = 0;
            if (ViewState["INDEX"] == null)
            {
                DocumentsList.Add(oDocumentsBD);
            }
            Session["DOCUMENTSLIST"] = DocumentsList;
            gvDocument.DataSource = DocumentsList;
            gvDocument.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvDocument_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            List<clsDocumentsBD> DocumentsList;
            clsDocumentsBD oDocumentsBD;
            if (Session["DOCUMENTSLIST"] != null)
            {
                DocumentsList = Session["DOCUMENTSLIST"] as List<clsDocumentsBD>;
                oDocumentsBD = DocumentsList[e.RowIndex];

                string DocumentLocation_Temp = clsUtility.GetFromWebConfig("DocumentLocation_Temp");
                string FilePath = string.Empty;
                ViewState["INDEX"] = e.RowIndex;
                FilePath = DocumentLocation_Temp + oDocumentsBD.GUID + oDocumentsBD.FileName;
                FileDownload(FilePath);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void gvDocument_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            List<clsDocumentsBD> DocumentsList;
            string DocumentLocation_Temp = clsUtility.GetFromWebConfig("DocumentLocation_Temp");
            string FilePath=string.Empty;
            if (Session["DOCUMENTSLIST"] != null)
            {
                DocumentsList = Session["DOCUMENTSLIST"] as List<clsDocumentsBD>;
                clsDocumentsBD oDocumentsBD = new clsDocumentsBD();
                oDocumentsBD = DocumentsList[e.RowIndex];
                Int64 DocumentId = Convert.ToInt64(gvDocument.DataKeys[e.RowIndex].Value);
                if (DocumentId > 0)
                {
                    clsManageTransaction.StartTransaction();
                    oDocumentsBD.Flag = string.Empty;
                    oDocumentsBD.DocumentId = DocumentId;
                    (new clsDocumentsBO()).DeleteDocuments(oDocumentsBD);
                    clsManageTransaction.EndTransaction();
                }
                FilePath = DocumentLocation_Temp + oDocumentsBD.GUID + oDocumentsBD.FileName;
                if(File.Exists(FilePath))
                {
                    File.Delete(FilePath);
                }
                DocumentsList.RemoveAt(e.RowIndex);
                gvDocument.DataSource = DocumentsList;
                gvDocument.DataBind();
            }
        }
        catch (Exception ex)
        {
            clsManageTransaction.RollBackTransaction();
            throw ex;
        }
    }
}
