﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using Admin.BO;
using Admin.BD;
public partial class SignIn : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //int iOne = 1;
            //int iZero = 0;
            //int iResult = iOne / iZero;

            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();

            ////Clear cookies
            //string[] cookies = Request.Cookies.AllKeys;
            //foreach (string cookie in cookies)
            //{
            //    Response.Cookies[cookie].Expires = DateTime.Now.AddDays(-1);
            //}
            SetCalender();
        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }

    private void SetCalender()
    {
        DataSet dsHoliday = new DataSet();
        string strHoliday;
        strHoliday = Server.MapPath(@"XMLs/HolidayList.xml");
        dsHoliday.ReadXml(strHoliday);
        if (dsHoliday.Tables["Event"].Rows.Count != 0)
        {
            rptHoliday.DataSource = dsHoliday.Tables["Event"];
            rptHoliday.DataBind();
        }
        txtLoginId.Focus();
    }
    protected void btnSignIn_Click(object sender, EventArgs e)
    {
        try
        {
            if (!string.IsNullOrEmpty(txtLoginId.Text.Trim()) && !string.IsNullOrEmpty(txtPassword.Text.Trim()))
            {
                List<AuthenticationBD> AuthenticationList = new List<AuthenticationBD>();
                AuthenticationList = clsAuthenticationBO.AuthenticateUser(txtLoginId.Text.Trim(), txtPassword.Text.Trim());
                if (AuthenticationList != null && AuthenticationList.Count > 0)
                {
                    Session["USERDETAILS"] = AuthenticationList;
                    Session["EmployeeID"] = AuthenticationList[0].EmployeeId;
                    Session["RoleId"] = AuthenticationList[0].RoleId;
                    Session["SESSIONID"] = AuthenticationList[4].SessionId;
                    lblMessage.Text = string.Empty;
                    Response.Redirect("Pages/Dashboard.aspx", false);
                }
                else
                {
                    lblMessage.Text = "Invalid Login Id / Password.";
                }
            }
            txtLoginId.Focus();
            txtLoginId.Text = string.Empty;

        }
        catch (Exception ex)
        {
            clsErrorLogBO.WriteErrorLog_Text(ex);
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect(Request.Path, false);
    }
}
