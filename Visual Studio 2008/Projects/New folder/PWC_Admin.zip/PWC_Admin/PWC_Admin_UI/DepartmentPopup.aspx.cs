﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Admin.BD;
using Admin.BO;
using System.Data;
public partial class DepartmentPopup : BasePage
{
    #region --Initializers--
    clsEmployeeBO objclsEmployeeBO = new clsEmployeeBO();
    #endregion
    #region --Pageload Method--
    /// <summary>
    /// The event take place each time page is loaded
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        BindTreeView();
    }

    #endregion
    private void BindTreeView()
    {
        if (Session["OrganisationStructure"] == null)
        {
            Session["OrganisationStructure"] = (new clsOrganizationStructureBO()).GetOrganisationStructure(0);
        }
        if (Session["OrganisationStructure"] != null)
        {
            List<clsOrganizationStructureBD> oOrganizationStructureList = new List<clsOrganizationStructureBD>();
            oOrganizationStructureList = Session["OrganisationStructure"] as List<clsOrganizationStructureBD>;
            foreach (clsOrganizationStructureBD oOrganizationStructure in oOrganizationStructureList)
            {
                AddNodes(oOrganizationStructure, tvOrganisationStructure.Nodes);
            }
        }
    }
    private void AddNodes(clsOrganizationStructureBD oOrganizationStructureBD, TreeNodeCollection oTreeNodeCollection)
    {
        TreeNode obj;
        clsOrganizationStructureBO oOrganizationStructureBO = new clsOrganizationStructureBO();
        obj = new TreeNode(oOrganizationStructureBD.Name, Convert.ToString(oOrganizationStructureBD.OrganisationStructureId));
        oTreeNodeCollection.Add(obj);
        List<clsOrganizationStructureBD> OrganizationStructureList = oOrganizationStructureBO.GetOrganisationStructure(oOrganizationStructureBD.OrganisationStructureId);
        foreach (clsOrganizationStructureBD oSubOrganizationStructure in OrganizationStructureList)
        {
            AddNodes(oSubOrganizationStructure, obj.ChildNodes);
        }
    }
}