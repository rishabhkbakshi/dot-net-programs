
--CREATE DATABASE PWCTravelAdmin
Go

USE PwcTravelAdmin
GO

--DROP TABLE Keywords
CREATE TABLE Keywords
(
	KeywordId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Keyword			NVARCHAR(50),
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)
GO

--DROP TABLE Masters
CREATE TABLE Masters
(
	MasterId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Value			NVARCHAR(200),
	KeywordId		BIGINT FOREIGN KEY REFERENCES Keywords(KeywordId) NOT NULL,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)
GO
--15062012
--DROP  TABLE Processes
CREATE TABLE Processes
(
	ProcessId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ProcessName		NVARCHAR(200),
	ParentId		BIGINT,
	NeedDocumentMgt	BIT,
	NeedApprovers	BIT,
	NeedEnforceSLA	BIT,
	DefaultURL		NVARCHAR(100),
	OnErrorURL		NVARCHAR(100),
	SequenceNo		INT,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25)
)
GO
CREATE TABLE OrganisationStructureType
(
	OrganisationStructureTypeId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Name						NVARCHAR(100),
	IsMultiple					BIT,
	Alias						NVARCHAR(100),
	DOC							DATETIME,
	DOU							DATETIME,
	[Status]					NVARCHAR(25),
	TransactionId				BIGINT
)


GO
CREATE TABLE OrganisationStructure
(
	OrganisationStructureId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Name						NVARCHAR(100),
	OrganisationStructureTypeId	BIGINT FOREIGN KEY REFERENCES OrganisationStructureType(OrganisationStructureTypeId) NOT NULL,
	Alias						NVARCHAR(100),
	DOC							DATETIME,
	DOU							DATETIME,
	[Status]					NVARCHAR(25),
	TransactionId				BIGINT
)

GO
CREATE TABLE Roles
(
	RoleId					BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	Name					NVARCHAR(100),
	OrganisationStructureId	BIGINT FOREIGN KEY REFERENCES OrganisationStructure(OrganisationStructureId) NOT NULL,
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)


GO
CREATE TABLE Authorizations
(
	AuthorizationId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	RoleId			BIGINT FOREIGN KEY REFERENCES Roles(RoleId) NOT NULL,
	ProcessId		BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	IsModify		BIT,
	IsDelete		BIT,
	IsSelect		BIT,
	IsView			BIT,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO

CREATE TABLE Employee
(
	EmployeeId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	EmployeeCode		NVARCHAR(50),
	FirstName			NVARCHAR(25),
	LastName			NVARCHAR(25),
	Gender				NVARCHAR(25),
	ReportingManager	BIGINT,
	DelegatationTo		BIGINT,
	Email				NVARCHAR(50),
	PersonalPhoneNo		NVARCHAR(20),
	PersonalVehicleNo	NVARCHAR(20),
	CompanyPhoneNo		NVARCHAR(20),
	CompanyVehicleNo	NVARCHAR(20),
	IsSelfApproved		BIT,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)
GO
CREATE TABLE Authentications
(
	AuthenticationId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	EmployeeId			BIGINT FOREIGN KEY REFERENCES Employee(EmployeeId) NOT NULL,
	Mode				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	ALogin				NVARCHAR(50),
	APassword			NVARCHAR(50),
	IPAddress			NVARCHAR(50),
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE Sessions
(
	SessionId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	EmployeeId			BIGINT FOREIGN KEY REFERENCES Employee(EmployeeId) NOT NULL,
	Mode				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	LogoutTime			DATETIME,
	LastActivity		DATETIME,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE Transactions
(
	TransactionId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	SessionId			BIGINT FOREIGN KEY REFERENCES [Sessions](SessionId) NOT NULL,
	ProcessId			BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	EndDateTime			DATETIME,
	LastActivity		DATETIME,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
)

GO
CREATE TABLE TravelPolicy
(
	TravelPolicyId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId					BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	TravelType				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Gender					NVARCHAR(25),
	DurationOfTravel		NUMERIC(10,2),
	Unit					BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	DefaultModeOfTravel		NVARCHAR(50),
	DefaultClassOfTravel	NVARCHAR(50),
	AlternateModeOfTravel	NVARCHAR(50),
	AlternateClassOfTravel	NVARCHAR(50),
	EffectiveFromDate		DATETIME,
	EffectiveToDate			DATETIME,
	IsBehalfOfBooking		BIT,
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)
GO
CREATE TABLE AccomodationRate
(
	AccomodationRateId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CityGradeId			BIGINT FOREIGN KEY REFERENCES CityGrade(CityGradeId) NOT NULL,
	Rate				NUMERIC(18,2),
	Unit				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Currency			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)
GO
CREATE TABLE AccomodationPolicy
(
	AccomodationPolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId					BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	TravelMode				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	AccomodationRateId		BIGINT FOREIGN KEY REFERENCES AccomodationRate(AccomodationRateId) NOT NULL,
	Gender					NVARCHAR(25),
	PriorityOfAllocation	NVARCHAR(50),
	IsEnforcePriority		BIT,
	EffectiveFromDate		DATETIME,
	EffectiveToDate			DATETIME,
	IsBehalfOfBooking		BIT,
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)

GO
CREATE TABLE CityGrade
(
	CityGradeId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CityGradeName	NVARCHAR(50),
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE VehicleType
(
	VehicleTypeId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	VehicleName			NVARCHAR(50),
	IsAc				BIT,
	Is4Wheeler			BIT,
	Rate				NUMERIC(18,2),
	Unit				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Currency			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)
GO
CREATE TABLE ConveyancePolicy
(
	ConveyancePolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	Gender				NVARCHAR(25),
	VehicleTypeId		BIGINT FOREIGN KEY REFERENCES VehicleType(VehicleTypeId) NOT NULL,
	IsEnforcePriority	BIT,
	EffectiveFromDate	DATETIME,
	EffectiveToDate		DATETIME,
	IsBehalfOfBooking	BIT,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)
GO 
CREATE TABLE ApprovalMaster
(
	ApprovalMasterId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ProcessId				BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	FromDate				DATETIME,
	ToDate					DATETIME,
	IsEscalated				BIT,
	EscalationAlertDuration	INT,
	Unit					BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Currency				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)

GO
CREATE TABLE ApprovalDetails
(
	ApprovalDetailId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ApprovalMasterId		BIGINT FOREIGN KEY REFERENCES ApprovalMaster(ApprovalMasterId) NOT NULL,
	RoleId					BIGINT FOREIGN KEY REFERENCES Roles(RoleId) NOT NULL,
	IsEscalated				BIT,
	EscalationAlertDuration	INT,
	Unit					BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Sequence				INT,
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)

GO
CREATE TABLE ApprovalEscalationDetails
(
	ApprovalEscalationDetailId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ApprovalDetailId			BIGINT FOREIGN KEY REFERENCES ApprovalDetails(ApprovalDetailId) NOT NULL,
	RoleId						BIGINT FOREIGN KEY REFERENCES Roles(RoleId) NOT NULL,
	Sequence					INT,
	Alias						NVARCHAR(100),
	DOC							DATETIME,
	DOU							DATETIME,
	[Status]					NVARCHAR(25),
	TransactionId				BIGINT
)
GO

CREATE TABLE AdvancePolicy
(
	AdvancePolicyId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	TravelType			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	APFrom				NUMERIC(10,2),
	FromUnit			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	APTo				NUMERIC(10,2),
	ToUnit				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Amount				NUMERIC(18,2),
	Currency			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO

CREATE TABLE PerDiemPolicy
(
	PerDiemPolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	TravelType		BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	GradeId			BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	NoOfNights		INT,
	Specific		NVARCHAR(2),--(Equal �=�,  �<�  Less than, �>� Greater than)"
	Amount			NUMERIC(18,2),
	Currency		BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	IsEquivalent 	BIT,
	EffectiveFrom	DATETIME,
	EffectiveTo		DATETIME,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE MagazinesPolicy
(
	MagazinesPolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	Amount				NUMERIC(18,2),
	IsBillAttached		BIT,
	BillName			NVARCHAR(100),
	PurchasedDate		DATETIME,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE TelephonePolicy
(
	TelephonePolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	AmountPerAnnum		NUMERIC(18,2),
	TypeOfPhone			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	IsBillAttached		BIT,
	BillName			NVARCHAR(50),
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE PetrolPolicy
(
	PetrolPolicyId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	TypeOfVehicle		BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	ValuePerAnnum		INT,
	Unit				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	IsBillAttached		BIT,
	BillName			NVARCHAR(50),
	IsVoucher			BIT,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE MaintenancePolicy
(
	MaintenancePolicyId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	TypeOfVehicle		BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Ownerships			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	ValuePerAnnum		INT,
	Unit				BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	IsBillAttached		BIT,
	BillName			NVARCHAR(50),
	IsVoucher			BIT,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)



GO
CREATE TABLE Grade
(
	GradeId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeName		NVARCHAR(100),
	Descriptions	NVARCHAR(250),
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE GradeRoleMapping
(
	GradeRoleMappingId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	GradeId				BIGINT FOREIGN KEY REFERENCES Grade(GradeId) NOT NULL,
	RoleId				BIGINT FOREIGN KEY REFERENCES Roles(RoleId) NOT NULL,
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)

GO
CREATE TABLE CostCenter
(
	CostCenterId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CostCenter				NVARCHAR(100),
	OrganisationStructureId	BIGINT FOREIGN KEY REFERENCES OrganisationStructure(OrganisationStructureId) NOT NULL,
	Description				NVARCHAR(250),
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)

GO
CREATE TABLE CountryMaster
(
	CountryId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CountryName		NVARCHAR(100),
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE StateMaster
(
	StateId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	StateName		NVARCHAR(100),
	CountryId		BIGINT FOREIGN KEY REFERENCES CountryMaster(CountryId) NOT NULL,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE CityMaster
(
	CityId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CityName		NVARCHAR(100),
	CityGradeId		BIGINT FOREIGN KEY REFERENCES CityGrade(CityGradeId) NOT NULL,
	StateId			BIGINT FOREIGN KEY REFERENCES StateMaster(StateId) NOT NULL,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE CityGrade
(
	CityGradeId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	CityGradeName	NVARCHAR(100),
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE VendorMaster
(
	VendorId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	VendorName		NVARCHAR(100),
	VendorType		BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	Alias			NVARCHAR(100),
	DOC				DATETIME,
	DOU				DATETIME,
	[Status]		NVARCHAR(25),
	TransactionId	BIGINT
)

GO
CREATE TABLE VendorContactDetails
(
	VendorContactDetailId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	VendorId				BIGINT FOREIGN KEY REFERENCES VendorMaster(VendorId) NOT NULL,
	CityId					BIGINT FOREIGN KEY REFERENCES CityMaster(CityId) NOT NULL,
	Email					NVARCHAR(25),
	PhoneNo1				INT,
	PhoneNo2				INT,
	VAddress				NVARCHAR(200),
	StateId					BIGINT FOREIGN KEY REFERENCES StateMaster(StateId) NOT NULL,
	CountryId				BIGINT FOREIGN KEY REFERENCES CountryMaster(CountryId) NOT NULL,
	Zipcode					INT,
	WebSite					NVARCHAR(100),
	Fax						NVARCHAR(50),
	Alias					NVARCHAR(100),
	DOC						DATETIME,
	DOU						DATETIME,
	[Status]				NVARCHAR(25),
	TransactionId			BIGINT
)

GO
CREATE TABLE VendorAddress
(
	VendorAddressId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	AddressType			BIGINT FOREIGN KEY REFERENCES Masters(MasterId) NOT NULL,
	IsPreferred			BIT,
	VAddress			NVARCHAR(200),
	CityId				BIGINT FOREIGN KEY REFERENCES CityMaster(CityId) NOT NULL,
	StateId				BIGINT FOREIGN KEY REFERENCES StateMaster(StateId) NOT NULL,
	CountryId			BIGINT FOREIGN KEY REFERENCES CountryMaster(CountryId) NOT NULL,
	ZipCode				NVARCHAR(25),
	WebSite				NVARCHAR(100),
	Email				NVARCHAR(25),
	Phone1				INT,
	Phone2				INT,
	Fax					NVARCHAR(50),
	Alias				NVARCHAR(100),
	DOC					DATETIME,
	DOU					DATETIME,
	[Status]			NVARCHAR(25),
	TransactionId		BIGINT
)


---START : These table will be created in Travel Database
GO
CREATE TABLE TravelRequest
(
	TravelRequestId		BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	TravelRequestCode	NVARCHAR(50),
	ProcessId			BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	FromDate			DATETIME,
	ToDate				DATETIME,
	Status				NVARCHAR(25),
	DOC					DATETIME,
	DOU					DATETIME,
	TransactionId		BIGINT

)
GO

CREATE TABLE ApprovalTransaction
(
	ApprovalTransactionId	BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ProcessId				BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	TravelRequestId			BIGINT FOREIGN KEY REFERENCES TravelRequest(TravelRequestId) NOT NULL,
	EmployeeId				BIGINT FOREIGN KEY REFERENCES Employee(EmployeeId) NOT NULL,
	Remark					NVARCHAR(200), 
	ActionTakenBy			BIGINT FOREIGN KEY REFERENCES Employee(EmployeeId) NOT NULL,
	Status					NVARCHAR(25),
	DOC						DATETIME,
	DOU						DATETIME,
	TransactionId			BIGINT
)
GO
CREATE TABLE Documents
(
	DocumentId			BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
	ProcessId			BIGINT FOREIGN KEY REFERENCES Processes(ProcessId) NOT NULL,
	TravelRequestId		BIGINT FOREIGN KEY REFERENCES TravelRequest(TravelRequestId) NOT NULL,
	ReferenceName		NVARCHAR(100),
	Remark				NVARCHAR(200),
	Location			NVARCHAR(100),
	Status				NVARCHAR(25),
	DOC					DATETIME,
	DOU					DATETIME,
	TransactionId		BIGINT
)
---END : These table will be created in Travel Database