-- ==========================================================================================
--START : AccomodationPolicy
-- ==========================================================================================
GO

-- ==========================================================================================
-- Entity Name:	usp_AccomodationPolicy_SELECTAll
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:38:27 PM
-- Description:	This stored procedure is INTENDed for SELECTing all rows FROM AccomodationPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_AccomodationPolicy_S
(
	@Flag					NVARCHAR(25),
	@AccomodationPolicyId	BIGINT
)
AS
IF	@Flag ='ALL'
	BEGIN
		SELECT	AccomodationPolicyId,
				GradeId,
				TravelMode,
				AccomodationRateId,
				Gender,
				PriorityOfAllocation,
				IsEnforcePriority,
				EffectiveFROMDate,
				EffectiveToDate,
				IsBehalfOfBooking,
				Alias,
				DOC,
				DOU,
				[Status],
				TransactionId
		FROM	AccomodationPolicy
		WHERE	[Status] = 'Active'
	END
ELSE
	BEGIN
		SELECT	AccomodationPolicyId,
				GradeId,
				TravelMode,
				AccomodationRateId,
				Gender,
				PriorityOfAllocation,
				IsEnforcePriority,
				EffectiveFROMDate,
				EffectiveToDate,
				IsBehalfOfBooking,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	AccomodationPolicy
		WHERE	AccomodationPolicyId = @AccomodationPolicyId
		AND		[Status] = 'Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	usp_AccomodationPolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:38:27 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to AccomodationPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_AccomodationPolicy_IU
(
	@Flag					NVARCHAR(25),
	@AccomodationPolicyId	BIGINT,
	@GradeId				BIGINT,
	@TravelMode				BIGINT,
	@AccomodationRateId		BIGINT,
	@Gender					NVARCHAR(25),
	@PriorityOfAllocation	NVARCHAR(50),
	@IsEnforcePriority		BIT,
	@EffectiveFROMDate		DATETIME,
	@EffectiveToDate		DATETIME,
	@IsBehalfOfBooking		BIT,
	@Alias					NVARCHAR(100),
	@DOC					DATETIME,
	@DOU					DATETIME,
	@Status					NVARCHAR(25),
	@TransactionId			BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO AccomodationPolicy(	GradeId,
										TravelMode,
										AccomodationRateId,
										Gender,
										PriorityOfAllocation,
										IsEnforcePriority,
										EffectiveFROMDate,
										EffectiveToDate,
										IsBehalfOfBooking,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@TravelMode,
										@AccomodationRateId,
										@Gender,
										@PriorityOfAllocation,
										@IsEnforcePriority,
										@EffectiveFROMDate,
										@EffectiveToDate,
										@IsBehalfOfBooking,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	AccomodationPolicy
		SET		GradeId					= @GradeId,
				TravelMode				= @TravelMode,
				AccomodationRateId		= @AccomodationRateId,
				Gender					= @Gender,
				PriorityOfAllocation	= @PriorityOfAllocation,
				IsEnforcePriority		= @IsEnforcePriority,
				EffectiveFROMDate		= @EffectiveFROMDate,
				EffectiveToDate			= @EffectiveToDate,
				IsBehalfOfBooking		= @IsBehalfOfBooking,
				Alias					= @Alias,
				DOC						= @DOC,
				DOU						= @DOU,
				Status					= @Status,
				TransactionId			= @TransactionId
		WHERE	AccomodationPolicyId	= @AccomodationPolicyId
		SELECT	@AccomodationPolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_AccomodationPolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:38:27 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM AccomodationPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_AccomodationPolicy_D
(
	@AccomodationPolicyId BIGINT
)
AS
BEGIN
	UPDATE	AccomodationPolicy
	SET		[Status]='Inactive'
	WHERE	AccomodationPolicyId = @AccomodationPolicyId

END
-- ==========================================================================================
--END : AccomodationPolicy
-- ==========================================================================================
-- ==========================================================================================
--START : AccomodationRate
-- ==========================================================================================

GO
-- ==========================================================================================
-- Entity Name:	usp_AccomodationRate_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:26 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM AccomodationRate table
-- ==========================================================================================
ALTER PROCEDURE usp_AccomodationRate_S
(
	@Flag				NVARCHAR(25),
	@AccomodationRateId BIGINT
)	
AS
BEGIN
	IF @Flag = 'ALL'
		BEGIN
			SELECT	AccomodationRateId,
					CityGradeId,
					Rate,
					Unit,
					Currency,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	AccomodationRate
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
			SELECT	AccomodationRateId,
					CityGradeId,
					Rate,
					Unit,
					Currency,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	AccomodationRate
			WHERE	AccomodationRateId = @AccomodationRateId
			AND		[Status] = 'Active'
		END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_AccomodationRate_IU
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:26 PM
-- Description:	This stored procedure is INTENDed for inserting/Updating VALUES to AccomodationRate table
-- ==========================================================================================
CREATE PROCEDURE usp_AccomodationRate_IU
(
	@Flag				NVARCHAR(25),
	@AccomodationRateId BIGINT,
	@CityGradeId		BIGINT,
	@Rate				NUMERIC(18,2),
	@Unit				BIGINT,
	@Currency			BIGINT,
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
BEGIN
IF @Flag ='INSERT'
	BEGIN
		INSERT INTO AccomodationRate(	CityGradeId,
										Rate,
										Unit,
										Currency,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@CityGradeId,
										@Rate,
										@Unit,
										@Currency,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
 ELSE
	BEGIN
		UPDATE	AccomodationRate
		SET		CityGradeId		= @CityGradeId,
				Rate 				= @Rate,
				Unit 				= @Unit,
				Currency			= @Currency,
				Alias				= @Alias,
				DOC 				= @DOC,
				DOU 				= @DOU,
				Status				= @Status,
				TransactionId		= @TransactionId
		WHERE	AccomodationRateId	= @AccomodationRateId
		SELECT	@AccomodationRateId
	END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_AccomodationRate_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:26 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM AccomodationRate table
-- ==========================================================================================
CREATE PROCEDURE usp_AccomodationRate_D
(
	@AccomodationRateId BIGINT
)
AS
BEGIN
	UPDATE	AccomodationRate
	SET		[Status] ='Inactive'
	WHERE	AccomodationRateId = @AccomodationRateId

END
GO


GO
-- ==========================================================================================
-- Entity Name:	usp_AdvancePolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:58 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM AdvancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_AdvancePolicy_S
(
	@Flag				NVARCHAR(25),
	@AdvancePolicyId	BIGINT
)	
AS
BEGIN
		IF @Flag = 'ALL'
		BEGIN
			SELECT	AdvancePolicyId,
					TravelMode,
					GradeId,
					APFrom,
					FromUnit,
					APTo,
					ToUnit,
					Amount,
					Currency,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	AdvancePolicy
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
			SELECT	AdvancePolicyId,
					TravelMode,
					GradeId,
					APFrom,
					FromUnit,
					APTo,
					ToUnit,
					Amount,
					Currency,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	AdvancePolicy
			WHERE	AdvancePolicyId = @AdvancePolicyId
			AND		[Status] = 'Active'
		END
END

GO

-- ==========================================================================================
-- Entity Name:	usp_AdvancePolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:58 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to AdvancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_AdvancePolicy_IU
(
	@Flag				NVARCHAR(25),
	@AdvancePolicyId	BIGINT,
	@TravelMode			BIGINT,
	@GradeId			BIGINT,
	@APFrom				NUMERIC(10,2),
	@FromUnit			BIGINT,
	@APTo				NUMERIC(10,2),
	@ToUnit				BIGINT,
	@Amount				NUMERIC(18,2),
	@Currency			BIGINT,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
		BEGIN
			INSERT INTO AdvancePolicy(	TravelMode,
										GradeId,
										APFrom,
										FromUnit,
										APTo,
										ToUnit,
										Amount,
										Currency,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
			VALUES					(	@TravelMode,
										@GradeId,
										@APFrom,
										@FromUnit,
										@APTo,
										@ToUnit,
										@Amount,
										@Currency,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)

			SELECT @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE	AdvancePolicy
			SET		TravelMode		= @TravelMode,
					GradeId			= @GradeId,
					APFrom			= @APFrom,
					FromUnit		= @FromUnit,
					APTo			= @APTo,
					ToUnit			= @ToUnit,
					Amount			= @Amount,
					Currency		= @Currency,
					Alias			= @Alias,
					DOC				= @DOC,
					DOU				= @DOU,
					Status			= @Status,
					TransactionId	= @TransactionId
			WHERE	AdvancePolicyId = @AdvancePolicyId
			SELECT	@AdvancePolicyId
		END
END

GO

-- ==========================================================================================
-- Entity Name:	usp_AdvancePolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:45:58 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM AdvancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_AdvancePolicy_D
(
	@AdvancePolicyId BIGINT
)
AS
BEGIN
	UPDATE	AdvancePolicy
	SET		[Status] = 'Inactive'
	WHERE	AdvancePolicyId = @AdvancePolicyId
END

GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalDetails_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:22 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM ApprovalDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalDetails_S
(
	@Flag				NVARCHAR(25),
	@ApprovalDetailId	BIGINT
)
AS
BEGIN
	IF @Flag ='ALL'
		BEGIN
			SELECT	ApprovalDetailId,
					ApprovalMasterId,
					RoleId,
					IsEscalated,
					EscalationAlertDuration
				  	Unit,
				  	Sequence,
				  	Alias,
				  	DOC,
				  	DOU,
				  	[Status],
				  	TransactionId
			FROM	ApprovalDetails
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
			SELECT	ApprovalDetailId,
					ApprovalMasterId,
					RoleId,
					IsEscalated,
					EscalationAlertDuration
				  	Unit,
				  	Sequence,
				  	Alias,
				  	DOC,
				  	DOU,
				  	[Status],
				  	TransactionId
			FROM	ApprovalDetails
			WHERE	ApprovalDetailId = @ApprovalDetailId
			AND		[Status] = 'Active'
		END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalDetails_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:22 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to ApprovalDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalDetails_I
(
	@Flag						NVARCHAR(25),
	@ApprovalDetailId			BIGINT,
	@ApprovalMasterId			BIGINT,
	@RoleId						BIGINT,
	@IsEscalated				BIT,
	@EscalationAlertDuration	INT,
	@Unit						BIGINT,
	@Sequence					INT,
	@Alias						NVARCHAR(100),
	@DOC						DATETIME,
	@DOU						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
		BEGIN
			INSERT INTO ApprovalDetails(	ApprovalMasterId,
											RoleId,
											IsEscalated,
											EscalationAlertDuration,
											Unit,
											Sequence,
											Alias,
											DOC,
											DOU,
											[Status],
											TransactionId
										)
			VALUES						(	@ApprovalMasterId,
											@RoleId,
											@IsEscalated,
											@EscalationAlertDuration,
											@Unit,
											@Sequence,
											@Alias,
											@DOC,
											@DOU,
											@Status,
											@TransactionId
										)
			SELECT @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE	ApprovalDetails
			SET		ApprovalMasterId		= @ApprovalMasterId,
					RoleId					= @RoleId,
					IsEscalated				= @IsEscalated,
					EscalationAlertDuration	= @EscalationAlertDuration,
					Unit					= @Unit,
					Sequence				= @Sequence,
					Alias					= @Alias,
					DOC 					= @DOC,
					DOU 					= @DOU,
					Status					= @Status,
					TransactionId			= @TransactionId
			WHERE	ApprovalDetailId		= @ApprovalDetailId
			SELECT  @ApprovalDetailId
		END
END


-- ==========================================================================================
-- Entity Name:	usp_ApprovalDetails_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:22 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM ApprovalDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalDetails_D
(
	@Flag				NVARCHAR(25),
	@ApprovalDetailId	BIGINT
)
AS
BEGIN
	UPDATE	ApprovalDetails
	SET		[Status] = 'Inactive'
	WHERE	ApprovalDetailId = @ApprovalDetailId
END

GO
-- ==========================================================================================
--END : ApprovalDetails
-- ==========================================================================================


-- ==========================================================================================
--START : ApprovalEscalationDetails
-- ==========================================================================================
-- ==========================================================================================
-- Entity Name:	usp_ApprovalEscalationDetails_SELECTRow
-- Author:		Abdur
-- Create date:	06/18/12 11:35:22 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM ApprovalEscalationDetails table
-- ==========================================================================================
CREATE PROCEDURE usp_ApprovalEscalationDetails_S
(
	@Flag							NVARCHAR(25),
	@ApprovalEscalationDetailId		BIGINT
)
AS
BEGIN
	IF @Flag ='ALL'
		BEGIN
			SELECT	ApprovalEscalationDetailId, 
					ApprovalDetailId, 
					RoleId, 
					Sequence, 
					Alias, 
					DOC, 
					DOU, 
					Status, 
					TransactionId
			FROM	ApprovalEscalationDetails
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
			SELECT	ApprovalEscalationDetailId, 
					ApprovalDetailId, 
					RoleId, 
					Sequence, 
					Alias, 
					DOC, 
					DOU, 
					Status, 
					TransactionId
			FROM	ApprovalEscalationDetails
			WHERE	ApprovalEscalationDetailId = @ApprovalEscalationDetailId
			AND		[Status] = 'Active'
		END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalEscalationDetails_I
-- Author:	Abdur
-- Create date:	06/18/12 11:35:22 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to ApprovalEscalationDetails table
-- ==========================================================================================
CREATE PROCEDURE usp_ApprovalEscalationDetails_I
(
	@Flag						NVARCHAR(25),
	@ApprovalEscalationDetailId	BIGINT,
	@ApprovalDetailId			BIGINT,
	@RoleId						BIGINT,	
	@Sequence					INT,
	@Alias						NVARCHAR(100),
	@DOC						DATETIME,
	@DOU						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
		BEGIN
			INSERT INTO ApprovalEscalationDetails(	ApprovalDetailId,
													RoleId,													
													Sequence,
													Alias,
													DOC,
													DOU,
													[Status],
													TransactionId
												)
			VALUES								(	@ApprovalDetailId,
													@RoleId,												
													@Sequence,
													@Alias,
													@DOC,
													@DOU,
													@Status,
													@TransactionId
											)
			SELECT @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE	ApprovalEscalationDetails
			SET		ApprovalDetailId				= @ApprovalDetailId,
					RoleId							= @RoleId,					
					Sequence						= @Sequence,
					Alias							= @Alias,
					DOC 							= @DOC,
					DOU 							= @DOU,
					Status							= @Status,
					TransactionId					= @TransactionId
			WHERE	ApprovalEscalationDetailId		= @ApprovalEscalationDetailId
			SELECT  @ApprovalEscalationDetailId
		END
END


-- ==========================================================================================
-- Entity Name:	usp_ApprovalEscalationDetails_UPDATERow
-- Author:	Abdur
-- Create date:	06/18/12 11:46:22 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM ApprovalEscalationDetails table
-- ==========================================================================================
CREATE PROCEDURE usp_ApprovalEscalationDetails_D
(
	@Flag						NVARCHAR(25),
	@ApprovalEscalationDetailId	BIGINT
)
AS
BEGIN
	UPDATE	ApprovalEscalationDetails
	SET		[Status] = 'Inactive'
	WHERE	ApprovalEscalationDetailId = @ApprovalEscalationDetailId
END

GO

-- ==========================================================================================
--END : ApprovalEscalationDetails
-- ==========================================================================================
-- ==========================================================================================
--START : ApprovalMaster
-- ==========================================================================================
GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalMaster_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:36 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM ApprovalMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalMaster_S
(
	@Flag				NVARCHAR(25),
	@ApprovalMasterId	BIGINT
)	
AS
BEGIN
	IF @Flag = 'ALL'
		BEGIN
			SELECT	ApprovalMasterId,
					ProcessId,
					FROMDate,
					ToDate,
					IsEscalated,
					EscalationAlertDuration,
					Unit,
					Currency,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	ApprovalMaster
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
		SELECT	ApprovalMasterId,
				ProcessId,
				FROMDate,
				ToDate,
				IsEscalated,
				EscalationAlertDuration,
				Unit,
				Currency,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	ApprovalMaster
		WHERE	ApprovalMasterId = @ApprovalMasterId
		AND		[Status] = 'Active'
	END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalMaster_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:36 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to ApprovalMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalMaster_IU
(
	@Flag				NVARCHAR(25),
	@ApprovalMasterId	BIGINT,
	@ProcessId			BIGINT,
	@FromDate			DATETIME,
	@ToDate				DATETIME,
	@IsEscalated		BIT,
	@EscalationAlertDuration INT,
	@Unit				BIGINT,
	@Currency			BIGINT,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO ApprovalMaster(	ProcessId,
									FromDate,
									ToDate,
									IsEscalated,
									EscalationAlertDuration,
									Unit,
									Currency,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@ProcessId,
									@FromDate,
									@ToDate,
									@IsEscalated,
									@EscalationAlertDuration,
									@Unit,
									@Currency,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT	@@IDENTITY
	END
	ELSE
	BEGIN
		UPDATE	ApprovalMaster
		SET		ProcessId				= @ProcessId,
				FROMDate				= @FROMDate,
				ToDate					= @ToDate,
				IsEscalated				= @IsEscalated,
				EscalationAlertDuration = @EscalationAlertDuration,
				Unit					= @Unit,
				Currency				= @Currency,
				Alias					= @Alias,
				DOC						= @DOC,
				DOU						= @DOU,
				Status					= @Status,
				TransactionId			= @TransactionId
		WHERE	ApprovalMasterId		= @ApprovalMasterId
		SELECT	@ApprovalMasterId
	END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_ApprovalMaster_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:46:36 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM ApprovalMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_ApprovalMaster_D
(
	@Flag				NVARCHAR(25),
	@ApprovalMasterId	BIGINT
)
AS
BEGIN
	UPDATE	ApprovalMaster
	SET		[Status] = 'Inactive'
	WHERE	ApprovalMasterId = @ApprovalMasterId
END

GO
-- ==========================================================================================
-- Entity Name:	usp_Authentications_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:36 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Authentications table
-- ==========================================================================================
ALTER PROCEDURE usp_Authentications_S
(
	@Flag				NVARCHAR(25),
	@AuthenticationId	BIGINT
)
AS
BEGIN
	IF @Flag = 'ALL'
		BEGIN
			SELECT	AuthenticationId,
					EmployeeId,
					Mode,
					ALogin,
					APassword,
					IPAddress,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	Authentications
			WHERE	[Status] = 'Active'
		END
	ELSE
		BEGIN
			SELECT	AuthenticationId,
					EmployeeId,
					Mode,
					ALogin,
					APassword,
					IPAddress,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	Authentications
			WHERE	AuthenticationId = @AuthenticationId
			AND		[Status] = 'Active'
		END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_Authentications_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:36 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Authentications table
-- ==========================================================================================
ALTER PROCEDURE usp_Authentications_IU
(
	@Flag				NVARCHAR(25),		
	@AuthenticationId	BIGINT,
	@EmployeeId 		BIGINT,
	@Mode				BIGINT,
	@ALogin				NVARCHAR(50),
	@APassword			NVARCHAR(50),
	@IPAddress			NVARCHAR(50),
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO Authentications(	EmployeeId,
										Mode,
										ALogin,
										APassword,
										IPAddress,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@EmployeeId,
										@Mode,
										@ALogin,
										@APassword,
										@IPAddress,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Authentications
		SET		EmployeeId		= @EmployeeId,
				Mode			= @Mode,
				ALogin			= @ALogin,
				APassword		= @APassword,
				IPAddress		= @IPAddress,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	AuthenticationId = @AuthenticationId
		SELECT	@AuthenticationId
	END
END
GO
-- ==========================================================================================
-- Entity Name:	usp_Authentications_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:36 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Authentications table
-- ==========================================================================================
ALTER PROCEDURE usp_Authentications_D
(
	@Flag				NVARCHAR(25),
	@AuthenticationId	BIGINT
)
AS
BEGIN
	UPDATE	Authentications
	SET		[Status] = 'Inactive'
	WHERE	AuthenticationId = @AuthenticationId
END

GO
-- ==========================================================================================
--END : Authentications
-- ==========================================================================================
-- ==========================================================================================
--START : Authorizations
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_Authorizations_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:51 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Authorizations table
-- ==========================================================================================
ALTER PROCEDURE usp_Authorizations_S
(
	@Flag				NVARCHAR(25),
	@AuthorizationId	BIGINT
)
AS
BEGIN
	IF @Flag = 'ALL'
	BEGIN
		SELECT	AuthorizationId,
				RoleId,
				ProcessId,
				IsModify,
				IsSELECT,
				IsView,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Authorizations
		WHERE	[Status] = 'Active'
	END
	ELSE
	BEGIN
		SELECT	AuthorizationId,
				RoleId,
				ProcessId,
				IsModify,
				IsSELECT,
				IsView,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Authorizations
		WHERE	AuthorizationId = @AuthorizationId
		AND		[Status] = 'Active'
	END
END
GO
-- ==========================================================================================
-- Entity Name:	usp_Authorizations_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:51 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Authorizations table
-- ==========================================================================================
ALTER PROCEDURE usp_Authorizations_IU
(
	@Flag				NVARCHAR(25),
	@AuthorizationId	BIGINT,
	@RoleId				BIGINT,
	@ProcessId			BIGINT,
	@IsModify 			BIT,
	@IsUPDATE 			BIT,
	@IsSELECT 			BIT,
	@IsView				BIT,
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO Authorizations(	RoleId,
									ProcessId,
									IsModify,
									IsUPDATE,
									IsSELECT,
									IsView,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@RoleId,
									@ProcessId,
									@IsModify,
									@IsUPDATE,
									@IsSELECT,
									@IsView,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Authorizations
		SET		RoleId			= @RoleId,
				ProcessId		= @ProcessId,
				IsModify		= @IsModify,
				IsUPDATE 		= @IsUPDATE,
				IsSELECT 		= @IsSELECT,
				IsView			= @IsView,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	AuthorizationId = @AuthorizationId
		SELECT	@AuthorizationId
	END
END

GO
-- ==========================================================================================
-- Entity Name:	usp_Authorizations_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:47:51 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Authorizations table
-- ==========================================================================================
ALTER PROCEDURE usp_Authorizations_D
(
	@Flag				NVARCHAR(25),
	@AuthorizationId	BIGINT
)
AS
BEGIN
	UPDATE	Authorizations
	SET		[Status] = 'Inactive'
	WHERE	AuthorizationId = @AuthorizationId

END

GO
-- ==========================================================================================
--END : Authorizations
-- ==========================================================================================
-- ==========================================================================================
--START : CityGrade
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_CityGrade_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:03 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM CityGrade table
-- ==========================================================================================
ALTER PROCEDURE usp_CityGrade_S
(
	@Flag			NVARCHAR(25),
	@CityGradeId	BIGINT
)
AS
BEGIN
	IF @Flag = 'ALL'
	BEGIN
		SELECT	CityGradeId,
				CityGradeName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CityGrade
		WHERE	[Status] ='Active'
	END
	ELSE
	BEGIN
		SELECT	CityGradeId,
				CityGradeName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CityGrade
		WHERE	CityGradeId = @CityGradeId
		AND		[Status] ='Active'
	END
END

GO

-- ==========================================================================================
-- Entity Name:	usp_CityGrade_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:03 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to CityGrade table
-- ==========================================================================================
CREATE PROCEDURE usp_CityGrade_IU
(
	@Flag			NVARCHAR(25),	
	@CityGradeId	BIGINT,
	@CityGradeName	NVARCHAR(50),
	@Alias			NVARCHAR(100),
	@DOC 			DATETIME,
	@DOU 			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)
AS
BEGIN
	IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO CityGrade(	CityGradeName,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
		VALUES				(	@CityGradeName,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
		SELECT @@IDENTITY
	END
	ELSE
	BEGIN
		UPDATE	CityGrade
		SET		CityGradeName	= @CityGradeName,
				Alias			= @Alias,
				DOC				= @DOC,
				DOU				= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	CityGradeId		= @CityGradeId
		SELECT	@CityGradeId
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CityGrade_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:03 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM CityGrade table
-- ==========================================================================================
ALTER PROCEDURE usp_CityGrade_D
(
	@CityGradeId BIGINT
)
AS
BEGIN
	UPDATE	CityGrade
	SET		[Status] = 'Inactive'
	WHERE	CityGradeId = @CityGradeId
END
  
GO
-- ==========================================================================================
--END : CityGrade
-- ==========================================================================================
-- ==========================================================================================
--START : CityMaster
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_CityMaster_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:18 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM CityMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CityMaster_S
(
	@Flag	NVARCHAR(25),
	@CityId BIGINT
)
AS
BEGIN
IF	@Flag = 'ALL'
	BEGIN
		SELECT	CityId,
				CityName,
				CityGradeId,
				StateId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CityMaster
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	CityId,
				CityName,
				CityGradeId,
				StateId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CityMaster
		WHERE	CityId = @CityId
		AND		[Status] ='Active'
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CityMaster_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:18 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to CityMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CityMaster_IU
(
	@Flag	NVARCHAR(25),
	@CityId BIGINT,
	@CityName NVARCHAR(100),
	@CityGradeId BIGINT,
	@StateId BIGINT,
	@Alias NVARCHAR(100),
	@DOC DATETIME,
	@DOU DATETIME,
	@Status NVARCHAR(25),
	@TransactionId BIGINT
)	
AS
BEGIN
IF	@Flag = 'INSERT'
	BEGIN
		INSERT INTO CityMaster(	CityName,
								CityGradeId,
								StateId,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
		VALUES				(	@CityName,
								@CityGradeId,
								@StateId,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
		SELECT  @@IDENTITY
	END
ELSE	
	BEGIN
		UPDATE	CityMaster
		SET		CityName		= @CityName,
				CityGradeId 	= @CityGradeId,
				StateId			= @StateId,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	CityId			= @CityId
		SELECT	@CityId
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CityMaster_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:18 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM CityMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CityMaster_D
(
	@CityId BIGINT
)
AS
BEGIN
	UPDATE	CityMaster
	SET		[Status]  ='Inactive'
	WHERE	CityId = @CityId
END

GO
-- ==========================================================================================
--END : CityMaster
-- ==========================================================================================
-- ==========================================================================================
--START : ConveyancePolicy
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_ConveyancePolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:28 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM ConveyancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_ConveyancePolicy_S
(
	@Flag				NVARCHAR(25),
	@ConveyancePolicyId BIGINT
)
AS
BEGIN
IF	@Flag = 'ALL'
	BEGIN
		SELECT	ConveyancePolicyId,
				GradeId,
				Gender,
				VehicleTypeId,
				IsEnforcePriority,
				EffectiveFROMDate,
				EffectiveToDate,
				IsBehalfOfBooking,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	ConveyancePolicy
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	ConveyancePolicyId,
				GradeId,
				Gender,
				VehicleTypeId,
				IsEnforcePriority,
				EffectiveFROMDate,
				EffectiveToDate,
				IsBehalfOfBooking,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	ConveyancePolicy
		WHERE	ConveyancePolicyId = @ConveyancePolicyId
		AND		[Status] ='Active'
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_ConveyancePolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:28 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to ConveyancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_ConveyancePolicy_IU
(
	@Flag				NVARCHAR(25),
	@ConveyancePolicyId BIGINT,
	@GradeId			BIGINT,
	@Gender				NVARCHAR(25),
	@VehicleTypeId		BIGINT,
	@IsEnforcePriority	BIT,
	@EffectiveFROMDate	DATETIME,
	@EffectiveToDate	DATETIME,
	@IsBehalfOfBooking	BIT,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)	
AS
BEGIN
	IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO ConveyancePolicy(	GradeId,
										Gender,
										VehicleTypeId,
										IsEnforcePriority,
										EffectiveFROMDate,
										EffectiveToDate,
										IsBehalfOfBooking,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@Gender,
										@VehicleTypeId,
										@IsEnforcePriority,
										@EffectiveFROMDate,
										@EffectiveToDate,
										@IsBehalfOfBooking,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	ConveyancePolicy
		SET		GradeId				= @GradeId,
				Gender				= @Gender,
				VehicleTypeId		= @VehicleTypeId,
				IsEnforcePriority	= @IsEnforcePriority,
				EffectiveFROMDate	= @EffectiveFROMDate,
				EffectiveToDate		= @EffectiveToDate,
				IsBehalfOfBooking	= @IsBehalfOfBooking,
				Alias				= @Alias,
				DOC 				= @DOC,
				DOU 				= @DOU,
				Status				= @Status,
				TransactionId		= @TransactionId
		WHERE	ConveyancePolicyId	= @ConveyancePolicyId
		SELECT	@ConveyancePolicyId
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_ConveyancePolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:28 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM ConveyancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_ConveyancePolicy_D
(
	
	@ConveyancePolicyId BIGINT
)	
AS
BEGIN
	UPDATE	ConveyancePolicy
	SET		[Status] = 'Inactive'
	WHERE	ConveyancePolicyId = @ConveyancePolicyId

END

GO

GO

-- ==========================================================================================
-- Entity Name:	usp_CostCenter_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:36 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM CostCenter table
-- ==========================================================================================
ALTER PROCEDURE usp_CostCenter_S
(
	@Flag			NVARCHAR(25),
	@CostCenterId	BIGINT
)
AS
BEGIN
IF @Flag = 'ALL'
	BEGIN
		SELECT	CostCenterId,
				CostCenter,
				OrganisationStructureId,
				Description,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CostCenter
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	CostCenterId,
				CostCenter,
				OrganisationStructureId,
				Description,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CostCenter
		WHERE	CostCenterId = @CostCenterId
		AND		[Status] ='Active'
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CostCenter_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:36 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to CostCenter table
-- ==========================================================================================
ALTER PROCEDURE usp_CostCenter_IU
(
	@Flag						NVARCHAR(25),
	@CostCenterId BIGINT,
	@CostCenter					NVARCHAR(100),
	@OrganisationStructureId	BIGINT,
	@Description				NVARCHAR(250),
	@Alias						NVARCHAR(100),
	@DOC						DATETIME,
	@DOU						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
BEGIN
IF	@Flag = 'INSERT'
	BEGIN
		INSERT INTO CostCenter(	CostCenter,
								OrganisationStructureId,
								Description,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
		VALUES				(	@CostCenter,
								@OrganisationStructureId,
								@Description,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
		SELECT @@IDENTITY
	END
ELSE	
	BEGIN
		UPDATE	CostCenter
		SET		CostCenter				= @CostCenter,
				OrganisationStructureId = @OrganisationStructureId,
				Description				= @Description,
				Alias					= @Alias,
				DOC 					= @DOC,
				DOU 					= @DOU,
				Status					= @Status,
				TransactionId			= @TransactionId
		WHERE	CostCenterId			= @CostCenterId
		SELECT	@CostCenterId
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CostCenter_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:36 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM CostCenter table
-- ==========================================================================================
ALTER PROCEDURE usp_CostCenter_D
(
	@Flag			NVARCHAR(25),
	@CostCenterId BIGINT
)	
AS
BEGIN
	UPDATE	CostCenter
	SET		[Status] = 'Inactive'
	WHERE	CostCenterId = @CostCenterId
END

GO
--END : CostCenter
-- ==========================================================================================
-- ==========================================================================================
--START : CountryMaster
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_CountryMaster_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:45 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM CountryMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CountryMaster_S
(
	@Flag			NVARCHAR(25),
	@CountryId BIGINT
)
AS
BEGIN
IF @Flag = 'ALL'
	BEGIN
		SELECT	CountryId,
				CountryName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CountryMaster
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	CountryId,
				CountryName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	CountryMaster
		WHERE	CountryId = @CountryId
		AND		[Status] ='Active'
	END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_CountryMaster_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:45 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to CountryMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CountryMaster_IU
(
	@Flag			NVARCHAR(25),
	@CountryId BIGINT,
	@CountryName NVARCHAR(100),
	@Alias NVARCHAR(100),
	@DOC DATETIME,
	@DOU DATETIME,
	@Status NVARCHAR(25),
	@TransactionId BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO CountryMaster(	CountryName,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@CountryName,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	CountryMaster
		SET		CountryName		= @CountryName,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	CountryId		= @CountryId
		SELECT	@CountryId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_CountryMaster_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:45 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM CountryMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_CountryMaster_D
(
	@CountryId BIGINT
)
AS
BEGIN
	UPDATE	CountryMaster
	SET		[Status] = 'Inactive'
	WHERE	CountryId = @CountryId
END

GO
--END : CountryMaster
-- ==========================================================================================
-- ==========================================================================================
--START : Employee
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_Employee_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:53 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Employee table
-- ==========================================================================================
ALTER PROCEDURE usp_Employee_S
(
	@Flag			NVARCHAR(25),
	@EmployeeId		BIGINT
)
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	EmployeeId,
				EmployeeCode,
				FirstName,
				LastName,
				Gender,
				ReportingManager,
				DelegatationTo,
				Email,
				PersonalPhoneNo,
				PersonalVehicleNo,
				CompanyPhoneNo,
				CompanyVehicleNo,
				IsSelfApproved,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Employee
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	EmployeeId,
				EmployeeCode,
				FirstName,
				LastName,
				Gender,
				ReportingManager,
				DelegatationTo,
				Email,
				PersonalPhoneNo,
				PersonalVehicleNo,
				CompanyPhoneNo,
				CompanyVehicleNo,
				IsSelfApproved,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Employee
		WHERE	EmployeeId = @EmployeeId
		AND		[Status] ='Active'
	END	
GO

-- ==========================================================================================
-- Entity Name:	usp_Employee_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:53 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Employee table
-- ==========================================================================================
ALTER PROCEDURE usp_Employee_IU
(
	@Flag				NVARCHAR(25),
	@EmployeeId			BIGINT,
	@EmployeeCode		NVARCHAR(50),
	@FirstName			NVARCHAR(25),
	@LastName			NVARCHAR(25),
	@Gender				NVARCHAR(25),
	@ReportingManager	BIGINT,
	@DelegatationTo		BIGINT,
	@Email				NVARCHAR(50),
	@PersonalPhoneNo	NVARCHAR(20),
	@PersonalVehicleNo	NVARCHAR(20),
	@CompanyPhoneNo		NVARCHAR(20),
	@CompanyVehicleNo	NVARCHAR(20),
	@IsSelfApproved		BIT,
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)	
AS
IF @Flag  ='INSERT'
	BEGIN
		INSERT INTO Employee(	EmployeeCode,
								FirstName,
								LastName,
								Gender,
								ReportingManager,
								DelegatationTo,
								Email,
								PersonalPhoneNo,
								PersonalVehicleNo,
								CompanyPhoneNo,
								CompanyVehicleNo,
								IsSelfApproved,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
		VALUES				(	@EmployeeCode,
								@FirstName,
								@LastName,
								@Gender,
								@ReportingManager,
								@DelegatationTo,
								@Email,
								@PersonalPhoneNo,
								@PersonalVehicleNo,
								@CompanyPhoneNo,
								@CompanyVehicleNo,
								@IsSelfApproved,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Employee
		SET		EmployeeCode		= @EmployeeCode,
				FirstName			= @FirstName,
				LastName			= @LastName,
				Gender				= @Gender,
				ReportingManager	= @ReportingManager,
				DelegatationTo		= @DelegatationTo,
				Email				= @Email,	
				PersonalPhoneNo		= @PersonalPhoneNo,
				PersonalVehicleNo	= @PersonalVehicleNo,
				CompanyPhoneNo		= @CompanyPhoneNo,
				CompanyVehicleNo	= @CompanyVehicleNo,
				IsSelfApproved		= @IsSelfApproved,
				Alias				= @Alias,
				DOC 				= @DOC,
				DOU 				= @DOU,
				Status				= @Status,
				TransactionId		= @TransactionId
		WHERE	EmployeeId			= @EmployeeId
		SELECT	@EmployeeId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Employee_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:48:53 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Employee table
-- ==========================================================================================
ALTER PROCEDURE usp_Employee_D
(
	@EmployeeId BIGINT
)
AS
BEGIN
	UPDATE	Employee
	SET		[Status] = 'Inactive'
	WHERE	EmployeeId = @EmployeeId
END

GO
--END : Employee
-- ==========================================================================================
-- ==========================================================================================
--START : Grade
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_Grade_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:49:02 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Grade table
-- ==========================================================================================
ALTER PROCEDURE usp_Grade_S
(
	@Flag			NVARCHAR(25),
	@GradeId BIGINT
)	
AS
IF @Flag ='ALL'
	BEGIN
		SELECT	GradeId,
				GradeName,
				Descriptions,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Grade
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	GradeId,
				GradeName,
				Descriptions,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Grade
		WHERE	GradeId = @GradeId
		AND		[Status] ='Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	usp_Grade_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:49:02 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Grade table
-- ==========================================================================================
ALTER PROCEDURE usp_Grade_IU
(
	@Flag			NVARCHAR(25),
	@GradeId		BIGINT,
	@GradeName		NVARCHAR(100),
	@Descriptions	NVARCHAR(250),
	@Alias			NVARCHAR(100),
	@DOC			DATETIME,
	@DOU			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)	
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO Grade(	GradeName,
							Descriptions,
							Alias,
							DOC,
							DOU,
							Status,
							TransactionId
						)
		VALUES			(	@GradeName,
							@Descriptions,
							@Alias,
							@DOC,
							@DOU,
							@Status,
							@TransactionId
						)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Grade
		SET		GradeName		= @GradeName,
				Descriptions	= @Descriptions,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	GradeId			= @GradeId
		SELECT	@GradeId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Grade_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 1:49:02 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Grade table
-- ==========================================================================================
ALTER PROCEDURE usp_Grade_D
(
	@GradeId BIGINT
)	
AS
BEGIN
	UPDATE	Grade
	SET		[Status] = 'Inactive'
	WHERE	GradeId = @GradeId
END

GO
-- ==========================================================================================
--END : Grade
-- ==========================================================================================
-- ==========================================================================================
--START : GradeRoleMapping
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_GradeRoleMapping_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:24:43 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM GradeRoleMapping table
-- ==========================================================================================
ALTER PROCEDURE usp_GradeRoleMapping_S
(
	@Flag			NVARCHAR(25),
	@GradeRoleMappingId BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	GradeRoleMappingId,
				GradeId,
				RoleId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	GradeRoleMapping
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	GradeRoleMappingId,
				GradeId,
				RoleId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	GradeRoleMapping
		WHERE	GradeRoleMappingId = @GradeRoleMappingId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_GradeRoleMapping_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:24:43 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to GradeRoleMapping table
-- ==========================================================================================
ALTER PROCEDURE usp_GradeRoleMapping_IU
(
	@Flag				NVARCHAR(25),
	@GradeRoleMappingId BIGINT,
	@GradeId			BIGINT,
	@RoleId				BIGINT,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)	
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO GradeRoleMapping(	GradeId,
										RoleId,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@RoleId,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE	
	BEGIN
		UPDATE	GradeRoleMapping
		SET		GradeId			= @GradeId,
				RoleId			= @RoleId,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	GradeRoleMappingId = @GradeRoleMappingId
		SELECT	@GradeRoleMappingId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_GradeRoleMapping_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:24:43 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM GradeRoleMapping table
-- ==========================================================================================
CREATE PROCEDURE usp_GradeRoleMapping_D
(
	@GradeRoleMappingId BIGINT
)	
AS
BEGIN
	UPDATE	GradeRoleMapping
	SET		[Status] = 'Inactive'
	WHERE	GradeRoleMappingId = @GradeRoleMappingId
END

GO
-- ==========================================================================================
--END : GradeRoleMapping
-- ==========================================================================================
-- ==========================================================================================
--START : MagazinesPolicy
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_MagazinesPolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:06 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM MagazinesPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_MagazinesPolicy_S
(
	@Flag				NVARCHAR(25),
	@MagazinesPolicyId	BIGINT
)
AS
IF @Flag = 'ALL'
BEGIN
	SELECT	MagazinesPolicyId,
			GradeId,
			Amount,
			IsBillAttached,
			BillName,
			PurchasedDate,
			Alias,
			DOC,
			DOU,
			Status,
			TransactionId
	FROM	MagazinesPolicy
	WHERE	[Status] ='Active'
END
ELSE
	BEGIN
		SELECT	MagazinesPolicyId,
				GradeId,
				Amount,
				IsBillAttached,
				BillName,
				PurchasedDate,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	MagazinesPolicy
		WHERE	MagazinesPolicyId = @MagazinesPolicyId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_MagazinesPolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:06 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to MagazinesPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_MagazinesPolicy_IU
(
	@Flag				NVARCHAR(25),
	@MagazinesPolicyId	BIGINT,
	@GradeId			BIGINT,
	@Amount				NUMERIC(18,2),
	@IsBillAttached		BIT,
	@BillName			NVARCHAR(100),
	@PurchasedDate		DATETIME,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO MagazinesPolicy(	GradeId,
										Amount,
										IsBillAttached,
										BillName,
										PurchasedDate,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@Amount,
										@IsBillAttached,
										@BillName,
										@PurchasedDate,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	MagazinesPolicy
		SET		GradeId				= @GradeId,
				Amount				= @Amount,
				IsBillAttached		= @IsBillAttached,
				BillName			= @BillName,
				PurchasedDate		= @PurchasedDate,
				Alias				= @Alias,
				DOC 				= @DOC,
				DOU 				= @DOU,
				Status				= @Status,
				TransactionId		= @TransactionId
		WHERE	MagazinesPolicyId	= @MagazinesPolicyId
		SELECT	@MagazinesPolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_MagazinesPolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:06 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM MagazinesPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_MagazinesPolicy_D
(
	@MagazinesPolicyId BIGINT
)	
AS
BEGIN
	UPDATE	MagazinesPolicy
	SET		[Status] = 'Inactive'
	WHERE	MagazinesPolicyId = @MagazinesPolicyId
END
GO

-- ==========================================================================================
--END : MagazinesPolicy
-- ==========================================================================================
-- ==========================================================================================
--START : MaintenancePolicy
-- ==========================================================================================
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_MaintenancePolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:17 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM MaintenancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_MaintenancePolicy_S
(
	@Flag					NVARCHAR(25),
	@MaintenancePolicyId	BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	MaintenancePolicyId,
				GradeId,
				TypeOfVehicle,
				Ownerships,
				ValuePerAnnum,
				Unit,
				IsBillAttached,
				BillName,
				IsVoucher,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	MaintenancePolicy
		WHERE	[Status] ='Active'
	END
ELSE
BEGIN
	SELECT	MaintenancePolicyId,
			GradeId,
			TypeOfVehicle,
			Ownerships,
			ValuePerAnnum,
			Unit,
			IsBillAttached,
			BillName,
			IsVoucher,
			Alias,
			DOC,
			DOU,
			Status,
			TransactionId
	FROM	MaintenancePolicy
	WHERE	MaintenancePolicyId = @MaintenancePolicyId
	AND		[Status] ='Active'
END

GO

-- ==========================================================================================
-- Entity Name:	usp_MaintenancePolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:17 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to MaintenancePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_MaintenancePolicy_IU
(
	@Flag					NVARCHAR(25),
	@MaintenancePolicyId	BIGINT,
	@GradeId				BIGINT,
	@TypeOfVehicle			BIGINT,
	@Ownerships				BIGINT,
	@ValuePerAnnum			INT,
	@Unit					BIGINT,
	@IsBillAttached			BIT,
	@BillName				NVARCHAR(50),
	@IsVoucher				BIT,
	@Alias					NVARCHAR(100),
	@DOC					DATETIME,
	@DOU					DATETIME,
	@Status					NVARCHAR(25),
	@TransactionId			BIGINT
)	
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO MaintenancePolicy(	GradeId,
										TypeOfVehicle,
										Ownerships,
										ValuePerAnnum,
										Unit,
										IsBillAttached,
										BillName,
										IsVoucher,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@TypeOfVehicle,
										@Ownerships,
										@ValuePerAnnum,
										@Unit,
										@IsBillAttached,
										@BillName,
										@IsVoucher,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE	
	BEGIN
		UPDATE	MaintenancePolicy
		SET		GradeId			= @GradeId,
				TypeOfVehicle	= @TypeOfVehicle,
				Ownerships		= @Ownerships,
				ValuePerAnnum	= @ValuePerAnnum,
				Unit			= @Unit,
				IsBillAttached	= @IsBillAttached,
				BillName		= @BillName,
				IsVoucher		= @IsVoucher,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	MaintenancePolicyId = @MaintenancePolicyId
		SELECT	@MaintenancePolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_MaintenancePolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:17 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM MaintenancePolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_MaintenancePolicy_D
(
	@MaintenancePolicyId BIGINT
)	
AS
BEGIN
	UPDATE	MaintenancePolicy
	SET		[Status] = 'Inactive'
	WHERE	MaintenancePolicyId = @MaintenancePolicyId
END

GO
-- ==========================================================================================
--END : MaintenancePolicy
-- ==========================================================================================
-- ==========================================================================================
--START : OrganisationStructure
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructure_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:26 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM OrganisationStructure table
-- ==========================================================================================
ALTER PROCEDURE usp_OrganisationStructure_S
(
	@Flag						NVARCHAR(25),
	@OrganisationStructureId	BIGINT
)
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	OrganisationStructureId,
				Name,
				OrganisationStructureTypeId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	OrganisationStructure
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	OrganisationStructureId,
				Name,
				OrganisationStructureTypeId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	OrganisationStructure
		WHERE	OrganisationStructureId = @OrganisationStructureId
		AND		[Status] ='Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructure_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:26 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to OrganisationStructure table
-- ==========================================================================================
ALTER PROCEDURE usp_OrganisationStructure_IU
(
	@Flag						NVARCHAR(25),
	@OrganisationStructureId	BIGINT,
	@Name						NVARCHAR(100),
	@OrganisationStructureTypeId BIGINT,
	@Alias						NVARCHAR(100),
	@DOC 						DATETIME,
	@DOU 						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO OrganisationStructure(	Name,
											OrganisationStructureTypeId,
											Alias,
											DOC,
											DOU,
											Status,
											TransactionId
										)
		VALUES							(	@Name,
											@OrganisationStructureTypeId,
											@Alias,
											@DOC,
											@DOU,
											@Status,
											@TransactionId
										)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	OrganisationStructure
		SET		Name						= @Name,
				OrganisationStructureTypeId = @OrganisationStructureTypeId,
				Alias						= @Alias,
				DOC 						= @DOC,
				DOU 						= @DOU,
				[Status]					= @Status,
				TransactionId				= @TransactionId
		WHERE	OrganisationStructureId = @OrganisationStructureId
		SELECT	@OrganisationStructureId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructure_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:26 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM OrganisationStructure table
-- ==========================================================================================
ALTER PROCEDURE usp_OrganisationStructure_D
(
	@OrganisationStructureId BIGINT
)	
AS
BEGIN
	UPDATE	OrganisationStructure
	SET		[Status] = 'Inactive'
	WHERE	OrganisationStructureId = @OrganisationStructureId
END

GO

-- ==========================================================================================
--END : OrganisationStructure
-- ==========================================================================================
-- ==========================================================================================
--START : OrganisationStructureType
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructureType_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:35 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM OrganisationStructureType table
-- ==========================================================================================
ALTER PROCEDURE usp_OrganisationStructureType_S
(
	@Flag							NVARCHAR(25),
	@OrganisationStructureTypeId	BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	OrganisationStructureTypeId,
				Name,
				IsMultiple,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	OrganisationStructureType
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	OrganisationStructureTypeId,
				Name,
				IsMultiple,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	OrganisationStructureType
		WHERE	OrganisationStructureTypeId = @OrganisationStructureTypeId
		AND		[Status] ='Active'
	END	
GO

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructureType_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:35 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to OrganisationStructureType table
-- ==========================================================================================
ALTER PROCEDURE usp_OrganisationStructureType_IU
(
	@Flag							NVARCHAR(25),
	@OrganisationStructureTypeId	BIGINT,
	@Name							NVARCHAR(100),
	@IsMultiple						BIT,
	@Alias							NVARCHAR(100),
	@DOC							DATETIME,
	@DOU							DATETIME,
	@Status							NVARCHAR(25),
	@TransactionId					BIGINT
)	
AS
IF	@Flag = 'INSERT'
	BEGIN
		INSERT INTO OrganisationStructureType(	Name,
												IsMultiple,
												Alias,
												DOC,
												DOU,
												Status,
												TransactionId
											)
		VALUES								(	@Name,
												@IsMultiple,
												@Alias,
												@DOC,
												@DOU,
												@Status,
												@TransactionId
											)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	OrganisationStructureType
		SET		Name			= @Name,
				IsMultiple		= @IsMultiple,
				Alias			= @Alias,
				DOC				= @DOC,
				DOU				= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	OrganisationStructureTypeId = @OrganisationStructureTypeId
		SELECT	@OrganisationStructureTypeId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_OrganisationStructureType_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:25:35 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM OrganisationStructureType table
-- ==========================================================================================
CREATE PROCEDURE usp_OrganisationStructureType_D
(
	@OrganisationStructureTypeId BIGINT
)	
AS
BEGIN
	UPDATE	OrganisationStructureType
	SET		[Status] = 'Inactive'
	WHERE	OrganisationStructureTypeId = @OrganisationStructureTypeId
END

GO
-- ==========================================================================================
--END : OrganisationStructureType
-- ==========================================================================================
-- ==========================================================================================
--START : PetrolPolicy
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_PetrolPolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:27 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM PetrolPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_PetrolPolicy_S
(
	@Flag			NVARCHAR(25),
	@PetrolPolicyId BIGINT
)	
AS
IF	@Flag = 'ALL'
	BEGIN
		SELECT	PetrolPolicyId,
				GradeId,
				TypeOfVehicle,
				ValuePerAnnum,
				Unit,
				IsBillAttached,
				BillName,
				IsVoucher,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	PetrolPolicy
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	PetrolPolicyId,
				GradeId,
				TypeOfVehicle,
				ValuePerAnnum,
				Unit,
				IsBillAttached,
				BillName,
				IsVoucher,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	PetrolPolicy
		WHERE	PetrolPolicyId = @PetrolPolicyId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_PetrolPolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:27 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to PetrolPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_PetrolPolicy_IU
(
	@Flag			NVARCHAR(25),
	@PetrolPolicyId BIGINT,
	@GradeId		BIGINT,
	@TypeOfVehicle	BIGINT,
	@ValuePerAnnum	INT,
	@Unit			BIGINT,
	@IsBillAttached BIT,
	@BillName		NVARCHAR(50),
	@IsVoucher		BIT,
	@Alias			NVARCHAR(100),
	@DOC 			DATETIME,
	@DOU 			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO PetrolPolicy(	GradeId,
									TypeOfVehicle,
									ValuePerAnnum,
									Unit,
									IsBillAttached,
									BillName,
									IsVoucher,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@GradeId,
									@TypeOfVehicle,
									@ValuePerAnnum,
									@Unit,
									@IsBillAttached,
									@BillName,
									@IsVoucher,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	PetrolPolicy
		SET		GradeId			= @GradeId,
				TypeOfVehicle	= @TypeOfVehicle,
				ValuePerAnnum	= @ValuePerAnnum,
				Unit			= @Unit,
				IsBillAttached	= @IsBillAttached,
				BillName		= @BillName,
				IsVoucher		= @IsVoucher,
				Alias			= @Alias,
				DOC				= @DOC,
				DOU				= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	PetrolPolicyId	= @PetrolPolicyId
		SELECT	@PetrolPolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_PetrolPolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:27 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM PetrolPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_PetrolPolicy_D
(
	@PetrolPolicyId BIGINT
)	
AS
BEGIN
	UPDATE	PetrolPolicy
	SET		[Status] = 'Inactive'
	WHERE	PetrolPolicyId = @PetrolPolicyId
END

GO
-- ==========================================================================================
--END : PetrolPolicy
-- ==========================================================================================
-- ==========================================================================================
--START : Processes
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_Processes_S
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:36 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Processes table
-- ==========================================================================================
ALTER PROCEDURE usp_Processes_S
(
	@Flag			NVARCHAR(25),
	@ProcessId BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	ProcessId,
				ProcessName,
				ParentId,
				NeedDocumentMgt,
				NeedApprovers,
				NeedEnforceSLA,
				DefaultURL,
				OnErrorURL,
				SequenceNo,
				Alias,
				DOC,
				DOU,
				Status
		FROM	Processes
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	ProcessId,
				ProcessName,
				ParentId,
				NeedDocumentMgt,
				NeedApprovers,
				NeedEnforceSLA,
				DefaultURL,
				OnErrorURL,
				SequenceNo,
				Alias,
				DOC,
				DOU,
				Status
		FROM	Processes
		WHERE	ProcessId = @ProcessId
		AND		[Status] ='Active'
	END	
GO

-- ==========================================================================================
-- Entity Name:	usp_Processes_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:36 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Processes table
-- ==========================================================================================
ALTER PROCEDURE usp_Processes_IU
(
	@Flag				NVARCHAR(25),
	@ProcessId			BIGINT,
	@ProcessName		NVARCHAR(200),
	@ParentId			BIGINT,
	@NeedDocumentMgt	BIT,
	@NeedApprovers		BIT,
	@NeedEnforceSLA		BIT,
	@DefaultURL			NVARCHAR(100),
	@OnErrorURL			NVARCHAR(100),
	@SequenceNo			INT,
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25)
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO Processes(	ProcessName,
								ParentId,
								NeedDocumentMgt,
								NeedApprovers,
								NeedEnforceSLA,
								DefaultURL,
								OnErrorURL,
								SequenceNo,
								Alias,
								DOC,
								DOU,
								Status
							)
		VALUES				(	@ProcessName,
								@ParentId,
								@NeedDocumentMgt,
								@NeedApprovers,
								@NeedEnforceSLA,
								@DefaultURL,
								@OnErrorURL,
								@SequenceNo,
								@Alias,
								@DOC,
								@DOU,
								@Status
							)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Processes
		SET		ProcessName		= @ProcessName,
				ParentId		= @ParentId,
				NeedDocumentMgt = @NeedDocumentMgt,
				NeedApprovers	= @NeedApprovers,
				NeedEnforceSLA	= @NeedEnforceSLA,
				DefaultURL 		= @DefaultURL,
				OnErrorURL 		= @OnErrorURL,
				SequenceNo 		= @SequenceNo,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status
		WHERE	ProcessId		= @ProcessId
		SELECT	@ProcessId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Processes_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:36 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Processes table
-- ==========================================================================================
ALTER PROCEDURE usp_Processes_D
(
	@ProcessId BIGINT
)	
AS
BEGIN
	UPDATE	Processes
	SET		[Status] = 'Inactive'
	WHERE	ProcessId = @ProcessId
END

GO
-- ==========================================================================================
--END : Processes
-- ==========================================================================================
-- ==========================================================================================
--START : Roles
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_Roles_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:48 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Roles table
-- ==========================================================================================
ALTER PROCEDURE usp_Roles_S
(
	@Flag			NVARCHAR(25),
	@RoleId			BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	RoleId,
				Name,
				OrganisationStructureId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Roles
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	RoleId,
				Name,
				OrganisationStructureId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Roles
		WHERE	RoleId = @RoleId
		AND		[Status] ='Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	usp_Roles_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:48 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Roles table
-- ==========================================================================================
ALTER PROCEDURE usp_Roles_IU
(
	@Flag						NVARCHAR(25),
	@RoleId						BIGINT,
	@Name						NVARCHAR(100),
	@OrganisationStructureId	BIGINT,
	@Alias						NVARCHAR(100),
	@DOC 						DATETIME,
	@DOU 						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
IF @Flag = 'INSERT'
BEGIN
	INSERT INTO Roles(	Name,
						OrganisationStructureId,
						Alias,
						DOC,
						DOU,
						Status,
						TransactionId
					)
	VALUES			(	@Name,
						@OrganisationStructureId,
						@Alias,
						@DOC,
						@DOU,
						@Status,
						@TransactionId
					)
	SELECT @@IDENTITY
END
ELSE
	BEGIN
		UPDATE	Roles
		SET		Name					= @Name,
				OrganisationStructureId = @OrganisationStructureId,
				Alias					= @Alias,
				DOC 					= @DOC,
				DOU 					= @DOU,
				Status					= @Status,
				TransactionId			= @TransactionId
		WHERE	RoleId					= @RoleId
		SELECT	@RoleId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Roles_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:48 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Roles table
-- ==========================================================================================
CREATE PROCEDURE usp_Roles_D
(
		@RoleId BIGINT
)	
AS
BEGIN
	UPDATE	Roles
	SET		[Status] = 'Inactive'
	WHERE	RoleId = @RoleId
END

GO
-- ==========================================================================================
--END : Roles
-- ==========================================================================================
-- ==========================================================================================
--START : Sessions
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_Sessions_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:57 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Sessions table
-- ==========================================================================================
ALTER PROCEDURE usp_Sessions_S
(
	@Flag			NVARCHAR(25),
	@SessionId		BIGINT
)	
AS
IF @Flag  ='ALL'
	BEGIN
		SELECT	SessionId,
				EmployeeId,
				Mode,
				LogoutTime,
				LastActivity,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Sessions
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	SessionId,
				EmployeeId,
				Mode,
				LogoutTime,
				LastActivity,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	Sessions
		WHERE	SessionId = @SessionId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Sessions_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:57 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Sessions table
-- ==========================================================================================
ALTER PROCEDURE usp_Sessions_IU
(
	@Flag			NVARCHAR(25),
	@SessionId		BIGINT,
	@EmployeeId		BIGINT,
	@Mode			BIGINT,
	@LogoutTime		DATETIME,
	@LastActivity	DATETIME,
	@Alias			NVARCHAR(100),
	@DOC			DATETIME,
	@DOU			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)	
AS
IF @Flag ='INSERT'
	BEGIN
		INSERT INTO Sessions(	EmployeeId,
								Mode,
								LogoutTime,
								LastActivity,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
		VALUES				(	@EmployeeId,
								@Mode,
								@LogoutTime,
								@LastActivity,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE Sessions
		SET		EmployeeId		= @EmployeeId,
				Mode			= @Mode,
				LogoutTime		= @LogoutTime,
				LastActivity	= @LastActivity,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	SessionId		= @SessionId
		SELECT	@SessionId
	END

GO	
-- ==========================================================================================
-- Entity Name:	usp_Sessions_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:26:57 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Sessions table
-- ==========================================================================================
ALTER PROCEDURE usp_Sessions_D
(
	@SessionId BIGINT
)	
AS
BEGIN
	UPDATE	Sessions
	SET		[Status] = 'Inactive'
	WHERE	SessionId = @SessionId
END
-- ==========================================================================================
--END : Sessions
-- ==========================================================================================
-- ==========================================================================================
--START : StateMaster
-- ==========================================================================================
GO

-- ==========================================================================================
-- Entity Name:	usp_StateMaster_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:08 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM StateMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_StateMaster_S
(
	@Flag		NVARCHAR(25),
	@StateId	BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	StateId,
				StateName,
				CountryId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	StateMaster
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	StateId,
				StateName,
				CountryId,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	StateMaster
		WHERE	StateId = @StateId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_StateMaster_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:08 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to StateMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_StateMaster_IU
(
	@Flag			NVARCHAR(25),
	@StateId		BIGINT,
	@StateName		NVARCHAR(100),
	@CountryId		BIGINT,
	@Alias			NVARCHAR(100),
	@DOC 			DATETIME,
	@DOU 			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)
AS
IF @Flag = 'INSERT'
BEGIN
	INSERT INTO StateMaster(	StateName,
								CountryId,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
	VALUES					(	@StateName,
								@CountryId,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
	SELECT @@IDENTITY
END
ELSE
	BEGIN
		UPDATE	StateMaster
		SET		StateName		= @StateName,
				CountryId		= @CountryId,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	StateId			= @StateId
		SELECT	@StateId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_StateMaster_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:08 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM StateMaster table
-- ==========================================================================================
CREATE PROCEDURE usp_StateMaster_D
(
	@StateId BIGINT
)	
AS
BEGIN
	UPDATE	StateMaster
	SET		[Status] = 'Inactive'
	WHERE	StateId = @StateId
END

GO
-- ==========================================================================================
--END : StateMaster
-- ==========================================================================================
-- ==========================================================================================
--START : TelephonePolicy
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_TelephonePolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:18 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM TelephonePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_TelephonePolicy_S
(
	@Flag				NVARCHAR(25),
	@TelephonePolicyId	BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	TelephonePolicyId,
				GradeId,
				AmountPerAnnum,
				TypeOfPhone,
				IsBillAttached,
				BillName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	TelephonePolicy
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	TelephonePolicyId,
				GradeId,
				AmountPerAnnum,
				TypeOfPhone,
				IsBillAttached,
				BillName,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	TelephonePolicy
		WHERE	TelephonePolicyId = @TelephonePolicyId
		AND		[Status] ='Active'
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_TelephonePolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:18 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to TelephonePolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_TelephonePolicy_IU
(
	@Flag				NVARCHAR(25),
	@TelephonePolicyId	BIGINT,
	@GradeId			BIGINT,
	@AmountPerAnnum		NUMERIC(18,2),
	@TypeOfPhone		BIGINT,
	@IsBillAttached		BIT,
	@BillName			NVARCHAR(50),
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO TelephonePolicy(	GradeId,
										AmountPerAnnum,
										TypeOfPhone,
										IsBillAttached,
										BillName,
										Alias,
										DOC,
										DOU,
										Status,
										TransactionId
									)
		VALUES						(	@GradeId,
										@AmountPerAnnum,
										@TypeOfPhone,
										@IsBillAttached,
										@BillName,
										@Alias,
										@DOC,
										@DOU,
										@Status,
										@TransactionId
									)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	TelephonePolicy
		SET		GradeId			= @GradeId,
				AmountPerAnnum	= @AmountPerAnnum,
				TypeOfPhone		= @TypeOfPhone,
				IsBillAttached	= @IsBillAttached,
				BillName		= @BillName,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	TelephonePolicyId = @TelephonePolicyId
		SELECT	@TelephonePolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_TelephonePolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:18 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM TelephonePolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_TelephonePolicy_D
(
	@TelephonePolicyId BIGINT
)	
AS
BEGIN
	UPDATE	TelephonePolicy
	SET		[Status] = 'Inactive'
	WHERE	TelephonePolicyId = @TelephonePolicyId
END

GO
-- ==========================================================================================
--END : TelephonePolicy
-- ==========================================================================================
-- ==========================================================================================
--START : Transactions
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_Transactions_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:27 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM Transactions table
-- ==========================================================================================
ALTER PROCEDURE usp_Transactions_S
(
	@Flag			NVARCHAR(25),
	@TransactionId	BIGINT
)
AS
IF @Flag ='ALL'
	BEGIN
		SELECT	TransactionId,
				SessionId,
				ProcessId,
				EndDateTime,
				LastActivity,
				Alias,
				DOC,
				DOU,
				Status
		FROM	Transactions
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	TransactionId,
				SessionId,
				ProcessId,
				EndDateTime,
				LastActivity,
				Alias,
				DOC,
				DOU,
				Status
		FROM	Transactions
		WHERE	TransactionId = @TransactionId
		AND		[Status] ='Active'
	END	
GO
-- ==========================================================================================
-- Entity Name:	usp_Transactions_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:27 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to Transactions table
-- ==========================================================================================
CREATE PROCEDURE usp_Transactions_IU
(
	@Flag			NVARCHAR(25),
	@TransactionId	BIGINT,
	@SessionId		BIGINT,
	@ProcessId		BIGINT,
	@EndDateTime	DATETIME,
	@LastActivity	DATETIME,
	@Alias			NVARCHAR(100),
	@DOC 			DATETIME,
	@DOU 			DATETIME,
	@Status			NVARCHAR(25)
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO Transactions(	SessionId,
									ProcessId,
									EndDateTime,
									LastActivity,
									Alias,
									DOC,
									DOU,
									Status
								)
		VALUES					(	@SessionId,
									@ProcessId,
									@EndDateTime,
									@LastActivity,
									@Alias,
									@DOC,
									@DOU,
									@Status
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	Transactions
		SET		SessionId		= @SessionId,
				ProcessId		= @ProcessId,
				EndDateTime 	= @EndDateTime,
				LastActivity	= @LastActivity,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status
		WHERE	TransactionId	= @TransactionId
		SELECT	@TransactionId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_Transactions_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:27 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM Transactions table
-- ==========================================================================================
CREATE PROCEDURE usp_Transactions_D
(
	@TransactionId BIGINT
)	
AS
BEGIN
	UPDATE	Transactions
	SET		[Status] = 'Inactive'
	WHERE	TransactionId = @TransactionId
END

GO
-- ==========================================================================================
--END : Transactions
-- ==========================================================================================
-- ==========================================================================================
--START : TravelPolicy
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_TravelPolicy_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:37 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM TravelPolicy table
-- ==========================================================================================
ALTER PROCEDURE usp_TravelPolicy_S
(
	@Flag			NVARCHAR(25),
	@TravelPolicyId BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	TravelPolicyId,
				GradeId,
				TravelMode,
				Gender,
				DurationOfTravel,
				Unit,
				DefaultModeOfTravel,
				DefaultClASsOfTravel,
				AlternateModeOfTravel,
				AlternateClASsOfTravel,
				EffectiveFROMDate,
				EffectiveToDate,
				IsBehalfOfBooking,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	TravelPolicy
		WHERE	[Status] ='Active'
	END
ELSE
BEGIN
	SELECT	TravelPolicyId,
			GradeId,
			TravelMode,
			Gender,
			DurationOfTravel,
			Unit,
			DefaultModeOfTravel,
			DefaultClASsOfTravel,
			AlternateModeOfTravel,
			AlternateClASsOfTravel,
			EffectiveFROMDate,
			EffectiveToDate,
			IsBehalfOfBooking,
			Alias,
			DOC,
			DOU,
			Status,
			TransactionId
	FROM	TravelPolicy
	WHERE	TravelPolicyId = @TravelPolicyId
	AND		[Status] ='Active'
END	
GO

-- ==========================================================================================
-- Entity Name:	usp_TravelPolicy_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:37 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to TravelPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_TravelPolicy_IU
(
	@Flag					NVARCHAR(25),
	@TravelPolicyId			BIGINT,
	@GradeId				BIGINT,
	@TravelMode				BIGINT,
	@Gender					NVARCHAR(25),
	@DurationOfTravel		NUMERIC(10,2),
	@Unit					BIGINT,
	@DefaultModeOfTravel	NVARCHAR(50),
	@DefaultClASsOfTravel	NVARCHAR(50),
	@AlternateModeOfTravel	NVARCHAR(50),
	@AlternateClASsOfTravel NVARCHAR(50),
	@EffectiveFROMDate		DATETIME,
	@EffectiveToDate		DATETIME,
	@IsBehalfOfBooking		BIT,
	@Alias					NVARCHAR(100),
	@DOC					DATETIME,
	@DOU					DATETIME,
	@Status					NVARCHAR(25),
	@TransactionId			BIGINT
)	
AS
IF @Flag = 'INSERT'
BEGIN
	INSERT INTO TravelPolicy(	GradeId,
								TravelMode,
								Gender,
								DurationOfTravel,
								Unit,
								DefaultModeOfTravel,
								DefaultClASsOfTravel,
								AlternateModeOfTravel,
								AlternateClASsOfTravel,
								EffectiveFROMDate,
								EffectiveToDate,
								IsBehalfOfBooking,
								Alias,
								DOC,
								DOU,
								Status,
								TransactionId
							)
	VALUES					(	@GradeId,
								@TravelMode,
								@Gender,
								@DurationOfTravel,
								@Unit,
								@DefaultModeOfTravel,
								@DefaultClASsOfTravel,
								@AlternateModeOfTravel,
								@AlternateClASsOfTravel,
								@EffectiveFROMDate,
								@EffectiveToDate,
								@IsBehalfOfBooking,
								@Alias,
								@DOC,
								@DOU,
								@Status,
								@TransactionId
							)
	SELECT @@IDENTITY
END
ELSE
	BEGIN
		UPDATE	TravelPolicy
		SET		GradeId					= @GradeId,
				TravelMode				= @TravelMode,
				Gender					= @Gender,
				DurationOfTravel		= @DurationOfTravel,
				Unit					= @Unit,
				DefaultModeOfTravel 	= @DefaultModeOfTravel,
				DefaultClASsOfTravel	= @DefaultClASsOfTravel,
				AlternateModeOfTravel	= @AlternateModeOfTravel,
				AlternateClASsOfTravel	= @AlternateClASsOfTravel,
				EffectiveFROMDate		= @EffectiveFROMDate,
				EffectiveToDate			= @EffectiveToDate,
				IsBehalfOfBooking		= @IsBehalfOfBooking,
				Alias					= @Alias,
				DOC 					= @DOC,
				DOU 					= @DOU,
				Status					= @Status,
				TransactionId			= @TransactionId
		WHERE	TravelPolicyId			= @TravelPolicyId
		SELECT	@TravelPolicyId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_TravelPolicy_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:37 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM TravelPolicy table
-- ==========================================================================================
CREATE PROCEDURE usp_TravelPolicy_D
(
	@TravelPolicyId BIGINT
)	
AS
BEGIN
	UPDATE	TravelPolicy
	SET		[Status] = 'Inactive'
	WHERE	TravelPolicyId = @TravelPolicyId
END
GO

-- ==========================================================================================
--END : TravelPolicy
-- ==========================================================================================
-- ==========================================================================================
--START : VehicleType
-- ==========================================================================================


-- ==========================================================================================
-- Entity Name:	usp_VehicleType_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:47 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM VehicleType table
-- ==========================================================================================
ALTER PROCEDURE usp_VehicleType_S
(
	@Flag			NVARCHAR(25),
	@VehicleTypeId	BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	VehicleTypeId,
				VehicleName,
				IsAc,
				Is4Wheeler,
				Rate,
				Unit,
				Currency,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VehicleType
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	VehicleTypeId,
				VehicleName,
				IsAc,
				Is4Wheeler,
				Rate,
				Unit,
				Currency,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VehicleType
		WHERE	VehicleTypeId = @VehicleTypeId
		AND		[Status] ='Active'
	END	
GO

-- ==========================================================================================
-- Entity Name:	usp_VehicleType_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:47 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to VehicleType table
-- ==========================================================================================
CREATE PROCEDURE usp_VehicleType_IU
(
	@Flag			NVARCHAR(25),
	@VehicleTypeId	BIGINT,
	@VehicleName	NVARCHAR(50),
	@IsAc			BIT,
	@Is4Wheeler		BIT,
	@Rate			NUMERIC(18,2),
	@Unit			BIGINT,
	@Currency		BIGINT,
	@Alias			NVARCHAR(100),
	@DOC			DATETIME,
	@DOU			DATETIME,
	@Status			NVARCHAR(25),
	@TransactionId	BIGINT
)
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO VehicleType(	VehicleName,
									IsAc,
									Is4Wheeler,
									Rate,
									Unit,
									Currency,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@VehicleName,
									@IsAc,
									@Is4Wheeler,
									@Rate,
									@Unit,
									@Currency,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	VehicleType
		SET		VehicleName		= @VehicleName,
				IsAc			= @IsAc,
				Is4Wheeler		= @Is4Wheeler,
				Rate 			= @Rate,
				Unit 			= @Unit,
				Currency		= @Currency,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	VehicleTypeId	= @VehicleTypeId
		SELECT	@VehicleTypeId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_VehicleType_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:47 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM VehicleType table
-- ==========================================================================================
CREATE PROCEDURE usp_VehicleType_D
(
	@VehicleTypeId BIGINT
)	
AS
BEGIN
	UPDATE	VehicleType
	SET		[Status] = 'Inactive'
	WHERE	VehicleTypeId = @VehicleTypeId
END

GO
-- ==========================================================================================
--END : VehicleType
-- ==========================================================================================
-- ==========================================================================================
--START : VendorAddress
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_VendorAddress_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:58 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM VendorAddress table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorAddress_S
(
	@Flag			NVARCHAR(25),
	@VendorAddressId BIGINT
)	
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	VendorAddressId,
				AddressType,
				IsPreferred,
				VAddress,
				CityId,
				StateId,
				CountryId,
				ZipCode,
				WebSite,
				Email,
				Phone1,
				Phone2,
				Fax,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VendorAddress
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	VendorAddressId,
				AddressType,
				IsPreferred,
				VAddress,
				CityId,
				StateId,
				CountryId,
				ZipCode,
				WebSite,
				Email,
				Phone1,
				Phone2,
				Fax,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VendorAddress
		WHERE	VendorAddressId = @VendorAddressId
		AND		[Status] ='Active'
	END
	
GO

-- ==========================================================================================
-- Entity Name:	usp_VendorAddress_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:58 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to VendorAddress table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorAddress_IU
(
	@Flag				NVARCHAR(25),
	@VendorAddressId	BIGINT,
	@AddressType		BIGINT,
	@IsPreferred		BIT,
	@VAddress			NVARCHAR(200),
	@CityId				BIGINT,
	@StateId			BIGINT,
	@CountryId			BIGINT,
	@ZipCode 			NVARCHAR(25),
	@WebSite 			NVARCHAR(100),
	@Email				NVARCHAR(25),
	@Phone1 			INT,
	@Phone2 			INT,
	@Fax				NVARCHAR(50),
	@Alias				NVARCHAR(100),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
)	
AS
IF @Flag = 'INSERT'
	BEGIN
		INSERT INTO VendorAddress(	AddressType,
									IsPreferred,
									VAddress,
									CityId,
									StateId,
									CountryId,
									ZipCode,
									WebSite,
									Email,
									Phone1,
									Phone2,
									Fax,
									Alias,
									DOC,
									DOU,
									Status,
									TransactionId
								)
		VALUES					(	@AddressType,
									@IsPreferred,
									@VAddress,
									@CityId,
									@StateId,
									@CountryId,
									@ZipCode,
									@WebSite,
									@Email,
									@Phone1,
									@Phone2,
									@Fax,
									@Alias,
									@DOC,
									@DOU,
									@Status,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	VendorAddress
		SET		AddressType		= @AddressType,
				IsPreferred		= @IsPreferred,
				VAddress		= @VAddress,
				CityId			= @CityId,
				StateId			= @StateId,
				CountryId		= @CountryId,
				ZipCode			= @ZipCode,
				WebSite			= @WebSite,
				Email			= @Email,
				Phone1 			= @Phone1,
				Phone2 			= @Phone2,
				Fax				= @Fax,
				Alias			= @Alias,
				DOC 			= @DOC,
				DOU 			= @DOU,
				Status			= @Status,
				TransactionId	= @TransactionId
		WHERE	VendorAddressId = @VendorAddressId
		SELECT	@VendorAddressId
	END
GO

-- ==========================================================================================
-- Entity Name:	usp_VendorAddress_UPDATERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:27:58 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM VendorAddress table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorAddress_D
(
	@VendorAddressId BIGINT
)	
AS
BEGIN
	UPDATE	VendorAddress
	SET		[Status] = 'Inactive'
	WHERE	VendorAddressId = @VendorAddressId
END

GO
-- ==========================================================================================
--END : VendorAddress
-- ==========================================================================================
-- ==========================================================================================
--START : VendorContactDetails
-- ==========================================================================================

-- ==========================================================================================
-- Entity Name:	usp_VendorContactDetails_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:06 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM VendorContactDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorContactDetails_S
(
	@Flag					NVARCHAR(25),
	@VENDorContactDetailId	BIGINT
)
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	VENDorContactDetailId,
				VendorId,
				CityId,
				Email,
				PhoneNo1,
				PhoneNo2,
				VAddress,
				StateId,
				CountryId,
				Zipcode,
				WebSite,
				Fax,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VendorContactDetails
		WHERE	[Status] ='Active'
	END
ELSE
	BEGIN
		SELECT	VENDorContactDetailId,
				VendorId,
				CityId,
				Email,
				PhoneNo1,
				PhoneNo2,
				VAddress,
				StateId,
				CountryId,
				Zipcode,
				WebSite,
				Fax,
				Alias,
				DOC,
				DOU,
				Status,
				TransactionId
		FROM	VendorContactDetails
		WHERE	VENDorContactDetailId = @VENDorContactDetailId
		AND		[Status] ='Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	usp_VendorContactDetails_UPDATE
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:06 PM
-- Description:	This stored procedure is INTENDed for updating VendorContactDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorContactDetails_IU
(	
	@Flag						NVARCHAR(25),
	@VENDorContactDetailId		BIGINT,
	@VendorId					BIGINT,
	@CityId						BIGINT,
	@Email						NVARCHAR(25),
	@PhoneNo1					INT,
	@PhoneNo2					INT,
	@VAddress					NVARCHAR(200),
	@StateId					BIGINT,
	@CountryId					BIGINT,
	@Zipcode					INT,
	@WebSite					NVARCHAR(100),
	@Fax						NVARCHAR(50),
	@Alias						NVARCHAR(100),
	@DOC						DATETIME,
	@DOU						DATETIME,
	@Status						NVARCHAR(25),
	@TransactionId				BIGINT
)
AS
BEGIN
	IF(@Flag='Insert')
		BEGIN
			INSERT INTO VendorContactDetails(	VendorId,
												CityId,
												Email,
												PhoneNo1,
												PhoneNo2,
												VAddress,
												StateId,
												CountryId,
												Zipcode,
												WebSite,
												Fax,
												Alias,
												DOC,
												DOU,
												Status,
												TransactionId
											)
			VALUES							(	@VendorId,
												@CityId,
												@Email,
												@PhoneNo1,
												@PhoneNo2,
												@VAddress,
												@StateId,
												@CountryId,
												@Zipcode,
												@WebSite,
												@Fax,
												@Alias,
												@DOC,
												@DOU,
												@Status,
												@TransactionId
											)

			SELECT @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE		VendorContactDetails
			SET			VendorId = @VendorId,
						CityId = @CityId,
						Email = @Email,
						PhoneNo1 = @PhoneNo1,
						PhoneNo2 = @PhoneNo2,
						VAddress = @VAddress,
						StateId = @StateId,
						CountryId = @CountryId,
						Zipcode = @Zipcode,
						WebSite = @WebSite,
						Fax = @Fax,
						Alias = @Alias,
						DOC = @DOC,
						DOU = @DOU,
						Status = @Status,
						TransactionId = @TransactionId
			WHERE		VENDorContactDetailId = @VENDorContactDetailId
			SELECT		@VENDorContactDetailId
		END


	END
GO

-- ==========================================================================================
-- Entity Name:	usp_VendorContactDetails_DELETERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:06 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM VendorContactDetails table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorContactDetails_D
(
	@VENDorContactDetailId BIGINT
)
AS
BEGIN
	UPDATE	dbo.VendorContactDetails
	SET		[Status]='Inactive'
	WHERE	VENDorContactDetailId = @VENDorContactDetailId

END

GO

-- ==========================================================================================
--END : VendorContactDetails
-- ==========================================================================================
-- ==========================================================================================
--START : VendorMaster
-- ==========================================================================================



-- ==========================================================================================
-- Entity Name:	usp_VendorMaster_SELECTRow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:16 PM
-- Description:	This stored procedure is INTENDed for SELECTing a specific row FROM VendorMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_VendrMaster_S
(
	@Flag				NVARCHAR(25),
	@VendorId			BIGINT
)
AS
BEGIN
	IF(@Flag='ALL')
		BEGIN
			SELECT	VendorId,
					VendorName,
					VendorType,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	VendorMaster
			WHERE	[Status] ='Active'
		END
	ELSE
		BEGIN
			SELECT	VendorId,
					VendorName,
					VendorType,
					Alias,
					DOC,
					DOU,
					Status,
					TransactionId
			FROM	VendorMaster
			WHERE	VendorId = @VendorId
			AND		[Status] ='Active'
		END
END
GO

-- ==========================================================================================
-- Entity Name:	usp_VendorMaster_Insert
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:16 PM
-- Description:	This stored procedure is INTENDed for inserting VALUES to VendorMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorMaster_IU
	@Flag				NVARCHAR(25),
	@VendorId			BIGINT,
	@VendorName			NVARCHAR(100),
	@VendorType			BIGINT,
	@Alias				NVARCHAR(100),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@Status				NVARCHAR(25),
	@TransactionId		BIGINT
AS
BEGIN

		IF	@Flag ='INSERT'
			BEGIN
					INSERT INTO VendorMaster(	VendorName,
												VendorType,
												Alias,
												DOC,
												DOU,
												Status,
												TransactionId
											)
					VALUES					(	@VendorName,
												@VendorType,
												@Alias,
												@DOC,
												@DOU,
												@Status,
												@TransactionId
											)			
					SELECT @@IDENTITY
			END
		ELSE
		BEGIN
			
				UPDATE		VendorMaster
				SET			VendorName		= @VendorName,
							VendorType		= @VendorType,
							Alias			= @Alias,
							DOC				= @DOC,
							DOU				= @DOU,
							Status			= @Status,
							TransactionId	= @TransactionId
				WHERE		VendorId		= @VendorId
				SELECT		@VendorId
		END
END
GO



-- ==========================================================================================
-- Entity Name:	usp_VendorMaster_DELETERow
-- Author:	Arvind Gautam
-- Create date:	06/15/12 2:28:16 PM
-- Description:	This stored procedure is INTENDed for deleting a specific row FROM VendorMaster table
-- ==========================================================================================
ALTER PROCEDURE usp_VendorMaster_D
(
	@VendorId BIGINT
)
AS
BEGIN
	UPDATE	VendorMaster
	SET		[Status] ='Inactive'
	WHERE	VendorId = @VendorId

END

GO
-- ==========================================================================================
--END : VendorMaster
-- ==========================================================================================
/*
AdvancePolicy - TravelMode-TravelType
Processes- TravelMode-TravelType
PerDiemPolicy- TravelMode-TravelType
TravelPolicy = ModeOfTravel-TravelMode
*/

-- ==========================================================================================
-- Entity Name:	uusp_ApprovalTransaction_S
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:36:29 PM
-- Description:	This stored procedure is intended for selecting a specific row from ApprovalTransaction table
-- ==========================================================================================
CREATE PROCEDURE uusp_ApprovalTransaction_S
(
	@Flag					NVARCHAR(25),
	@ApprovalTransactionId	BIGINT
)
AS
IF @Flag = 'ALL'
	BEGIN
		SELECT	ApprovalTransactionId,
				ProcessId,
				TravelRequestId,
				EmployeeId,
				Remark,
				ActionTakenBy,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	ApprovalTransaction
		WHERE	[Status]='Active'
	END
ELSE
	BEGIN
		SELECT	ApprovalTransactionId,
				ProcessId,
				TravelRequestId,
				EmployeeId,
				Remark,
				ActionTakenBy,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	ApprovalTransaction
		WHERE	ApprovalTransactionId = @ApprovalTransactionId
		AND		[Status]='Active'
	END

GO

-- ==========================================================================================
-- Entity Name:	uusp_ApprovalTransaction_Insert
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:36:29 PM
-- Description:	This stored procedure is intended for inserting values to ApprovalTransaction table
-- ==========================================================================================
CREATE PROCEDURE uusp_ApprovalTransaction_IU
(
	@Flag					NVARCHAR(25),
	@ApprovalTransactionId	BIGINT,
	@ProcessId				BIGINT,
	@TravelRequestId		BIGINT,
	@EmployeeId				BIGINT,
	@Remark					NVARCHAR(200),
	@ActionTakenBy			BIGINT,
	@Status					NVARCHAR(25),
	@DOC					DATETIME,
	@DOU					DATETIME,
	@TransactionId			BIGINT
)	
AS
IF @Flag ='INSERT'
	BEGIN
		INSERT INTO ApprovalTransaction	(	ProcessId,
											TravelRequestId,
											EmployeeId,
											Remark,
											ActionTakenBy,
											Status,
											DOC,
											DOU,
											TransactionId
										)
		VALUES							(	@ProcessId,
											@TravelRequestId,
											@EmployeeId,
											@Remark,
											@ActionTakenBy,
											@Status,
											@DOC,
											@DOU,
											@TransactionId
										)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	ApprovalTransaction
		SET		ProcessId				= @ProcessId,
				TravelRequestId 		= @TravelRequestId,
				EmployeeId				= @EmployeeId,
				Remark					= @Remark,
				ActionTakenBy			= @ActionTakenBy,
				Status					= @Status,
				DOC						= @DOC,
				DOU						= @DOU,
				TransactionId			= @TransactionId
		WHERE	ApprovalTransactionId	= @ApprovalTransactionId
		SELECT	@ApprovalTransactionId
	END
GO


-- ==========================================================================================
-- Entity Name:	uusp_ApprovalTransaction_D
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:36:29 PM
-- Description:	This stored procedure is intended for deleting a specific row from ApprovalTransaction table
-- ==========================================================================================
CREATE PROCEDURE uusp_ApprovalTransaction_D
(
	@ApprovalTransactionId BIGINT
)	
AS
BEGIN
	UPDATE ApprovalTransaction
	SET		[Status] = 'Inactive'
	WHERE	ApprovalTransactionId = @ApprovalTransactionId
END

GO

-- ==========================================================================================
-- Entity Name:	uusp_Documents_S
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:33 PM
-- Description:	This stored procedure is intended for selecting a specific row from Documents table
-- ==========================================================================================
CREATE PROCEDURE uusp_Documents_S
(
	@Flag		NVARCHAR(25),
	@DocumentId BIGINT
)	
AS
IF @Flag  ='ALL'
	BEGIN
		SELECT	DocumentId,
				ProcessId,
				TravelRequestId,
				ReferenceName,
				Remark,
				Location,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	Documents
		WHERE	[Status] = 'Active'
	END
ELSE
	BEGIN
		SELECT	DocumentId,
				ProcessId,
				TravelRequestId,
				ReferenceName,
				Remark,
				Location,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	Documents
		WHERE	DocumentId = @DocumentId
		AND		[Status] = 'Active'
	END
	
GO

-- ==========================================================================================
-- Entity Name:	uusp_Documents_Insert
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:33 PM
-- Description:	This stored procedure is intended for inserting values to Documents table
-- ==========================================================================================
CREATE PROCEDURE uusp_Documents_IU
(
	@Flag				NVARCHAR(25),
	@DocumentId			BIGINT,
	@ProcessId			BIGINT,
	@TravelRequestId	BIGINT,
	@ReferenceName		NVARCHAR(100),
	@Remark				NVARCHAR(200),
	@Location			NVARCHAR(100),
	@Status				NVARCHAR(25),
	@DOC 				DATETIME,
	@DOU 				DATETIME,
	@TransactionId		BIGINT
)	
AS
IF	@Flag = 'INSERT'
	BEGIN
		INSERT INTO Documents(	ProcessId,
								TravelRequestId,
								ReferenceName,
								Remark,
								Location,
								Status,
								DOC,
								DOU,
								TransactionId
							 )
		VALUES				 (	@ProcessId,
								@TravelRequestId,
								@ReferenceName,
								@Remark,
								@Location,
								@Status,
								@DOC,
								@DOU,
								@TransactionId
							 )
		SELECT @@IDENTITY
	END
ELSE	
	BEGIN
		UPDATE	Documents
		SET		ProcessId		= @ProcessId,
				TravelRequestId = @TravelRequestId,
				ReferenceName	= @ReferenceName,
				Remark			= @Remark,
				Location		= @Location,
				Status			= @Status,
				DOC 			= @DOC,
				DOU 			= @DOU,
				TransactionId	= @TransactionId
		WHERE	DocumentId		= @DocumentId
		SELECT	@DocumentId
	END
GO

-- ==========================================================================================
-- Entity Name:	uusp_Documents_D
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:33 PM
-- Description:	This stored procedure is intended for deleting a specific row from Documents table
-- ==========================================================================================
CREATE PROCEDURE uusp_Documents_D
(
	@Flag		NVARCHAR(25),
	@DocumentId BIGINT
)	
AS
BEGIN
	UPDATE	Documents
	SET		[Status] = 'Inactive'
	WHERE	DocumentId = @DocumentId
END

GO

-- ==========================================================================================
-- Entity Name:	uusp_TravelRequest_S
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:42 PM
-- Description:	This stored procedure is intended for selecting a specific row from TravelRequest table
-- ==========================================================================================
CREATE PROCEDURE uusp_TravelRequest_S
(
	@Flag				NVARCHAR(25),
	@TravelRequestId	BIGINT
)	
AS
IF	@Flag = 'ALL'
	BEGIN
		SELECT	TravelRequestId,
				TravelRequestCode,
				ProcessId,
				FromDate,
				ToDate,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	TravelRequest
		WHERE	TravelRequestId = @TravelRequestId
	END
ELSE
	BEGIN
		SELECT	TravelRequestId,
				TravelRequestCode,
				ProcessId,
				FromDate,
				ToDate,
				Status,
				DOC,
				DOU,
				TransactionId
		FROM	TravelRequest
		WHERE	TravelRequestId = @TravelRequestId
	END	
GO

-- ==========================================================================================
-- Entity Name:	uusp_TravelRequest_IU
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:42 PM
-- Description:	This stored procedure is intended for inserting values to TravelRequest table
-- ==========================================================================================
Create Procedure uusp_TravelRequest_IU
(
	@Flag				NVARCHAR(25),
	@TravelRequestId	BIGINT,
	@TravelRequestCode	NVARCHAR(50),
	@ProcessId			BIGINT,
	@FromDate			DATETIME,
	@ToDate				DATETIME,
	@Status				NVARCHAR(25),
	@DOC				DATETIME,
	@DOU				DATETIME,
	@TransactionId		BIGINT
)	
AS
IF @Flag ='INSERT'
	BEGIN
		INSERT INTO TravelRequest(	TravelRequestCode,
									ProcessId,
									FromDate,
									ToDate,
									Status,
									DOC,
									DOU,
									TransactionId
								)
		VALUES					(	@TravelRequestCode,
									@ProcessId,
									@FromDate,
									@ToDate,
									@Status,
									@DOC,
									@DOU,
									@TransactionId
								)
		SELECT @@IDENTITY
	END
ELSE
	BEGIN
		UPDATE	TravelRequest
		SET		TravelRequestCode = @TravelRequestCode,
				ProcessId = @ProcessId,
				FromDate = @FromDate,
				ToDate = @ToDate,
				Status = @Status,
				DOC = @DOC,
				DOU = @DOU,
				TransactionId = @TransactionId
		WHERE	TravelRequestId = @TravelRequestId
		SELECT	@TravelRequestId
	END

GO

-- ==========================================================================================
-- Entity Name:	uusp_TravelRequest_D
-- Author:	Arvind Gautam
-- Create date:	06/18/12 4:38:42 PM
-- Description:	This stored procedure is intended for deleting a specific row from TravelRequest table
-- ==========================================================================================
CREATE PROCEDURE uusp_TravelRequest_D
(
	@TravelRequestId BIGINT
)
AS
BEGIN
	UPDATE	TravelRequest
	SET		Status = 'Inactive'
	WHERE	TravelRequestId = @TravelRequestId
END

GO
