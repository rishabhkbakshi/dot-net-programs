﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using Admin.BD;
using Admin.BO;
using System.Configuration;
namespace Admin.BO
{
    public class clsCostCenterDepartmentHeadMappingBO
    {
        public static int CostCenterDepartmentHeadMapping(clsCostCenterDepartmentHeadMappingBD objCostCenterDepartmentHeadMapping)
        {
            OleDbConnection cnCostCenterDepartmentHeadMapping = new OleDbConnection(ConfigurationManager.AppSettings["strConnection"]);
            try
            {
                OleDbCommand cmdCostCenterDepartmentHeadMapping = new OleDbCommand("usp_CostCenterDepartmentHead_IU", cnCostCenterDepartmentHeadMapping);
                cmdCostCenterDepartmentHeadMapping.CommandType = CommandType.StoredProcedure;
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("@Flag", objCostCenterDepartmentHeadMapping.Flag);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("CDHID", objCostCenterDepartmentHeadMapping.CDHID);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("OSID", objCostCenterDepartmentHeadMapping.OSID);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("CostCenter", objCostCenterDepartmentHeadMapping.CostCenter);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("EmpId", objCostCenterDepartmentHeadMapping.EmpId);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("Email", objCostCenterDepartmentHeadMapping.Email);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("DOC", objCostCenterDepartmentHeadMapping.DOC);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("DOU", objCostCenterDepartmentHeadMapping.DOU);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("Status", objCostCenterDepartmentHeadMapping.Status);
                cmdCostCenterDepartmentHeadMapping.Parameters.AddWithValue("GradeId", objCostCenterDepartmentHeadMapping.GradeId);
                cnCostCenterDepartmentHeadMapping.Open();
                int Mapping = Convert.ToInt32(cmdCostCenterDepartmentHeadMapping.ExecuteScalar());
                cnCostCenterDepartmentHeadMapping.Close();
                return Mapping;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                cnCostCenterDepartmentHeadMapping.Close();
                cnCostCenterDepartmentHeadMapping.Dispose();
            }

        }

        public static DataTable GetCostCenterDepartmentHeadMapping()
        {
            OleDbConnection cnRequest = new OleDbConnection(ConfigurationManager.AppSettings["strConnection"]);
            try
            {
                DataTable dtRequest = new DataTable();
                OleDbCommand cmdRequest = new OleDbCommand("usp_CostCenterDepartmentHead_S", cnRequest);
                cmdRequest.CommandType = CommandType.StoredProcedure;
                OleDbDataAdapter daRequest = new OleDbDataAdapter(cmdRequest);
                daRequest.Fill(dtRequest);
                return dtRequest;
            }
            catch (Exception ex)
            {
                return new DataTable();
            }
            finally
            {
                cnRequest.Close();
                cnRequest.Dispose();
            }
        }

        public static bool DeleteCostCenterDepartmentHeadMapping(long CDHID)
        {
            OleDbConnection cnRequest = new OleDbConnection(ConfigurationManager.AppSettings["strConnection"]);
            try
            {
                OleDbCommand cmdRequest = new OleDbCommand("usp_CostCenterDepartmentHead_D", cnRequest);
                cnRequest.Open();
                cmdRequest.CommandType = CommandType.StoredProcedure;
                cmdRequest.Parameters.AddWithValue("@CDHID", CDHID);
                cmdRequest.ExecuteNonQuery();
                cnRequest.Close();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                throw ex;
            }
            finally
            {
                cnRequest.Close();
                cnRequest.Dispose();
            }
        }
    }
}


