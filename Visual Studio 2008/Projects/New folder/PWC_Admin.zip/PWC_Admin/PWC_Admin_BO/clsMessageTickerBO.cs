﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using Admin.BD;
namespace Admin.BO
{
    public class clsMessageTickerBO
    {
        public static DataTable GetMessageTickerData(string Flag, long MTID)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                DataTable dtMessageTicker = new DataTable();
                OleDbCommand cmdusp_MessageTicker_Select = new OleDbCommand("usp_MessageTicker_S", oCon);
                cmdusp_MessageTicker_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_MessageTicker_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_MessageTicker_Select.Parameters.Add("@MTID", OleDbType.BigInt).Value = MTID;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_MessageTicker_Select);
                objOleDbDataAdapter.Fill(dtMessageTicker);
                return dtMessageTicker;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int InsertUpdateMessageTickerData(clsMessageTickerBD oclsMessageTickerBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_MessageTicker_Select = new OleDbCommand("usp_MessageTicker_IU", oCon);
                cmdusp_MessageTicker_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_MessageTicker_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = oclsMessageTickerBD.Flag;
                cmdusp_MessageTicker_Select.Parameters.Add("@MTID", OleDbType.BigInt).Value = oclsMessageTickerBD.MTID;
                cmdusp_MessageTicker_Select.Parameters.Add("@Message", OleDbType.VarChar).Value = oclsMessageTickerBD.Message;
                cmdusp_MessageTicker_Select.Parameters.Add("@RoleId", OleDbType.BigInt).Value = oclsMessageTickerBD.RoleID;
                cmdusp_MessageTicker_Select.Parameters.Add("@Color", OleDbType.VarChar).Value = oclsMessageTickerBD.Color;
                cmdusp_MessageTicker_Select.Parameters.Add("@Status", OleDbType.VarChar).Value = oclsMessageTickerBD.Status;
                cmdusp_MessageTicker_Select.Parameters.Add("@DOC", OleDbType.Date).Value = oclsMessageTickerBD.DOC;
                cmdusp_MessageTicker_Select.Parameters.Add("@DOU", OleDbType.Date).Value = oclsMessageTickerBD.DOU;
                return cmdusp_MessageTicker_Select.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int DeleteMessageTickerData(long MTID)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_MessageTicker_Select = new OleDbCommand("usp_MessageTicker_D", oCon);
                cmdusp_MessageTicker_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_MessageTicker_Select.Parameters.Add("@MTID", OleDbType.BigInt).Value = MTID;
                return cmdusp_MessageTicker_Select.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
