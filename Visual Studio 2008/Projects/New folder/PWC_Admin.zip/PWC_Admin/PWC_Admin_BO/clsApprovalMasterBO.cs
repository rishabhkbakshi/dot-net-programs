﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using Admin.BD;
using System.Configuration;

namespace Admin.BO
{
    public class clsApprovalMasterBO
    {
        /// <summary>
        /// Use to Insert and Update roles in DB
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public Int64 InsertUpdate(clsApprovalMasterBD oApprovalMasterBD)
        {
            try
            {
                OleDbCommand cmdApprovalMaster = new OleDbCommand("usp_ApprovalMaster_IU", clsManageTransaction.objConnection);
                cmdApprovalMaster.CommandType = CommandType.StoredProcedure;
                cmdApprovalMaster.Transaction = clsManageTransaction.objTran;
                cmdApprovalMaster.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalMasterBD.Flag;
                cmdApprovalMaster.Parameters.Add("@ApprovalMasterId", OleDbType.BigInt).Value = oApprovalMasterBD.ApprovalMasterId;
                cmdApprovalMaster.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = oApprovalMasterBD.ProcessId;
                cmdApprovalMaster.Parameters.Add("@FromDate", OleDbType.Date).Value = oApprovalMasterBD.FromDate;
                cmdApprovalMaster.Parameters.Add("@ToDate", OleDbType.Date).Value = oApprovalMasterBD.ToDate;
                cmdApprovalMaster.Parameters.Add("@IsEscalated", OleDbType.Boolean).Value = oApprovalMasterBD.IsEscalated;
                cmdApprovalMaster.Parameters.Add("@EscalationAlertDuration", OleDbType.Integer).Value = oApprovalMasterBD.EscalationAlertDuration;
                cmdApprovalMaster.Parameters.Add("@Unit", OleDbType.BigInt).Value = oApprovalMasterBD.Unit;
                cmdApprovalMaster.Parameters.Add("@Currency", OleDbType.BigInt).Value = oApprovalMasterBD.Currency;
                cmdApprovalMaster.Parameters.Add("@Alias", OleDbType.VarChar).Value = oApprovalMasterBD.Alias;
                cmdApprovalMaster.Parameters.Add("@DOC", OleDbType.Date).Value = oApprovalMasterBD.DOC;
                cmdApprovalMaster.Parameters.Add("@DOU", OleDbType.Date).Value = oApprovalMasterBD.DOU;
                cmdApprovalMaster.Parameters.Add("@Status", OleDbType.VarChar).Value = oApprovalMasterBD.Status;
                cmdApprovalMaster.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oApprovalMasterBD.TransactionId; 
                return Convert.ToInt64(cmdApprovalMaster.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public DataSet Select(clsApprovalMasterBD oApprovalMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdApprovalMaster = new OleDbCommand("usp_ApprovalMaster_S", oCon);
                cmdApprovalMaster.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdApprovalMaster.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalMasterBD.Flag;
                cmdApprovalMaster.Parameters.Add("@ApprovalMasterId", OleDbType.BigInt).Value = oApprovalMasterBD.ApprovalMasterId;
                OleDbDataAdapter daApprovalMaster = new OleDbDataAdapter(cmdApprovalMaster);
                DataSet dsApprovalMaster = new DataSet();
                daApprovalMaster.Fill(dsApprovalMaster);
                return dsApprovalMaster;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        /// <summary>
        /// To delete particular role(making inactive)
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int Delete(Int64 ApprovalMasterId)
        {
            try
            {
                OleDbCommand cmdApprovalMaster = new OleDbCommand("usp_ApprovalMaster_D", clsManageTransaction.objConnection);
                cmdApprovalMaster.CommandType = CommandType.StoredProcedure;
                cmdApprovalMaster.Transaction = clsManageTransaction.objTran;
                cmdApprovalMaster.Parameters.Add("@ApprovalMasterId", OleDbType.BigInt).Value = ApprovalMasterId;
                return cmdApprovalMaster.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
