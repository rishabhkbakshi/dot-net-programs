﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

namespace Admin.BO
{
    public class clsKeywordMasterBO
    {

        /// <summary>
        /// Method to insert and update record into database.
        /// </summary>
        /// <param name="objclsKeywordMasterBO"></param>
        /// <returns> bool</returns>        
        public int InsertUpdateKeywordMaster(clsKeywordMasterBD objclsKeywordMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_KeywordMaster_IU = new OleDbCommand("usp_Keywords_IU", clsManageTransaction.objConnection);
                cmdusp_KeywordMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_KeywordMaster_IU.CommandType = CommandType.StoredProcedure;
                //oCon.Open();
                cmdusp_KeywordMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_KeywordMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_KeywordMaster_IU.Parameters.Add("@Flag", OleDbType.Char).Value = objclsKeywordMasterBD.CFlag;
                cmdusp_KeywordMaster_IU.Parameters.Add("@KeywordId", OleDbType.BigInt).Value = objclsKeywordMasterBD.KeywordId;
                cmdusp_KeywordMaster_IU.Parameters.Add("@Keyword", OleDbType.VarChar).Value = objclsKeywordMasterBD.Keyword;
                cmdusp_KeywordMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsKeywordMasterBD.Alias;
                cmdusp_KeywordMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsKeywordMasterBD.Status;
                cmdusp_KeywordMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsKeywordMasterBD.TransactionId;
                return cmdusp_KeywordMaster_IU.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }

        }
        /// <summary>
        /// Fetch all the records inside the keywords
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectKeywordMaster()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_KeywordMaster_Select = new OleDbCommand("usp_Keywords_Select", oCon);
                cmdusp_KeywordMaster_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_KeywordMaster_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// To delete the Keyword Master
        /// </summary>
        /// <param name="objclsKeywordMasterBD"></param>
        /// <returns></returns>
        public int DelKeywordMaster(clsKeywordMasterBD objclsKeywordMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_KeywordMaster_Del = new OleDbCommand("usp_Keywords_Delete", clsManageTransaction.objConnection);
                cmdusp_KeywordMaster_Del.Transaction = clsManageTransaction.objTran;
                cmdusp_KeywordMaster_Del.CommandType = CommandType.StoredProcedure;
                cmdusp_KeywordMaster_Del.Parameters.Add("@KeywordId", OleDbType.BigInt).Value = objclsKeywordMasterBD.KeywordId;
                cmdusp_KeywordMaster_Del.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsKeywordMasterBD.Status;
                return cmdusp_KeywordMaster_Del.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

    }//Class Close
}//NameSpace Close
