﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsEmployeeBO
    {
        /// <summary>
        /// To insert and update the Employees
        /// </summary>
        /// <param name="objclsEmployeeBD"></param>
        /// <returns></returns>
        public long InsertUpdateEmployee(clsEmployeeBD objclsEmployeeBD)
        {
            try
            {
                OleDbCommand cmdusp_Employee_IU = new OleDbCommand("usp_Employee_IU", clsManageTransaction.objConnection);
                cmdusp_Employee_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_Employee_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_Employee_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeeBD.CFlag;
                cmdusp_Employee_IU.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeeBD.EmployeeId;
                cmdusp_Employee_IU.Parameters.Add("@EmployeeCode", OleDbType.VarChar).Value = objclsEmployeeBD.EmployeeCode;
                cmdusp_Employee_IU.Parameters.Add("@FirstName", OleDbType.VarChar).Value = objclsEmployeeBD.FirstName;
                cmdusp_Employee_IU.Parameters.Add("@LastName", OleDbType.VarChar).Value = objclsEmployeeBD.LastName;
                cmdusp_Employee_IU.Parameters.Add("@Gender", OleDbType.VarChar).Value = objclsEmployeeBD.Gender;
                cmdusp_Employee_IU.Parameters.Add("@ReportingManager", OleDbType.BigInt).Value = objclsEmployeeBD.ReportingManager;
                cmdusp_Employee_IU.Parameters.Add("@DelegatationTo", OleDbType.BigInt).Value = objclsEmployeeBD.DelegatationTo;
                cmdusp_Employee_IU.Parameters.Add("@Email", OleDbType.VarChar).Value = objclsEmployeeBD.Email;
                cmdusp_Employee_IU.Parameters.Add("@PersonalPhoneNo", OleDbType.VarChar).Value = objclsEmployeeBD.PersonalPhoneNo;
                cmdusp_Employee_IU.Parameters.Add("@PersonalVehicleNo", OleDbType.VarChar).Value = objclsEmployeeBD.PersonalVehicleNo;
                cmdusp_Employee_IU.Parameters.Add("@CompanyPhoneNo", OleDbType.VarChar).Value = objclsEmployeeBD.CompanyPhoneNo;
                cmdusp_Employee_IU.Parameters.Add("@CompanyVehicleNo", OleDbType.VarChar).Value = objclsEmployeeBD.CompanyVehicleNo;
                cmdusp_Employee_IU.Parameters.Add("@IsSelfApproved", OleDbType.Boolean).Value = objclsEmployeeBD.IsSelfApproved;
                cmdusp_Employee_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsEmployeeBD.Alias;
                cmdusp_Employee_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsEmployeeBD.DOC;
                cmdusp_Employee_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsEmployeeBD.DOU;
                cmdusp_Employee_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsEmployeeBD.Status;
                cmdusp_Employee_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsEmployeeBD.TransactionId;
                cmdusp_Employee_IU.Parameters.Add("@DepartmentId", OleDbType.BigInt).Value = objclsEmployeeBD.DepartmentId;
                cmdusp_Employee_IU.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsEmployeeBD.RoleId;
                cmdusp_Employee_IU.Parameters.Add("@Location", OleDbType.BigInt).Value = objclsEmployeeBD.LocationId;
                return Convert.ToInt64(cmdusp_Employee_IU.ExecuteScalar());
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active Employees
        /// </summary>
        /// <param name="objclsEmployeeBD"></param>
        /// <returns></returns>
        public DataTable SelectEmployee(clsEmployeeBD objclsEmployeeBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_Employee_S = new OleDbCommand("usp_Employee_S", oCon);
                cmd_Employee_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_Employee_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeeBD.CFlag;
                cmd_Employee_S.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeeBD.EmployeeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_Employee_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(make Inactive) particular Employee
        /// </summary>
        /// <param name="objclsEmployeeBD"></param>
        /// <returns></returns>
        public int DeleteEmployee(clsEmployeeBD objclsEmployeeBD)
        {
            try
            {
                OleDbCommand cmdusp_uspEmployee_D = new OleDbCommand("usp_Employee_D", clsManageTransaction.objConnection);
                cmdusp_uspEmployee_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspEmployee_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspEmployee_D.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeeBD.EmployeeId;
                return cmdusp_uspEmployee_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active Employees
        /// </summary>
        /// <param name="objclsEmployeeBD"></param>
        /// <returns></returns>
        public DataTable SelectOrganisationStructure(string Flage, long OrganisationStructureTypeId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_Employee_S = new OleDbCommand("usp_OrganisationStructures", oCon);
                cmd_Employee_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_Employee_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flage;
                cmd_Employee_S.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = OrganisationStructureTypeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_Employee_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        /// <summary>
        /// To Fetch Organization Structure Datae
        /// </summary>
        /// <returns>DataTable</returns>
        public DataSet SelectOS()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_Employee_S = new OleDbCommand("usp_GetOSTrees", oCon);
                cmd_Employee_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_Employee_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
    }
}
