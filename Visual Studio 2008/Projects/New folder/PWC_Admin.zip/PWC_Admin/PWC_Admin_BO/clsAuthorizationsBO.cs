﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsAuthorizationsBO
    {
        /// <summary>
        /// Insert and update data in TravelPolicy
        /// </summary>
        /// <param name="objclsAuthorizationsBO"></param>
        /// <returns></returns>
        public bool InsertUpdateAuthorizations(clsAuthorizationsBD objclsAuthorizationsBD)
        {
            try
            {
                OleDbCommand cmdusp_AuthorizationsIU = new OleDbCommand("usp_Authorizations_IU", clsManageTransaction.objConnection);
                cmdusp_AuthorizationsIU.Transaction = clsManageTransaction.objTran;
                cmdusp_AuthorizationsIU.CommandType = CommandType.StoredProcedure;
                cmdusp_AuthorizationsIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAuthorizationsBD.CFlag;
                cmdusp_AuthorizationsIU.Parameters.Add("@AuthorizationId", OleDbType.BigInt).Value = objclsAuthorizationsBD.AuthorizationId;
                cmdusp_AuthorizationsIU.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsAuthorizationsBD.RoleId;
                cmdusp_AuthorizationsIU.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = objclsAuthorizationsBD.ProcessId;
                cmdusp_AuthorizationsIU.Parameters.Add("@IsModify", OleDbType.Boolean).Value = objclsAuthorizationsBD.IsModify;
                cmdusp_AuthorizationsIU.Parameters.Add("@IsDelete", OleDbType.Boolean).Value = objclsAuthorizationsBD.IsDelete;
                cmdusp_AuthorizationsIU.Parameters.Add("@IsAdd", OleDbType.Boolean).Value = objclsAuthorizationsBD.IsAdd;
                cmdusp_AuthorizationsIU.Parameters.Add("@IsView", OleDbType.Boolean).Value = objclsAuthorizationsBD.IsView;
                cmdusp_AuthorizationsIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAuthorizationsBD.Alias;
                cmdusp_AuthorizationsIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAuthorizationsBD.DOC;
                cmdusp_AuthorizationsIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAuthorizationsBD.DOU;
                cmdusp_AuthorizationsIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAuthorizationsBD.Status;
                cmdusp_AuthorizationsIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAuthorizationsBD.TransactionId;
                cmdusp_AuthorizationsIU.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch all the records from Authorizations table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectAuthorizationsData(long RoleId)   
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_AuthorizationsData_Select = new OleDbCommand("usp_AuthorizationsByProcess_S", oCon);
                cmdusp_AuthorizationsData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_AuthorizationsData_Select.Parameters.Add("@RoleId", OleDbType.VarChar).Value = RoleId;                
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_AuthorizationsData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="RoleId"></param>
        /// <returns></returns>
        public DataTable SelectProcessAll()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdProcess = new OleDbCommand("usp_Processes_ALL", oCon);
                cmdProcess.CommandType = CommandType.StoredProcedure;
                oCon.Open();               
                OleDbDataAdapter daProcess = new OleDbDataAdapter(cmdProcess);
                DataSet dsProcess = new DataSet();
                daProcess.Fill(dsProcess);
                return dsProcess.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
    }
}
