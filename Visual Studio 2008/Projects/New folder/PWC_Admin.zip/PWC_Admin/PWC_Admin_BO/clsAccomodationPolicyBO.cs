﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
   public class clsAccomodationPolicyBO
   {
       /// <summary>
       /// Insert and update data in AccomodationPolicy
       /// </summary>
       /// <param name="objclsAccomodationPolicyBD"></param>
       /// <returns></returns>
       public int InsertUpdateAccomodationPolicy(clsAccomodationPolicyBD objclsAccomodationPolicyBD)
       {
           try
           {
               OleDbCommand cmdusp_AccomodationPolicyIU = new OleDbCommand("usp_AccomodationPolicy_IU", clsManageTransaction.objConnection);
               cmdusp_AccomodationPolicyIU.Transaction = clsManageTransaction.objTran;
               cmdusp_AccomodationPolicyIU.CommandType = CommandType.StoredProcedure;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAccomodationPolicyBD.CFlag;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = objclsAccomodationPolicyBD.AccomodationPolicyId;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsAccomodationPolicyBD.GradeId;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@TravelType", OleDbType.BigInt).Value = objclsAccomodationPolicyBD.TravelType;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@AccomodationRateId", OleDbType.BigInt).Value = objclsAccomodationPolicyBD.AccomodationRateId;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@Gender", OleDbType.VarChar).Value = objclsAccomodationPolicyBD.Gender;              
               cmdusp_AccomodationPolicyIU.Parameters.Add("@PriorityOfAllocation", OleDbType.VarChar).Value = objclsAccomodationPolicyBD.PriorityOfAllocation;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@IsEnforcePriority", OleDbType.Boolean).Value = objclsAccomodationPolicyBD.IsEnforcePriority;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@EffectiveFROMDate", OleDbType.Date).Value = objclsAccomodationPolicyBD.EffectiveFROMDate;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@EffectiveToDate", OleDbType.Date).Value = objclsAccomodationPolicyBD.EffectiveToDate;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@IsBehalfOfBooking", OleDbType.Boolean).Value = objclsAccomodationPolicyBD.IsBehalfOfBooking;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAccomodationPolicyBD.Alias;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAccomodationPolicyBD.DOC;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAccomodationPolicyBD.DOU;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAccomodationPolicyBD.Status;
               cmdusp_AccomodationPolicyIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAccomodationPolicyBD.TransactionId;
               int retval = Convert.ToInt32(cmdusp_AccomodationPolicyIU.ExecuteScalar());
               return retval;
           }
           catch (Exception ex)
           {
               clsErrorLogBO.WriteErrorLog_Text(ex);
               throw ex;
           }
       }
       /// <summary>
       /// Fetch all the records from AccomodationPolicy table
       /// </summary>
       /// <returns>DataTable</returns>
       public DataTable SelectAccomodationPolicyData(long AccomodationPolicyId)
       {
           string Flag = AccomodationPolicyId == 0 ? "ALL" : "ACCOMODATIONPOLICYID";
           string ConnectionString = Convert.ToString(ConfigurationSettings.AppSettings["strConnection"]);
           ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
           OleDbConnection oCon = new OleDbConnection(ConnectionString);
           try
           {
               OleDbCommand cmdusp_AccomodationPolicyData_Select = new OleDbCommand("usp_AccomodationPolicy_S", oCon);
               cmdusp_AccomodationPolicyData_Select.CommandType = CommandType.StoredProcedure;
               oCon.Open();
               cmdusp_AccomodationPolicyData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
               cmdusp_AccomodationPolicyData_Select.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = AccomodationPolicyId;
               OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_AccomodationPolicyData_Select);
               DataSet objDataSet = new DataSet();
               objOleDbDataAdapter.Fill(objDataSet);
               return objDataSet.Tables[0];
           }
           catch (Exception ex)
           {
               clsErrorLogBO.WriteErrorLog_Text(ex);
               return null;
           }
           finally
           {
               oCon.Close();
               oCon.Dispose();
           }

       }
       /// <summary>
       /// Method to delete AccomodationPolicy record from the database.
       /// </summary>
       /// <param name="TravelPolicyId">AccomodationPolicyId</param>
       /// <returns>bool</returns>
       public bool DeleteAccomodationPolicy(Int64 AccomodationPolicyId)
       {
           try
           {
               OleDbCommand cmdusp_AccomodationPolicyDelete = new OleDbCommand("usp_AccomodationPolicy_D", clsManageTransaction.objConnection);
               cmdusp_AccomodationPolicyDelete.Transaction = clsManageTransaction.objTran;
               cmdusp_AccomodationPolicyDelete.CommandType = CommandType.StoredProcedure;
               cmdusp_AccomodationPolicyDelete.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = AccomodationPolicyId;
               cmdusp_AccomodationPolicyDelete.ExecuteNonQuery();
               return true;
           }
           catch (Exception ex)
           {
               clsErrorLogBO.WriteErrorLog_Text(ex);
               throw ex;
           }
       }
       /// <summary>
       /// Fetch all the records from Masters table based on Keyword
       /// </summary>
       ///<param name="AccomodationPolicyId"></param>
       /// <returns>DataTable</returns>
       public DataTable GetAccomodationPriorityData(long AccomodationPolicyId)
       {
           string Flag = AccomodationPolicyId == 0 ? "ALL" : "ACCOMODATIONPOLICYID";
           string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
           string ConnectionString = string.Empty;
           if (string.Compare(IsEncrypted, "No") == 0)
           {
               ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
           }
           else
           {
               ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
               ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
           }
           OleDbConnection oCon = new OleDbConnection(ConnectionString);
           try
           {
               OleDbCommand cmdusp_AccomodationPriority_Select = new OleDbCommand("usp_AccomodationPriority_S", oCon);
               cmdusp_AccomodationPriority_Select.CommandType = CommandType.StoredProcedure;
               oCon.Open();
               cmdusp_AccomodationPriority_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
               cmdusp_AccomodationPriority_Select.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = AccomodationPolicyId;
               OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_AccomodationPriority_Select);
               DataSet objDataSet = new DataSet();
               objOleDbDataAdapter.Fill(objDataSet);
               return objDataSet.Tables[0];
           }
           catch (Exception)
           {
               return null;
           }
           finally
           {
               oCon.Close();
               oCon.Dispose();
           }

       }
       /// <summary>
       /// Insert and update data in AccomodationPriority
       /// </summary>
       /// <param name="objclsAccomodationPriorityBD"></param>
       /// <returns></returns>
       public bool InsertUpdateAccomodationPriority(clsAccomodationPriorityBD objclsAccomodationPriorityBD)
       {
           try
           {
               OleDbCommand cmdusp_AccomodationPriorityIU = new OleDbCommand("usp_AccomodationPriority_IU", clsManageTransaction.objConnection);
               cmdusp_AccomodationPriorityIU.Transaction = clsManageTransaction.objTran;
               cmdusp_AccomodationPriorityIU.CommandType = CommandType.StoredProcedure;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAccomodationPriorityBD.CFlag;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@AccomodationPriorityId", OleDbType.BigInt).Value = objclsAccomodationPriorityBD.AccomodationPriorityId;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = objclsAccomodationPriorityBD.AccomodationPolicyId;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@AccomodationType", OleDbType.BigInt).Value = objclsAccomodationPriorityBD.AccomodationType;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@AccomodationName", OleDbType.VarChar).Value = objclsAccomodationPriorityBD.AccomodationName;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@Priority", OleDbType.Integer).Value = objclsAccomodationPriorityBD.Priority;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAccomodationPriorityBD.Alias;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAccomodationPriorityBD.DOC;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAccomodationPriorityBD.DOU;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAccomodationPriorityBD.Status;
               cmdusp_AccomodationPriorityIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAccomodationPriorityBD.TransactionId;
               cmdusp_AccomodationPriorityIU.ExecuteNonQuery();
               return true;
           }
           catch (Exception ex)
           {
               clsErrorLogBO.WriteErrorLog_Text(ex);
               throw ex;
           }
       }
   }
}