﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsGradeMasterBO
    {
        /// <summary>
        /// Insert and update data in Grade
        /// </summary>
        /// <param name="objclsGradeMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateGradeMaster(clsGradeMasterBD objclsGradeMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_GradeMaster_IU = new OleDbCommand("usp_Grade_IU", clsManageTransaction.objConnection);
                cmdusp_GradeMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_GradeMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_GradeMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsGradeMasterBD.CFlag;
                cmdusp_GradeMaster_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsGradeMasterBD.GradeId;
                cmdusp_GradeMaster_IU.Parameters.Add("@GradeName", OleDbType.VarChar).Value = objclsGradeMasterBD.GradeName;
                cmdusp_GradeMaster_IU.Parameters.Add("@Descriptions", OleDbType.VarChar).Value = objclsGradeMasterBD.Descriptions;
                cmdusp_GradeMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsGradeMasterBD.Alias;
                cmdusp_GradeMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsGradeMasterBD.DOC;
                cmdusp_GradeMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsGradeMasterBD.DOU;
                cmdusp_GradeMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsGradeMasterBD.Status;
                cmdusp_GradeMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsGradeMasterBD.TransactionId;
                cmdusp_GradeMaster_IU.Parameters.Add("@ParentId", OleDbType.BigInt).Value = objclsGradeMasterBD.ParentId;
                cmdusp_GradeMaster_IU.Parameters.Add("@Level", OleDbType.VarChar).Value = objclsGradeMasterBD.Level;
                return cmdusp_GradeMaster_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active Grade
        /// </summary>
        /// <param name="objclsGradeMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectGradeMaster(clsGradeMasterBD objclsGradeMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_GradeMaster_S = new OleDbCommand("usp_Grade_S", oCon);
                cmdusp_GradeMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_GradeMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsGradeMasterBD.CFlag;
                cmdusp_GradeMaster_S.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsGradeMasterBD.GradeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_GradeMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete a particular grade(making inactive)
        /// </summary>
        /// <param name="objclsGradeMasterBD"></param>
        /// <returns></returns>
        public int DeleteGradeMaster(clsGradeMasterBD objclsGradeMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_GradeMaste_D = new OleDbCommand("usp_Grade_D", clsManageTransaction.objConnection);
                cmdusp_GradeMaste_D.CommandType = CommandType.StoredProcedure;
                cmdusp_GradeMaste_D.Transaction = clsManageTransaction.objTran;
                cmdusp_GradeMaste_D.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsGradeMasterBD.GradeId;
                return cmdusp_GradeMaste_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
