﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsAdvancePolicyBO
    {
        /// <summary>
        /// To insert and update Advance policy
        /// </summary>
        /// <param name="objclsAdvancePolicyBD"></param>
        /// <returns></returns>
        public int InsertUpdateAdvancePolicy(clsAdvancePolicyBD objclsAdvancePolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_AdvancePolicy_IU = new OleDbCommand("usp_AdvancePolicy_IU", clsManageTransaction.objConnection);
                cmdusp_AdvancePolicy_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_AdvancePolicy_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAdvancePolicyBD.CFlag;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@AdvancePolicyId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.AdvancePolicyId;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@TravelType", OleDbType.BigInt).Value = objclsAdvancePolicyBD.TravelType;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.GradeId;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@APFrom", OleDbType.Numeric).Value = objclsAdvancePolicyBD.APFrom;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@FromUnit", OleDbType.BigInt).Value = objclsAdvancePolicyBD.FromUnit;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@APTo", OleDbType.Numeric).Value = objclsAdvancePolicyBD.APTo;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@ToUnit", OleDbType.BigInt).Value = objclsAdvancePolicyBD.ToUnit;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@Amount", OleDbType.Numeric).Value = objclsAdvancePolicyBD.Amount;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@Currency", OleDbType.BigInt).Value = objclsAdvancePolicyBD.Currency;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAdvancePolicyBD.Alias;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAdvancePolicyBD.DOC;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAdvancePolicyBD.DOU;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAdvancePolicyBD.Status;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.TransactionId;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@PermissibleUnsettledAmount", OleDbType.Numeric).Value = objclsAdvancePolicyBD.PermissibleUnsettledAmount;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@ApproverGradeId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.ApproverGradeId;
                cmdusp_AdvancePolicy_IU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.ApproverGradeId;
                return Convert.ToInt32(cmdusp_AdvancePolicy_IU.ExecuteScalar());
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active records in AdvancePolicy
        /// </summary>
        /// <param name="objclsAdvancePolicyBD"></param>
        /// <returns></returns>
        public DataTable SelectAdvancePolicy(clsAdvancePolicyBD objclsAdvancePolicyBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_AdvancePolicy_S = new OleDbCommand("usp_AdvancePolicy_S", oCon);
                cmd_AdvancePolicy_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_AdvancePolicy_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAdvancePolicyBD.CFlag;
                cmd_AdvancePolicy_S.Parameters.Add("@AdvancePolicyId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.AdvancePolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_AdvancePolicy_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(make inactive) a particular AdvancePolicy
        /// </summary>
        /// <param name="objclsAdvancePolicyBD"></param>
        /// <returns></returns>
        public int DeleteAdvancePolicy(clsAdvancePolicyBD objclsAdvancePolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_uspAdvancePolicy_D = new OleDbCommand("usp_AdvancePolicy_D", clsManageTransaction.objConnection);
                cmdusp_uspAdvancePolicy_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspAdvancePolicy_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspAdvancePolicy_D.Parameters.Add("@AdvancePolicyId", OleDbType.BigInt).Value = objclsAdvancePolicyBD.AdvancePolicyId;
                return cmdusp_uspAdvancePolicy_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
