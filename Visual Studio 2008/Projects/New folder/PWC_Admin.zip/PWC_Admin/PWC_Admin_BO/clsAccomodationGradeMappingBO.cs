﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsAccomodationGradeMappingBO
    {
        /// <summary>
        /// To Insert and update in AccomodationGradeMapping
        /// </summary>
        /// <param name="objclsAccomodationGradeMappingBD"></param>
        /// <returns></returns>
        public int InsertUpdateAccomodationGradeMapping(clsAccomodationGradeMappingBD objclsAccomodationGradeMappingBD)
        {
            try
            {
                OleDbCommand cmdusp_AccomodationGradeMapping_IU = new OleDbCommand("usp_AccomodationGradeMapping_IU", clsManageTransaction.objConnection);
                cmdusp_AccomodationGradeMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_AccomodationGradeMapping_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAccomodationGradeMappingBD.CFlag;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@AGMId", OleDbType.BigInt).Value = objclsAccomodationGradeMappingBD.AGMId;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@AccomodationId", OleDbType.BigInt).Value = objclsAccomodationGradeMappingBD.AccomodationId;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsAccomodationGradeMappingBD.GradeId;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAccomodationGradeMappingBD.Alias;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAccomodationGradeMappingBD.DOC;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAccomodationGradeMappingBD.DOU;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAccomodationGradeMappingBD.Status;
                cmdusp_AccomodationGradeMapping_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAccomodationGradeMappingBD.TransactionId;
                return cmdusp_AccomodationGradeMapping_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Delete (make inactive) the AccomodationGradeMapping
        /// </summary>
        /// <param name="objclsAccomodationGradeMappingBD"></param>
        /// <param name="MasterId"></param>
        /// <param name="CityId"></param>
        /// <returns></returns>
        public int DeleteAccomodationGradeMapping(clsAccomodationGradeMappingBD objclsAccomodationGradeMappingBD,Int64 MasterId,Int64 CityId)
        {
            try
            {
                OleDbCommand cmdusp_uspAccomodationGradeMapping_D = new OleDbCommand("usp_AccomodationGradeMapping_D", clsManageTransaction.objConnection);
                cmdusp_uspAccomodationGradeMapping_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspAccomodationGradeMapping_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspAccomodationGradeMapping_D.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsAccomodationGradeMappingBD.GradeId;
                cmdusp_uspAccomodationGradeMapping_D.Parameters.Add("@MasterID", OleDbType.BigInt).Value = MasterId;
                cmdusp_uspAccomodationGradeMapping_D.Parameters.Add("@CityID", OleDbType.BigInt).Value = CityId;
                return cmdusp_uspAccomodationGradeMapping_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
