﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsPolicyGradeMappingBO
    {
        /// <summary>
        /// To insert and update PolicyGradeMapping
        /// </summary>
        /// <param name="objclsPolicyGradeMappingBD"></param>
        /// <returns></returns>
        public int InsertUpdatePolicyGradeMapping(clsPolicyGradeMappingBD objclsPolicyGradeMappingBD)
        {
            try
            {
                OleDbCommand cmdusp_PolicyGradeMapping_IU = new OleDbCommand("usp_PolicyGradeMapping_IU", clsManageTransaction.objConnection);
                cmdusp_PolicyGradeMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_PolicyGradeMapping_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsPolicyGradeMappingBD.CFlag;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@PolicyGradeMappingId", OleDbType.BigInt).Value = objclsPolicyGradeMappingBD.PolicyGradeMappingId;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@ReferencePolicyId", OleDbType.BigInt).Value = objclsPolicyGradeMappingBD.ReferencePolicyId;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@ReferencePolicyType", OleDbType.VarChar).Value = objclsPolicyGradeMappingBD.ReferencePolicyType;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsPolicyGradeMappingBD.GradeId;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsPolicyGradeMappingBD.Alias;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsPolicyGradeMappingBD.DOC;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsPolicyGradeMappingBD.DOU;
                cmdusp_PolicyGradeMapping_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsPolicyGradeMappingBD.Status;
                return cmdusp_PolicyGradeMapping_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active PolicyGradeMapping
        /// </summary>
        /// <param name="objclsPolicyGradeMappingBD"></param>
        /// <returns></returns>
        public DataTable SelectPolicyGradeMapping(clsPolicyGradeMappingBD objclsPolicyGradeMappingBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_PolicyGradeMapping_S = new OleDbCommand("usp_PolicyGradeMapping_S", oCon);
                cmd_PolicyGradeMapping_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_PolicyGradeMapping_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsPolicyGradeMappingBD.CFlag;
                cmd_PolicyGradeMapping_S.Parameters.Add("@PolicyGradeMappingId", OleDbType.BigInt).Value = objclsPolicyGradeMappingBD.ReferencePolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_PolicyGradeMapping_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) a particular  PolicyGradeMapping
        /// </summary>
        /// <param name="objclsPolicyGradeMappingBD"></param>
        /// <returns></returns>
        public int DeletePolicyGradeMapping(clsPolicyGradeMappingBD objclsPolicyGradeMappingBD)
        {
            try
            {
                OleDbCommand cmdusp_uspPolicyGradeMapping_D = new OleDbCommand("usp_PolicyGradeMapping_D", clsManageTransaction.objConnection);
                cmdusp_uspPolicyGradeMapping_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspPolicyGradeMapping_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspPolicyGradeMapping_D.Parameters.Add("@PolicyGradeMappingId", OleDbType.BigInt).Value = objclsPolicyGradeMappingBD.ReferencePolicyId;
                return cmdusp_uspPolicyGradeMapping_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
