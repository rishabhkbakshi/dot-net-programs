﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsVehicleTypeBO
    {
        /// <summary>
        /// To insert and update vehicle type
        /// </summary>
        /// <param name="objclsVehicleTypeBD"></param>
        /// <returns></returns>
        public int InsertUpdateVehicleType(clsVehicleTypeBD objclsVehicleTypeBD)
        {
            try
            {
                OleDbCommand cmdusp_VehicleType_IU = new OleDbCommand("usp_VehicleType_IU", clsManageTransaction.objConnection);
                cmdusp_VehicleType_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_VehicleType_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_VehicleType_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVehicleTypeBD.CFlag;
                cmdusp_VehicleType_IU.Parameters.Add("@VehicleTypeId", OleDbType.BigInt).Value = objclsVehicleTypeBD.VehicleTypeId;
                cmdusp_VehicleType_IU.Parameters.Add("@VehicleName", OleDbType.VarChar).Value = objclsVehicleTypeBD.VehicleName;
                cmdusp_VehicleType_IU.Parameters.Add("@IsAc", OleDbType.Boolean).Value = objclsVehicleTypeBD.IsAc;
                cmdusp_VehicleType_IU.Parameters.Add("@Is4Wheeler", OleDbType.Boolean).Value = objclsVehicleTypeBD.Is4Wheeler;
                cmdusp_VehicleType_IU.Parameters.Add("@Rate", OleDbType.Numeric).Value = objclsVehicleTypeBD.Rate;
                cmdusp_VehicleType_IU.Parameters.Add("@Unit", OleDbType.BigInt).Value = objclsVehicleTypeBD.Unit;
                cmdusp_VehicleType_IU.Parameters.Add("@Currency", OleDbType.BigInt).Value = objclsVehicleTypeBD.Currency;
                cmdusp_VehicleType_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsVehicleTypeBD.Alias;
                cmdusp_VehicleType_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVehicleTypeBD.DOC;
                cmdusp_VehicleType_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVehicleTypeBD.DOU;
                cmdusp_VehicleType_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsVehicleTypeBD.Status;
                cmdusp_VehicleType_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVehicleTypeBD.TransactionId;
                return cmdusp_VehicleType_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active Vehicle type
        /// </summary>
        /// <param name="objclsVehicleTypeBD"></param>
        /// <returns></returns>
        public DataTable SelectVehicleType(clsVehicleTypeBD objclsVehicleTypeBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_VehicleType_S = new OleDbCommand("usp_VehicleType_S", oCon);
                cmd_VehicleType_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_VehicleType_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVehicleTypeBD.CFlag;
                cmd_VehicleType_S.Parameters.Add("@VehicleTypeId", OleDbType.BigInt).Value = objclsVehicleTypeBD.VehicleTypeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_VehicleType_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) a particular  Vehicle type
        /// </summary>
        /// <param name="objclsVehicleTypeBD"></param>
        /// <returns></returns>
        public int DeleteVehicleType(clsVehicleTypeBD objclsVehicleTypeBD)
        {
            try
            {
                OleDbCommand cmdusp_uspVehicleType_D = new OleDbCommand("usp_VehicleType_D", clsManageTransaction.objConnection);
                cmdusp_uspVehicleType_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspVehicleType_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspVehicleType_D.Parameters.Add("@VehicleTypeId", OleDbType.BigInt).Value = objclsVehicleTypeBD.VehicleTypeId;
                return cmdusp_uspVehicleType_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
