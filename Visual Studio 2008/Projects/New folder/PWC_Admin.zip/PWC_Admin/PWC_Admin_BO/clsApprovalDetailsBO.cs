﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using Admin.BD;
using System.Configuration;
namespace Admin.BO
{
    public class clsApprovalDetailsBO
    {
        /// <summary>
        /// Use to Insert and Update roles in DB
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public Int64 InsertUpdate(clsApprovalDetailsBD oApprovalDetailsBD)
        {
            try
            {
                OleDbCommand cmdApprovalDetails = new OleDbCommand("usp_ApprovalDetails_IU", clsManageTransaction.objConnection);
                cmdApprovalDetails.CommandType = CommandType.StoredProcedure;
                cmdApprovalDetails.Transaction = clsManageTransaction.objTran;
                cmdApprovalDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalDetailsBD.Flag;
                cmdApprovalDetails.Parameters.Add("@ApprovalDetailId", OleDbType.BigInt).Value = oApprovalDetailsBD.ApprovalDetailId;
                cmdApprovalDetails.Parameters.Add("@ApprovalMasterId", OleDbType.BigInt).Value = oApprovalDetailsBD.ApprovalMasterId;
                cmdApprovalDetails.Parameters.Add("@RoleId", OleDbType.BigInt).Value = oApprovalDetailsBD.RoleId;
                cmdApprovalDetails.Parameters.Add("@IsEscalated", OleDbType.Boolean).Value = oApprovalDetailsBD.IsEscalated;
                cmdApprovalDetails.Parameters.Add("@EscalationDuration", OleDbType.Integer).Value = oApprovalDetailsBD.EscalationDuration;
                cmdApprovalDetails.Parameters.Add("@Unit", OleDbType.BigInt).Value = oApprovalDetailsBD.Unit;
                cmdApprovalDetails.Parameters.Add("@Sequence", OleDbType.Integer).Value = oApprovalDetailsBD.Sequence;
                cmdApprovalDetails.Parameters.Add("@Alias", OleDbType.VarChar).Value = oApprovalDetailsBD.Alias;
                cmdApprovalDetails.Parameters.Add("@DOC", OleDbType.Date).Value = oApprovalDetailsBD.DOC;
                cmdApprovalDetails.Parameters.Add("@DOU", OleDbType.Date).Value = oApprovalDetailsBD.DOU;
                cmdApprovalDetails.Parameters.Add("@Status", OleDbType.VarChar).Value = oApprovalDetailsBD.Status;
                cmdApprovalDetails.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oApprovalDetailsBD.TransactionId;
                return Convert.ToInt64(cmdApprovalDetails.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public DataTable Select(clsApprovalDetailsBD oApprovalDetailsBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdApprovalDetails = new OleDbCommand("usp_ApprovalDetails_S", oCon);
                cmdApprovalDetails.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdApprovalDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalDetailsBD.Flag;
                cmdApprovalDetails.Parameters.Add("@ApprovalDetailId", OleDbType.BigInt).Value = oApprovalDetailsBD.ApprovalDetailId;
                OleDbDataAdapter daApprovalDetails = new OleDbDataAdapter(cmdApprovalDetails);
                DataSet dsApprovalDetails = new DataSet();
                daApprovalDetails.Fill(dsApprovalDetails);
                return dsApprovalDetails.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        /// <summary>
        /// To delete particular role(making inactive)
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int Delete(string Flag, Int64 Id)
        {
            try
            {
                OleDbCommand cmdApprovalDetails = new OleDbCommand("usp_ApprovalDetails_D", clsManageTransaction.objConnection);
                cmdApprovalDetails.CommandType = CommandType.StoredProcedure;
                cmdApprovalDetails.Transaction = clsManageTransaction.objTran;
                cmdApprovalDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdApprovalDetails.Parameters.Add("@ApprovalDetailId", OleDbType.BigInt).Value = Id;
                return cmdApprovalDetails.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
