﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;
namespace Admin.BO
{
    public class clsVendorDetailsBO
    {
        /// <summary>
        /// Insert and update data in VendorMaster
        /// </summary>
        /// <param name="objclsVendorMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateVendorMaster(clsVendorMasterBD objclsVendorMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_VendorMasterIU = new OleDbCommand("usp_VendorMaster_IU", clsManageTransaction.objConnection);
                cmdusp_VendorMasterIU.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorMasterIU.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorMasterIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVendorMasterBD.CFlag;
                cmdusp_VendorMasterIU.Parameters.Add("@VendorId", OleDbType.BigInt).Value = objclsVendorMasterBD.VendorId;
                cmdusp_VendorMasterIU.Parameters.Add("@VendorName", OleDbType.VarChar).Value = objclsVendorMasterBD.VendorName;
                cmdusp_VendorMasterIU.Parameters.Add("@VendorType", OleDbType.BigInt).Value = objclsVendorMasterBD.VendorType;
                cmdusp_VendorMasterIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsVendorMasterBD.Alias;
                cmdusp_VendorMasterIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVendorMasterBD.DOC;
                cmdusp_VendorMasterIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVendorMasterBD.DOU;
                cmdusp_VendorMasterIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsVendorMasterBD.Status;
                cmdusp_VendorMasterIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVendorMasterBD.TransactionId;
                int retval = Convert.ToInt32(cmdusp_VendorMasterIU.ExecuteScalar());
                return retval;

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Insert and update data in VendorAddress
        /// </summary>
        /// <param name="objclsVendorAddressBD"></param>
        /// <returns></returns>
        public bool InsertUpdateVendorAddress(clsVendorAddressBD objclsVendorAddressBD)
        {
            try
            {
                OleDbCommand cmdusp_VendorAddressIU = new OleDbCommand("usp_VendorAddress_IU", clsManageTransaction.objConnection);
                cmdusp_VendorAddressIU.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorAddressIU.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorAddressIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVendorAddressBD.CFlag;
                cmdusp_VendorAddressIU.Parameters.Add("@VendorAddressId", OleDbType.BigInt).Value = objclsVendorAddressBD.VendorAddressId;
                cmdusp_VendorAddressIU.Parameters.Add("@VendorId", OleDbType.BigInt).Value = objclsVendorAddressBD.VendorId;
                cmdusp_VendorAddressIU.Parameters.Add("@AddressType", OleDbType.BigInt).Value = objclsVendorAddressBD.AddressType;
                cmdusp_VendorAddressIU.Parameters.Add("@IsPreferred", OleDbType.Boolean).Value = objclsVendorAddressBD.IsPreferred;
                cmdusp_VendorAddressIU.Parameters.Add("@VAddress", OleDbType.VarChar).Value = objclsVendorAddressBD.VAddress;
                cmdusp_VendorAddressIU.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsVendorAddressBD.CityId;
                cmdusp_VendorAddressIU.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsVendorAddressBD.StateId;
                cmdusp_VendorAddressIU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsVendorAddressBD.CountryId;
                cmdusp_VendorAddressIU.Parameters.Add("@ZipCode", OleDbType.VarChar).Value = objclsVendorAddressBD.ZipCode;
                cmdusp_VendorAddressIU.Parameters.Add("@WebSite", OleDbType.VarChar).Value = objclsVendorAddressBD.WebSite;
                cmdusp_VendorAddressIU.Parameters.Add("@Email", OleDbType.VarChar).Value = objclsVendorAddressBD.Email;
                cmdusp_VendorAddressIU.Parameters.Add("@Phone1", OleDbType.VarChar).Value = objclsVendorAddressBD.Phone1;
                cmdusp_VendorAddressIU.Parameters.Add("@Phone2", OleDbType.VarChar).Value = objclsVendorAddressBD.Phone2;
                cmdusp_VendorAddressIU.Parameters.Add("@Fax", OleDbType.VarChar).Value = objclsVendorAddressBD.Fax;
                cmdusp_VendorAddressIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsVendorAddressBD.Alias;
                cmdusp_VendorAddressIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVendorAddressBD.DOC;
                cmdusp_VendorAddressIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVendorAddressBD.DOU;
                cmdusp_VendorAddressIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsVendorAddressBD.Status;
                cmdusp_VendorAddressIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVendorAddressBD.TransactionId;
                cmdusp_VendorAddressIU.ExecuteNonQuery();
                return true;

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Insert and update data in VendorContact
        /// </summary>
        /// <param name="objclsVendorContactDetailsBD"></param>
        /// <returns></returns>
        public bool InsertUpdateVendorContact(clsVendorContactDetailsBD objclsVendorContactDetailsBD)
        {
            try
            {
                OleDbCommand cmdusp_VendorContactIU = new OleDbCommand("usp_VendorContactDetails_IU", clsManageTransaction.objConnection);
                cmdusp_VendorContactIU.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorContactIU.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorContactIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.CFlag;
                cmdusp_VendorContactIU.Parameters.Add("@VENDorContactDetailId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.VENDorContactDetailId;
                cmdusp_VendorContactIU.Parameters.Add("@VendorId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.VendorId;
                cmdusp_VendorContactIU.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.CityId;
                cmdusp_VendorContactIU.Parameters.Add("@Email", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.Email;
                cmdusp_VendorContactIU.Parameters.Add("@PhoneNo1", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.PhoneNo1;
                cmdusp_VendorContactIU.Parameters.Add("@PhoneNo2", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.PhoneNo2;
                cmdusp_VendorContactIU.Parameters.Add("@VAddress", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.VAddress;               
                cmdusp_VendorContactIU.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.StateId;
                cmdusp_VendorContactIU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.CountryId;
                cmdusp_VendorContactIU.Parameters.Add("@ZipCode", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.ZipCode;
                cmdusp_VendorContactIU.Parameters.Add("@WebSite", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.WebSite;             
                cmdusp_VendorContactIU.Parameters.Add("@Fax", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.Fax;
                cmdusp_VendorContactIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.Alias;
                cmdusp_VendorContactIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVendorContactDetailsBD.DOC;
                cmdusp_VendorContactIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVendorContactDetailsBD.DOU;
                cmdusp_VendorContactIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsVendorContactDetailsBD.Status;
                cmdusp_VendorContactIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVendorContactDetailsBD.TransactionId;
                cmdusp_VendorContactIU.ExecuteNonQuery();
                return true;

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch all the records from VendrMaster table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectVendrMasterData(long VendorId)
        {
            string Flag = VendorId == 0 ? "ALL" : "VENDORID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_VendrMasterData_Select = new OleDbCommand("usp_VendrMaster_S", oCon);
                cmdusp_VendrMasterData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_VendrMasterData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_VendrMasterData_Select.Parameters.Add("@VendorId", OleDbType.BigInt).Value = VendorId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_VendrMasterData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Fetch all the records from AccomodationPolicy table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectAccomodationPolicyData(long AccomodationPolicyId)
        {
            string Flag = AccomodationPolicyId == 0 ? "ALL" : "ACCOMODATIONPOLICYID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_AccomodationPolicyData_Select = new OleDbCommand("usp_AccomodationPolicy_S", oCon);
                cmdusp_AccomodationPolicyData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_AccomodationPolicyData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_AccomodationPolicyData_Select.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = AccomodationPolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_AccomodationPolicyData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Method to delete VendorMaster record from the database.
        /// </summary>
        /// <param name="VendorId">VendorId</param>
        /// <returns>bool</returns>
        public bool DeleteVendorMaster(Int64 VendorId)
        {
            try
            {
                OleDbCommand cmdusp_VendorMasterDelete = new OleDbCommand("usp_VenderMaster_D", clsManageTransaction.objConnection);
                cmdusp_VendorMasterDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorMasterDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorMasterDelete.Parameters.Add("@VendorId", OleDbType.BigInt).Value = VendorId;
                cmdusp_VendorMasterDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                //throw exception.
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// Fetch all the records from VendrAddress table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectVendorAddressData(long VendorId, string Flag)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_VendrMasterData_Select = new OleDbCommand("usp_VendorAddress_S", oCon);
                cmdusp_VendrMasterData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_VendrMasterData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_VendrMasterData_Select.Parameters.Add("@VendorAddressId", OleDbType.BigInt).Value = VendorId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_VendrMasterData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }

        /// <summary>
        /// Fetch all the records from VendorContactDetails table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectVendorContactData(long VENDorContactDetailId, string Flag)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_VendrMasterData_Select = new OleDbCommand("usp_VendorContactDetails_S", oCon);
                cmdusp_VendrMasterData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_VendrMasterData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_VendrMasterData_Select.Parameters.Add("@VENDorContactDetailId", OleDbType.BigInt).Value = VENDorContactDetailId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_VendrMasterData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }

        /// <summary>
        /// Method to delete VendorAddress record from the database.
        /// </summary>
        /// <param name="VendorId">VendorId</param>
        /// <returns>bool</returns>
        public bool DeleteVendorAddress(Int64 VendorAddressId)
        {
            try
            {
                OleDbCommand cmdusp_VendorMasterDelete = new OleDbCommand("usp_VendorAddress_D", clsManageTransaction.objConnection);
                cmdusp_VendorMasterDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorMasterDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorMasterDelete.Parameters.Add("@VendorAddressId", OleDbType.BigInt).Value = VendorAddressId;
                cmdusp_VendorMasterDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                //throw exception.
               clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// Method to delete VendorContactDetails record from the database.
        /// </summary>
        /// <param name="VendorId">VendorId</param>
        /// <returns>bool</returns>
        public bool DeleteContactDetails(Int64 VENDorContactDetailId)
        {
            try
            {
                OleDbCommand cmdusp_VendorMasterDelete = new OleDbCommand("usp_VendorContactDetails_D", clsManageTransaction.objConnection);
                cmdusp_VendorMasterDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorMasterDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorMasterDelete.Parameters.Add("@VENDorContactDetailId", OleDbType.BigInt).Value = VENDorContactDetailId;
                cmdusp_VendorMasterDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                //throw exception.
               clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

    }
}
