﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Data;
using System.Xml;

namespace Admin.BO
{
    public class clsErrorLogBO
    {
        /// <summary>
        /// Method to write exception message in log file.
        /// This log file is created inside "Application folfer" folder in the System 
        /// </summary>
        /// <param name="strMessage"></param>              
        public static void WriteErrorLog_Text(Exception ex)
        {
           try
            {
                string strDirPath = System.Web.HttpContext.Current.Server.MapPath("~\\ErrorLog\\");
                if (!Directory.Exists(strDirPath))
                    Directory.CreateDirectory(strDirPath);
                string strFilePath = strDirPath + "ErrorLog.txt";
                FileStream fs = new FileStream(strFilePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                StreamWriter w = new StreamWriter(fs);
                w.BaseStream.Seek(0, SeekOrigin.End);
                w.Write("Log Entry : \r\n");                
                w.Write("{0} {1} \r\n", DateTime.Now.ToLongTimeString(), DateTime.Now.ToLongDateString());                
                w.WriteLine("=======Error Description=======");
                string[] str = ex.StackTrace.Split('\n');
                w.WriteLine("Source: " + str[str.Length - 1].ToString().Trim());
                w.WriteLine("Message: " + ex.Message);
                w.WriteLine("--------------------------------------------------------------------------------------------------------------------");
                w.Flush(); // update underlying file
                w.Close();
                fs.Close();
            }
           catch (Exception ex1)
           {
               string sMessage = ex1.Message;
            }

        }
        /// <summary>
        /// Method to write exception message in log file in xml file.
        /// This log file is created inside "Application folfer" folder in the System 
        /// </summary>
        /// <param name="strMessage"></param>
        public static void WriteErrorLog_Xml(Exception ex)
        {
            XmlDocument xmlDoc = new XmlDocument();
                XmlNode rnode;
                try
                {
                    if (File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/ErrorLog/ErrorLog.xml")))
                    {
                        xmlDoc.Load(System.Web.HttpContext.Current.Server.MapPath("~/ErrorLog/ErrorLog.xml"));
                        rnode = xmlDoc.SelectSingleNode("Error");
                    }
                    else
                    {
                        XmlNode node = xmlDoc.CreateXmlDeclaration("1.0", "UTF-8", null);
                        xmlDoc.AppendChild(node);
                        rnode = xmlDoc.CreateElement("Error");
                        xmlDoc.AppendChild(rnode);
                    }
                    XmlNode Error = xmlDoc.CreateElement("Error");
                    rnode.AppendChild(Error);
                    string[] str = ex.StackTrace.Split('\n');
                    XmlNode cnodeDate = xmlDoc.CreateElement("ErrorDateTime");
                    cnodeDate.AppendChild(xmlDoc.CreateCDataSection((System.DateTime.Now).ToString()));
                    Error.AppendChild(cnodeDate);
                    XmlNode cnodeSource = xmlDoc.CreateElement("Source");
                    cnodeSource.AppendChild(xmlDoc.CreateCDataSection(str[str.Length - 1].ToString().Trim()));
                    Error.AppendChild(cnodeSource);
                    XmlNode cnodeMessage = xmlDoc.CreateElement("Message");
                    cnodeMessage.AppendChild(xmlDoc.CreateCDataSection(ex.Message));
                    Error.AppendChild(cnodeMessage);
                    xmlDoc.Save(System.Web.HttpContext.Current.Server.MapPath("~/ErrorLog/ErrorLog.xml"));      
            }
            catch (Exception ex1 )
           {
               throw ex1;
            }
        }
    }
}
