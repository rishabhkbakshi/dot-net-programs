﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

using Admin.BD;

namespace Admin.BO
{
    public class clsPetrolPoliciesBO
    {
        /// <summary>
        /// To Insert and Update city inside CityMaster
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdatePetrolPolicies(clsPetrolPoliciesBD oPetrolPoliciesBD, String Flag)
        {
            try
            {
                OleDbCommand cmdPetrolPolicies_IU = new OleDbCommand("usp_PetrolPolicies_IU", clsManageTransaction.objConnection);
                cmdPetrolPolicies_IU.CommandType = CommandType.StoredProcedure;
                cmdPetrolPolicies_IU.Transaction = clsManageTransaction.objTran;
                cmdPetrolPolicies_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdPetrolPolicies_IU.Parameters.Add("@PPId", OleDbType.BigInt).Value = oPetrolPoliciesBD.PPId;
                cmdPetrolPolicies_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = oPetrolPoliciesBD.GradeId;
                cmdPetrolPolicies_IU.Parameters.Add("@Limit", OleDbType.Decimal).Value = oPetrolPoliciesBD.Limit;
                cmdPetrolPolicies_IU.Parameters.Add("@Unit", OleDbType.VarChar).Value = oPetrolPoliciesBD.Unit;
                cmdPetrolPolicies_IU.Parameters.Add("@Period", OleDbType.Decimal).Value = oPetrolPoliciesBD.Period;
                cmdPetrolPolicies_IU.Parameters.Add("@PUnit", OleDbType.VarChar).Value = oPetrolPoliciesBD.PUnit;
                cmdPetrolPolicies_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = oPetrolPoliciesBD.Alias;
                cmdPetrolPolicies_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = oPetrolPoliciesBD.Status;
                cmdPetrolPolicies_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = oPetrolPoliciesBD.DOC;
                cmdPetrolPolicies_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = oPetrolPoliciesBD.DOU;
                cmdPetrolPolicies_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oPetrolPoliciesBD.TransactionId;
                return cmdPetrolPolicies_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active citys
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectPetrolPolicies(string Flag, Int64 PPId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdPetrolPolicies_S = new OleDbCommand("usp_PetrolPolicies_S", oCon);
                cmdPetrolPolicies_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdPetrolPolicies_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdPetrolPolicies_S.Parameters.Add("@PPId", OleDbType.BigInt).Value = PPId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdPetrolPolicies_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) particular city
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int DeletePetrolPolicies(Int64 PPId)
        {
            try
            {
                OleDbCommand cmdPetrolPolicies_D = new OleDbCommand("usp_PetrolPolicies_D", clsManageTransaction.objConnection);
                cmdPetrolPolicies_D.CommandType = CommandType.StoredProcedure;
                cmdPetrolPolicies_D.Transaction = clsManageTransaction.objTran;
                cmdPetrolPolicies_D.Parameters.Add("@PPId", OleDbType.BigInt).Value = PPId;
                return cmdPetrolPolicies_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
