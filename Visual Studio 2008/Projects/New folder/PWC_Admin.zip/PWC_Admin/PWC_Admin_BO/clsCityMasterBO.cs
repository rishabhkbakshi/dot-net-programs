﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsCityMasterBO
    {
        /// <summary>
        /// To Insert and Update city inside CityMaster
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateCityMaster(clsCityMasterBD objclsCityMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_CityMaster_IU = new OleDbCommand("usp_CityMaster_IU", clsManageTransaction.objConnection);
                cmdusp_CityMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_CityMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_CityMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCityMasterBD.CFlag;
                cmdusp_CityMaster_IU.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsCityMasterBD.CityId;
                cmdusp_CityMaster_IU.Parameters.Add("@CityName", OleDbType.VarChar).Value = objclsCityMasterBD.CityName;
                cmdusp_CityMaster_IU.Parameters.Add("@CityGradeId", OleDbType.BigInt).Value = objclsCityMasterBD.CityGradeId;
                cmdusp_CityMaster_IU.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsCityMasterBD.StateId;
                cmdusp_CityMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsCityMasterBD.Alias;
                cmdusp_CityMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsCityMasterBD.DOC;
                cmdusp_CityMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsCityMasterBD.DOU;
                cmdusp_CityMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsCityMasterBD.Status;
                cmdusp_CityMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsCityMasterBD.TransactionId;
                return cmdusp_CityMaster_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active citys
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectCityMaster(clsCityMasterBD objclsCityMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spCityMaster_S = new OleDbCommand("usp_CityMaster_S", oCon);
                cmd_spCityMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spCityMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCityMasterBD.CFlag;
                cmd_spCityMaster_S.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsCityMasterBD.CityId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spCityMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) particular city
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int DeleteCityMaster(clsCityMasterBD objclsCityMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_CityMaster_D = new OleDbCommand("usp_CityMaster_D", clsManageTransaction.objConnection);
                cmdusp_CityMaster_D.CommandType = CommandType.StoredProcedure;
                cmdusp_CityMaster_D.Transaction = clsManageTransaction.objTran;
                cmdusp_CityMaster_D.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsCityMasterBD.CityId;
                return cmdusp_CityMaster_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
