﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;
namespace Admin.BO
{
    public class clsVendorServiceChargesBO
    {
        /// <summary>
        /// Insert and update data in Vendor ServiceCharges
        /// </summary>
        /// <param name="clsVendorServiceChargesBD"></param>
        /// <returns>Int64</returns>
        public Int64 InsertUpdatecVendorServiceCharges(clsVendorServiceChargesBD objclsVendorServiceChargesBD)
        {
            try
            {
                OleDbCommand cmdusp_VendorServiceCharges_IU = new OleDbCommand("usp_VendorServiceCharges_IU", clsManageTransaction.objConnection);
                cmdusp_VendorServiceCharges_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_VendorServiceCharges_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVendorServiceChargesBD.CFlag;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@VendorServiceChargeId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.VendorServiceChargeId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@VendorId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.VendorId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@TypeOfTravelId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.TypeOfTravelId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@TravelModeId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.TravelModeId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@EffectiveFromDate", OleDbType.DBDate).Value = objclsVendorServiceChargesBD.EffectiveFromDate;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@EffectiveToDate", OleDbType.DBDate).Value = objclsVendorServiceChargesBD.EffectiveToDate;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = "Active";
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@Amount", OleDbType.Numeric).Value = objclsVendorServiceChargesBD.Amount;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@CurrencyId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.CurrencyId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVendorServiceChargesBD.DOC;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVendorServiceChargesBD.DOU;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.TransactionId;
                cmdusp_VendorServiceCharges_IU.Parameters.Add("@ServiceTypeID", OleDbType.BigInt).Value = objclsVendorServiceChargesBD.ServiceTypeID;
                int retvalue = Convert.ToInt32(cmdusp_VendorServiceCharges_IU.ExecuteScalar());
                clsManageTransaction.EndTransaction();
                return retvalue;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        public DataTable SelectVendorServiceData(long VendorServiceChargeId)
        {
            string Flag = VendorServiceChargeId == 0 ? "ALL" : "VendorServiceChargeId";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_VendorServiceCharges_S = new OleDbCommand("usp_VendorServiceCharges_S", oCon);
                cmdusp_VendorServiceCharges_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_VendorServiceCharges_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_VendorServiceCharges_S.Parameters.Add("@VendorServiceChargeId", OleDbType.BigInt).Value = VendorServiceChargeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_VendorServiceCharges_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        public bool DeleteServiceCharge(Int64 VendorServiceChargeId)
        {
            try
            {
                OleDbCommand cmdusp_TravelPolicyDelete = new OleDbCommand("usp_VendorServiceCharges_D", clsManageTransaction.objConnection);
                cmdusp_TravelPolicyDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_TravelPolicyDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_TravelPolicyDelete.Parameters.Add("@@VendorServiceChargeId", OleDbType.BigInt).Value = VendorServiceChargeId;
                cmdusp_TravelPolicyDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
