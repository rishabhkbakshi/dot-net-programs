﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Admin.BD;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
namespace Admin.BO
{
    public class clsProcessBO
    {
        /// <summary>
        /// Use to Insert and Update roles in DB
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public Int64 InsertUpdateProcess(clsProcessBD oProcessBD)
        {
            try
            {
                OleDbCommand cmdProcess = new OleDbCommand("usp_Processes_IU", clsManageTransaction.objConnection);
                cmdProcess.CommandType = CommandType.StoredProcedure;
                cmdProcess.Transaction = clsManageTransaction.objTran;
                cmdProcess.Parameters.Add("@Flag", OleDbType.VarChar).Value = oProcessBD.Flag;
                cmdProcess.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = oProcessBD.ProcessId;
                cmdProcess.Parameters.Add("@ProcessName", OleDbType.VarChar).Value = oProcessBD.ProcessName;
                cmdProcess.Parameters.Add("@ParentId", OleDbType.BigInt).Value = oProcessBD.ParentId;
                cmdProcess.Parameters.Add("@NeedDocumentMgt", OleDbType.Boolean).Value = oProcessBD.NeedDocumentMgt;
                cmdProcess.Parameters.Add("@NeedApprovers", OleDbType.Boolean).Value = oProcessBD.NeedApprovers;
                cmdProcess.Parameters.Add("@NeedEnforceSLA", OleDbType.Boolean).Value = oProcessBD.NeedEnforceSLA;
                cmdProcess.Parameters.Add("@DefaultURL", OleDbType.VarChar).Value = oProcessBD.DefaultURL;
                cmdProcess.Parameters.Add("@OnErrorURL", OleDbType.VarChar).Value = oProcessBD.OnErrorURL;
                cmdProcess.Parameters.Add("@SequenceNo", OleDbType.Integer).Value = oProcessBD.SequenceNo;
                cmdProcess.Parameters.Add("@Alias", OleDbType.VarChar).Value = oProcessBD.Alias;
                cmdProcess.Parameters.Add("@DOC", OleDbType.DBDate).Value = oProcessBD.DOC;
                cmdProcess.Parameters.Add("@DOU", OleDbType.DBDate).Value = oProcessBD.DOU;
                cmdProcess.Parameters.Add("@Status", OleDbType.VarChar).Value = oProcessBD.Status;
                cmdProcess.Parameters.Add("@ImageUrl", OleDbType.VarChar).Value = oProcessBD.ImageUrl;

                return Convert.ToInt64(cmdProcess.ExecuteScalar());
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectProcess(clsProcessBD oProcessBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdProcess = new OleDbCommand("usp_Processes_S", oCon);
                cmdProcess.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdProcess.Parameters.Add("@Flag", OleDbType.VarChar).Value = oProcessBD.Flag;
                cmdProcess.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = oProcessBD.ProcessId;
                OleDbDataAdapter daProcess = new OleDbDataAdapter(cmdProcess);
                DataSet dsProcess = new DataSet();
                daProcess.Fill(dsProcess);
                return dsProcess.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public List<clsProcessBD> GetProcessByParent(long ParentId, long? RoleId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdProcess = new OleDbCommand("usp_Processes_S", oCon);
                cmdProcess.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdProcess.Parameters.Add("@Flag", OleDbType.VarChar).Value = "PARENTID";
                cmdProcess.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = ParentId;
                cmdProcess.Parameters.Add("@RoleId", OleDbType.BigInt).Value = RoleId;
                OleDbDataAdapter daProcess = new OleDbDataAdapter(cmdProcess);
                DataSet dsProcess = new DataSet();
                daProcess.Fill(dsProcess);
                List<clsProcessBD> oProcessList = new List<clsProcessBD>();
                clsProcessBD oProcessBD;
                foreach (DataRow drProcess in dsProcess.Tables[0].Rows)
                {
                    oProcessBD = new clsProcessBD();
                    oProcessBD.ProcessId = Convert.ToInt64(drProcess["ProcessId"]);
                    oProcessBD.ProcessName = Convert.ToString(drProcess["ProcessName"]);
                    oProcessBD.ParentId = Convert.ToInt64(drProcess["ParentId"]);
                    oProcessBD.NeedDocumentMgt = Convert.ToBoolean(drProcess["NeedDocumentMgt"]);
                    if (drProcess["NeedApprovers"] != System.DBNull.Value)
                    {
                        oProcessBD.NeedApprovers = Convert.ToBoolean(drProcess["NeedApprovers"]);
                    }
                    if (drProcess["NeedEnforceSLA"] != System.DBNull.Value)
                    {
                        oProcessBD.NeedEnforceSLA = Convert.ToBoolean(drProcess["NeedEnforceSLA"]);
                    }
                    oProcessBD.DefaultURL = Convert.ToString(drProcess["DefaultURL"]);
                    oProcessBD.OnErrorURL = Convert.ToString(drProcess["OnErrorURL"]);
                    oProcessBD.SequenceNo = Convert.ToInt16(drProcess["SequenceNo"]);
                    oProcessBD.Alias = Convert.ToString(drProcess["Alias"]);
                    if (drProcess["DOC"] != System.DBNull.Value)
                    {
                        oProcessBD.DOC = Convert.ToDateTime(drProcess["DOC"]);
                    }
                    if (drProcess["DOU"] != System.DBNull.Value)
                    {
                        oProcessBD.DOU = Convert.ToDateTime(drProcess["DOU"]);
                    }
                    oProcessBD.Status = Convert.ToString(drProcess["Status"]);
                    oProcessList.Add(oProcessBD);
                }
                return oProcessList;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// To delete particular role(making inactive)
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int DeleteProcess(clsProcessBD oProcessBD)
        {
            try
            {
                OleDbCommand cmdProcess = new OleDbCommand("usp_Processes_D", clsManageTransaction.objConnection);
                cmdProcess.CommandType = CommandType.StoredProcedure;
                cmdProcess.Transaction = clsManageTransaction.objTran;
                cmdProcess.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = oProcessBD.ProcessId;
                return cmdProcess.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
