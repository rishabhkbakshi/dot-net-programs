﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
   public class clsEmployeePassportUploadBO
    {
        /// <summary>
        /// Insert and update data in PassportDetails
        /// </summary>
        /// <param name="objclsEmployeePassportUploadBD"></param>
        /// <returns></returns>
       public bool InsertUpdateEmployeePassportUpload(clsEmployeePassportUploadBD objclsEmployeePassportUploadBD)
        {
            try
            {
                OleDbCommand cmdusp_PassportDetailsIU = new OleDbCommand("usp_EmployeePassportUpload_IU", clsManageTransaction.objConnection);
                cmdusp_PassportDetailsIU.Transaction = clsManageTransaction.objTran;
                cmdusp_PassportDetailsIU.CommandType = CommandType.StoredProcedure;
                cmdusp_PassportDetailsIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.CFlag;
                cmdusp_PassportDetailsIU.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeePassportUploadBD.EmployeeId;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportNo", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.PassportNo;
                cmdusp_PassportDetailsIU.Parameters.Add("@CountryName", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.CountryName;
                cmdusp_PassportDetailsIU.Parameters.Add("@StateName", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.StateName;
                cmdusp_PassportDetailsIU.Parameters.Add("@CityName", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.CityName;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportIssueDate", OleDbType.Date).Value = objclsEmployeePassportUploadBD.PassportIssueDate;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportExpiryDate", OleDbType.Date).Value = objclsEmployeePassportUploadBD.PassportExpiryDate;               
                cmdusp_PassportDetailsIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsEmployeePassportUploadBD.DOC;
                cmdusp_PassportDetailsIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsEmployeePassportUploadBD.DOU;
                cmdusp_PassportDetailsIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsEmployeePassportUploadBD.Status;
                cmdusp_PassportDetailsIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsEmployeePassportUploadBD.TransactionId;
                cmdusp_PassportDetailsIU.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
