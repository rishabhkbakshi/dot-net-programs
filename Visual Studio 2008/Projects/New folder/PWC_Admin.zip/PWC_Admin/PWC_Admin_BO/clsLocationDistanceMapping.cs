﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
namespace Admin.BO
{
    public class clsLocationDistanceMapping
    {
        #region "START: PUBLIC STATIC METHODS"

        public static long InsertUpdateLocationDistanceMapingMaster(clsLocationDistanceMappingBD oclsLocationDistanceMappingBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                long ID = 0;
                OleDbCommand cmdusp_LocationDistanceMapping_IU = new OleDbCommand("usp_LocationMappingMaster_IU", oCon);
                cmdusp_LocationDistanceMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@LocationDistanceMappingMaster_ID", oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@Country", oclsLocationDistanceMappingBD.Country);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@State", oclsLocationDistanceMappingBD.State);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@City", oclsLocationDistanceMappingBD.City);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@ForYear", oclsLocationDistanceMappingBD.ForYear);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@FromDate", oclsLocationDistanceMappingBD.FromDate);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@ToDate", oclsLocationDistanceMappingBD.ToDate);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@TransactionID", oclsLocationDistanceMappingBD.TransactionID);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@DOC", oclsLocationDistanceMappingBD.DOC);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@DOU", oclsLocationDistanceMappingBD.DOU);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@Status", oclsLocationDistanceMappingBD.Status);
                oCon.Open();
                ID = Convert.ToInt64(cmdusp_LocationDistanceMapping_IU.ExecuteScalar());
                oCon.Close();
                return ID;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static int InsertLocationDistanceMaping(clsLocationDistanceMappingBD oclsLocationDistanceMappingBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_LocationDistanceMapping_IU = new OleDbCommand("usp_LocationMapping_I", oCon);
                cmdusp_LocationDistanceMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@LocationDistanceMappingMaster_ID", oclsLocationDistanceMappingBD.LocationDistanceMappingMaster_ID);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@FromLocation", oclsLocationDistanceMappingBD.FromLocation);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@ToLocation", oclsLocationDistanceMappingBD.ToLocation);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@Distance", oclsLocationDistanceMappingBD.Distance);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@PickUpDropLocation", oclsLocationDistanceMappingBD.PickUpDropLocation);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@Rate", oclsLocationDistanceMappingBD.Rate);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@FullVehicle", oclsLocationDistanceMappingBD.FullVehicle);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@WaitingCharges", oclsLocationDistanceMappingBD.WaitingCharges);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@TransactionID", oclsLocationDistanceMappingBD.TransactionID);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@DOC", oclsLocationDistanceMappingBD.DOC);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@DOU", oclsLocationDistanceMappingBD.DOU);
                cmdusp_LocationDistanceMapping_IU.Parameters.AddWithValue("@Status", oclsLocationDistanceMappingBD.Status);
                oCon.Open();
                int i = cmdusp_LocationDistanceMapping_IU.ExecuteNonQuery();
                oCon.Close();
                return i;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static List<clsLocationDistanceMappingBD> GetLocationMappedWithDistance(clsLocationDistanceMappingBD oclsLocationDistanceMappingBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                DataTable dtLocationMapping = new DataTable();
                List<clsLocationDistanceMappingBD> oclsLocationDistanceMappingBDList = new List<clsLocationDistanceMappingBD>();
                OleDbCommand cmdusp_LocationMapping_Select = new OleDbCommand("usp_LocationDistanceMapping_S", oCon);
                cmdusp_LocationMapping_Select.CommandType = CommandType.StoredProcedure;
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@Country", oclsLocationDistanceMappingBD.Country);
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@State", oclsLocationDistanceMappingBD.State);
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@City", oclsLocationDistanceMappingBD.City);
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@ForYear", oclsLocationDistanceMappingBD.ForYear);
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@FromDate", Convert.ToDateTime(oclsLocationDistanceMappingBD.FromDate));
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@ToDate", Convert.ToDateTime(oclsLocationDistanceMappingBD.ToDate));
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_LocationMapping_Select);
                objOleDbDataAdapter.Fill(dtLocationMapping);
                if (dtLocationMapping.Rows.Count > 0)
                {
                    for (int i = 0; i < dtLocationMapping.Rows.Count; i++)
                    {
                        clsLocationDistanceMappingBD oLocationDistanceMappingBD = new clsLocationDistanceMappingBD();
                        oLocationDistanceMappingBD.LocationDistanceMappingMaster_ID = Convert.ToInt64(dtLocationMapping.Rows[i]["LocationDistanceMappingMaster_ID"]);
                        oLocationDistanceMappingBD.LocationDistanceMapping_ID = Convert.ToInt64(dtLocationMapping.Rows[i]["LocationDistanceMapping_ID"]);
                        oLocationDistanceMappingBD.FromLocation = Convert.ToString(dtLocationMapping.Rows[i]["FromLocation"]);
                        oLocationDistanceMappingBD.ToLocation = Convert.ToString(dtLocationMapping.Rows[i]["ToLocation"]);
                        oLocationDistanceMappingBD.Distance = Convert.ToString(dtLocationMapping.Rows[i]["Distance"]);
                        oLocationDistanceMappingBD.PickUpDropLocation = Convert.ToString(dtLocationMapping.Rows[i]["PickUpDropLocation"]);
                        oLocationDistanceMappingBD.Rate = Convert.ToString(dtLocationMapping.Rows[i]["Rate"]);
                        oLocationDistanceMappingBD.FullVehicle = Convert.ToString(dtLocationMapping.Rows[i]["FullVehicle"]);
                        oLocationDistanceMappingBD.WaitingCharges = Convert.ToString(dtLocationMapping.Rows[i]["WaitingCharges"]);
                        oLocationDistanceMappingBD.TransactionID = Convert.ToInt64(dtLocationMapping.Rows[i]["TransactionID"]);
                        oLocationDistanceMappingBD.DOC = Convert.ToDateTime(dtLocationMapping.Rows[i]["DOC"]);
                        oLocationDistanceMappingBD.DOU = Convert.ToDateTime(dtLocationMapping.Rows[i]["DOU"]);
                        oLocationDistanceMappingBD.Status = Convert.ToString(dtLocationMapping.Rows[i]["Status"]);
                        oclsLocationDistanceMappingBDList.Add(oLocationDistanceMappingBD);
                    }
                }
                return oclsLocationDistanceMappingBDList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static DataTable GetCountryStateCity(string Flag, long ID)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                DataTable dtCity = new DataTable();
                OleDbCommand cmdusp_LocationMapping_Select = new OleDbCommand("usp_Country_State_City_S", oCon);
                cmdusp_LocationMapping_Select.CommandType = CommandType.StoredProcedure;
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@Flag", Flag);
                cmdusp_LocationMapping_Select.Parameters.AddWithValue("@ID", ID);
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_LocationMapping_Select);
                objOleDbDataAdapter.Fill(dtCity);
                return dtCity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static bool DeleteLocationMapping(long LocationDistanceMappingMaster_ID)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_LocationDistanceMapping_D = new OleDbCommand("usp_LocationMapping_D", oCon);
                cmdusp_LocationDistanceMapping_D.CommandType = CommandType.StoredProcedure;
                cmdusp_LocationDistanceMapping_D.Parameters.AddWithValue("@LocationDistanceMappingMaster_ID", LocationDistanceMappingMaster_ID);
                oCon.Open();
                cmdusp_LocationDistanceMapping_D.ExecuteNonQuery();
                oCon.Close();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static DataTable GetYear()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdYear = new OleDbCommand("usp_SDOPlanGetYear", oCon);
                cmdYear.CommandType = CommandType.StoredProcedure;
                OleDbDataAdapter daYear = new OleDbDataAdapter(cmdYear);
                DataTable dtYear = new DataTable();
                oCon.Open();
                daYear.Fill(dtYear);
                return dtYear;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        #endregion "END: PUBLIC STATIC METHODS"

    }
}
