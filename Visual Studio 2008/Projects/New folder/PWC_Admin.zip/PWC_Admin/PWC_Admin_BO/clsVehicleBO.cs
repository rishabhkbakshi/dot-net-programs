﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsVehicleBO
    {
        /// <summary>
        /// Insert & Update into Vehicle
        /// </summary>
        /// <param name="objclsVehicleBD"></param>
        /// <returns></returns>
        public int InsertUpdateVehicle(clsVehicleBD oVehicleBD)
        {
            try
            {
                OleDbCommand cmdVehicle_IU = new OleDbCommand("usp_Vehicle_IU", clsManageTransaction.objConnection);
                cmdVehicle_IU.CommandType = CommandType.StoredProcedure;
                cmdVehicle_IU.Transaction = clsManageTransaction.objTran;
                cmdVehicle_IU.CommandType = CommandType.StoredProcedure;
                cmdVehicle_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = oVehicleBD.Flag;
                cmdVehicle_IU.Parameters.Add("@VehicleId", OleDbType.BigInt).Value = oVehicleBD.VehicleId;
                cmdVehicle_IU.Parameters.Add("@Make", OleDbType.VarChar).Value = oVehicleBD.Make;
                cmdVehicle_IU.Parameters.Add("@Model", OleDbType.VarChar).Value = oVehicleBD.Model;
                cmdVehicle_IU.Parameters.Add("@VehicleType", OleDbType.BigInt).Value = oVehicleBD.VehicleType;
                cmdVehicle_IU.Parameters.Add("@RegistrationNumber", OleDbType.VarChar).Value = oVehicleBD.RegistrationNumber;
                cmdVehicle_IU.Parameters.Add("@AllocatedTo", OleDbType.VarChar).Value = oVehicleBD.AllocatedTo;
                cmdVehicle_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = oVehicleBD.Alias;
                cmdVehicle_IU.Parameters.Add("@DOC", OleDbType.Date).Value = oVehicleBD.DOC;
                cmdVehicle_IU.Parameters.Add("@DOU", OleDbType.Date).Value = oVehicleBD.DOU;
                cmdVehicle_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = oVehicleBD.Status;
                cmdVehicle_IU.Parameters.Add("@TransactionId", OleDbType.VarChar).Value = oVehicleBD.TransactionId;
                return cmdVehicle_IU.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch Active Vehicle datas from database
        /// </summary>
        /// <returns></returns>
        public DataTable SelectVehicle(string Flag, Int64 VehicleId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdVehicle_Select = new OleDbCommand("usp_Vehicle_S", oCon);
                cmdVehicle_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdVehicle_Select);
                cmdVehicle_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdVehicle_Select.Parameters.Add("@VehicleId", OleDbType.VarChar).Value = VehicleId;
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// Delete the Vehicle data
        /// </summary>
        /// <param name="objclsVehicleBD"></param>
        /// <returns></returns>
        public int DeleteVehicle(Int64 VehicleId)
        {
            try
            {
                OleDbCommand cmdVehicle_D = new OleDbCommand("usp_Vehicle_D", clsManageTransaction.objConnection);
                cmdVehicle_D.CommandType = CommandType.StoredProcedure;
                cmdVehicle_D.Transaction = clsManageTransaction.objTran;
                cmdVehicle_D.Parameters.Add("@VehicleId", OleDbType.BigInt).Value = VehicleId;
                return cmdVehicle_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
