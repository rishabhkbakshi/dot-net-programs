﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsEmployeeDataUploadBO
    {
        /// <summary>
        /// To insert the Employees
        /// </summary>
        /// <param name="objclsEmployeeDataUploadBD"></param>
        /// <returns></returns>
        public long EmployeeDataUploadIU(clsEmployeeDataUploadBD objclsEmployeeDataUploadBD)
        {
            try
            {
                OleDbCommand EmployeeDataUpload_IU = new OleDbCommand("usp_EmployeeDataUpload_IU", clsManageTransaction.objConnection);
                EmployeeDataUpload_IU.Transaction = clsManageTransaction.objTran;
                EmployeeDataUpload_IU.CommandType = CommandType.StoredProcedure;
                EmployeeDataUpload_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.CFlag;
                EmployeeDataUpload_IU.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeeDataUploadBD.EmployeeId;
                EmployeeDataUpload_IU.Parameters.Add("@EmployeeCode", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.EmployeeCode;
                EmployeeDataUpload_IU.Parameters.Add("@FirstName", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.FirstName;
                EmployeeDataUpload_IU.Parameters.Add("@LastName", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.LastName;
                EmployeeDataUpload_IU.Parameters.Add("@Gender", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.Gender;
                EmployeeDataUpload_IU.Parameters.Add("@ReportingManager", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.ReportingManager;
                EmployeeDataUpload_IU.Parameters.Add("@DelegatationTo", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.DelegatationTo;
                EmployeeDataUpload_IU.Parameters.Add("@Email", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.Email;
                EmployeeDataUpload_IU.Parameters.Add("@PersonalPhoneNo", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.PersonalPhoneNo;
                EmployeeDataUpload_IU.Parameters.Add("@PersonalVehicleNo", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.PersonalVehicleNo;
                EmployeeDataUpload_IU.Parameters.Add("@CompanyPhoneNo", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.CompanyPhoneNo;
                EmployeeDataUpload_IU.Parameters.Add("@CompanyVehicleNo", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.CompanyVehicleNo;
                EmployeeDataUpload_IU.Parameters.Add("@IsSelfApproved", OleDbType.Boolean).Value = objclsEmployeeDataUploadBD.IsSelfApproved;
                EmployeeDataUpload_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.Alias;
                EmployeeDataUpload_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsEmployeeDataUploadBD.DOC;
                EmployeeDataUpload_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsEmployeeDataUploadBD.DOU;
                EmployeeDataUpload_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.Status;
                EmployeeDataUpload_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsEmployeeDataUploadBD.TransactionId;
                EmployeeDataUpload_IU.Parameters.Add("@DepartmentName", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.DepartmentName;
                EmployeeDataUpload_IU.Parameters.Add("@RoleName", OleDbType.VarChar).Value = objclsEmployeeDataUploadBD.RoleName;
                long retval = Convert.ToInt32(EmployeeDataUpload_IU.ExecuteScalar());
                return retval;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
