﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;
namespace Admin.BO
{
    public class clsDocumentsBO
    {
        /// <summary>
        /// To insert and update document
        /// </summary>
        /// <param name="objclsDocumentsBD"></param>
        /// <returns></returns>
        public int InsertUpdateDocuments(clsDocumentsBD objclsDocumentsBD)
        {
            try
            {
                OleDbCommand cmdusp_Documents_IU = new OleDbCommand("usp_Documents_IU", clsManageTransaction.objConnection);
                cmdusp_Documents_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_Documents_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_Documents_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsDocumentsBD.Flag;
                cmdusp_Documents_IU.Parameters.Add("@DocumentId", OleDbType.BigInt).Value = objclsDocumentsBD.DocumentId;
                cmdusp_Documents_IU.Parameters.Add("@ProcessId", OleDbType.BigInt).Value = objclsDocumentsBD.ProcessId;
                cmdusp_Documents_IU.Parameters.Add("@TravelRequestId", OleDbType.BigInt).Value = objclsDocumentsBD.TravelRequestId;
                cmdusp_Documents_IU.Parameters.Add("@ReferenceName", OleDbType.VarChar).Value = objclsDocumentsBD.ReferenceName;
                cmdusp_Documents_IU.Parameters.Add("@Remark", OleDbType.VarChar).Value = objclsDocumentsBD.Remark;
                cmdusp_Documents_IU.Parameters.Add("@FileName", OleDbType.VarChar).Value = objclsDocumentsBD.FileName;
                cmdusp_Documents_IU.Parameters.Add("@GUID", OleDbType.VarChar).Value = objclsDocumentsBD.GUID;
                cmdusp_Documents_IU.Parameters.Add("@Location", OleDbType.VarChar).Value = objclsDocumentsBD.Location;
                cmdusp_Documents_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsDocumentsBD.Status;
                cmdusp_Documents_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsDocumentsBD.DOC;
                cmdusp_Documents_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsDocumentsBD.DOU;
                cmdusp_Documents_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsDocumentsBD.TransactionId;
                return cmdusp_Documents_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To fetch all active the records of documents
        /// </summary>
        /// <param name="objclsDocumentsBD"></param>
        /// <returns></returns>
        public DataTable SelectDocuments(clsDocumentsBD objclsDocumentsBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_Documents_S = new OleDbCommand("usp_Documents_S", oCon);
                cmd_Documents_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_Documents_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsDocumentsBD.Flag;
                cmd_Documents_S.Parameters.Add("@DocumentId", OleDbType.BigInt).Value = objclsDocumentsBD.DocumentId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_Documents_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(make inactive) particular Document
        /// </summary>
        /// <param name="objclsDocumentsBD"></param>
        /// <returns></returns>
        public int DeleteDocuments(clsDocumentsBD objclsDocumentsBD)
        {
            try
            {
                OleDbCommand cmdusp_uspDocuments_D = new OleDbCommand("usp_Documents_D", clsManageTransaction.objConnection);
                cmdusp_uspDocuments_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspDocuments_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspDocuments_D.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsDocumentsBD.Flag;
                cmdusp_uspDocuments_D.Parameters.Add("@DocumentId", OleDbType.BigInt).Value = objclsDocumentsBD.DocumentId;
                return cmdusp_uspDocuments_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
