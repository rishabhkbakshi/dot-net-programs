﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsGradeRoleMappingBO
    {
        /// <summary>
        /// Insert and Update  Grade Role Mapping
        /// </summary>
        /// <param name="objclsGradeRoleMappingBD"></param>
        /// <returns></returns>
        public int InsertUpdateGradeRoleMapping(clsGradeRoleMappingBD objclsGradeRoleMappingBD)
        {
            try
            {
                OleDbCommand cmdusp_GradeRoleMapping_IU = new OleDbCommand("usp_GradeRoleMapping_IU", clsManageTransaction.objConnection);
                cmdusp_GradeRoleMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_GradeRoleMapping_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsGradeRoleMappingBD.CFlag;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@GradeRoleMappingId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.GradeRoleMappingId;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.GradeId;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.RoleId;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsGradeRoleMappingBD.Alias;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsGradeRoleMappingBD.DOC;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsGradeRoleMappingBD.DOU;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsGradeRoleMappingBD.Status;
                cmdusp_GradeRoleMapping_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.TransactionId;
                return cmdusp_GradeRoleMapping_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the records from Grade Role Mapping
        /// </summary>
        /// <param name="objclsGradeRoleMappingBD"></param>
        /// <returns></returns>
        public DataTable SelectGradeRoleMapping(clsGradeRoleMappingBD objclsGradeRoleMappingBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_GradeRoleMapping_S = new OleDbCommand("usp_GradeRoleMapping_S", oCon);
                cmd_GradeRoleMapping_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_GradeRoleMapping_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsGradeRoleMappingBD.CFlag;
                cmd_GradeRoleMapping_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.GradeRoleMappingId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_GradeRoleMapping_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(Make Inactive) particular grade role mapping
        /// </summary>
        /// <param name="objclsGradeRoleMappingBD"></param>
        /// <returns></returns>
        public int DeleteGradeRoleMapping(clsGradeRoleMappingBD objclsGradeRoleMappingBD)
        {
            try
            {
                OleDbCommand cmdusp_uspGradeRoleMapping_D = new OleDbCommand("usp_GradeRoleMapping_D", clsManageTransaction.objConnection);
                cmdusp_uspGradeRoleMapping_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspGradeRoleMapping_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspGradeRoleMapping_D.Parameters.Add("@GradeRoleMappingId", OleDbType.BigInt).Value = objclsGradeRoleMappingBD.GradeRoleMappingId;
                return cmdusp_uspGradeRoleMapping_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
