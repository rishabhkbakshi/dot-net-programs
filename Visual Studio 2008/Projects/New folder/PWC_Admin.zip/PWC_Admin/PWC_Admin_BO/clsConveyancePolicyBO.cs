﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;
namespace Admin.BO
{
    public class clsConveyancePolicyBO
    {

        /// <summary>
        /// Insert and update data in ConveyancePolicyId
        /// </summary>
        /// <param name="objclsAccomodationPolicyBD"></param>
        /// <returns></returns>
        public int InsertUpdateConveyancePolicy(clsConveyancePolicyBD objclsConveyancePolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_ConveyancePolicyIU = new OleDbCommand("usp_ConveyancePolicy_IU", clsManageTransaction.objConnection);
                cmdusp_ConveyancePolicyIU.Transaction = clsManageTransaction.objTran;
                cmdusp_ConveyancePolicyIU.CommandType = CommandType.StoredProcedure;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsConveyancePolicyBD.CFlag;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = objclsConveyancePolicyBD.ConveyancePolicyId;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsConveyancePolicyBD.GradeId;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@Gender", OleDbType.VarChar).Value = objclsConveyancePolicyBD.Gender;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@VehicleTypeId", OleDbType.BigInt).Value = objclsConveyancePolicyBD.VehicleTypeId;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@IsEnforcePriority", OleDbType.Boolean).Value = objclsConveyancePolicyBD.IsEnforcePriority;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@EffectiveFROMDate", OleDbType.Date).Value = objclsConveyancePolicyBD.EffectiveFROMDate;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@EffectiveToDate", OleDbType.Date).Value = objclsConveyancePolicyBD.EffectiveToDate;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@IsBehalfOfBooking", OleDbType.Boolean).Value = objclsConveyancePolicyBD.IsBehalfOfBooking;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsConveyancePolicyBD.Alias;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsConveyancePolicyBD.DOC;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsConveyancePolicyBD.DOU;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsConveyancePolicyBD.Status;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsConveyancePolicyBD.TransactionId;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@AfterOutTime", OleDbType.Integer).Value = objclsConveyancePolicyBD.AfterOutTime;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@DefaultMode", OleDbType.VarChar).Value = objclsConveyancePolicyBD.DefaultMode;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@AlternateMode", OleDbType.VarChar).Value = objclsConveyancePolicyBD.AlternateMode;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@DefaultClass", OleDbType.BigInt).Value = objclsConveyancePolicyBD.DefaultClass;
                cmdusp_ConveyancePolicyIU.Parameters.Add("@AlternateClass", OleDbType.BigInt).Value = objclsConveyancePolicyBD.AlternateClass;
                return Convert.ToInt32(cmdusp_ConveyancePolicyIU.ExecuteScalar());
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch all the records from ConveyancePolicyId table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectConveyancePolicyData(long ConveyancePolicyId)
        {
            string Flag = ConveyancePolicyId == 0 ? "ALL" : "CONVEYANCEPOLICYID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_ConveyancePolicyData_Select = new OleDbCommand("usp_ConveyancePolicy_S", oCon);
                cmdusp_ConveyancePolicyData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_ConveyancePolicyData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_ConveyancePolicyData_Select.Parameters.Add("@ConveyancePolicyId", OleDbType.BigInt).Value = ConveyancePolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_ConveyancePolicyData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Method to delete ConveyancePolicy record from the database.
        /// </summary>
        /// <param name="TravelPolicyId">ConveyancePolicyId</param>
        /// <returns>bool</returns>
        public bool DeleteConveyancePolicy(Int64 ConveyancePolicyId)
        {
            try
            {
                OleDbCommand cmdusp_ConveyancePolicyDelete = new OleDbCommand("usp_ConveyancePolicy_D", clsManageTransaction.objConnection);
                cmdusp_ConveyancePolicyDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_ConveyancePolicyDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_ConveyancePolicyDelete.Parameters.Add("@AccomodationPolicyId", OleDbType.BigInt).Value = ConveyancePolicyId;
                cmdusp_ConveyancePolicyDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                //throw exception.
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// Fetch all the records from VehicleType table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectVehicleType(long VehicleTypeId)
        {
            string Flag = VehicleTypeId == 0 ? "ALL" : "VEHICLETYPEID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_VehicleType_Select = new OleDbCommand("usp_VehicleType_S", oCon);
                cmdusp_VehicleType_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_VehicleType_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_VehicleType_Select.Parameters.Add("@VehicleTypeId", OleDbType.BigInt).Value = VehicleTypeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_VehicleType_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }

    }
}
