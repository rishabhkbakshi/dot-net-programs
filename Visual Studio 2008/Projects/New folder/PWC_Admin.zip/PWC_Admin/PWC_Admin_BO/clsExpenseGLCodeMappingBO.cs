﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsExpenseGLCodeMappingBO
    {
        /// <summary>
        /// InsertUpdateExpenseGLCodeMapping
        /// </summary>
        /// <param name="oclsExpenseGLCodeMappingBD">clsExpenseGLCodeMappingBD</param>
        /// <returns>int</returns>
        public static bool InsertUpdateExpenseGLCodeMapping(clsExpenseGLCodeMappingBD oclsExpenseGLCodeMappingBD)
        {

            bool Result = false;
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_ExpenseGLCodeMapping_IU = new OleDbCommand("usp_ExpenseGLCodeMapping_IU", oCon);
                cmdusp_ExpenseGLCodeMapping_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = oclsExpenseGLCodeMappingBD.Flag;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@ExpGL_Id", OleDbType.BigInt).Value = oclsExpenseGLCodeMappingBD.ExpGL_Id;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@ExpenseCategory", OleDbType.BigInt).Value = oclsExpenseGLCodeMappingBD.ExpenseCategory;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@TypeOfTravel", OleDbType.VarChar).Value = oclsExpenseGLCodeMappingBD.TravelType;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@GLCode", OleDbType.VarChar).Value = oclsExpenseGLCodeMappingBD.GLCode;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@Debit", OleDbType.Numeric).Value = oclsExpenseGLCodeMappingBD.Debit;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@Credit", OleDbType.Numeric).Value = oclsExpenseGLCodeMappingBD.Credit;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = oclsExpenseGLCodeMappingBD.Status;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = oclsExpenseGLCodeMappingBD.DOC;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = oclsExpenseGLCodeMappingBD.DOU;
                cmdusp_ExpenseGLCodeMapping_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oclsExpenseGLCodeMappingBD.TransactionId;
                oCon.Open();
                Result = Convert.ToInt32(cmdusp_ExpenseGLCodeMapping_IU.ExecuteScalar()) == 0 ? false : true;
                oCon.Close();
                return Result;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
            }
        }

        public static DataTable GetExpenseGLCodeMappingDetails(string Flag, long ExpGL_Id)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_ExpenseCodeGLCodeMapping_S = new OleDbCommand("usp_ExpenseCodeGLCodeMapping_S", oCon);
                cmd_ExpenseCodeGLCodeMapping_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_ExpenseCodeGLCodeMapping_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmd_ExpenseCodeGLCodeMapping_S.Parameters.Add("@ExpGL_Id", OleDbType.BigInt).Value = ExpGL_Id;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_ExpenseCodeGLCodeMapping_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static DataTable GetExpenseCategory()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_ExpenseCategory_S = new OleDbCommand("usp_ExpenseCategory_S", oCon);
                cmd_ExpenseCategory_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_ExpenseCategory_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

    }
}
