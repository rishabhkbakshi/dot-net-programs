﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

namespace Admin.BO
{
    public class clsAccomodationsBO
    {
        /// <summary>
        /// Insert Update in Accomodations
        /// </summary>
        /// <param name="oAccomodationsBD">clsAccomodationsBD</param>
        /// <returns>bool</returns>
        public bool InsertUpdateAccomodations(clsAccomodationsBD oAccomodationsBD)
        {
            try
            {
                OleDbCommand cmdAccomodations = new OleDbCommand("usp_Accomodations_IU", clsManageTransaction.objConnection);
                cmdAccomodations.Transaction = clsManageTransaction.objTran;
                cmdAccomodations.CommandType = CommandType.StoredProcedure;
                cmdAccomodations.Parameters.Add("@Flag", OleDbType.VarChar).Value = oAccomodationsBD.CFlag;
                cmdAccomodations.Parameters.Add("@AccomodationID", OleDbType.BigInt).Value = oAccomodationsBD.AccomodationID;
                cmdAccomodations.Parameters.Add("@MasterID", OleDbType.BigInt).Value = oAccomodationsBD.MasterID;
                cmdAccomodations.Parameters.Add("@CityID", OleDbType.BigInt).Value = oAccomodationsBD.CityID;
                cmdAccomodations.Parameters.Add("@AccomodationName", OleDbType.VarChar).Value = oAccomodationsBD.AccomodationName;
                cmdAccomodations.Parameters.Add("@AccomodationAddress", OleDbType.VarChar).Value = oAccomodationsBD.AccomodationAddress;
                cmdAccomodations.Parameters.Add("@ContactNumber", OleDbType.VarChar).Value = oAccomodationsBD.ContactNumber;
                cmdAccomodations.Parameters.Add("@ContactPerson", OleDbType.VarChar).Value = oAccomodationsBD.ContactPerson;
                cmdAccomodations.Parameters.Add("@ContactPersonMobileNumber", OleDbType.VarChar).Value = oAccomodationsBD.ContactPersonMobileNumber;
                cmdAccomodations.Parameters.Add("@NumberOfRoom", OleDbType.Integer).Value = oAccomodationsBD.NumberOfRoom;
                cmdAccomodations.Parameters.Add("@Email", OleDbType.VarChar).Value = oAccomodationsBD.Email;
                cmdAccomodations.Parameters.Add("@Alias", OleDbType.VarChar).Value = oAccomodationsBD.Alias;
                cmdAccomodations.Parameters.Add("@DOC", OleDbType.Date).Value = oAccomodationsBD.DOC;
                cmdAccomodations.Parameters.Add("@DOU", OleDbType.Date).Value = oAccomodationsBD.DOU;
                cmdAccomodations.Parameters.Add("@Status", OleDbType.VarChar).Value = oAccomodationsBD.Status;
                cmdAccomodations.Parameters.Add("@TransactionID", OleDbType.BigInt).Value = oAccomodationsBD.TransactionID;
                cmdAccomodations.Parameters.Add("@ApprovedRoomRate", OleDbType.Decimal).Value = oAccomodationsBD.ApprovedRoomRate;
                cmdAccomodations.Parameters.Add("@Description", OleDbType.VarChar).Value = oAccomodationsBD.Description;
                cmdAccomodations.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Select Accomodations Datae
        /// </summary>
        /// <param name="AccomodationId">long</param>
        /// <returns>DataTable</returns>
        public DataTable SelectAccomodationData(long AccomodationId)
        {
            string Flag = AccomodationId == 0 ? "ALL" : "ACCOMODATIONID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Accomodation_Select = new OleDbCommand("usp_Accomodations_S", oCon);
                cmdusp_Accomodation_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Accomodation_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_Accomodation_Select.Parameters.Add("@AccomodationID", OleDbType.BigInt).Value = AccomodationId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Accomodation_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// To Select Accomodation to bind in AccomodationGrade
        /// </summary>
        /// <param name="oAccomodationsBD"></param>
        /// <returns></returns>
        public DataTable SelectAccomodationData(clsAccomodationsBD oAccomodationsBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Accomodation_Select = new OleDbCommand("usp_Accomodations_S", oCon);
                cmdusp_Accomodation_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Accomodation_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = oAccomodationsBD.CFlag;
                cmdusp_Accomodation_Select.Parameters.Add("@AccomodationID", OleDbType.BigInt).Value = oAccomodationsBD.AccomodationID;
                cmdusp_Accomodation_Select.Parameters.Add("@MasterID", OleDbType.BigInt).Value = oAccomodationsBD.MasterID;
                cmdusp_Accomodation_Select.Parameters.Add("@CityID", OleDbType.BigInt).Value = oAccomodationsBD.CityID;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Accomodation_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// To Select Accomodation to bind in AccomodationGrade
        /// </summary>
        /// <param name="oAccomodationsBD"></param>
        /// <param name="gradeID"></param>
        /// <returns></returns>
        public DataTable SelectAccomodationData(clsAccomodationsBD oAccomodationsBD, Int64 gradeID)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Accomodation_Select = new OleDbCommand("usp_Accomodations_S", oCon);
                cmdusp_Accomodation_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Accomodation_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = oAccomodationsBD.CFlag;
                cmdusp_Accomodation_Select.Parameters.Add("@AccomodationID", OleDbType.BigInt).Value = oAccomodationsBD.AccomodationID;
                cmdusp_Accomodation_Select.Parameters.Add("@MasterID", OleDbType.BigInt).Value = oAccomodationsBD.MasterID;
                cmdusp_Accomodation_Select.Parameters.Add("@CityID", OleDbType.BigInt).Value = oAccomodationsBD.CityID;
                cmdusp_Accomodation_Select.Parameters.Add("@GradeId", OleDbType.BigInt).Value = gradeID;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Accomodation_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// Delete Accomodation data
        /// </summary>
        /// <param name="AccomodationId">Int64</param>
        /// <returns>bool</returns>

        public bool DeleteAccomodation(Int64 AccomodationId)
        {
            try
            {
                OleDbCommand cmdusp_TravelPolicyDelete = new OleDbCommand("usp_Accomodations_D", clsManageTransaction.objConnection);
                cmdusp_TravelPolicyDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_TravelPolicyDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_TravelPolicyDelete.Parameters.Add("@AccomodationID", OleDbType.BigInt).Value = AccomodationId;
                cmdusp_TravelPolicyDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
