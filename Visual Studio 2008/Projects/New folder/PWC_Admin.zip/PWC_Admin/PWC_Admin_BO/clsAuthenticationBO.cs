﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsAuthenticationBO
    {

        public static List<AuthenticationBD> AuthenticateUser(string LoginId, string Password)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                List<AuthenticationBD> AuthenticationList = new List<AuthenticationBD>();
                DataSet dsAuthenticateUser = new DataSet();
                OleDbCommand cmdAuthenticateUser = new OleDbCommand("usp_AuthenticateUser", oCon);
                cmdAuthenticateUser.Parameters.AddWithValue("@ALogin", LoginId);
                cmdAuthenticateUser.Parameters.AddWithValue("@APassword", Password);
                cmdAuthenticateUser.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter daAuthenticateUser = new OleDbDataAdapter(cmdAuthenticateUser);
                daAuthenticateUser.Fill(dsAuthenticateUser);
                Int64 EmployeeId = Convert.ToInt64(dsAuthenticateUser.Tables[0].Rows[0]["EmployeeId"]);
                if (EmployeeId > 0)
                {
                    foreach (DataTable dtEmpoyee in dsAuthenticateUser.Tables)
                    {
                        AuthenticationBD oAuthenticationBD = new AuthenticationBD();
                        foreach (DataRow drEmployee in dtEmpoyee.Rows)
                        {
                            if (dtEmpoyee.Columns.Count > 1)
                            {
                                oAuthenticationBD.EmployeeId = Convert.ToInt64(drEmployee["EmployeeId"]);
                                oAuthenticationBD.EmployeeCode = Convert.ToString(drEmployee["EmployeeCode"]);
                                oAuthenticationBD.FirstName = Convert.ToString(drEmployee["FirstName"]);
                                oAuthenticationBD.LastName = Convert.ToString(drEmployee["LastName"]);
                                oAuthenticationBD.Email = Convert.ToString(drEmployee["Email"]);
                                oAuthenticationBD.PersonalPhoneNo = Convert.ToString(drEmployee["PersonalPhoneNo"]);
                                oAuthenticationBD.PersonalVehicleNo = Convert.ToString(drEmployee["PersonalVehicleNo"]);
                                oAuthenticationBD.CompanyPhoneNo = Convert.ToString(drEmployee["CompanyPhoneNo"]);
                                oAuthenticationBD.CompanyVehicleNo = Convert.ToString(drEmployee["CompanyVehicleNo"]);
                                oAuthenticationBD.IsSelfApproved = Convert.ToBoolean(drEmployee["IsSelfApproved"]);
                                oAuthenticationBD.RoleId = Convert.ToInt64(drEmployee["RoleId"]);
                                oAuthenticationBD.DepartmentId = Convert.ToInt64(drEmployee["DepartmentId"]);
                                oAuthenticationBD.SessionId = 0;
                            }
                            else
                            {
                                oAuthenticationBD.SessionId = Convert.ToInt64(drEmployee["SessionId"]);
                            }
                        }
                        AuthenticationList.Add(oAuthenticationBD);
                    }
                }
                return AuthenticationList;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        } 
    }
}
