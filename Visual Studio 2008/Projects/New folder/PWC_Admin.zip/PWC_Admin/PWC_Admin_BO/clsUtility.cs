﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Mail;
using System.Collections;
using System.Net;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.Data.OleDb;
using System.IO;

namespace Admin.BO
{
    public static class clsUtility
    {
        /// <summary>
        /// Fetch all the records from Masters table based on Keyword
        /// </summary>
        ///<param name="Flag"></param>
        /// <returns>DataTable</returns>
        public static DataTable GetMasterValue(string Flag)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Master_Select = new OleDbCommand("usp_GetMasterValue_S", oCon);
                cmdusp_Master_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Master_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Master_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }

        /// <summary>
        /// Fetch all the records from Country table
        /// </summary>
        ///<param name="Flag"></param>
        /// <returns>DataTable</returns>
        public static DataTable GetCountryData(string Flag, long CountryId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Master_Select = new OleDbCommand("usp_CountryMaster_S", oCon);
                cmdusp_Master_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Master_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_Master_Select.Parameters.Add("@CountryId", OleDbType.BigInt).Value = CountryId;


                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Master_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Fetch all the records from State table
        /// </summary>
        ///<param name="Flag"></param>
        /// <returns>DataTable</returns>
        public static DataTable GetStateData(string Flag, long StateId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Master_Select = new OleDbCommand("usp_StateMaster_S", oCon);
                cmdusp_Master_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Master_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_Master_Select.Parameters.Add("@StateId", OleDbType.BigInt).Value = StateId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Master_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Fetch all the records from City table based
        /// </summary>
        ///<param name="Flag"></param>
        /// <returns>DataTable</returns>
        public static DataTable GetCityData(string Flag, long CityId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Master_Select = new OleDbCommand("usp_CityMaster_S", oCon);
                cmdusp_Master_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_Master_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_Master_Select.Parameters.Add("@CityId", OleDbType.BigInt).Value = CityId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Master_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception)
            {
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }


        /// <summary>
        /// Sending a mail.
        /// </summary>
        /// <param name="From">String</param>
        /// <param name="To">String</param>
        /// <param name="Name">String</param>
        /// <param name="Subject">String</param>
        /// <param name="Body">String</param>
        /// <param name="IsBodyHTML">Boolean</param>
        /// <param name="htDetails">Hashtable</param>
        public static void SendMail(string From, string To, string Name, string Subject, string Body, bool IsBodyHTML)
        {
            MailMessage MailObj = new MailMessage();

            try
            {
                MailObj.To.Add(To);
                //MailObj.CC.Add(GetFromWebConfig("CCMail"));
                MailObj.From = new MailAddress(GetFromWebConfig("MailFrom"));
                MailObj.IsBodyHtml = true;
                MailObj.Priority = MailPriority.High;
                MailObj.Subject = Subject;
                MailObj.IsBodyHtml = IsBodyHTML;
                MailObj.Body = Body;
                SmtpClient smtpcli = new SmtpClient();
                smtpcli.Host = GetFromWebConfig("MailHost");
                smtpcli.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpcli.Port = Convert.ToInt32(GetFromWebConfig("Port"));
                smtpcli.Credentials = new NetworkCredential(GetFromWebConfig("MailFrom"), GetFromWebConfig("MailPassword"));
                try
                {
                    smtpcli.Timeout = Convert.ToInt32(GetFromWebConfig("MailTimeOut"));
                    smtpcli.Send(MailObj);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                //throw ex;
            }
        }
        #region "GenerateMail"
        /// <summary>
        /// GenerateMail :Used to Get the template for Body for Email.
        /// </summary>
        /// <param name="BODY">string</param>
        /// <param name="path">string</param>
        /// <param name="content">string</param>
        /// 
        public static void GenerateMail(out string BODY, string path, string content)
        {
            BODY = @"<!-- saved from url=(0022)http://internet.e-mail -->
					<html xmlns:xsd='http://www.w3.org/1999/XMLSchema'>
					<head>
						
					<META http-equiv='Content-Type' content='text/html; charset=us-ascii'>
					<style type='text/css'>
					.Content1 {font: normal 10px verdana; color: #565A59; text-decoration: none;}
					.font12 {color: black; font: 12px verdana}
					.font12bold {color: black; font: bold 12px verdana}
					.font14 {color: #765EAA; font: 14px verdana}
					.font14bold {color: #765EAA; font: bold 14px verdana}
					.font11 {color: black; font: 11px verdana}
					.font11bold {color: black; font: bold 11px verdana}
					P {color: black; font: 12px verdana}
					TABLE {font: 12px verdana}
					P#PoweredBy {color: black; font: 12px verdana; margin-right: 5px}
					</style>
					</head>
					<body class='font12'>
					<table border='1' bordercolor='#EE9C00' bordercolorlight='#EE9C00' bordercolordark='#ffffff' width='90%' cellspacing='0' cellpadding='25'>
					<tr> 
					<td> 
					<table border='0' bordercolor='#dddddd' bordercolordark='#ffffff' width='99%' id='Salutation' cellpadding='0' cellspacing='0' style='FONT: 12px verdana'>
					<tr> 
					<td align='left'><a href='" + path + "'><IMG src='" + path + @"Images/qc3_small.png' border=0 ></a></td>
					</tr>
                    <tr height='10'><td></td></tr>         					
					<tr>
					<td align='left'>
					<p align='justify' class=Content1>" + content + @"</p>
					</td>
					</tr></table></td></tr></table>";
        }

        #endregion
        #region "GetFromWebConfig"
        /// <summary>
        /// GetFromWebConfig : Used to fetch value from WebConfig using Key
        /// </summary>
        /// <param name="strWebConfig">string</param>
        /// <returns>string</returns>
        public static string GetFromWebConfig(string strWebConfig)
        {
            //variable to hold our return value
            string conn = string.Empty;
            //check if a value was provided
            if (!string.IsNullOrEmpty(strWebConfig))
            {
                //name provided so search for that connection
                conn = ConfigurationManager.AppSettings[strWebConfig].ToString();
            }
            //return the value
            return conn;
        }

        #endregion

        /// <summary>
        /// DecryptConnectionString
        /// </summary>
        /// <param name="ConnectionString">string</param>
        /// <returns>string</returns>
        public static string DecryptConnectionString(string ConnectionString)
        {
            try
            {
                string strConnection = string.Empty;
                UTF8Encoding UTencode = new UTF8Encoding();
                Decoder dec = UTencode.GetDecoder();
                byte[] Bdecode = Convert.FromBase64String(ConnectionString);
                int charcount = dec.GetCharCount(Bdecode, 0, Bdecode.Length);
                char[] dechar = new char[charcount];
                dec.GetChars(Bdecode, 0, Bdecode.Length, dechar, 0);
                strConnection = new string(dechar);
                return strConnection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
