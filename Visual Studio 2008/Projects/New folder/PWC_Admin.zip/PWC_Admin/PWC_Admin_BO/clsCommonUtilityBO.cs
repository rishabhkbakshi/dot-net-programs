﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Admin.BO
{
    public class clsCommonUtilityBO
    {
        /// <summary>
        /// Gets all active organisation
        /// </summary>
        /// <returns></returns>
        public static DataTable GetOrganization()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spOrganisation_S = new OleDbCommand("usp_OrganisationStructure_S", oCon);
                cmd_spOrganisation_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spOrganisation_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = "ALL";
                cmd_spOrganisation_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = 0;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spOrganisation_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)   
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static DataTable GetOrganizationType()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spOrganisationType_S = new OleDbCommand("usp_OrganisationStructureType_S", oCon);
                cmd_spOrganisationType_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spOrganisationType_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = "ALL";
                cmd_spOrganisationType_S.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = 0;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spOrganisationType_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        public static DataTable GetOrganizationBasedOnType(Int64 OrgId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spOrganisation_S = new OleDbCommand("usp_OrganisationStructure_S", oCon);
                cmd_spOrganisation_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spOrganisation_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = "OT";
                cmd_spOrganisation_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = OrgId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spOrganisation_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
    }
}
