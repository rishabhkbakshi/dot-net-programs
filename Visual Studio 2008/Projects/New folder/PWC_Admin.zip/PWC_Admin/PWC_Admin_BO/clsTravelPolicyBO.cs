﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;

using Admin.BD;

namespace Admin.BO
{
    public class clsTravelPolicyBO
    {
        /// <summary>
        /// Fetch all the records inside the keywords
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectGradeMaster(long GradeId)
        {
            string Flag = GradeId == 0 ? "ALL" : "GRADEID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_GradeMaster_Select = new OleDbCommand("usp_Grade_S", oCon);
                cmdusp_GradeMaster_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_GradeMaster_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_GradeMaster_Select.Parameters.Add("@GradeId", OleDbType.BigInt).Value = GradeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_GradeMaster_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Insert and update data in TravelPolicy
        /// </summary>
        /// <param name="objclsTravelPolicyBD"></param>
        /// <returns>Int64</returns>
        public Int64 InsertUpdateTravelPolicy(clsTravelPolicyBD objclsTravelPolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_TravelPolicyIU = new OleDbCommand("usp_TravelPolicy_IU", clsManageTransaction.objConnection);
                cmdusp_TravelPolicyIU.Transaction = clsManageTransaction.objTran;           
                cmdusp_TravelPolicyIU.CommandType = CommandType.StoredProcedure;               
                cmdusp_TravelPolicyIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsTravelPolicyBD.CFlag;
                cmdusp_TravelPolicyIU.Parameters.Add("@TravelPolicyId", OleDbType.BigInt).Value = objclsTravelPolicyBD.TravelPolicyId;
                cmdusp_TravelPolicyIU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsTravelPolicyBD.GradeId;
                cmdusp_TravelPolicyIU.Parameters.Add("@TravelType", OleDbType.BigInt).Value = objclsTravelPolicyBD.TravelType;
                cmdusp_TravelPolicyIU.Parameters.Add("@Gender", OleDbType.VarChar).Value = objclsTravelPolicyBD.Gender;
                cmdusp_TravelPolicyIU.Parameters.Add("@DurationOfTravel", OleDbType.Numeric).Value = objclsTravelPolicyBD.DurationOfTravel;
                cmdusp_TravelPolicyIU.Parameters.Add("@Unit", OleDbType.BigInt).Value = objclsTravelPolicyBD.Unit;
                cmdusp_TravelPolicyIU.Parameters.Add("@DefaultModeOfTravel", OleDbType.VarChar).Value = objclsTravelPolicyBD.DefaultModeOfTravel;
                cmdusp_TravelPolicyIU.Parameters.Add("@DefaultClASsOfTravel", OleDbType.VarChar).Value = objclsTravelPolicyBD.DefaultClASsOfTravel;
                cmdusp_TravelPolicyIU.Parameters.Add("@AlternateModeOfTravel", OleDbType.VarChar).Value = objclsTravelPolicyBD.AlternateModeOfTravel;
                cmdusp_TravelPolicyIU.Parameters.Add("@AlternateClASsOfTravel", OleDbType.VarChar).Value = objclsTravelPolicyBD.AlternateClASsOfTravel;
                cmdusp_TravelPolicyIU.Parameters.Add("@EffectiveFROMDate", OleDbType.DBDate).Value = objclsTravelPolicyBD.EffectiveFROMDate;
                cmdusp_TravelPolicyIU.Parameters.Add("@EffectiveToDate", OleDbType.DBDate).Value = objclsTravelPolicyBD.EffectiveToDate;
                cmdusp_TravelPolicyIU.Parameters.Add("@IsBehalfOfBooking", OleDbType.Boolean).Value = objclsTravelPolicyBD.IsBehalfOfBooking;
                cmdusp_TravelPolicyIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsTravelPolicyBD.Alias;
                cmdusp_TravelPolicyIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsTravelPolicyBD.DOC;
                cmdusp_TravelPolicyIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsTravelPolicyBD.DOU;
                cmdusp_TravelPolicyIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsTravelPolicyBD.Status;
                cmdusp_TravelPolicyIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsTravelPolicyBD.TransactionId;
                //commented and modified by mahesh for applying policy on list of grade
                //cmdusp_TravelPolicyIU.ExecuteNonQuery();
                //return true;   
                int retvalue = Convert.ToInt32(cmdusp_TravelPolicyIU.ExecuteScalar());
                //return (Int64)cmdusp_TravelPolicyIU.ExecuteScalar();
                //ended
                clsManageTransaction.EndTransaction();
                return retvalue;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }            
        }
        /// <summary>
        /// Fetch all the records from TravelPolicy table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectTravelPolicyData(long TravelPolicyId)
        {
            string Flag = TravelPolicyId == 0 ? "ALL" : "TRAVELPOLICYID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_TravelPolicyData_Select = new OleDbCommand("usp_TravelPolicy_S", oCon);
                cmdusp_TravelPolicyData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_TravelPolicyData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_TravelPolicyData_Select.Parameters.Add("@TravelPolicyId", OleDbType.BigInt).Value = TravelPolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_TravelPolicyData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Method to delete TravelPolicy record from the database.
        /// </summary>
        /// <param name="TravelPolicyId">TravelPolicyId</param>
        /// <returns>bool</returns>
        public bool DeleteTravelPolicy(Int64 TravelPolicyId)
        {
            try
            {
                OleDbCommand cmdusp_TravelPolicyDelete = new OleDbCommand("usp_TravelPolicy_D", clsManageTransaction.objConnection);
                cmdusp_TravelPolicyDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_TravelPolicyDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_TravelPolicyDelete.Parameters.Add("@TravelPolicyId", OleDbType.BigInt).Value = TravelPolicyId;
                cmdusp_TravelPolicyDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
