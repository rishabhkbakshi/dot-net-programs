﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsCityGradeMasterBO
    {
        /// <summary>
        /// Insert and Update into CityGrade Master
        /// </summary>
        /// <param name="objclsCityGradeMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateCityGradeMaster(clsCityGradeMasterBD objclsCityGradeMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_CityGradeMaster_IU = new OleDbCommand("usp_CityGrade_IU", clsManageTransaction.objConnection);
                cmdusp_CityGradeMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_CityGradeMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCityGradeMasterBD.CFlag;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@CityGradeId", OleDbType.BigInt).Value = objclsCityGradeMasterBD.CityGradeId;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@CityGradeName", OleDbType.VarChar).Value = objclsCityGradeMasterBD.CityGradeName;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsCityGradeMasterBD.Alias;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsCityGradeMasterBD.DOC;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsCityGradeMasterBD.DOU;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsCityGradeMasterBD.Status;
                cmdusp_CityGradeMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsCityGradeMasterBD.TransactionId;
                return cmdusp_CityGradeMaster_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            
        }
        /// <summary>
        /// Takes the active city grade records from database
        /// </summary>
        /// <param name="objclsCityGradeMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectCityGradeMaster(clsCityGradeMasterBD objclsCityGradeMasterBD)
        {
            string ConnectionString = Convert.ToString(ConfigurationSettings.AppSettings["strConnection"]);
            ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_CityGradeMaster_S = new OleDbCommand("usp_CityGrade_S", oCon);
                cmdusp_CityGradeMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();                
                cmdusp_CityGradeMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCityGradeMasterBD.CFlag;
                cmdusp_CityGradeMaster_S.Parameters.Add("@CityGradeId", OleDbType.BigInt).Value = objclsCityGradeMasterBD.CityGradeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_CityGradeMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// Delete particular citygrade item
        /// </summary>
        /// <param name="objclsCityGradeMasterBD"></param>
        /// <returns></returns>
        public int DeleteCityGradeMaster(clsCityGradeMasterBD objclsCityGradeMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_Master_D = new OleDbCommand("usp_CityGrade_D", clsManageTransaction.objConnection);
                cmdusp_Master_D.Transaction = clsManageTransaction.objTran;
                cmdusp_Master_D.CommandType = CommandType.StoredProcedure;
                cmdusp_Master_D.Parameters.Add("@CityGradeId", OleDbType.BigInt).Value = objclsCityGradeMasterBD.CityGradeId;
                return cmdusp_Master_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }            
        }
    }//Class Close
}//NameSpace Close
