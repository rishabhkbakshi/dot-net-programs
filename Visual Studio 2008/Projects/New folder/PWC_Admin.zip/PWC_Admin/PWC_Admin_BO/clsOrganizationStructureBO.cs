﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsOrganizationStructureBO
    {
        /// <summary>
        /// To Insert and update records in Organization structure type
        /// </summary>
        /// <param name="objclsOrganizationStructureBD"></param>
        /// <returns></returns>
        public int InsertUpdateOrganizationStructureType(clsOrganizationStructureBD objclsOrganizationStructureBD)
        {
            try
            {
                OleDbCommand cmdusp_OrganizationStructureType_IU = new OleDbCommand("usp_OrganisationStructure_IU", clsManageTransaction.objConnection);
                cmdusp_OrganizationStructureType_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_OrganizationStructureType_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsOrganizationStructureBD.CFlag;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.OrganisationStructureId;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Name", OleDbType.VarChar).Value = objclsOrganizationStructureBD.Name;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.OrganisationStructureTypeId;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsOrganizationStructureBD.Alias;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsOrganizationStructureBD.DOC;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsOrganizationStructureBD.DOU;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsOrganizationStructureBD.Status;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.TransactionId;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@CostCenter", OleDbType.VarChar).Value = objclsOrganizationStructureBD.CostCenter;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@ParentId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.ParentId;
                return cmdusp_OrganizationStructureType_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active records in Organization Structure
        /// </summary>
        /// <param name="objclsOrganizationStructureBD"></param>
        /// <returns></returns>
        public DataTable SelectOrganizationStructure(clsOrganizationStructureBD objclsOrganizationStructureBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_uspOrganizationStructure_S = new OleDbCommand("usp_OrganisationStructure_S", oCon);
                cmd_uspOrganizationStructure_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_uspOrganizationStructure_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsOrganizationStructureBD.CFlag;
                cmd_uspOrganizationStructure_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.OrganisationStructureId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_uspOrganizationStructure_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(making inactive) particular organization type
        /// </summary>
        /// <param name="objclsOrganizationStructureBD"></param>
        /// <returns></returns>
        public int DeleteOrganizationStructure(clsOrganizationStructureBD objclsOrganizationStructureBD)
        {
            try
            {
                OleDbCommand cmdusp_uspOrganizationStructure_D = new OleDbCommand("usp_OrganisationStructure_D", clsManageTransaction.objConnection);
                cmdusp_uspOrganizationStructure_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspOrganizationStructure_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspOrganizationStructure_D.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsOrganizationStructureBD.OrganisationStructureId;
                return cmdusp_uspOrganizationStructure_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        public List<clsOrganizationStructureBD> GetOrganisationStructure(long ParentId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_OrganizationStructure = new OleDbCommand("usp_GetOrganisationStructure", oCon);
                cmd_OrganizationStructure.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_OrganizationStructure.Parameters.Add("@ParentId", OleDbType.BigInt).Value = ParentId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_OrganizationStructure);
                DataSet dsOrganisationStructure = new DataSet();
                objOleDbDataAdapter.Fill(dsOrganisationStructure);
                clsOrganizationStructureBD oOrganizationStructureBD;
                List<clsOrganizationStructureBD> OrganizationStructureList = new List<clsOrganizationStructureBD>();
                foreach (DataRow drOrganisationStructure in dsOrganisationStructure.Tables[0].Rows)
                {
                    oOrganizationStructureBD = new clsOrganizationStructureBD();
                    oOrganizationStructureBD.OrganisationStructureId = Convert.ToInt64(drOrganisationStructure["OrganisationStructureId"]);
                    oOrganizationStructureBD.Name = Convert.ToString(drOrganisationStructure["Name"]);
                    oOrganizationStructureBD.CostCenter = Convert.ToString(drOrganisationStructure["CostCenter"]);
                    oOrganizationStructureBD.ParentId = Convert.ToInt64(drOrganisationStructure["ParentId"]);
                    oOrganizationStructureBD.OrganisationStructureTypeId = Convert.ToInt64(drOrganisationStructure["OrganisationStructureTypeId"]);
                    oOrganizationStructureBD.OrganisationStructureTypeName = Convert.ToString(drOrganisationStructure["OrganisationStructureTypeName"]);
                    OrganizationStructureList.Add(oOrganizationStructureBD);
                }
                return OrganizationStructureList;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        public DataTable SelectLocation()
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdSelectLocation = new OleDbCommand("usp_Location_S", oCon);
                cmdSelectLocation.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdSelectLocation);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

    }//Class Close
}//NameSpace Close

