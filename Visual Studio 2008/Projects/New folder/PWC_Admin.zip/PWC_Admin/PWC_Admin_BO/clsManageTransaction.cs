﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace Admin.BO
{
    public static class clsManageTransaction
    {
        public static OleDbConnection objConnection = null;
        public static OleDbTransaction objTran = null;

        public static void StartTransaction()
        {
            try
            {
                string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
                string strCON = string.Empty;
                if (string.Compare(IsEncrypted, "No") == 0)
                {
                    strCON = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
                }
                else
                {
                    strCON = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                    strCON = clsUtility.DecryptConnectionString(strCON);
                }
                objConnection = new OleDbConnection(strCON);
                if (objConnection.State != ConnectionState.Open)
                    objConnection.Open();
                objTran = objConnection.BeginTransaction();
            }
            catch
            {
            }
        }
        public static void EndTransaction()
        {
            if (objConnection != null)
            {
                if (objConnection.State == ConnectionState.Open)
                {
                    objTran.Commit();
                    objConnection.Close();
                }
            }
        }
        public static void RollBackTransaction()
        {
            if (objConnection != null)
            {
                if (objConnection.State == ConnectionState.Open)
                {
                    objTran.Rollback();
                    objConnection.Close();
                }
            }
        }

    }
}
