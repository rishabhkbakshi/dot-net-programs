﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsRoleMasterBO
    {
        /// <summary>
        /// Use to Insert and Update roles in DB
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateRoleMaster(clsRoleMasterBD objclsRoleMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_RoleMaster_IU = new OleDbCommand("usp_Roles_IU", clsManageTransaction.objConnection);
                cmdusp_RoleMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_RoleMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_RoleMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsRoleMasterBD.CFlag;
                cmdusp_RoleMaster_IU.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsRoleMasterBD.RoleId;
                cmdusp_RoleMaster_IU.Parameters.Add("@Name", OleDbType.VarChar).Value = objclsRoleMasterBD.Name;
                cmdusp_RoleMaster_IU.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsRoleMasterBD.OrganisationStructureId;
                cmdusp_RoleMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsRoleMasterBD.Alias;
                cmdusp_RoleMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsRoleMasterBD.DOC;
                cmdusp_RoleMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsRoleMasterBD.DOU;
                cmdusp_RoleMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsRoleMasterBD.Status;
                cmdusp_RoleMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsRoleMasterBD.TransactionId;
                return cmdusp_RoleMaster_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectRoleMaster(clsRoleMasterBD objclsRoleMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spRoleMaster_S = new OleDbCommand("usp_Roles_S", oCon);
                cmd_spRoleMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spRoleMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsRoleMasterBD.CFlag;
                cmd_spRoleMaster_S.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsRoleMasterBD.RoleId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spRoleMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete particular role(making inactive)
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int DeleteRoleMaster(clsRoleMasterBD objclsRoleMasterBD)
        {
           try
            {
                OleDbCommand cmdusp_RoleMaster_D = new OleDbCommand("usp_Roles_D", clsManageTransaction.objConnection);
                cmdusp_RoleMaster_D.CommandType = CommandType.StoredProcedure;
                cmdusp_RoleMaster_D.Transaction = clsManageTransaction.objTran;
                cmdusp_RoleMaster_D.Parameters.Add("@RoleId", OleDbType.BigInt).Value = objclsRoleMasterBD.RoleId;
                return cmdusp_RoleMaster_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close

