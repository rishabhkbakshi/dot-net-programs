﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsCostCenterBO
    {
        /// <summary>
        /// Insert and update Costcenter
        /// </summary>
        /// <param name="objclsCostCenterBD"></param>
        /// <returns></returns>
        public int InsertUpdateCostCenter(clsCostCenterBD objclsCostCenterBD)
        {
            try
            {
                OleDbCommand cmdusp_CostCenter_IU = new OleDbCommand("usp_CostCenter_IU", clsManageTransaction.objConnection);
                cmdusp_CostCenter_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_CostCenter_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_CostCenter_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCostCenterBD.CFlag;
                cmdusp_CostCenter_IU.Parameters.Add("@CostCenterId", OleDbType.BigInt).Value = objclsCostCenterBD.CostCenterId;
                cmdusp_CostCenter_IU.Parameters.Add("@CostCenter", OleDbType.VarChar).Value = objclsCostCenterBD.CostCenter;
                cmdusp_CostCenter_IU.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsCostCenterBD.OrganisationStructureId;
                cmdusp_CostCenter_IU.Parameters.Add("@Description", OleDbType.VarChar).Value = objclsCostCenterBD.Description;
                cmdusp_CostCenter_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsCostCenterBD.Alias;
                cmdusp_CostCenter_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsCostCenterBD.DOC;
                cmdusp_CostCenter_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsCostCenterBD.DOU;
                cmdusp_CostCenter_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsCostCenterBD.Status;
                cmdusp_CostCenter_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsCostCenterBD.TransactionId;
                return cmdusp_CostCenter_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To fetch all active records in CostCenter
        /// </summary>
        /// <param name="objclsCostCenterBD"></param>
        /// <returns></returns>
        public DataTable SelectCostCenter(clsCostCenterBD objclsCostCenterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_CostCenter_S = new OleDbCommand("usp_CostCenter_S", oCon);
                cmd_CostCenter_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_CostCenter_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCostCenterBD.CFlag;
                cmd_CostCenter_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsCostCenterBD.CostCenterId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_CostCenter_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(Make Inactive) a particular CostCenter
        /// </summary>
        /// <param name="objclsCostCenterBD"></param>
        /// <returns></returns>
        public int DeleteCostCenter(clsCostCenterBD objclsCostCenterBD)
        {
            try
            {
                OleDbCommand cmdusp_uspCostCenter_D = new OleDbCommand("usp_CostCenter_D", clsManageTransaction.objConnection);
                cmdusp_uspCostCenter_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspCostCenter_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspCostCenter_D.Parameters.Add("@CostCenterId", OleDbType.BigInt).Value = objclsCostCenterBD.CostCenterId;
                return cmdusp_uspCostCenter_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
