﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

using Admin.BD;
namespace Admin.BO
{
    public class clsTelephonePolicyBO
    {
        /// <summary>
        /// To Insert and Update city inside CityMaster
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateTelephonePolicies(clsTelephonePolicyBD oTelephonePoliciesBD, String Flag)
        {
            try
            {
                OleDbCommand cmdTelephonePolicies_IU = new OleDbCommand("usp_TelephonePolicies_IU", clsManageTransaction.objConnection);
                cmdTelephonePolicies_IU.CommandType = CommandType.StoredProcedure;
                cmdTelephonePolicies_IU.Transaction = clsManageTransaction.objTran;
                cmdTelephonePolicies_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdTelephonePolicies_IU.Parameters.Add("@TPId", OleDbType.BigInt).Value = oTelephonePoliciesBD.TPId;
                cmdTelephonePolicies_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = oTelephonePoliciesBD.GradeId;
                cmdTelephonePolicies_IU.Parameters.Add("@Amount", OleDbType.BigInt).Value = oTelephonePoliciesBD.Amount;
                cmdTelephonePolicies_IU.Parameters.Add("@CurrencyId", OleDbType.Decimal).Value = oTelephonePoliciesBD.CurrencyId;
                cmdTelephonePolicies_IU.Parameters.Add("@Type", OleDbType.VarChar).Value = oTelephonePoliciesBD.Type;
                cmdTelephonePolicies_IU.Parameters.Add("@Alias", OleDbType.Decimal).Value = oTelephonePoliciesBD.Alias;
                cmdTelephonePolicies_IU.Parameters.Add("@DOC", OleDbType.VarChar).Value = oTelephonePoliciesBD.DOC;
                cmdTelephonePolicies_IU.Parameters.Add("@DOU", OleDbType.VarChar).Value = oTelephonePoliciesBD.DOU;
                cmdTelephonePolicies_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = oTelephonePoliciesBD.Status;
                cmdTelephonePolicies_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oTelephonePoliciesBD.TransactionId;
                return cmdTelephonePolicies_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active citys
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectTelephonePolicies(string Flag, Int64 TPId)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdTelephonePolicies_S = new OleDbCommand("usp_TelephonePolicies_S", oCon);
                cmdTelephonePolicies_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdTelephonePolicies_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdTelephonePolicies_S.Parameters.Add("@TPId", OleDbType.BigInt).Value = TPId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdTelephonePolicies_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) particular city
        /// </summary>
        /// <param name="objclsCityMasterBD"></param>
        /// <returns></returns>
        public int DeleteTelephonePolicies(Int64 TPId)
        {
            try
            {
                OleDbCommand cmdTelephonePolicies_D = new OleDbCommand("usp_TelephonePolicies_D", clsManageTransaction.objConnection);
                cmdTelephonePolicies_D.CommandType = CommandType.StoredProcedure;
                cmdTelephonePolicies_D.Transaction = clsManageTransaction.objTran;
                cmdTelephonePolicies_D.Parameters.Add("@TPId", OleDbType.BigInt).Value = TPId;
                return cmdTelephonePolicies_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
