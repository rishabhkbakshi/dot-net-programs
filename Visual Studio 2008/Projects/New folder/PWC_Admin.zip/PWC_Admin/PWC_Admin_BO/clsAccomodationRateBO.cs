﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsAccomodationRateBO
    {
        /// <summary>
        /// Insert and update data in TravelPolicy
        /// </summary>
        /// <param name="objclsTravelPolicyBD"></param>
        /// <returns></returns>
        public bool InsertUpdateAccomodationRate(clsAccomodationRateBD objclsAccomodationRateBD)
        {
            try
            {
                bool Result = false;
                OleDbCommand cmdusp_AccomodationRateIU = new OleDbCommand("usp_AccomodationRate_IU", clsManageTransaction.objConnection);
                cmdusp_AccomodationRateIU.Transaction = clsManageTransaction.objTran;
                cmdusp_AccomodationRateIU.CommandType = CommandType.StoredProcedure;
                cmdusp_AccomodationRateIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsAccomodationRateBD.CFlag;
                cmdusp_AccomodationRateIU.Parameters.Add("@AccomodationRateId", OleDbType.BigInt).Value = objclsAccomodationRateBD.AccomodationRateId;
                cmdusp_AccomodationRateIU.Parameters.Add("@CityGradeId", OleDbType.BigInt).Value = objclsAccomodationRateBD.CityGradeId;
                cmdusp_AccomodationRateIU.Parameters.Add("@Rate", OleDbType.Numeric).Value = objclsAccomodationRateBD.Rate;
                cmdusp_AccomodationRateIU.Parameters.Add("@Unit", OleDbType.BigInt).Value = objclsAccomodationRateBD.Unit;
                cmdusp_AccomodationRateIU.Parameters.Add("@Currency", OleDbType.BigInt).Value = objclsAccomodationRateBD.Currency;
                cmdusp_AccomodationRateIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsAccomodationRateBD.Alias;
                cmdusp_AccomodationRateIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsAccomodationRateBD.DOC;
                cmdusp_AccomodationRateIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsAccomodationRateBD.DOU;
                cmdusp_AccomodationRateIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsAccomodationRateBD.Status;
                cmdusp_AccomodationRateIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsAccomodationRateBD.TransactionId;
                int i = Convert.ToInt32(cmdusp_AccomodationRateIU.ExecuteNonQuery());
                Result = i == -1 ? false : true;
                return Result;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch all the records from AccomodationRate table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectAccomodationRateData(long AccomodationRateId)
        {
            string Flag = AccomodationRateId == 0 ? "ALL" : "ACCOMODATIONRATEID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_AccomodationRate_Select = new OleDbCommand("usp_AccomodationRate_S", oCon);
                cmdusp_AccomodationRate_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_AccomodationRate_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_AccomodationRate_Select.Parameters.Add("@AccomodationRateId", OleDbType.BigInt).Value = AccomodationRateId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_AccomodationRate_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                return null;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Method to delete AccomodationRate record from the database.
        /// </summary>
        /// <param name="AccomodationRateId">AccomodationRateId</param>
        /// <returns>bool</returns>
        /// 
        public bool DeleteAccomodationRate(Int64 AccomodationRateId)
        {
            try
            {
                OleDbCommand cmdusp_TravelPolicyDelete = new OleDbCommand("usp_AccomodationRate_D", clsManageTransaction.objConnection);
                cmdusp_TravelPolicyDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_TravelPolicyDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_TravelPolicyDelete.Parameters.Add("@TravelPolicyId", OleDbType.BigInt).Value = AccomodationRateId;
                cmdusp_TravelPolicyDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
