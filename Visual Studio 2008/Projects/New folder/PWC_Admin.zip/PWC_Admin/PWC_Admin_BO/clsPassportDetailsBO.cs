﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;

namespace Admin.BO
{
    public class clsPassportDetailsBO
    {
        /// <summary>
        /// Insert and update data in PassportDetails
        /// </summary>
        /// <param name="objclsPassportDetailsBD"></param>
        /// <returns></returns>
        public bool InsertUpdatePassportDetails(clsPassportDetailsBD objclsPassportDetailsBD)
        {
            try
            {
                bool Result = false;
                OleDbCommand cmdusp_PassportDetailsIU = new OleDbCommand("usp_PassportDetails_IU", clsManageTransaction.objConnection);
                cmdusp_PassportDetailsIU.Transaction = clsManageTransaction.objTran;
                cmdusp_PassportDetailsIU.CommandType = CommandType.StoredProcedure;
                cmdusp_PassportDetailsIU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsPassportDetailsBD.CFlag;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportDetailsId", OleDbType.BigInt).Value = objclsPassportDetailsBD.PassportDetailsId;
                cmdusp_PassportDetailsIU.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsPassportDetailsBD.EmployeeId;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportNo", OleDbType.VarChar).Value = objclsPassportDetailsBD.PassportNo;
                cmdusp_PassportDetailsIU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsPassportDetailsBD.CountryId;
                cmdusp_PassportDetailsIU.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsPassportDetailsBD.StateId;
                cmdusp_PassportDetailsIU.Parameters.Add("@CityId", OleDbType.BigInt).Value = objclsPassportDetailsBD.CityId;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportIssueDate", OleDbType.Date).Value = objclsPassportDetailsBD.PassportIssueDate;
                cmdusp_PassportDetailsIU.Parameters.Add("@PassportExpiryDate", OleDbType.Date).Value = objclsPassportDetailsBD.PassportExpiryDate;
                cmdusp_PassportDetailsIU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsPassportDetailsBD.Alias;
                cmdusp_PassportDetailsIU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsPassportDetailsBD.DOC;
                cmdusp_PassportDetailsIU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsPassportDetailsBD.DOU;
                cmdusp_PassportDetailsIU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsPassportDetailsBD.Status;
                cmdusp_PassportDetailsIU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsPassportDetailsBD.TransactionId;
                int i = cmdusp_PassportDetailsIU.ExecuteNonQuery();
                Result = i == -1 ? false : true;
                return Result;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// Fetch all the records from PassportDetails table
        /// </summary>
        /// <returns>DataTable</returns>
        public DataTable SelectPassportDetailsData(long PassportDetailsId)
        {
            string Flag = PassportDetailsId == 0 ? "ALL" : "PASSPORTDETAILSID";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_PassportDetailsData_Select = new OleDbCommand("usp_PassportDetails_S", oCon);
                cmdusp_PassportDetailsData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_PassportDetailsData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_PassportDetailsData_Select.Parameters.Add("@PassportDetailsId", OleDbType.BigInt).Value = PassportDetailsId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_PassportDetailsData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        public DataTable SelectPassportDetailsDataEmployeeWise(long EmployeeId)
        {
            string Flag = "EMPLOYEE";
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_PassportDetailsData_Select = new OleDbCommand("usp_PassportDetails_S", oCon);
                cmdusp_PassportDetailsData_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdusp_PassportDetailsData_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_PassportDetailsData_Select.Parameters.Add("@PassportDetailsId", OleDbType.BigInt).Value = EmployeeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_PassportDetailsData_Select);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }

        }
        /// <summary>
        /// Method to delete PassportDetails record from the database.
        /// </summary>
        /// <param name="PassportDetailsId">PassportDetailsId</param>
        /// <returns>bool</returns>
        public bool DeletePassportDetails(long PassportDetailsId)
        {
            try
            {
                OleDbCommand cmdusp_PassportDetailsDelete = new OleDbCommand("usp_PassportDetails_D", clsManageTransaction.objConnection);
                cmdusp_PassportDetailsDelete.Transaction = clsManageTransaction.objTran;
                cmdusp_PassportDetailsDelete.CommandType = CommandType.StoredProcedure;
                cmdusp_PassportDetailsDelete.Parameters.Add("@PassportDetailsId", OleDbType.BigInt).Value = PassportDetailsId;
                cmdusp_PassportDetailsDelete.ExecuteNonQuery();
                return true;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
