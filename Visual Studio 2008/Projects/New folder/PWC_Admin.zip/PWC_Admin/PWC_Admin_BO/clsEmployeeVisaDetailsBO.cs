﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsEmployeeVisaDetailsBO
    {
        /// <summary>
        /// To Insert & Update  EmployeeVisaDetails 
        /// </summary>
        /// <param name="objclsEmployeeVisaDetailsBD"></param>
        /// <returns></returns>
        public int InsertUpdateEmployeeVisaDetails(clsEmployeeVisaDetailsBD objclsEmployeeVisaDetailsBD)
        {
            try
            {
                OleDbCommand cmdusp_EmployeeVisaDetails_IU = new OleDbCommand("usp_EmployeeVisaDetails_IU", clsManageTransaction.objConnection);
                cmdusp_EmployeeVisaDetails_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_EmployeeVisaDetails_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.CFlag;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@VisaId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.VisaId;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@VisaNo", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.VisaNo;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.EmployeeId;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@PassportNo", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.PassportNo;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@VisaType", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.VisaType;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.CountryId;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@FromDate", OleDbType.DBDate).Value = objclsEmployeeVisaDetailsBD.FromDate;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@ToDate", OleDbType.DBDate).Value = objclsEmployeeVisaDetailsBD.ToDate;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.Alias;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@DOC", OleDbType.Date).Value = objclsEmployeeVisaDetailsBD.DOC;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@DOU", OleDbType.Date).Value = objclsEmployeeVisaDetailsBD.DOU;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.Status;
                cmdusp_EmployeeVisaDetails_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.TransactionId;
                return cmdusp_EmployeeVisaDetails_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active records of  EmployeeVisaDetails
        /// </summary>
        /// <param name="objclsEmployeeVisaDetailsBD"></param>
        /// <returns></returns>
        public DataTable SelectEmployeeVisaDetails(clsEmployeeVisaDetailsBD objclsEmployeeVisaDetailsBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_EmployeeVisaDetails_S = new OleDbCommand("usp_EmployeeVisaDetails_S", oCon);
                cmd_EmployeeVisaDetails_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_EmployeeVisaDetails_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsEmployeeVisaDetailsBD.CFlag;
                cmd_EmployeeVisaDetails_S.Parameters.Add("@VisaId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.VisaId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_EmployeeVisaDetails_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Delete(make inactive) particular EmployeeVisaDetails
        /// </summary>
        /// <param name="objclsEmployeeVisaDetailsBD"></param>
        /// <returns></returns>
        public int DeleteEmployeeVisaDetails(clsEmployeeVisaDetailsBD objclsEmployeeVisaDetailsBD)
        {
            try
            {
                OleDbCommand cmdusp_uspEmployeeVisaDetails_D = new OleDbCommand("usp_EmployeeVisaDetails_D", clsManageTransaction.objConnection);
                cmdusp_uspEmployeeVisaDetails_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspEmployeeVisaDetails_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspEmployeeVisaDetails_D.Parameters.Add("@VisaId", OleDbType.BigInt).Value = objclsEmployeeVisaDetailsBD.VisaId;
                return cmdusp_uspEmployeeVisaDetails_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }

        /// <summary>
        /// GetPassportNumber
        /// </summary>
        /// <param name="EmployeeId">long</param>
        /// <returns>string</returns>
        public static string GetPassportNumber(long EmployeeId)
        {
            try
            {
                string PassportNumber = string.Empty;
                string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
                string ConnectionString = string.Empty;
                if (string.Compare(IsEncrypted, "No") == 0)
                {
                    ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
                }
                else
                {
                    ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                    ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
                }
                OleDbConnection oCon = new OleDbConnection(ConnectionString);
                OleDbCommand cmd_EmployeeVisaDetails_S = new OleDbCommand("usp_EmployeePassportNumberForVisa_S", oCon);
                cmd_EmployeeVisaDetails_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_EmployeeVisaDetails_S.Parameters.Add("@EmployeeId", OleDbType.BigInt).Value = EmployeeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_EmployeeVisaDetails_S);
                DataTable objDataTable = new DataTable();
                objOleDbDataAdapter.Fill(objDataTable);
                if (objDataTable.Rows.Count > 0)
                {
                    PassportNumber = Convert.ToString(objDataTable.Rows[0]["PassportNo"]);
                }
                return PassportNumber;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
