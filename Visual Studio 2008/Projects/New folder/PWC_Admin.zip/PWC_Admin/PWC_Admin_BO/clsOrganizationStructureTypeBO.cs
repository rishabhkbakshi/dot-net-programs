﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;
namespace Admin.BO
{
    public class clsOrganizationStructureTypeBO
    {
        /// <summary>
        /// Insert And Update particular organization structure type
        /// </summary>
        /// <param name="objclsOrganizationStructureTypeBD"></param>
        /// <returns></returns>
        public int InsertUpdateOrganizationStructureType(clsOrganizationStructureTypeBD objclsOrganizationStructureTypeBD)
        {
            try
            {
                OleDbCommand cmdusp_OrganizationStructureType_IU = new OleDbCommand("usp_OrganisationStructureType_IU", clsManageTransaction.objConnection);
                cmdusp_OrganizationStructureType_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_OrganizationStructureType_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.CFlag;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = objclsOrganizationStructureTypeBD.OrganisationStructureTypeId;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Name", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.Name;                
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.Alias;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsOrganizationStructureTypeBD.DOC;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsOrganizationStructureTypeBD.DOU;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.Status;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsOrganizationStructureTypeBD.TransactionId;
                cmdusp_OrganizationStructureType_IU.Parameters.Add("@Level", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.Level;
                return cmdusp_OrganizationStructureType_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all active organization structure type
        /// </summary>
        /// <param name="objclsOrganizationStructureTypeBD"></param>
        /// <returns></returns>
        public DataTable SelectOrganizationStructureType(clsOrganizationStructureTypeBD objclsOrganizationStructureTypeBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_uspOrganizationStructureType_S = new OleDbCommand("usp_OrganisationStructureType_S", oCon);
                cmd_uspOrganizationStructureType_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_uspOrganizationStructureType_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsOrganizationStructureTypeBD.CFlag;
                cmd_uspOrganizationStructureType_S.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = objclsOrganizationStructureTypeBD.OrganisationStructureTypeId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_uspOrganizationStructureType_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To Make inactive particular Organization type
        /// </summary>
        /// <param name="objclsOrganizationStructureTypeBD"></param>
        /// <returns></returns>
        public int DeleteOrganizationStructureType(clsOrganizationStructureTypeBD objclsOrganizationStructureTypeBD)
        {            
            try
            {
                OleDbCommand cmdusp_uspOrganizationStructureType_D = new OleDbCommand("usp_OrganisationStructureType_D", clsManageTransaction.objConnection);
                cmdusp_uspOrganizationStructureType_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspOrganizationStructureType_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspOrganizationStructureType_D.Parameters.Add("@OrganisationStructureTypeId", OleDbType.BigInt).Value = objclsOrganizationStructureTypeBD.OrganisationStructureTypeId;
                return cmdusp_uspOrganizationStructureType_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
