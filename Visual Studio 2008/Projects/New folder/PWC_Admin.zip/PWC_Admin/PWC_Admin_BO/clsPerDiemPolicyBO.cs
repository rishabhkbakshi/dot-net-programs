﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;


namespace Admin.BO
{
    public class clsPerDiemPolicyBO
    {
        public Int64 InsertUpdatePerDiemPolicy(clsPerDiemPolicyBD objclsPerDiemPolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_PerDiemPolicy_IU = new OleDbCommand("usp_PerDiemPolicy_IU", clsManageTransaction.objConnection);
                cmdusp_PerDiemPolicy_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_PerDiemPolicy_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.CFlag;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@PerDiemPolicyId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.PerDiemPolicyId;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@TravelType", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.TravelType;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@GradeId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.GradeId;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Specific", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.Specific;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Amount", OleDbType.Numeric).Value = objclsPerDiemPolicyBD.Amount;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Currency", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.Currency;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@IsEquivalent", OleDbType.Boolean).Value = objclsPerDiemPolicyBD.IsEquivalent;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@EffectiveFrom", OleDbType.DBDate).Value = objclsPerDiemPolicyBD.EffectiveFrom;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@EffectiveTo", OleDbType.DBDate).Value = objclsPerDiemPolicyBD.EffectiveTo;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.Alias;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsPerDiemPolicyBD.DOC;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsPerDiemPolicyBD.DOU;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.Status;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.TransactionId;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@ForValue", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.ForValue;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@ForUnit", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.ForUnit;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@Allowance", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.Allowance;
                cmdusp_PerDiemPolicy_IU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.CountryId;
                //commented and modified by mahesh for applying policy on list of policy
                //return cmdusp_PerDiemPolicy_IU.ExecuteNonQuery();
                return  Convert.ToInt64(cmdusp_PerDiemPolicy_IU.ExecuteScalar());
                //ended
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        public DataTable SelectPerDiemPolicy(clsPerDiemPolicyBD objclsPerDiemPolicyBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_PerDiemPolicy_S = new OleDbCommand("usp_PerDiemPolicy_S", oCon);
                cmd_PerDiemPolicy_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_PerDiemPolicy_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsPerDiemPolicyBD.CFlag;
                cmd_PerDiemPolicy_S.Parameters.Add("@OrganisationStructureId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.PerDiemPolicyId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_PerDiemPolicy_S);
                DataSet objDataSet = new DataSet();
                objDataSet.Clear();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        public int DeletePerDiemPolicy(clsPerDiemPolicyBD objclsPerDiemPolicyBD)
        {
            try
            {
                OleDbCommand cmdusp_uspPerDiemPolicy_D = new OleDbCommand("usp_PerDiemPolicy_D", clsManageTransaction.objConnection);
                cmdusp_uspPerDiemPolicy_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspPerDiemPolicy_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspPerDiemPolicy_D.Parameters.Add("@PerDiemPolicyId", OleDbType.BigInt).Value = objclsPerDiemPolicyBD.PerDiemPolicyId;
                return cmdusp_uspPerDiemPolicy_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
