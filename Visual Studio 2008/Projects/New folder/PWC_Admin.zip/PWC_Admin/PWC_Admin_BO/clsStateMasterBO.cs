﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;


namespace Admin.BO
{
    public class clsStateMasterBO
    {
        /// <summary>
        /// To Insert and Update State inside StateMaster
        /// </summary>
        /// <param name="objclsStateMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateStateMaster(clsStateMasterBD objclsStateMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_StateMaster_IU = new OleDbCommand("usp_StateMaster_IU", clsManageTransaction.objConnection);
                cmdusp_StateMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_StateMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_StateMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsStateMasterBD.CFlag;
                cmdusp_StateMaster_IU.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsStateMasterBD.StateId;
                cmdusp_StateMaster_IU.Parameters.Add("@StateName", OleDbType.VarChar).Value = objclsStateMasterBD.StateName;
                cmdusp_StateMaster_IU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsStateMasterBD.CountryId;
                cmdusp_StateMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsStateMasterBD.Alias;
                cmdusp_StateMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsStateMasterBD.DOC;
                cmdusp_StateMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsStateMasterBD.DOU;
                cmdusp_StateMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsStateMasterBD.Status;
                cmdusp_StateMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsStateMasterBD.TransactionId;
                int i = Convert.ToInt32(cmdusp_StateMaster_IU.ExecuteScalar());
                return i;
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active State
        /// </summary>
        /// <param name="objclsStateMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectStateMaster(clsStateMasterBD objclsStateMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spStateMaster_S = new OleDbCommand("usp_StateMaster_S", oCon);
                cmd_spStateMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spStateMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsStateMasterBD.CFlag;
                cmd_spStateMaster_S.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsStateMasterBD.StateId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spStateMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) particular State
        /// </summary>
        /// <param name="objclsStateMasterBD"></param>
        /// <returns></returns>
        public int DeleteStateMaster(clsStateMasterBD objclsStateMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_StateMaster_D = new OleDbCommand("usp_StateMaster_D", clsManageTransaction.objConnection);
                cmdusp_StateMaster_D.CommandType = CommandType.StoredProcedure;
                cmdusp_StateMaster_D.Transaction = clsManageTransaction.objTran;
                cmdusp_StateMaster_D.Parameters.Add("@StateId", OleDbType.BigInt).Value = objclsStateMasterBD.StateId;
                return cmdusp_StateMaster_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close

