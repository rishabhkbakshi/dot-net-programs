﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Admin.BO
{
    public class clsCountryMasterBO
    {
        /// <summary>
        /// To Insert and Update Country inside CountryMaster
        /// </summary>
        /// <param name="objclsCountryMasterBD"></param>
        /// <returns></returns>
        public int InsertUpdateCountryMaster(clsCountryMasterBD objclsCountryMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_CountryMaster_IU = new OleDbCommand("usp_CountryMaster_IU", clsManageTransaction.objConnection);
                cmdusp_CountryMaster_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_CountryMaster_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_CountryMaster_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCountryMasterBD.CFlag;
                cmdusp_CountryMaster_IU.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsCountryMasterBD.CountryId;
                cmdusp_CountryMaster_IU.Parameters.Add("@CountryName", OleDbType.VarChar).Value = objclsCountryMasterBD.CountryName;
                cmdusp_CountryMaster_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsCountryMasterBD.Alias;
                cmdusp_CountryMaster_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsCountryMasterBD.DOC;
                cmdusp_CountryMaster_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsCountryMasterBD.DOU;
                cmdusp_CountryMaster_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsCountryMasterBD.Status;
                cmdusp_CountryMaster_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsCountryMasterBD.TransactionId;
                return cmdusp_CountryMaster_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        ///  To Fetch all the active Countrys
        /// </summary>
        /// <param name="objclsCountryMasterBD"></param>
        /// <returns></returns>
        public DataTable SelectCountryMaster(clsCountryMasterBD objclsCountryMasterBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_spCountryMaster_S = new OleDbCommand("usp_CountryMaster_S", oCon);
                cmd_spCountryMaster_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_spCountryMaster_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsCountryMasterBD.CFlag;
                cmd_spCountryMaster_S.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsCountryMasterBD.CountryId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_spCountryMaster_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) particular Country
        /// </summary>
        /// <param name="objclsCountryMasterBD"></param>
        /// <returns></returns>
        public int DeleteCountryMaster(clsCountryMasterBD objclsCountryMasterBD)
        {
            try
            {
                OleDbCommand cmdusp_CountryMaster_D = new OleDbCommand("usp_CountryMaster_D", clsManageTransaction.objConnection);
                cmdusp_CountryMaster_D.CommandType = CommandType.StoredProcedure;
                cmdusp_CountryMaster_D.Transaction = clsManageTransaction.objTran;
                cmdusp_CountryMaster_D.Parameters.Add("@CountryId", OleDbType.BigInt).Value = objclsCountryMasterBD.CountryId;
                return cmdusp_CountryMaster_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
