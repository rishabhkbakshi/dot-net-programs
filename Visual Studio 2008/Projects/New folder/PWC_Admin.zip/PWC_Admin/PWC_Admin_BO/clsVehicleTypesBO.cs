﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Admin.BD;
using System.Data.OleDb;
using System.Configuration;
using System.Data;


namespace Admin.BO
{
    public class clsVehicleTypesBO
    {
        /// <summary>
        /// To insert and update Vehicletypes
        /// </summary>
        /// <param name="objclsVehicleTypesBD"></param>
        /// <returns></returns>
        public int InsertUpdateVehicleTypes(clsVehicleTypesBD objclsVehicleTypesBD)
        {
            try
            {
                OleDbCommand cmdusp_VehicleTypes_IU = new OleDbCommand("usp_VehicleTypes_IU", clsManageTransaction.objConnection);
                cmdusp_VehicleTypes_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_VehicleTypes_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_VehicleTypes_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVehicleTypesBD.CFlag;
                cmdusp_VehicleTypes_IU.Parameters.Add("@VehicleTypesId", OleDbType.BigInt).Value = objclsVehicleTypesBD.VehicleTypesId;
                cmdusp_VehicleTypes_IU.Parameters.Add("@ClassOfVehicle", OleDbType.BigInt).Value = objclsVehicleTypesBD.ClassOfVehicle;
                cmdusp_VehicleTypes_IU.Parameters.Add("@TypeOfBody", OleDbType.BigInt).Value = objclsVehicleTypesBD.TypeOfBody;
                cmdusp_VehicleTypes_IU.Parameters.Add("@CC", OleDbType.VarChar).Value = objclsVehicleTypesBD.CC;
                cmdusp_VehicleTypes_IU.Parameters.Add("@ApprovedRate", OleDbType.Numeric).Value = objclsVehicleTypesBD.ApprovedRate;
                cmdusp_VehicleTypes_IU.Parameters.Add("@FromDate", OleDbType.DBDate).Value = objclsVehicleTypesBD.FromDate;
                cmdusp_VehicleTypes_IU.Parameters.Add("@ToDate", OleDbType.DBDate).Value = objclsVehicleTypesBD.ToDate;
                cmdusp_VehicleTypes_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsVehicleTypesBD.Alias;
                cmdusp_VehicleTypes_IU.Parameters.Add("@DOC", OleDbType.DBDate).Value = objclsVehicleTypesBD.DOC;
                cmdusp_VehicleTypes_IU.Parameters.Add("@DOU", OleDbType.DBDate).Value = objclsVehicleTypesBD.DOU;
                cmdusp_VehicleTypes_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsVehicleTypesBD.Status;
                cmdusp_VehicleTypes_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsVehicleTypesBD.TransactionId;
                return cmdusp_VehicleTypes_IU.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// To Fetch all the active Vehicletypes
        /// </summary>
        /// <param name="objclsVehicleTypesBD"></param>
        /// <returns></returns>
        public DataTable SelectVehicleTypes(clsVehicleTypesBD objclsVehicleTypesBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmd_VehicleTypes_S = new OleDbCommand("usp_VehicleTypes_S", oCon);
                cmd_VehicleTypes_S.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmd_VehicleTypes_S.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsVehicleTypesBD.CFlag;
                cmd_VehicleTypes_S.Parameters.Add("@VehicleTypesId", OleDbType.BigInt).Value = objclsVehicleTypesBD.VehicleTypesId;
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmd_VehicleTypes_S);
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// To delete(make inactive) a particular  Vehicletypes
        /// </summary>
        /// <param name="objclsVehicleTypesBD"></param>
        /// <returns></returns>
        public int DeleteVehicleTypes(clsVehicleTypesBD objclsVehicleTypesBD)
        {
            try
            {
                OleDbCommand cmdusp_uspVehicleTypes_D = new OleDbCommand("usp_VehicleTypes_D", clsManageTransaction.objConnection);
                cmdusp_uspVehicleTypes_D.CommandType = CommandType.StoredProcedure;
                cmdusp_uspVehicleTypes_D.Transaction = clsManageTransaction.objTran;
                cmdusp_uspVehicleTypes_D.Parameters.Add("@VehicleTypesId", OleDbType.BigInt).Value = objclsVehicleTypesBD.VehicleTypesId;
                return cmdusp_uspVehicleTypes_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }
}
