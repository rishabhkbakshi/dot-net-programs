﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using Admin.BD;
using System.Configuration;

namespace Admin.BO
{
    public class clsApprovalEscalationDetailsBO
    {
        /// <summary>
        /// Use to Insert and Update roles in DB
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public Int64 InsertUpdate(clsApprovalEscalationDetailsBD oApprovalEscalationDetailsBD)
        {
            try
            {
                OleDbCommand cmdApprovalEscalationDetails = new OleDbCommand("usp_ApprovalEscalationDetails_IU", clsManageTransaction.objConnection);
                cmdApprovalEscalationDetails.CommandType = CommandType.StoredProcedure;
                cmdApprovalEscalationDetails.Transaction = clsManageTransaction.objTran;
                cmdApprovalEscalationDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalEscalationDetailsBD.Flag;
                cmdApprovalEscalationDetails.Parameters.Add("@ApprovalEscalationDetailId", OleDbType.BigInt).Value = oApprovalEscalationDetailsBD.ApprovalEscalationDetailId;
                cmdApprovalEscalationDetails.Parameters.Add("@ApprovalDetailId", OleDbType.BigInt).Value = oApprovalEscalationDetailsBD.ApprovalDetailId;
                cmdApprovalEscalationDetails.Parameters.Add("@RoleId", OleDbType.BigInt).Value = oApprovalEscalationDetailsBD.RoleId;
                cmdApprovalEscalationDetails.Parameters.Add("@Sequence", OleDbType.Integer).Value = oApprovalEscalationDetailsBD.Sequence;
                cmdApprovalEscalationDetails.Parameters.Add("@Alias", OleDbType.VarChar).Value = oApprovalEscalationDetailsBD.Alias;
                cmdApprovalEscalationDetails.Parameters.Add("@DOC", OleDbType.Date).Value = oApprovalEscalationDetailsBD.DOC;
                cmdApprovalEscalationDetails.Parameters.Add("@DOU", OleDbType.Date).Value = oApprovalEscalationDetailsBD.DOU;
                cmdApprovalEscalationDetails.Parameters.Add("@Status", OleDbType.VarChar).Value = oApprovalEscalationDetailsBD.Status;
                cmdApprovalEscalationDetails.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = oApprovalEscalationDetailsBD.TransactionId;
                return Convert.ToInt64(cmdApprovalEscalationDetails.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// To Fetch  All Active Roles
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public DataTable Select(clsApprovalEscalationDetailsBD oApprovalEscalationDetailsBD)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdApprovalEscalationDetails = new OleDbCommand("usp_ApprovalEscalationDetails_S", oCon);
                cmdApprovalEscalationDetails.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                cmdApprovalEscalationDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = oApprovalEscalationDetailsBD.Flag;
                cmdApprovalEscalationDetails.Parameters.Add("@ApprovalEscalationDetailId", OleDbType.BigInt).Value = oApprovalEscalationDetailsBD.ApprovalEscalationDetailId;
                OleDbDataAdapter daApprovalEscalationDetails = new OleDbDataAdapter(cmdApprovalEscalationDetails);
                DataSet dsApprovalEscalationDetails = new DataSet();
                daApprovalEscalationDetails.Fill(dsApprovalEscalationDetails);
                return dsApprovalEscalationDetails.Tables[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }

        /// <summary>
        /// To delete particular role(making inactive)
        /// </summary>
        /// <param name="objclsRoleMasterBD"></param>
        /// <returns></returns>
        public int Delete(string Flag, Int64 Id)
        {
            try
            {
                OleDbCommand cmdApprovalEscalationDetails = new OleDbCommand("usp_ApprovalEscalationDetails_D", clsManageTransaction.objConnection);
                cmdApprovalEscalationDetails.CommandType = CommandType.StoredProcedure;
                cmdApprovalEscalationDetails.Transaction = clsManageTransaction.objTran;
                cmdApprovalEscalationDetails.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdApprovalEscalationDetails.Parameters.Add("@ApprovalEscalationDetailId", OleDbType.BigInt).Value = Id;
                return cmdApprovalEscalationDetails.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
