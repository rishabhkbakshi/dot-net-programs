﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Data;
using System.Configuration;
using Admin.BD;


namespace Admin.BO
{
    public class clsMastersBO
    {
        /// <summary>
        /// Insert & Update into Masters
        /// </summary>
        /// <param name="objclsMastersBD"></param>
        /// <returns></returns>
        public int InsertUpdateMasters(clsMastersBD objclsMastersBD)
        {
            try
            {
                OleDbCommand cmdusp_Master_IU = new OleDbCommand("usp_Masters_IU", clsManageTransaction.objConnection);
                cmdusp_Master_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_Master_IU.Transaction = clsManageTransaction.objTran;
                cmdusp_Master_IU.CommandType = CommandType.StoredProcedure;
                cmdusp_Master_IU.Parameters.Add("@Flag", OleDbType.VarChar).Value = objclsMastersBD.CFlag;
                cmdusp_Master_IU.Parameters.Add("@Value", OleDbType.VarChar).Value = objclsMastersBD.Value;
                cmdusp_Master_IU.Parameters.Add("@KeywordId", OleDbType.BigInt).Value = objclsMastersBD.KeywordId;
                cmdusp_Master_IU.Parameters.Add("@Alias", OleDbType.VarChar).Value = objclsMastersBD.Alias;
                cmdusp_Master_IU.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsMastersBD.Status;
                cmdusp_Master_IU.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsMastersBD.TransactionId;
                cmdusp_Master_IU.Parameters.Add("@MasterId", OleDbType.BigInt).Value = objclsMastersBD.MasterId;
                cmdusp_Master_IU.Parameters.Add("@Key1", OleDbType.VarChar).Value = objclsMastersBD.Key1;
                cmdusp_Master_IU.Parameters.Add("@Key2", OleDbType.VarChar).Value = objclsMastersBD.Key2;
                cmdusp_Master_IU.Parameters.Add("@Key3", OleDbType.VarChar).Value = objclsMastersBD.Key3;
                cmdusp_Master_IU.Parameters.Add("@Key4", OleDbType.VarChar).Value = objclsMastersBD.Key4;
                cmdusp_Master_IU.Parameters.Add("@Key5", OleDbType.VarChar).Value = objclsMastersBD.Key5;
                return cmdusp_Master_IU.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
        /// <summary>
        /// Fetch Active Master datas from database
        /// </summary>
        /// <returns></returns>
        public DataTable SelectMasters(string Flag, Int64 Id)
        {
            string IsEncrypted = System.Configuration.ConfigurationSettings.AppSettings["IsEncrypted"].ToString();
            string ConnectionString = string.Empty;
            if (string.Compare(IsEncrypted, "No") == 0)
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnectionWithout"].ToString();
            }
            else
            {
                ConnectionString = System.Configuration.ConfigurationSettings.AppSettings["strConnection"].ToString();
                ConnectionString = clsUtility.DecryptConnectionString(ConnectionString);
            }
            OleDbConnection oCon = new OleDbConnection(ConnectionString);
            try
            {
                OleDbCommand cmdusp_Master_Select = new OleDbCommand("usp_Masters_Select", oCon);
                cmdusp_Master_Select.CommandType = CommandType.StoredProcedure;
                oCon.Open();
                OleDbDataAdapter objOleDbDataAdapter = new OleDbDataAdapter(cmdusp_Master_Select);
                cmdusp_Master_Select.Parameters.Add("@Flag", OleDbType.VarChar).Value = Flag;
                cmdusp_Master_Select.Parameters.Add("@KeywordId", OleDbType.BigInt).Value = Id;
                DataSet objDataSet = new DataSet();
                objOleDbDataAdapter.Fill(objDataSet);
                return objDataSet.Tables[0];
            }
            catch (Exception ex)
            {

                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
            finally
            {
                oCon.Close();
                oCon.Dispose();
            }
        }
        /// <summary>
        /// Delete the master data
        /// </summary>
        /// <param name="objclsMastersBD"></param>
        /// <returns></returns>
        public int DeleteMasters(clsMastersBD objclsMastersBD)
        {
            try
            {
                OleDbCommand cmdusp_Master_D = new OleDbCommand("usp_Masters_Delete", clsManageTransaction.objConnection);
                cmdusp_Master_D.CommandType = CommandType.StoredProcedure;
                cmdusp_Master_D.Transaction = clsManageTransaction.objTran;
                cmdusp_Master_D.Parameters.Add("@Status", OleDbType.VarChar).Value = objclsMastersBD.Status;
                cmdusp_Master_D.Parameters.Add("@TransactionId", OleDbType.BigInt).Value = objclsMastersBD.TransactionId;
                cmdusp_Master_D.Parameters.Add("@MasterId", OleDbType.BigInt).Value = objclsMastersBD.MasterId;
                return cmdusp_Master_D.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                clsManageTransaction.RollBackTransaction();
                clsErrorLogBO.WriteErrorLog_Text(ex);
                throw ex;
            }
        }
    }//Class Close
}//NameSpace Close
